package com.palmergames.bukkit.util;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.utils.CombatUtil;
import java.util.function.Consumer;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class DrawSmokeTaskFactory {
   public static Consumer<Location> showToPlayer(@NotNull Player player) {
      return showToPlayer(player, WorldCoord.parseWorldCoord((Entity)player));
   }

   public static Consumer<Location> showToPlayer(@NotNull Player player, @NotNull WorldCoord worldCoord) {
      Resident resident = TownyAPI.getInstance().getResident(player);
      return showToPlayer(player, resident == null ? Color.GRAY : getAffiliationColor(resident, worldCoord));
   }

   public static Consumer<Location> showToPlayer(@NotNull Player player, @NotNull Color particleColor) {
      DustOptions dustOptions = new DustOptions(particleColor, 2.0F);
      return (location) -> {
         player.spawnParticle(Particle.REDSTONE, location.add(0.5D, 1.5D, 0.5D), 5, dustOptions);
      };
   }

   public static Color getAffiliationColor(Resident resident, WorldCoord coord) {
      Town residentTown = resident.getTownOrNull();
      Town town = coord.getTownOrNull();
      if (residentTown != null && town != null) {
         if (CombatUtil.isAlly(residentTown, town)) {
            return Color.GREEN;
         } else {
            return CombatUtil.isEnemy(residentTown, town) ? Color.RED : Color.GRAY;
         }
      } else {
         return Color.GRAY;
      }
   }
}
