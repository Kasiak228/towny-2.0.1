package com.palmergames.bukkit.util;

public class Compass {
   public static Compass.Point getCompassPointForDirection(double inDegrees) {
      double degrees = (inDegrees - 90.0D) % 360.0D;
      if (degrees < 0.0D) {
         degrees += 360.0D;
      }

      if (0.0D <= degrees && degrees < 22.5D) {
         return Compass.Point.W;
      } else if (22.5D <= degrees && degrees < 67.5D) {
         return Compass.Point.NW;
      } else if (67.5D <= degrees && degrees < 112.5D) {
         return Compass.Point.N;
      } else if (112.5D <= degrees && degrees < 157.5D) {
         return Compass.Point.NE;
      } else if (157.5D <= degrees && degrees < 202.5D) {
         return Compass.Point.E;
      } else if (202.5D <= degrees && degrees < 247.5D) {
         return Compass.Point.SE;
      } else if (247.5D <= degrees && degrees < 292.5D) {
         return Compass.Point.S;
      } else if (292.5D <= degrees && degrees < 337.5D) {
         return Compass.Point.SW;
      } else {
         return 337.5D <= degrees && degrees < 360.0D ? Compass.Point.W : null;
      }
   }

   public static enum Point {
      N,
      NE,
      E,
      SE,
      S,
      SW,
      W,
      NW;

      // $FF: synthetic method
      private static Compass.Point[] $values() {
         return new Compass.Point[]{N, NE, E, SE, S, SW, W, NW};
      }
   }
}
