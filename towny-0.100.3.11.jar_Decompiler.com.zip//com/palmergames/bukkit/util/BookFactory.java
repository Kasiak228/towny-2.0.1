package com.palmergames.bukkit.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

public class BookFactory {
   private static final float MAX_LINE_WIDTH = FontUtil.measureWidth("LLLLLLLLLLLLLLLLLLL");

   public static ItemStack makeBook(String title, String author, String rawText) {
      ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
      BookMeta meta = (BookMeta)book.getItemMeta();
      meta.setTitle(title);
      meta.setAuthor(author);
      List<String> pages = getPages(rawText);
      Iterator var6 = pages.iterator();

      while(var6.hasNext()) {
         String page = (String)var6.next();
         meta.addPage(new String[]{page});
      }

      book.setItemMeta(meta);
      return book;
   }

   public static ItemStack makeBook(String title, String author, List<String> pages) {
      ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
      BookMeta meta = (BookMeta)book.getItemMeta();
      meta.setTitle(title);
      meta.setAuthor(author);
      Iterator var5 = pages.iterator();

      while(var5.hasNext()) {
         String page = (String)var5.next();
         meta.addPage(new String[]{page});
      }

      book.setItemMeta(meta);
      return book;
   }

   private static List<String> getLines(String rawText) {
      ArrayList lines = new ArrayList();

      try {
         String[] var2 = rawText.split("\n");
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            String section = var2[var4];
            if (section.equals("")) {
               lines.add("\n");
            } else {
               String[] words = Colors.strip(section).split(" ");
               String line = "";

               for(int index = 0; index < words.length; ++index) {
                  String word = words[index];
                  if (line.isEmpty()) {
                     line = word;
                  } else if (FontUtil.measureWidth(line + " " + word) > MAX_LINE_WIDTH) {
                     lines.add(line + "\n");
                     line = word;
                  } else {
                     line = line + " " + word;
                  }
               }

               if (!line.equals("")) {
                  lines.add(line + "\n");
               }
            }
         }
      } catch (IllegalArgumentException var10) {
         lines.clear();
      }

      return lines;
   }

   private static List<String> getPages(String rawText) {
      rawText = "\n" + rawText;
      List<String> pages = new ArrayList();
      List<String> lines = getLines(rawText);
      String pageText = "";

      for(int i = 1; i < lines.size(); ++i) {
         pageText = pageText + (String)lines.get(i);
         if (i != 1 && i % 14 == 0) {
            pages.add(pageText);
            pageText = "";
         }
      }

      if (!pageText.isEmpty()) {
         pages.add(pageText);
      }

      return pages;
   }
}
