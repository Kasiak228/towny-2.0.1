package com.palmergames.bukkit.util;

import com.palmergames.adventure.text.format.NamedTextColor;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.utils.TownyComponents;
import com.palmergames.util.StringMgmt;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.ChatColor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class Colors {
   private static final Map<String, String> LEGACY_LOOKUP = new HashMap();
   private static final Pattern LEGACY_PATTERN = Pattern.compile("[§&][0-9a-fk-or]");
   public static final String Black = "§0";
   public static final String Navy = "§1";
   public static final String Green = "§2";
   public static final String Blue = "§3";
   public static final String Red = "§4";
   public static final String Purple = "§5";
   public static final String Gold = "§6";
   public static final String LightGray = "§7";
   public static final String Gray = "§8";
   public static final String DarkPurple = "§9";
   public static final String LightGreen = "§a";
   public static final String LightBlue = "§b";
   public static final String Rose = "§c";
   public static final String LightPurple = "§d";
   public static final String Yellow = "§e";
   public static final String White = "§f";
   public static final String DARK_RED = "<dark_red>";
   public static final String RED = "<red>";
   public static final String GOLD = "<gold>";
   public static final String YELLOW = "<yellow>";
   public static final String DARK_GREEN = "<dark_green>";
   public static final String GREEN = "<green>";
   public static final String DARK_AQUA = "<dark_aqua>";
   public static final String AQUA = "<aqua>";
   public static final String DARK_BLUE = "<dark_blue>";
   public static final String BLUE = "<blue>";
   public static final String LIGHT_PURPLE = "<light_purple>";
   public static final String DARK_PURPLE = "<dark_purple>";
   public static final String WHITE = "<white>";
   public static final String GRAY = "<gray>";
   public static final String DARK_GRAY = "<dark_gray>";
   public static final String BLACK = "<black>";
   public static final String OBFUSCATED = "<obfuscated>";
   public static final String BOLD = "<bold>";
   public static final String STRIKETHROUGH = "<strikethrough>";
   public static final String UNDERLINED = "<underlined>";
   public static final String ITALIC = "<italic>";
   public static final String RESET = "<reset>";
   private static final Function<String, String> modernHexFunction = (hex) -> {
      return "<#" + hex + ">";
   };

   public static String strip(String line) {
      return TownyComponents.stripTags(ChatColor.stripColor(line));
   }

   public static String translateColorCodes(String str) {
      return StringMgmt.translateHexColors(ChatColor.translateAlternateColorCodes('&', str));
   }

   public static String translateLegacyCharacters(String input) {
      String legacy;
      for(Matcher matcher = LEGACY_PATTERN.matcher(input); matcher.find(); input = input.replace(legacy, (CharSequence)LEGACY_LOOKUP.getOrDefault(legacy.substring(1), legacy))) {
         legacy = matcher.group();
      }

      return input;
   }

   public static String translateLegacyHex(String input) {
      return StringMgmt.translateHexColors(input, modernHexFunction);
   }

   @Nullable
   public static NamedTextColor toNamedTextColor(@NotNull String color) {
      byte var2 = -1;
      switch(color.hashCode()) {
      case -2040442827:
         if (color.equals("<dark_aqua>")) {
            var2 = 7;
         }
         break;
      case -2039668137:
         if (color.equals("<dark_blue>")) {
            var2 = 3;
         }
         break;
      case -2034890386:
         if (color.equals("<dark_gray>")) {
            var2 = 17;
         }
         break;
      case -1956210915:
         if (color.equals("<light_purple>")) {
            var2 = 27;
         }
         break;
      case -1820576139:
         if (color.equals("<dark_purple>")) {
            var2 = 11;
         }
         break;
      case -758063046:
         if (color.equals("<dark_red>")) {
            var2 = 9;
         }
         break;
      case 5225:
         if (color.equals("§0")) {
            var2 = 0;
         }
         break;
      case 5226:
         if (color.equals("§1")) {
            var2 = 2;
         }
         break;
      case 5227:
         if (color.equals("§2")) {
            var2 = 4;
         }
         break;
      case 5228:
         if (color.equals("§3")) {
            var2 = 6;
         }
         break;
      case 5229:
         if (color.equals("§4")) {
            var2 = 8;
         }
         break;
      case 5230:
         if (color.equals("§5")) {
            var2 = 10;
         }
         break;
      case 5231:
         if (color.equals("§6")) {
            var2 = 12;
         }
         break;
      case 5232:
         if (color.equals("§7")) {
            var2 = 14;
         }
         break;
      case 5233:
         if (color.equals("§8")) {
            var2 = 16;
         }
         break;
      case 5234:
         if (color.equals("§9")) {
            var2 = 18;
         }
         break;
      case 5274:
         if (color.equals("§a")) {
            var2 = 20;
         }
         break;
      case 5275:
         if (color.equals("§b")) {
            var2 = 22;
         }
         break;
      case 5276:
         if (color.equals("§c")) {
            var2 = 24;
         }
         break;
      case 5277:
         if (color.equals("§d")) {
            var2 = 26;
         }
         break;
      case 5278:
         if (color.equals("§e")) {
            var2 = 28;
         }
         break;
      case 5279:
         if (color.equals("§f")) {
            var2 = 30;
         }
         break;
      case 58907657:
         if (color.equals("<red>")) {
            var2 = 25;
         }
         break;
      case 202813070:
         if (color.equals("<yellow>")) {
            var2 = 29;
         }
         break;
      case 324031323:
         if (color.equals("<black>")) {
            var2 = 1;
         }
         break;
      case 472839383:
         if (color.equals("<green>")) {
            var2 = 21;
         }
         break;
      case 921803889:
         if (color.equals("<white>")) {
            var2 = 31;
         }
         break;
      case 1343008968:
         if (color.equals("<dark_green>")) {
            var2 = 5;
         }
         break;
      case 1810812486:
         if (color.equals("<aqua>")) {
            var2 = 23;
         }
         break;
      case 1811587176:
         if (color.equals("<blue>")) {
            var2 = 19;
         }
         break;
      case 1816285474:
         if (color.equals("<gold>")) {
            var2 = 13;
         }
         break;
      case 1816364927:
         if (color.equals("<gray>")) {
            var2 = 15;
         }
      }

      NamedTextColor var10000;
      switch(var2) {
      case 0:
      case 1:
         var10000 = NamedTextColor.BLACK;
         break;
      case 2:
      case 3:
         var10000 = NamedTextColor.DARK_BLUE;
         break;
      case 4:
      case 5:
         var10000 = NamedTextColor.DARK_GREEN;
         break;
      case 6:
      case 7:
         var10000 = NamedTextColor.DARK_AQUA;
         break;
      case 8:
      case 9:
         var10000 = NamedTextColor.DARK_RED;
         break;
      case 10:
      case 11:
         var10000 = NamedTextColor.DARK_PURPLE;
         break;
      case 12:
      case 13:
         var10000 = NamedTextColor.GOLD;
         break;
      case 14:
      case 15:
         var10000 = NamedTextColor.GRAY;
         break;
      case 16:
      case 17:
         var10000 = NamedTextColor.DARK_GRAY;
         break;
      case 18:
      case 19:
         var10000 = NamedTextColor.BLUE;
         break;
      case 20:
      case 21:
         var10000 = NamedTextColor.GREEN;
         break;
      case 22:
      case 23:
         var10000 = NamedTextColor.AQUA;
         break;
      case 24:
      case 25:
         var10000 = NamedTextColor.RED;
         break;
      case 26:
      case 27:
         var10000 = NamedTextColor.LIGHT_PURPLE;
         break;
      case 28:
      case 29:
         var10000 = NamedTextColor.YELLOW;
         break;
      case 30:
      case 31:
         var10000 = NamedTextColor.WHITE;
         break;
      default:
         var10000 = null;
      }

      return var10000;
   }

   public static String colorTown(String townName) {
      String var10000 = getTownColor();
      return translateColorCodes(var10000 + townName);
   }

   public static String colorTown(Town town) {
      String var10000 = getTownColor();
      return translateColorCodes(var10000 + town);
   }

   public static String colorNation(String nationName) {
      String var10000 = getNationColor();
      return translateColorCodes(var10000 + nationName);
   }

   public static String colorNation(Nation nation) {
      String var10000 = getNationColor();
      return translateColorCodes(var10000 + nation);
   }

   public static String getTownColor() {
      return TownySettings.getPAPIFormattingMayor();
   }

   public static String getNationColor() {
      return TownySettings.getPAPIFormattingKing();
   }

   public static boolean containsColourCode(String input) {
      return LEGACY_PATTERN.matcher(input).find() || input.length() != strip(input).length();
   }

   public static String getLegacyFromNamedTextColor(NamedTextColor colour) {
      String var1 = "<" + colour.toString() + ">";
      byte var2 = -1;
      switch(var1.hashCode()) {
      case -2040442827:
         if (var1.equals("<dark_aqua>")) {
            var2 = 3;
         }
         break;
      case -2039668137:
         if (var1.equals("<dark_blue>")) {
            var2 = 1;
         }
         break;
      case -2034890386:
         if (var1.equals("<dark_gray>")) {
            var2 = 8;
         }
         break;
      case -1956210915:
         if (var1.equals("<light_purple>")) {
            var2 = 13;
         }
         break;
      case -1820576139:
         if (var1.equals("<dark_purple>")) {
            var2 = 5;
         }
         break;
      case -758063046:
         if (var1.equals("<dark_red>")) {
            var2 = 4;
         }
         break;
      case 58907657:
         if (var1.equals("<red>")) {
            var2 = 12;
         }
         break;
      case 202813070:
         if (var1.equals("<yellow>")) {
            var2 = 14;
         }
         break;
      case 324031323:
         if (var1.equals("<black>")) {
            var2 = 0;
         }
         break;
      case 472839383:
         if (var1.equals("<green>")) {
            var2 = 10;
         }
         break;
      case 921803889:
         if (var1.equals("<white>")) {
            var2 = 15;
         }
         break;
      case 1343008968:
         if (var1.equals("<dark_green>")) {
            var2 = 2;
         }
         break;
      case 1810812486:
         if (var1.equals("<aqua>")) {
            var2 = 11;
         }
         break;
      case 1811587176:
         if (var1.equals("<blue>")) {
            var2 = 9;
         }
         break;
      case 1816285474:
         if (var1.equals("<gold>")) {
            var2 = 6;
         }
         break;
      case 1816364927:
         if (var1.equals("<gray>")) {
            var2 = 7;
         }
      }

      String var10000;
      switch(var2) {
      case 0:
         var10000 = "§0";
         break;
      case 1:
         var10000 = "§1";
         break;
      case 2:
         var10000 = "§2";
         break;
      case 3:
         var10000 = "§3";
         break;
      case 4:
         var10000 = "§4";
         break;
      case 5:
         var10000 = "§5";
         break;
      case 6:
         var10000 = "§6";
         break;
      case 7:
         var10000 = "§7";
         break;
      case 8:
         var10000 = "§8";
         break;
      case 9:
         var10000 = "§9";
         break;
      case 10:
         var10000 = "§a";
         break;
      case 11:
         var10000 = "§b";
         break;
      case 12:
         var10000 = "§c";
         break;
      case 13:
         var10000 = "§d";
         break;
      case 14:
         var10000 = "§e";
         break;
      case 15:
         var10000 = "§f";
         break;
      default:
         var10000 = null;
      }

      return var10000;
   }

   static {
      LEGACY_LOOKUP.put("0", "<black>");
      LEGACY_LOOKUP.put("1", "<dark_blue>");
      LEGACY_LOOKUP.put("2", "<dark_green>");
      LEGACY_LOOKUP.put("3", "<dark_aqua>");
      LEGACY_LOOKUP.put("4", "<dark_red>");
      LEGACY_LOOKUP.put("5", "<dark_purple>");
      LEGACY_LOOKUP.put("6", "<gold>");
      LEGACY_LOOKUP.put("7", "<gray>");
      LEGACY_LOOKUP.put("8", "<dark_gray>");
      LEGACY_LOOKUP.put("9", "<blue>");
      LEGACY_LOOKUP.put("a", "<green>");
      LEGACY_LOOKUP.put("b", "<aqua>");
      LEGACY_LOOKUP.put("c", "<red>");
      LEGACY_LOOKUP.put("d", "<light_purple>");
      LEGACY_LOOKUP.put("e", "<yellow>");
      LEGACY_LOOKUP.put("f", "<white>");
      LEGACY_LOOKUP.put("k", "<obfuscated>");
      LEGACY_LOOKUP.put("l", "<bold>");
      LEGACY_LOOKUP.put("m", "<strikethrough>");
      LEGACY_LOOKUP.put("n", "<underlined>");
      LEGACY_LOOKUP.put("o", "<italic>");
      LEGACY_LOOKUP.put("r", "<reset>");
   }
}
