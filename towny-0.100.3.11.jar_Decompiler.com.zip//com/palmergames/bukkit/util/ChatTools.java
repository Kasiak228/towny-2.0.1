package com.palmergames.bukkit.util;

import com.palmergames.bukkit.towny.object.TownyObject;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.towny.utils.TownyComponents;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class ChatTools {
   private static final int DEFAULT_CHAT_WIDTH = 320;
   private static final float SPACE_WIDTH = FontUtil.measureWidth(' ');
   private static final float UNDERSCORE_WIDTH = FontUtil.measureWidth('_');
   private static final String WIDGET = ".oOo.";
   private static final float WIDGET_WIDTH = FontUtil.measureWidth(".oOo.");
   private static final String SUBWIDGET = " .]|[. ";
   private static final float SUBWIDGET_WIDTH = FontUtil.measureWidth(" .]|[. ");

   public static String listArr(String[] args, String prefix) {
      return list(Arrays.asList(args), prefix);
   }

   public static String list(Collection<String> args) {
      return list(args, "");
   }

   public static String list(Collection<String> args, String prefix) {
      return args.isEmpty() ? "" : prefix + String.join(", ", args);
   }

   public static String stripColour(String s) {
      return Colors.strip(s);
   }

   public static String formatTitle(TownyObject object) {
      String title = object.getFormattedName();
      if (title.length() > 51) {
         title = object.getName();
      }

      if (title.length() > 51) {
         title = title.substring(0, 51);
      }

      return formatTitle(title);
   }

   public static String formatTitle(String title) {
      String var10000 = Translation.of("status_title_secondary_colour");
      title = ".[ " + var10000 + title + Translation.of("status_title_primary_colour") + " ].";
      if (!FontUtil.isValidMinecraftFont(title)) {
         return legacyFormatTitle(title);
      } else {
         float width = FontUtil.measureWidth(TownyComponents.miniMessage(title));
         float remainder = 320.0F - WIDGET_WIDTH * 2.0F - width - 2.0F;
         if (remainder < 1.0F) {
            var10000 = Translation.of("status_title_primary_colour");
            return var10000 + title;
         } else if (remainder < 14.0F) {
            var10000 = Translation.of("status_title_primary_colour");
            return var10000 + ".oOo." + title + ".oOo.";
         } else {
            int times = (int)Math.floor((double)(remainder / (UNDERSCORE_WIDTH * 2.0F)));
            var10000 = Translation.of("status_title_primary_colour");
            return var10000 + ".oOo." + repeatChar(times, "_") + title + repeatChar(times, "_") + ".oOo.";
         }
      }
   }

   private static String legacyFormatTitle(String title) {
      String line = ".oOo.__________________________________________________.oOo.";
      if (title.length() > line.length()) {
         title = title.substring(0, line.length());
      }

      int pivot = line.length() / 2;
      String var10000 = Translation.of("status_title_primary_colour");
      String out = var10000 + line.substring(0, Math.max(0, pivot - title.length() / 2));
      out = out + title + line.substring(pivot + title.length() / 2);
      return out;
   }

   public static String formatSubTitle(String subtitle) {
      if (!FontUtil.isValidMinecraftFont(subtitle)) {
         return legacyFormatSubtitle(subtitle);
      } else {
         float width = FontUtil.measureWidth(TownyComponents.miniMessage(subtitle));
         float remainder = 320.0F - SUBWIDGET_WIDTH * 2.0F - width - 2.0F;
         String var10000;
         if (remainder < 1.0F) {
            var10000 = Translation.of("status_title_primary_colour");
            return var10000 + subtitle;
         } else if (remainder < 10.0F) {
            var10000 = Translation.of("status_title_primary_colour");
            return var10000 + " .]|[. " + subtitle + Translation.of("status_title_primary_colour") + " .]|[. ";
         } else {
            int times = (int)Math.floor((double)(remainder / (SPACE_WIDTH * 2.0F)));
            var10000 = Translation.of("status_title_primary_colour");
            return var10000 + " .]|[. " + repeatChar(times, " ") + subtitle + repeatChar(times, " ") + Translation.of("status_title_primary_colour") + " .]|[. ";
         }
      }
   }

   private static String legacyFormatSubtitle(String subtitle) {
      String line = " .]|[.                                                                     .]|[.";
      int pivot = line.length() / 2;
      String center = subtitle + Translation.of("status_title_primary_colour");
      String var10000 = Translation.of("status_title_primary_colour");
      String out = var10000 + line.substring(0, Math.max(0, pivot - center.length() / 2));
      out = out + center + line.substring(Math.min(line.length(), pivot + center.length() / 2));
      return out;
   }

   private static String repeatChar(int num, String character) {
      String output = "";

      for(int i = 0; i < num; ++i) {
         output = output + character;
      }

      return output;
   }

   public static String formatCommand(String command, String subCommand, String help) {
      return formatCommand("", command, subCommand, help);
   }

   public static String formatCommand(String requirement, String command, String subCommand, String help) {
      String out = "  ";
      if (requirement.length() > 0) {
         out = out + Translation.of("help_menu_requirement") + requirement + ": ";
      }

      out = out + Translation.of("help_menu_command") + command;
      if (subCommand.length() > 0) {
         out = out + " " + Translation.of("help_menu_subcommand") + subCommand;
      }

      if (help.length() > 0) {
         out = out + Translation.of("help_menu_explanation") + " : " + help;
      }

      return out;
   }

   public static String[] formatList(String title, String subject, List<String> list, String page) {
      List<String> output = new ArrayList();
      output.add(0, formatTitle(title));
      output.add(1, subject);
      output.addAll(list);
      output.add(page);
      return (String[])output.toArray(new String[0]);
   }
}
