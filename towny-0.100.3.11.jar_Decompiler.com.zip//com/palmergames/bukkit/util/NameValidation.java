package com.palmergames.bukkit.util;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.exceptions.InvalidNameException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.Government;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.util.StringMgmt;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;
import java.util.Objects;
import java.util.logging.Level;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Stream;
import org.bukkit.NamespacedKey;

public class NameValidation {
   private static Pattern namePattern = null;
   private static Pattern stringPattern = null;
   private static final Collection<String> bannedNames = new HashSet(Arrays.asList("here", "leave", "list", "online", "new", "plots", "add", "kick", "claim", "unclaim", "withdraw", "delete", "outlawlist", "deposit", "outlaw", "outpost", "ranklist", "rank", "reclaim", "reslist", "say", "set", "toggle", "join", "invite", "buy", "mayor", "bankhistory", "enemy", "ally", "townlist", "allylist", "enemylist", "king", "merge", "jail", "plotgrouplist", "trust", "purge", "leader", "baltop", "all", "help", "spawn", "takeoverclaim", "ban", "unjail", "trusttown", "forsale", "fs", "notforsale", "nfs", "buytown", "sanctiontown", "create", "cede"));
   private static final Pattern numberPattern = Pattern.compile("\\d");

   public static String checkAndFilterPlayerName(String name) throws InvalidNameException {
      String out = filterName(name);
      testForBadSymbols(name);
      if (!isNameAllowedViaRegex(out)) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_invalid_characters", out));
      } else {
         return out;
      }
   }

   public static String checkAndFilterTownNameOrThrow(String name) throws InvalidNameException {
      String out = filterName(name);
      testNameLength(out);
      testForNumbersInTownName(out);
      testForImproperNameAndThrow(out);
      testCapitalization(out);
      testForSubcommand(out);
      if (out.startsWith(TownySettings.getTownAccountPrefix())) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_begins_with_eco_prefix", out));
      } else {
         return out;
      }
   }

   public static String checkAndFilterNationNameOrThrow(String name) throws InvalidNameException {
      String out = filterName(name);
      testNameLength(out);
      testForNumbersInNationName(out);
      testForImproperNameAndThrow(out);
      testCapitalization(out);
      testForSubcommand(out);
      if (out.startsWith(TownySettings.getNationAccountPrefix())) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_begins_with_eco_prefix", out));
      } else {
         return out;
      }
   }

   public static String checkAndFilterGovernmentNameOrThrow(String name, Government gov) throws InvalidNameException {
      if (gov instanceof Town) {
         return checkAndFilterTownNameOrThrow(name);
      } else {
         return gov instanceof Nation ? checkAndFilterNationNameOrThrow(name) : name;
      }
   }

   public static String checkAndFilterPlotNameOrThrow(String name) throws InvalidNameException {
      name = filterName(name);
      testNameLength(name);
      testForImproperNameAndThrow(name);
      return name;
   }

   public static String checkAndFilterPlotGroupNameOrThrow(String name) throws InvalidNameException {
      return checkAndFilterPlotNameOrThrow(filterCommas(name));
   }

   public static String checkAndFilterDistrictNameOrThrow(String name) throws InvalidNameException {
      return checkAndFilterPlotNameOrThrow(filterCommas(name));
   }

   public static String checkAndFilterTitlesSurnameOrThrow(String[] words) throws InvalidNameException {
      String title = StringMgmt.join((Object[])filterNameArray(words));
      testForConfigBlacklistedName(title);
      if (title.length() > TownySettings.getMaxTitleLength()) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_title_too_long", title));
      } else {
         return title;
      }
   }

   public static String checkAndFilterTagOrThrow(String tag) throws TownyException {
      tag = filterName(tag);
      if (tag.length() > TownySettings.getMaxTagLength()) {
         throw new TownyException(Translatable.of("msg_err_tag_too_long"));
      } else {
         testForEmptyName(tag);
         testAllUnderscores(tag);
         testForImproperNameAndThrow(tag);
         return tag;
      }
   }

   public static boolean isValidBoardString(String message) {
      try {
         testForBadSymbols(message);
         testForConfigBlacklistedName(message);
      } catch (InvalidNameException var3) {
         return false;
      }

      try {
         if (stringPattern == null) {
            stringPattern = Pattern.compile(TownySettings.getStringCheckRegex(), 258);
         }

         return stringPattern.matcher(message).find();
      } catch (PatternSyntaxException var2) {
         Towny.getPlugin().getLogger().log(Level.WARNING, "Failed to compile the string check regex pattern because it contains errors (" + TownySettings.getStringCheckRegex() + ")", var2);
         return false;
      }
   }

   public static void testForImproperNameAndThrow(String name) throws InvalidNameException {
      testForEmptyName(name);
      testForConfigBlacklistedName(name);
      testAllUnderscores(name);
      testForBadSymbols(name);
      if (!isNameAllowedViaRegex(name)) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_invalid_characters", name));
      }
   }

   private static void testForEmptyName(String name) throws InvalidNameException {
      if (name.isEmpty()) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_is_empty"));
      }
   }

   private static void testForConfigBlacklistedName(String line) throws InvalidNameException {
      String[] words = line.split(" ");
      String[] var2 = words;
      int var3 = words.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String word = var2[var4];
         if (!word.isEmpty()) {
            Stream var10000 = TownySettings.getBlacklistedNames().stream();
            Objects.requireNonNull(word);
            if (var10000.anyMatch(word::equalsIgnoreCase)) {
               throw new InvalidNameException(Translatable.of("msg_err_name_validation_is_not_permitted", word));
            }
         }
      }

   }

   private static void testAllUnderscores(String name) throws InvalidNameException {
      char[] var1 = name.toCharArray();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         char letter = var1[var3];
         if (letter != '_') {
            return;
         }
      }

      throw new InvalidNameException(Translatable.of("msg_err_name_validation_is_all_underscores", name));
   }

   private static void testCapitalization(String name) throws InvalidNameException {
      int maxCapitals = TownySettings.getMaxNameCapitalLetters();
      if (maxCapitals != -1) {
         int capitals = 0;
         boolean skip = true;
         char[] var4 = name.toCharArray();
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            char letter = var4[var6];
            if (skip) {
               skip = false;
            } else if (letter == '_') {
               skip = true;
            } else if (!Character.isLowerCase(letter)) {
               ++capitals;
            }
         }

         if (capitals > maxCapitals) {
            throw new InvalidNameException(Translatable.of("msg_err_name_validation_too_many_capitals", name, capitals, maxCapitals));
         }
      }
   }

   private static void testForBadSymbols(String message) throws InvalidNameException {
      if (message.contains("'") || message.contains("`")) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_contains_harmful_characters", message));
      }
   }

   private static void testForSubcommand(String name) throws InvalidNameException {
      if (isBannedName(name)) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_used_in_command_structure", name));
      }
   }

   private static void testNameLength(String name) throws InvalidNameException {
      if (name.length() > TownySettings.getMaxNameLength()) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_name_too_long", name));
      }
   }

   private static void testForNumbersInNationName(String name) throws InvalidNameException {
      if (!TownySettings.areNumbersAllowedInNationNames() && nameContainsNumbers(name)) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_contains_numbers", name));
      }
   }

   private static void testForNumbersInTownName(String name) throws InvalidNameException {
      if (!TownySettings.areNumbersAllowedInTownNames() && nameContainsNumbers(name)) {
         throw new InvalidNameException(Translatable.of("msg_err_name_validation_contains_numbers", name));
      }
   }

   private static boolean nameContainsNumbers(String name) {
      return numberPattern.matcher(name).find();
   }

   private static boolean isNameAllowedViaRegex(String name) {
      try {
         if (namePattern == null) {
            namePattern = Pattern.compile(TownySettings.getNameCheckRegex(), 258);
         }

         return namePattern.matcher(name).find();
      } catch (PatternSyntaxException var2) {
         Towny.getPlugin().getLogger().log(Level.WARNING, "Failed to compile the name check regex pattern because it contains errors (" + TownySettings.getNameCheckRegex() + ")", var2);
         return false;
      }
   }

   private static String filterName(String input) {
      return input.replaceAll(TownySettings.getNameFilterRegex(), "_").replaceAll(TownySettings.getNameRemoveRegex(), "").replace("&k", "");
   }

   private static String[] filterNameArray(String[] arr) {
      int count = 0;
      String[] var2 = arr;
      int var3 = arr.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String word = var2[var4];
         arr[count] = filterName(word);
         ++count;
      }

      return arr;
   }

   private static String filterCommas(String input) {
      return input.replace(",", "_");
   }

   static boolean isBannedName(String name) {
      return bannedNames.contains(name.toLowerCase(Locale.ROOT));
   }

   /** @deprecated */
   @Deprecated
   public static String checkAndFilterName(String name) throws InvalidNameException {
      String out = filterName(name);
      testForEmptyName(out);
      testAllUnderscores(out);
      testForImproperNameAndThrow(out);
      return out;
   }

   static {
      TownySettings.addReloadListener(NamespacedKey.fromString("towny:regex-patterns"), () -> {
         namePattern = null;
         stringPattern = null;
      });
   }
}
