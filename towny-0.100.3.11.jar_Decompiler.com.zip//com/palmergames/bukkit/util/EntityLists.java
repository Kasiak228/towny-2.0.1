package com.palmergames.bukkit.util;

import com.palmergames.bukkit.towny.object.AbstractRegistryList;
import java.util.Collection;
import org.bukkit.Registry;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.jetbrains.annotations.NotNull;

public class EntityLists extends AbstractRegistryList<EntityType> {
   public static final EntityLists VEHICLES = (EntityLists)newBuilder().startsWith("minecart").endsWith("minecart").endsWith("boat").endsWith("raft").build();
   public static final EntityLists MOUNTABLE = (EntityLists)newBuilder().add("horse", "strider", "pig", "donkey", "mule", "trader_llama", "camel").build();
   public static final EntityLists MILKABLE = (EntityLists)newBuilder().add("cow", "mooshroom", "goat").build();
   public static final EntityLists DYEABLE = (EntityLists)newBuilder().add("sheep", "wolf", "cat").build();
   public static final EntityLists SWITCH_PROTECTED = (EntityLists)newBuilder().add("chest_minecart", "furnace_minecart", "hopper_minecart", "chest_boat").build();
   public static final EntityLists RIGHT_CLICK_PROTECTED = (EntityLists)newBuilder().add("tropical_fish", "salmon", "cod", "item_frame", "glow_item_frame", "painting", "leash_knot", "command_block_minecart", "tnt_minecart", "spawner_minecart", "tadpole", "axolotl").build();
   public static final EntityLists DESTROY_PROTECTED = (EntityLists)newBuilder().add("item_frame", "glow_item_frame", "painting", "armor_stand", "end_crystal", "minecart", "chest_minecart", "command_block_minecart", "hopper_minecart").build();
   public static final EntityLists ITEM_FRAMES = (EntityLists)newBuilder().add("item_frame", "glow_item_frame").build();
   public static final EntityLists HANGING = (EntityLists)newBuilder().add("item_frame", "glow_item_frame", "painting").build();
   public static final EntityLists BOATS = (EntityLists)newBuilder().endsWith("boat").endsWith("raft").build();
   public static final EntityLists EXPLOSIVE = (EntityLists)newBuilder().add("creeper").endsWith("fireball").add("firework_rocket", "tnt_minecart", "tnt", "wither", "wither_skull", "end_crystal").build();
   public static final EntityLists PVE_EXPLOSIVE = (EntityLists)newBuilder().add("creeper").endsWith("fireball").add("wither", "wither_skull", "end_crystal").build();
   public static final EntityLists PVP_EXPLOSIVE = (EntityLists)newBuilder().add("firework_rocket", "tnt_minecart", "tnt", "end_crystal").build();
   public static final EntityLists ANIMALS = (EntityLists)newBuilder().filter((type) -> {
      return type.getEntityClass() != null && Animals.class.isAssignableFrom(type.getEntityClass());
   }).build();

   public EntityLists(Collection<EntityType> collection) {
      super(Registry.ENTITY_TYPE, collection);
   }

   public boolean contains(@NotNull Entity entity) {
      return this.contains(entity.getType());
   }

   public static AbstractRegistryList.Builder<EntityType, EntityLists> newBuilder() {
      return (new AbstractRegistryList.Builder(Registry.ENTITY_TYPE, EntityType.class, EntityLists::new)).filter((type) -> {
         return type != EntityType.UNKNOWN;
      });
   }
}
