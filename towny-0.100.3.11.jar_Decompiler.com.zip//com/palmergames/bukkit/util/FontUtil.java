package com.palmergames.bukkit.util;

import com.palmergames.adventure.text.Component;
import com.palmergames.adventure.text.format.Style;
import com.palmergames.adventure.text.format.TextDecoration;
import com.palmergames.bukkit.towny.libs.pixelwidth.DefaultCharacterWidthFunction;
import com.palmergames.bukkit.towny.libs.pixelwidth.PixelWidthSource;
import com.palmergames.bukkit.towny.libs.pixelwidth.function.CharacterWidthFunction;
import org.bukkit.map.MinecraftFont;
import org.jetbrains.annotations.ApiStatus.Internal;

public class FontUtil {
   @Internal
   public static final MinecraftFont font = new MinecraftFont();
   private static final PixelWidthSource widthSource = PixelWidthSource.pixelWidth((CharacterWidthFunction)(new DefaultCharacterWidthFunction() {
      public float handleMissing(int codepoint, Style style) {
         try {
            MinecraftFont var10000 = FontUtil.font;
            String var10001 = String.valueOf((char)codepoint);
            return (float)var10000.getWidth(var10001 + (style.hasDecoration(TextDecoration.BOLD) ? 1 : 0));
         } catch (IllegalArgumentException var4) {
            return 6.0F;
         }
      }
   }));

   public static float measureWidth(Component source) {
      return widthSource.width(source);
   }

   public static float measureWidth(String source) {
      return widthSource.width(source, Style.empty());
   }

   public static float measureWidth(String source, Style style) {
      return widthSource.width(source, style);
   }

   public static float measureWidth(char source) {
      return widthSource.width(source, Style.empty());
   }

   public static float measureWidth(char source, Style style) {
      return widthSource.width(source, style);
   }

   public static boolean isValidMinecraftFont(String text) {
      return font.isValid(text);
   }
}
