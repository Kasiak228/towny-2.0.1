package com.palmergames.bukkit.util;

import java.util.function.Consumer;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.World;

public class DrawUtil {
   public static void runOnSurface(World world, int x1, int z1, int x2, int z2, int height, Consumer<Location> locationConsumer) {
      int _x1 = Math.min(x1, x2);
      int _x2 = Math.max(x1, x2);
      int _z1 = Math.min(z1, z2);
      int _z2 = Math.max(z1, z2);

      for(int z = _z1; z <= _z2; ++z) {
         for(int x = _x1; x <= _x2; ++x) {
            if (world.isChunkLoaded(x >> 4, z >> 4)) {
               int start = world.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
               int end = start + height < world.getMaxHeight() ? start + height - 1 : world.getMaxHeight();

               for(int y = start; y <= end; ++y) {
                  locationConsumer.accept(new Location(world, (double)x, (double)y, (double)z));
               }
            }
         }
      }

   }
}
