package com.palmergames.bukkit.util;

import com.google.common.base.Charsets;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.exceptions.CancelledEventException;
import com.palmergames.bukkit.towny.hooks.PluginIntegrations;
import com.palmergames.bukkit.towny.utils.MinecraftVersion;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Registry;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.generator.WorldInfo;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.PluginManager;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;

public class BukkitTools {
   private static Towny plugin = null;
   private static final MethodHandle GET_OFFLINE_PLAYER_CACHED;

   public static void initialize(Towny plugin) {
      BukkitTools.plugin = plugin;
   }

   public static Collection<? extends Player> getOnlinePlayers() {
      return getServer().getOnlinePlayers();
   }

   public static List<Player> matchPlayer(String name) {
      List<Player> matchedPlayers = new ArrayList();
      Iterator var2 = Bukkit.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         Player iterPlayer = (Player)var2.next();
         String iterPlayerName = iterPlayer.getName();
         if (!PluginIntegrations.getInstance().isNPC(iterPlayer)) {
            if (name.equalsIgnoreCase(iterPlayerName)) {
               matchedPlayers.clear();
               matchedPlayers.add(iterPlayer);
               break;
            }

            if (iterPlayerName.toLowerCase(Locale.ENGLISH).contains(name.toLowerCase(Locale.ENGLISH))) {
               matchedPlayers.add(iterPlayer);
            }
         }
      }

      return matchedPlayers;
   }

   public static UUID getUUIDSafely(String name) {
      OfflinePlayer cached = getOfflinePlayerIfCached(name);
      return cached != null ? cached.getUniqueId() : null;
   }

   @Nullable
   public static Player getPlayerExact(String name) {
      return getServer().getPlayerExact(name);
   }

   @Nullable
   public static Player getPlayer(String playerId) {
      return getServer().getPlayer(playerId);
   }

   @Nullable
   public static Player getPlayer(UUID playerUUID) {
      return getServer().getPlayer(playerUUID);
   }

   public static boolean playerCanSeePlayer(Player seeing, Player seen) {
      if (Bukkit.getPluginManager().isPluginEnabled("PremiumVanish") && MinecraftVersion.CURRENT_VERSION.isOlderThanOrEquals(MinecraftVersion.MINECRAFT_1_19_3)) {
         Iterator var2 = seen.getMetadata("vanished").iterator();

         MetadataValue meta;
         do {
            if (!var2.hasNext()) {
               return true;
            }

            meta = (MetadataValue)var2.next();
         } while(!meta.asBoolean());

         return false;
      } else {
         return seeing.canSee(seen);
      }
   }

   public static Collection<? extends Player> getVisibleOnlinePlayers(CommandSender sender) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         return (Collection)Bukkit.getOnlinePlayers().stream().filter((p) -> {
            return playerCanSeePlayer(player, p);
         }).collect(Collectors.toCollection(ArrayList::new));
      } else {
         return Bukkit.getOnlinePlayers();
      }
   }

   public static boolean isOnline(String name) {
      return Bukkit.getPlayerExact(name) != null;
   }

   public static List<World> getWorlds() {
      return getServer().getWorlds();
   }

   public static World getWorld(String name) {
      return getServer().getWorld(name);
   }

   public static World getWorld(UUID worldUID) {
      return getServer().getWorld(worldUID);
   }

   public static UUID getWorldUUID(String name) {
      World world = getWorld(name);
      return world != null ? world.getUID() : null;
   }

   public static Server getServer() {
      return Bukkit.getServer();
   }

   public static PluginManager getPluginManager() {
      return getServer().getPluginManager();
   }

   /** @deprecated */
   @Deprecated
   public static BukkitScheduler getScheduler() {
      return getServer().getScheduler();
   }

   /** @deprecated */
   @Deprecated
   public static int scheduleSyncDelayedTask(Runnable task, long delay) {
      return getScheduler().scheduleSyncDelayedTask(plugin, task, delay);
   }

   /** @deprecated */
   @Deprecated
   public static int scheduleAsyncDelayedTask(Runnable task, long delay) {
      return getScheduler().runTaskLaterAsynchronously(plugin, task, delay).getTaskId();
   }

   /** @deprecated */
   @Deprecated
   public static int scheduleSyncRepeatingTask(Runnable task, long delay, long repeat) {
      return getScheduler().scheduleSyncRepeatingTask(plugin, task, delay, repeat);
   }

   /** @deprecated */
   @Deprecated
   public static int scheduleAsyncRepeatingTask(Runnable task, long delay, long repeat) {
      return getScheduler().runTaskTimerAsynchronously(plugin, task, delay, repeat).getTaskId();
   }

   public static HashMap<String, Integer> getPlayersPerWorld() {
      HashMap<String, Integer> m = new HashMap();
      Iterator var1 = getServer().getWorlds().iterator();

      while(var1.hasNext()) {
         World world = (World)var1.next();
         m.put(world.getName(), 0);
      }

      var1 = getServer().getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player player = (Player)var1.next();
         m.put(player.getWorld().getName(), (Integer)m.get(player.getWorld().getName()) + 1);
      }

      return m;
   }

   public static int calcChunk(int value) {
      return value * TownySettings.getTownBlockSize() / 16;
   }

   public static boolean hasPlayedBefore(String name) {
      return getServer().getOfflinePlayer(name).hasPlayedBefore();
   }

   public static OfflinePlayer getOfflinePlayer(String name) {
      return Bukkit.getOfflinePlayer(name);
   }

   @Nullable
   public static OfflinePlayer getOfflinePlayerIfCached(@NotNull String name) {
      if (GET_OFFLINE_PLAYER_CACHED == null) {
         return null;
      } else {
         try {
            return GET_OFFLINE_PLAYER_CACHED.invokeExact(getServer(), name);
         } catch (Throwable var2) {
            return null;
         }
      }
   }

   public static OfflinePlayer getOfflinePlayerForVault(String name) {
      return Bukkit.getOfflinePlayer(UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(Charsets.UTF_8)));
   }

   public static String convertCoordtoXYZ(Location loc) {
      String var10000 = loc.getWorld().getName();
      return var10000 + " " + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
   }

   public static List<String> getWorldNames() {
      return (List)getWorlds().stream().map(WorldInfo::getName).collect(Collectors.toList());
   }

   public static List<String> getWorldNames(boolean lowercased) {
      return lowercased ? (List)getWorlds().stream().map((world) -> {
         return world.getName().toLowerCase(Locale.ROOT);
      }).collect(Collectors.toList()) : getWorldNames();
   }

   public static Location getBedOrRespawnLocation(Player player) {
      return MinecraftVersion.CURRENT_VERSION.isOlderThanOrEquals(MinecraftVersion.MINECRAFT_1_20_3) ? player.getBedSpawnLocation() : player.getRespawnLocation();
   }

   public static String potionEffectName(@NotNull PotionEffectType type) {
      return (type instanceof Keyed ? type.getKey().getKey() : type.getName()).toLowerCase(Locale.ROOT);
   }

   public static Objective objective(Scoreboard board, @NotNull String name, @NotNull String displayName) {
      return MinecraftVersion.CURRENT_VERSION.isOlderThanOrEquals(MinecraftVersion.MINECRAFT_1_19_1) ? board.registerNewObjective(name, "dummy", displayName) : board.registerNewObjective(name, Criteria.DUMMY, displayName);
   }

   public static boolean isEventCancelled(@NotNull Event event) {
      fireEvent(event);
      if (event instanceof Cancellable) {
         Cancellable cancellable = (Cancellable)event;
         return cancellable.isCancelled();
      } else {
         return false;
      }
   }

   public static void ifCancelledThenThrow(@NotNull CancellableTownyEvent event) throws CancelledEventException {
      fireEvent(event);
      if (event.isCancelled()) {
         throw new CancelledEventException(event);
      }
   }

   public static void fireEvent(@NotNull Event event) {
      Bukkit.getPluginManager().callEvent(event);
   }

   @Nullable
   public static String matchMaterialName(String name) {
      Material mat = (Material)matchRegistry(Registry.MATERIAL, name);
      return mat == null ? null : mat.getKey().getKey().toUpperCase(Locale.ROOT);
   }

   @Nullable
   public static <T extends Keyed> T matchRegistry(@NotNull Registry<T> registry, @NotNull String input) {
      String filtered = input.toLowerCase(Locale.ROOT).replaceAll("\\s+", "_");
      if (filtered.isEmpty()) {
         return null;
      } else {
         NamespacedKey key = NamespacedKey.fromString(filtered);
         return key != null ? registry.get(key) : null;
      }
   }

   public static String keyAsString(@NotNull NamespacedKey key) {
      return key.getNamespace().equals("minecraft") ? key.getKey() : key.toString();
   }

   @NotNull
   public static CommandMap getCommandMap() throws ReflectiveOperationException {
      try {
         Method commandMapGetter = getServer().getClass().getMethod("getCommandMap");
         return (CommandMap)commandMapGetter.invoke(getServer());
      } catch (ReflectiveOperationException var2) {
         Field bukkitCommandMap = getServer().getClass().getDeclaredField("commandMap");
         bukkitCommandMap.setAccessible(true);
         return (CommandMap)bukkitCommandMap.get(getServer());
      }
   }

   @Internal
   public static Collection<String> convertKeyedToString(@NotNull Collection<? extends Keyed> keys) {
      Set<String> set = new HashSet();
      Iterator var2 = keys.iterator();

      while(var2.hasNext()) {
         Keyed keyed = (Keyed)var2.next();
         set.add(keyAsString(keyed.getKey()));
      }

      return set;
   }

   static {
      MethodHandle temp = null;

      try {
         temp = MethodHandles.publicLookup().unreflect(Server.class.getMethod("getOfflinePlayerIfCached", String.class));
      } catch (ReflectiveOperationException var2) {
      }

      GET_OFFLINE_PLAYER_CACHED = temp;
   }
}
