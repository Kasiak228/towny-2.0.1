package com.palmergames.bukkit.config.migration;

import com.palmergames.bukkit.config.CommentedConfiguration;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.StringMgmt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import org.bukkit.Registry;
import org.bukkit.entity.EntityType;
import org.jetbrains.annotations.Nullable;

public class RunnableMigrations {
   private final Map<String, Consumer<CommentedConfiguration>> BY_NAME = new HashMap();
   private final Consumer<CommentedConfiguration> MIGRATE_NOTIFICATIONS = (config) -> {
      if (Boolean.parseBoolean(config.getString("notification.notifications_appear_in_action_bar", "true"))) {
         config.set("notification.notifications_appear_as", "action_bar");
      } else if (Boolean.parseBoolean(config.getString("notification.notifications_appear_on_bossbar", "false"))) {
         config.set("notification.notifications_appear_as", "bossbar");
      } else {
         config.set("notification.notifications_appear_as", "chat");
      }

   };
   private final Consumer<CommentedConfiguration> ADD_TOWNBLOCKTYPE_LIMITS = (config) -> {
      Iterator var1 = config.getMapList("levels.town_level").iterator();

      while(var1.hasNext()) {
         Map<?, ?> level = (Map)var1.next();
         level.put("townBlockTypeLimits", new HashMap());
      }

   };
   private final Consumer<CommentedConfiguration> CONVERT_ENTITY_CLASS_NAMES = (config) -> {
      List<String> entities = new ArrayList(Arrays.asList(config.getString("new_world_settings.plot_management.wild_revert_on_mob_explosion.entities", "").split(",")));
      ListIterator iterator = entities.listIterator();

      while(true) {
         while(iterator.hasNext()) {
            String entity = (String)iterator.next();
            if (entity.equals("Fireball") && entities.contains("LargeFireball")) {
               iterator.remove();
            } else {
               Iterator var4 = Registry.ENTITY_TYPE.iterator();

               while(var4.hasNext()) {
                  EntityType type = (EntityType)var4.next();
                  if (type.getEntityClass() != null && type.getEntityClass().getSimpleName().equalsIgnoreCase(entity)) {
                     iterator.set(BukkitTools.keyAsString(type.getKey()));
                     break;
                  }
               }
            }
         }

         config.set("new_world_settings.plot_management.wild_revert_on_mob_explosion.entities", String.join(",", entities));
         return;
      }
   };
   private final Consumer<CommentedConfiguration> ADD_MILKABLE_ANIMALS = (config) -> {
      Iterator var1 = config.getMapList("townblocktypes.types").iterator();

      while(var1.hasNext()) {
         Map<?, ?> plotType = (Map)var1.next();
         if (plotType.get("name").equals("farm")) {
            String allowedBlocks = (String)plotType.get("allowedBlocks");
            plotType.replace("allowedBlocks", "COW_SPAWN_EGG,GOAT_SPAWN_EGG,MOOSHROOM_SPAWN_EGG," + allowedBlocks);
         }
      }

   };
   private final Consumer<CommentedConfiguration> UPDATE_FARM_BLOCKS = (config) -> {
      Iterator var1 = config.getMapList("townblocktypes.types").iterator();

      while(var1.hasNext()) {
         Map<?, ?> plotType = (Map)var1.next();
         if (plotType.get("name").equals("farm")) {
            String rawBlocks = (String)plotType.get("allowedBlocks");
            List<String> currentBlocks = Arrays.asList(rawBlocks.split(","));
            List<String> missingBlocks = (List)Arrays.asList(TownySettings.getDefaultFarmblocks().split(",")).stream().filter((block) -> {
               return !currentBlocks.contains(block);
            }).collect(Collectors.toList());
            plotType.replace("allowedBlocks", rawBlocks + "," + StringMgmt.join((Collection)missingBlocks, ","));
         }
      }

   };

   public RunnableMigrations() {
      this.BY_NAME.put("migrate_notifications", this.MIGRATE_NOTIFICATIONS);
      this.BY_NAME.put("add_townblocktype_limits", this.ADD_TOWNBLOCKTYPE_LIMITS);
      this.BY_NAME.put("convert_entity_class_names", this.CONVERT_ENTITY_CLASS_NAMES);
      this.BY_NAME.put("add_milkable_animals_to_farm_plot", this.ADD_MILKABLE_ANIMALS);
      this.BY_NAME.put("update_farm_blocks", this.UPDATE_FARM_BLOCKS);
   }

   @Nullable
   public Consumer<CommentedConfiguration> getByName(String name) {
      return (Consumer)this.BY_NAME.get(name.toLowerCase(Locale.ROOT));
   }

   public boolean addMigration(String name, Consumer<CommentedConfiguration> migration) {
      return this.BY_NAME.putIfAbsent(name.toLowerCase(Locale.ROOT), migration) == null;
   }
}
