package com.palmergames.bukkit.config.migration;

public enum MigrationType {
   OVERWRITE(false),
   APPEND(false),
   NATION_LEVEL_ADD(false),
   TOWN_LEVEL_ADD(false),
   TOWNYPERMS_ADD(false),
   FARMBLOCK_ADD(false),
   REPLACE(false),
   REMOVE(true),
   MOVE(true),
   RUNNABLE(true);

   public final boolean early;

   private MigrationType(boolean early) {
      this.early = early;
   }

   public boolean isEarly() {
      return this.early;
   }

   // $FF: synthetic method
   private static MigrationType[] $values() {
      return new MigrationType[]{OVERWRITE, APPEND, NATION_LEVEL_ADD, TOWN_LEVEL_ADD, TOWNYPERMS_ADD, FARMBLOCK_ADD, REPLACE, REMOVE, MOVE, RUNNABLE};
   }
}
