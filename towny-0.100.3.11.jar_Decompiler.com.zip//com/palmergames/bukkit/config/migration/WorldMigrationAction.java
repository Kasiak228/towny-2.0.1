package com.palmergames.bukkit.config.migration;

import com.palmergames.bukkit.towny.object.TownyWorld;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;

public enum WorldMigrationAction {
   UPDATE_WORLD_BLOCK_IGNORE((townyWorld, change) -> {
      if (change.type == MigrationType.REPLACE) {
         townyWorld.setPlotManagementIgnoreIds(replaceAll((List)townyWorld.getPlotManagementIgnoreIds().stream().map(WorldMigrationAction::matName).collect(Collectors.toList()), change.key, change.value));
      } else {
         String var10001 = (String)townyWorld.getPlotManagementIgnoreIds().stream().map((type) -> {
            return type.getKey().toString();
         }).collect(Collectors.joining(","));
         townyWorld.setPlotManagementIgnoreIds(splitMats(var10001 + change.value));
      }

   }),
   UPDATE_WORLD_DELETE_MAYOR((townyWorld, change) -> {
      if (change.type == MigrationType.REPLACE) {
         townyWorld.setPlotManagementMayorDelete(replaceAll((List)townyWorld.getPlotManagementMayorDelete().stream().map(WorldMigrationAction::matName).collect(Collectors.toList()), change.key, change.value));
      } else {
         String var10001 = (String)townyWorld.getPlotManagementMayorDelete().stream().map((type) -> {
            return type.getKey().toString();
         }).collect(Collectors.joining(","));
         townyWorld.setPlotManagementMayorDelete(splitMats(var10001 + change.value));
      }

   }),
   UPDATE_WORLD_UNCLAIM_DELETE((townyWorld, change) -> {
      if (change.type == MigrationType.REPLACE) {
         townyWorld.setPlotManagementDeleteIds(replaceAll((List)townyWorld.getPlotManagementDeleteIds().stream().map(WorldMigrationAction::matName).collect(Collectors.toList()), change.key, change.value));
      } else {
         String var10001 = (String)townyWorld.getPlotManagementDeleteIds().stream().map((type) -> {
            return type.getKey().toString();
         }).collect(Collectors.joining(","));
         townyWorld.setPlotManagementDeleteIds(splitMats(var10001 + change.value));
      }

   }),
   UPDATE_WILDERNESS_IGNORE_MATS((townyWorld, change) -> {
      if (change.type == MigrationType.REPLACE) {
         townyWorld.setUnclaimedZoneIgnore(replaceAll((List)townyWorld.getUnclaimedZoneIgnoreMaterials().stream().map(WorldMigrationAction::matName).collect(Collectors.toList()), change.key, change.value));
      } else {
         String var10001 = (String)townyWorld.getUnclaimedZoneIgnoreMaterials().stream().map((type) -> {
            return type.getKey().toString();
         }).collect(Collectors.joining(","));
         townyWorld.setUnclaimedZoneIgnore(splitMats(var10001 + change.value));
      }

   }),
   UPDATE_WORLD_EXPLOSION_REVERT_BLOCKS((townyWorld, change) -> {
      if (change.type == MigrationType.REPLACE) {
         townyWorld.setPlotManagementWildRevertMaterials(replaceAll((List)townyWorld.getPlotManagementWildRevertBlocks().stream().map(WorldMigrationAction::matName).collect(Collectors.toList()), change.key, change.value));
      } else {
         String var10001 = (String)townyWorld.getPlotManagementWildRevertBlocks().stream().map((type) -> {
            return type.getKey().toString();
         }).collect(Collectors.joining(","));
         townyWorld.setPlotManagementWildRevertMaterials(splitMats(var10001 + change.value));
      }

   }),
   UPDATE_WORLD_EXPLOSION_REVERT_ENTITIES((townyWorld, change) -> {
      if (change.type == MigrationType.REPLACE) {
         townyWorld.setPlotManagementWildRevertEntities(replaceAll((List)townyWorld.getPlotManagementWildRevertEntities().stream().map(WorldMigrationAction::entityName).collect(Collectors.toList()), change.key, change.value));
      } else {
         String var10001 = (String)townyWorld.getPlotManagementWildRevertEntities().stream().map((type) -> {
            return type.getKey().toString();
         }).collect(Collectors.joining(","));
         townyWorld.setPlotManagementWildRevertEntities(splitMats(var10001 + change.value));
      }

   }),
   UPDATE_WORLD_UNCLAIM_REVERT_ENTITIES((townyWorld, change) -> {
      if (change.type == MigrationType.REPLACE) {
         townyWorld.setUnclaimDeleteEntityTypes(replaceAll((List)townyWorld.getUnclaimDeleteEntityTypes().stream().map(WorldMigrationAction::entityName).collect(Collectors.toList()), change.key, change.value));
      } else {
         String var10001 = (String)townyWorld.getUnclaimDeleteEntityTypes().stream().map((type) -> {
            return type.getKey().toString();
         }).collect(Collectors.joining(","));
         townyWorld.setUnclaimDeleteEntityTypes(splitMats(var10001 + change.value));
      }

   });

   final BiConsumer<TownyWorld, Change> action;

   private WorldMigrationAction(BiConsumer<TownyWorld, Change> action) {
      this.action = action;
   }

   public BiConsumer<TownyWorld, Change> getAction() {
      return this.action;
   }

   private static List<String> splitMats(String string) {
      return Arrays.asList(string.split(","));
   }

   private static List<String> replaceAll(List<String> list, String oldValue, String newValue) {
      List<String> toReplace = new ArrayList(list);
      ListIterator iterator = toReplace.listIterator();

      while(iterator.hasNext()) {
         if (((String)iterator.next()).equalsIgnoreCase(oldValue)) {
            iterator.set(newValue);
         }
      }

      return toReplace;
   }

   private static String matName(Material material) {
      return material.getKey().getKey();
   }

   private static String entityName(EntityType entity) {
      return entity.getKey().getKey();
   }

   // $FF: synthetic method
   private static WorldMigrationAction[] $values() {
      return new WorldMigrationAction[]{UPDATE_WORLD_BLOCK_IGNORE, UPDATE_WORLD_DELETE_MAYOR, UPDATE_WORLD_UNCLAIM_DELETE, UPDATE_WILDERNESS_IGNORE_MATS, UPDATE_WORLD_EXPLOSION_REVERT_BLOCKS, UPDATE_WORLD_EXPLOSION_REVERT_ENTITIES, UPDATE_WORLD_UNCLAIM_REVERT_ENTITIES};
   }
}
