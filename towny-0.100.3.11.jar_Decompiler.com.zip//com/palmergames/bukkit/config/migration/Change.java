package com.palmergames.bukkit.config.migration;

class Change {
   MigrationType type;
   String path;
   String key;
   String value;
   WorldMigrationAction worldAction;

   public String toString() {
      return "Change{type=" + this.type + ", key=" + this.path + ", value='" + this.value + ", worldAction='" + this.worldAction + "'}";
   }
}
