package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyTimerHandler;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.utils.CombatUtil;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.Iterator;
import org.bukkit.NamespacedKey;
import org.bukkit.Server;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason;

public class HealthRegenTimerTask extends TownyTimerTask {
   private final Server server;

   public HealthRegenTimerTask(Towny plugin, Server server) {
      super(plugin);
      this.server = server;
   }

   public void run() {
      Iterator var1;
      Player player;
      if (this.plugin.isFolia()) {
         var1 = this.server.getOnlinePlayers().iterator();

         while(var1.hasNext()) {
            player = (Player)var1.next();
            this.plugin.getScheduler().run((Entity)player, (Runnable)(() -> {
               this.evaluatePlayer(player);
            }));
         }
      } else {
         var1 = this.server.getOnlinePlayers().iterator();

         while(var1.hasNext()) {
            player = (Player)var1.next();
            this.evaluatePlayer(player);
         }
      }

   }

   public void evaluatePlayer(Player player) {
      if (!(player.getHealth() <= 0.0D)) {
         if (TownyAPI.getInstance().isTownyWorld(player.getWorld())) {
            Town town = TownyAPI.getInstance().getTown(player);
            if (town != null) {
               if (this.playerAllowedToHealHere(town, TownyAPI.getInstance().getTownBlock(player))) {
                  this.evaluateHealth(player);
               }

            }
         }
      }
   }

   private boolean playerAllowedToHealHere(Town playersTown, TownBlock tbAtPlayer) {
      if (tbAtPlayer == null) {
         return false;
      } else {
         Town townAtPlayer = tbAtPlayer.getTownOrNull();
         return townAtPlayer != null && !townAtPlayer.hasActiveWar() && CombatUtil.isAlly(townAtPlayer, playersTown) && !tbAtPlayer.getType().equals(TownBlockType.ARENA);
      }
   }

   private void evaluateHealth(Player player) {
      if (TownySettings.preventSaturationLoss() && player.getSaturation() != 1.0F) {
         player.setSaturation(1.0F);
      }

      double currentHP = player.getHealth();
      double futureHP = currentHP + 1.0D;
      double maxHP = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
      double gained = futureHP > maxHP ? 1.0D - (futureHP - maxHP) : 1.0D;
      if (!(gained <= 0.0D)) {
         this.plugin.getScheduler().run((Entity)player, (Runnable)(() -> {
            this.tryIncreaseHealth(player, currentHP, maxHP, gained);
         }));
      }
   }

   private void tryIncreaseHealth(Player player, double currentHealth, double maxHealth, double gained) {
      EntityRegainHealthEvent event = new EntityRegainHealthEvent(player, gained, RegainReason.REGEN);
      if (!BukkitTools.isEventCancelled(event)) {
         player.setHealth(Math.min(maxHealth, event.getAmount() + currentHealth));
      }
   }

   static {
      TownySettings.addReloadListener(NamespacedKey.fromString("towny:health-regen-task"), () -> {
         TownyTimerHandler.toggleHealthRegen(TownySettings.hasHealthRegen());
      });
   }
}
