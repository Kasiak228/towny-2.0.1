package com.palmergames.bukkit.towny.tasks;

import com.google.gson.JsonParser;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyUpdateChecker;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.util.Colors;
import com.palmergames.bukkit.util.Version;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class UpdateCheckerTask implements Runnable {
   private final Towny towny;

   public UpdateCheckerTask(Towny towny) {
      this.towny = towny;
   }

   public void run() {
      this.towny.getLogger().info(Translation.of("msg_checking_for_updates"));

      try {
         URL url = new URL("https://api.github.com/repos/TownyAdvanced/Towny/releases");
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));

         try {
            try {
               Version latestVersion = Version.fromString((new JsonParser()).parse(reader).getAsJsonArray().get(0).getAsJsonObject().get("tag_name").getAsString());
               boolean upToDate = Version.fromString(this.towny.getVersion()).isNewerThanOrEquals(latestVersion);
               if (!upToDate) {
                  TownyUpdateChecker.setUpdate(true);
                  TownyUpdateChecker.setNewVersion(latestVersion);
                  this.towny.getLogger().info(Colors.strip(Translation.of("msg_new_update_available", latestVersion, this.towny.getVersion())));
                  this.towny.getLogger().info(Translation.of("msg_download_here", "https://github.com/TownyAdvanced/Towny/releases/tag/" + latestVersion));
               } else {
                  this.towny.getLogger().info(Translation.of("msg_no_new_updates"));
                  TownyUpdateChecker.setCheckedSuccessfully(true);
               }
            } catch (Exception var7) {
            }
         } catch (Throwable var8) {
            try {
               reader.close();
            } catch (Throwable var6) {
               var8.addSuppressed(var6);
            }

            throw var8;
         }

         reader.close();
      } catch (IOException var9) {
         this.towny.getLogger().info(Translation.of("msg_no_new_updates"));
      }

   }
}
