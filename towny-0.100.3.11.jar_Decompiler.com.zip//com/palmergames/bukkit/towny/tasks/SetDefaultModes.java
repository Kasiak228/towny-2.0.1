package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.permissions.PermissionNodes;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.TimerTask;

public class SetDefaultModes extends TimerTask {
   protected String name;
   protected boolean notify;

   public SetDefaultModes(String name, boolean notify) {
      this.name = name;
      this.notify = notify;
   }

   public void run() {
      if (BukkitTools.isOnline(this.name)) {
         try {
            TownyUniverse townyUniverse = TownyUniverse.getInstance();
            String modeString = townyUniverse.getPermissionSource().getPlayerPermissionStringNode(this.name, PermissionNodes.TOWNY_DEFAULT_MODES.getNode());
            if (modeString.isEmpty()) {
               return;
            }

            String[] modes = modeString.split(",");
            Resident resident = townyUniverse.getResident(this.name);
            if (resident != null) {
               resident.setModes(modes, this.notify);
            }
         } catch (NullPointerException var5) {
         }

      }
   }
}
