package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.regen.PlotBlockData;
import com.palmergames.bukkit.towny.regen.TownyRegenAPI;
import com.palmergames.bukkit.towny.regen.WorldCoordEntityRemover;
import com.palmergames.bukkit.towny.regen.WorldCoordMaterialRemover;
import java.util.Iterator;

public class RepeatingTimerTask extends TownyTimerTask {
   private Long timerCounter = 0L;

   public RepeatingTimerTask(Towny plugin) {
      super(plugin);
   }

   public void run() {
      if (TownyRegenAPI.hasActiveRegenerations()) {
         this.revertAnotherBlockToWilderness();
      }

      if (WorldCoordEntityRemover.hasQueue()) {
         this.tryDeleteTownBlockEntityQueue();
      }

      if (WorldCoordMaterialRemover.hasQueue()) {
         this.tryDeleteTownBlockMaterials();
      }

   }

   private void revertAnotherBlockToWilderness() {
      if (Math.max(1L, TownySettings.getPlotManagementSpeed()) <= this.timerCounter = this.timerCounter + 1L) {
         Iterator var1 = TownyRegenAPI.getActivePlotBlockDatas().iterator();

         while(var1.hasNext()) {
            PlotBlockData plotBlockData = (PlotBlockData)var1.next();
            if (plotBlockData != null) {
               this.plugin.getScheduler().run(plotBlockData.getWorldCoord().getLowerMostCornerLocation(), () -> {
                  if (!plotBlockData.restoreNextBlock()) {
                     TownyRegenAPI.finishPlotBlockData(plotBlockData);
                  }

               });
            }
         }

         this.timerCounter = 0L;
      }
   }

   private void tryDeleteTownBlockEntityQueue() {
      if (WorldCoordEntityRemover.getActiveQueueSize() < 10) {
         WorldCoord wc = WorldCoordEntityRemover.getWorldCoordFromQueue();
         if (wc != null) {
            WorldCoordEntityRemover.doDeleteTownBlockEntities(wc);
         }
      }
   }

   private void tryDeleteTownBlockMaterials() {
      if (WorldCoordMaterialRemover.getActiveQueueSize() < 10) {
         WorldCoord wc = WorldCoordMaterialRemover.getWorldCoordFromQueue();
         if (wc != null) {
            this.plugin.getScheduler().runAsync(() -> {
               WorldCoordMaterialRemover.queueUnclaimMaterialsDeletion(wc);
            });
         }
      }
   }
}
