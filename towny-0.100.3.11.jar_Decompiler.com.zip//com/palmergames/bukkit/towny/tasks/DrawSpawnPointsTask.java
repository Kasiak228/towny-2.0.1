package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyTimerHandler;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.object.SpawnPoint;
import java.util.Iterator;
import org.bukkit.NamespacedKey;

public class DrawSpawnPointsTask extends TownyTimerTask {
   public DrawSpawnPointsTask(Towny plugin) {
      super(plugin);
   }

   public void run() {
      Iterator var1 = TownyUniverse.getInstance().getSpawnPoints().values().iterator();

      while(var1.hasNext()) {
         SpawnPoint spawnPoint = (SpawnPoint)var1.next();
         spawnPoint.drawParticle();
      }

   }

   static {
      TownySettings.addReloadListener(NamespacedKey.fromString("towny:spawnpoint-task"), () -> {
         TownyTimerHandler.toggleDrawSpointsTask(TownySettings.getVisualizedSpawnPointsEnabled());
      });
   }
}
