package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyTimerHandler;
import com.palmergames.bukkit.towny.event.teleport.CancelledTownyTeleportEvent;
import com.palmergames.bukkit.towny.event.teleport.SuccessfulTownyTeleportEvent;
import com.palmergames.bukkit.towny.object.EconomyHandler;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TeleportRequest;
import com.palmergames.bukkit.towny.object.TeleportWarmupParticle;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.towny.object.economy.Account;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.paperlib.PaperLib;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TeleportWarmupTimerTask extends TownyTimerTask {
   private static final Map<Resident, TeleportRequest> TELEPORT_QUEUE = new ConcurrentHashMap();

   public TeleportWarmupTimerTask(Towny plugin) {
      super(plugin);
   }

   public void run() {
      long currentTime = System.currentTimeMillis();
      int teleportWarmupTime = TownySettings.getTeleportWarmupTime();
      Iterator iterator = TELEPORT_QUEUE.entrySet().iterator();

      while(iterator.hasNext()) {
         Entry<Resident, TeleportRequest> next = (Entry)iterator.next();
         Resident resident = (Resident)next.getKey();
         TeleportRequest request = (TeleportRequest)next.getValue();
         long teleportTime = request.requestTime() + (long)teleportWarmupTime * 1000L;
         if (currentTime > teleportTime) {
            iterator.remove();
            Player player = resident.getPlayer();
            if (player != null) {
               PaperLib.teleportAsync(player, request.destinationLocation(), TeleportCause.COMMAND);
               BukkitTools.fireEvent(new SuccessfulTownyTeleportEvent(resident, request.destinationLocation(), request.teleportCost()));
               if (request.cooldown() > 0) {
                  CooldownTimerTask.addCooldownTimer(resident.getName(), "teleport", request.cooldown());
               }
            }
         } else {
            long millis = teleportTime - currentTime;
            int seconds = (int)Math.max(1L, millis / 1000L);
            if (TownySettings.isTeleportWarmupUsingTitleMessage() && millis >= 1000L) {
               String title = TownySettings.isMovementCancellingSpawnWarmup() ? Translatable.of("teleport_warmup_title_dont_move").forLocale(resident) : "";
               String subtitle = Translatable.of("teleport_warmup_subtitle_seconds_remaining", seconds).forLocale(resident);
               resident.getPlayer().sendTitle(title, subtitle, 0, 25, seconds == 1 ? 15 : 0);
            }

            if (TownySettings.isTeleportWarmupShowingParticleEffect()) {
               double progress = (double)(teleportWarmupTime - seconds) / (double)teleportWarmupTime;
               double offset = 2.0D + progress * -2.0D;
               new TeleportWarmupParticle(resident.getPlayer().getLocation().add(0.0D, offset, 0.0D));
            }
         }
      }

   }

   public static void requestTeleport(Resident resident, Location spawnLoc) {
      requestTeleport(resident, spawnLoc, 0);
   }

   public static void requestTeleport(Resident resident, Location spawnLoc, int cooldown) {
      requestTeleport(resident, spawnLoc, cooldown, (Account)null, 0.0D);
   }

   public static void requestTeleport(@NotNull Resident resident, @NotNull Location destination, int cooldown, @Nullable Account teleportAccount, double teleportCost) {
      TeleportRequest request = TeleportRequest.teleportRequest(System.currentTimeMillis(), destination, cooldown, teleportCost, teleportAccount);
      TELEPORT_QUEUE.put(resident, request);
   }

   @Contract("null -> false")
   public static boolean abortTeleportRequest(@Nullable Resident resident) {
      return abortTeleportRequest(resident, CancelledTownyTeleportEvent.CancelledTeleportReason.UNKNOWN);
   }

   @Contract("null -> false")
   public static boolean abortTeleportRequest(@Nullable Resident resident, CancelledTownyTeleportEvent.CancelledTeleportReason reason) {
      if (resident == null) {
         return false;
      } else {
         TeleportRequest request = (TeleportRequest)TELEPORT_QUEUE.remove(resident);
         if (request == null) {
            return false;
         } else {
            if (request.teleportCost() != 0.0D && TownyEconomyHandler.isActive() && request.teleportAccount() != null) {
               TownyEconomyHandler.economyExecutor().execute(() -> {
                  request.teleportAccount().payTo(request.teleportCost(), (EconomyHandler)resident, Translation.of("msg_cost_spawn_refund"));
               });
               TownyMessaging.sendMsg(resident, Translatable.of("msg_cost_spawn_refund"));
            }

            BukkitTools.fireEvent(new CancelledTownyTeleportEvent(resident, request.destinationLocation(), request.teleportCost(), reason));
            return true;
         }
      }
   }

   public static boolean hasTeleportRequest(@NotNull Resident resident) {
      return TELEPORT_QUEUE.containsKey(resident);
   }

   public static TeleportRequest getTeleportRequest(@NotNull Resident resident) {
      return (TeleportRequest)TELEPORT_QUEUE.get(resident);
   }

   static {
      TownySettings.addReloadListener(NamespacedKey.fromString("towny:warmup-task"), () -> {
         TownyTimerHandler.toggleTeleportWarmup(TownySettings.getTeleportWarmupTime() > 0);
      });
   }
}
