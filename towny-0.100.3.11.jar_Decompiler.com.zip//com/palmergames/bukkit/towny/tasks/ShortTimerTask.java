package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.event.time.NewShortTimeEvent;
import com.palmergames.bukkit.towny.regen.TownyRegenAPI;
import com.palmergames.bukkit.util.BukkitTools;

public class ShortTimerTask extends TownyTimerTask {
   public ShortTimerTask(Towny plugin) {
      super(plugin);
   }

   public void run() {
      if (TownyRegenAPI.getPlotChunks().size() < 20 && TownyRegenAPI.regenQueueHasAvailable()) {
         TownyRegenAPI.getWorldCoordFromQueueForRegeneration();
      }

      BukkitTools.fireEvent(new NewShortTimeEvent(System.currentTimeMillis()));
   }
}
