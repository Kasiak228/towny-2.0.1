package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.object.Resident;
import java.util.ArrayList;
import java.util.Iterator;

public class NPCCleanupTask implements Runnable {
   public void run() {
      Iterator var1 = (new ArrayList(TownyUniverse.getInstance().getResidents())).iterator();

      while(var1.hasNext()) {
         Resident resident = (Resident)var1.next();
         if (resident.isNPC() && !resident.hasTown()) {
            TownyUniverse.getInstance().getDataSource().removeResident(resident);
         }
      }

   }
}
