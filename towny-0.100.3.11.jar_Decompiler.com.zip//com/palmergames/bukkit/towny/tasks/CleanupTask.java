package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.util.FileMgmt;
import java.io.File;

public class CleanupTask implements Runnable {
   private String dataFolderPath;

   public CleanupTask() {
      String var10001 = TownyUniverse.getInstance().getRootFolder();
      this.dataFolderPath = var10001 + File.separator + "data" + File.separator;
   }

   public void run() {
      this.cleanupBackups();
      this.cleanupPlotBlockData();
   }

   private void cleanupBackups() {
      long deleteAfter = TownySettings.getBackupLifeLength();
      if (deleteAfter >= 0L) {
         Towny.getPlugin().getLogger().info("Cleaning up old backups...");
         String var10002 = TownyUniverse.getInstance().getRootFolder();
         if (FileMgmt.deleteOldBackups(new File(var10002 + File.separator + "backup"), deleteAfter)) {
            Towny.getPlugin().getLogger().info("Successfully cleaned backups.");
         } else {
            Towny.getPlugin().getLogger().info("Could not delete old backups.");
         }
      }

   }

   private void cleanupPlotBlockData() {
      File plotBlockDataFolder = new File(this.dataFolderPath + "plot-block-data");
      File[] worldFolders = plotBlockDataFolder.listFiles(File::isDirectory);
      File[] var3 = worldFolders;
      int var4 = worldFolders.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         File worldfolder = var3[var5];
         String var10002 = this.dataFolderPath;
         File worldFolder = new File(var10002 + "plot-block-data" + File.separator + worldfolder.getName());
         File[] plotBlockDataFiles = worldFolder.listFiles((file) -> {
            return file.getName().endsWith(".data");
         });
         File[] var9 = plotBlockDataFiles;
         int var10 = plotBlockDataFiles.length;

         for(int var11 = 0; var11 < var10; ++var11) {
            File plotBlockDataFile = var9[var11];
            String var10001 = plotBlockDataFile.getParent();
            FileMgmt.zipFile(plotBlockDataFile, var10001 + File.separator + plotBlockDataFile.getName().replace("data", "zip"));
            FileMgmt.deleteFile(plotBlockDataFile);
         }
      }

   }
}
