package com.palmergames.bukkit.towny.tasks;

import com.palmergames.util.FileMgmt;
import java.io.File;

public class DeleteFileTask implements Runnable {
   private final File file;
   private final boolean permanent;

   public DeleteFileTask(File file, boolean permanent) {
      this.file = file;
      this.permanent = permanent;
   }

   public void run() {
      if (this.file.exists()) {
         if (this.permanent) {
            this.file.delete();
         } else {
            FileMgmt.moveFile(this.file, "deleted");
         }

      }
   }
}
