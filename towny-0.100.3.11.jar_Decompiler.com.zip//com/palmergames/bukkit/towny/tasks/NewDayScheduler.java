package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.scheduling.ScheduledTask;
import com.palmergames.bukkit.towny.scheduling.impl.FoliaTaskScheduler;
import com.palmergames.util.TimeMgmt;
import java.util.concurrent.TimeUnit;
import org.bukkit.NamespacedKey;

public class NewDayScheduler extends TownyTimerTask {
   private static long newDayInterval = -1L;
   private static ScheduledTask scheduleTask;
   private static ScheduledTask newDayTask;

   public NewDayScheduler(Towny plugin) {
      super(plugin);
   }

   public void run() {
      logTime();
      cancelScheduledNewDay();
      newDayInterval = TownySettings.getDayInterval();
      long secondsUntilNextNewDay = TimeMgmt.townyTime();
      if (!(this.plugin.getScheduler() instanceof FoliaTaskScheduler) && secondsUntilNextNewDay >= TimeUnit.MINUTES.toSeconds(2L)) {
         scheduleTask = this.plugin.getScheduler().runLater((Runnable)(new NewDayScheduler(this.plugin)), secondsUntilNextNewDay / 2L * 20L);
         TownyMessaging.sendDebugMsg("Re-evaluation of New Day time scheduled for: " + TimeMgmt.formatCountdownTime(secondsUntilNextNewDay / 2L) + " from now.");
      } else {
         TownyMessaging.sendDebugMsg("New Day time finalized for: " + TimeMgmt.formatCountdownTime(secondsUntilNextNewDay) + " from now.");
         this.scheduleUpComingNewDay(secondsUntilNextNewDay);
      }

   }

   private void scheduleUpComingNewDay(long secondsUntilNextNewDay) {
      newDayTask = this.plugin.getScheduler().runAsyncLater(() -> {
         TownyEconomyHandler.economyExecutor().execute(new DailyTimerTask(this.plugin));
      }, secondsUntilNextNewDay * 20L);
   }

   public static boolean isNewDaySchedulerRunning() {
      return scheduleTask != null && !scheduleTask.isCancelled();
   }

   public static boolean isNewDayScheduled() {
      return newDayTask != null && !newDayTask.isCancelled();
   }

   public static boolean isNewDayRunning() {
      return newDayTask != null && newDayTask.isCurrentlyRunning();
   }

   public static void cancelScheduledNewDay() {
      if (scheduleTask != null) {
         scheduleTask.cancel();
         scheduleTask = null;
      }

      if (newDayTask != null) {
         newDayTask.cancel();
         newDayTask = null;
      }

   }

   public static void newDay() {
      TownyEconomyHandler.economyExecutor().execute(new DailyTimerTask(Towny.getPlugin()));
   }

   public static void logTime() {
      Towny.getPlugin().getLogger().info("Time until a New Day: " + TimeMgmt.formatCountdownTime(TimeMgmt.townyTime()));
   }

   static {
      TownySettings.addReloadListener(NamespacedKey.fromString("towny:new-day-scheduler"), (config) -> {
         if (newDayInterval != TownySettings.getDayInterval() && isNewDaySchedulerRunning()) {
            cancelScheduledNewDay();
            (new NewDayScheduler(Towny.getPlugin())).run();
         }

      });
      scheduleTask = null;
      newDayTask = null;
   }
}
