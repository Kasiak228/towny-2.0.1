package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.EconomyHandler;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PlotClaim implements Runnable {
   Towny plugin;
   private final Player player;
   private final Resident resident;
   private final List<WorldCoord> selection;
   private final boolean claim;
   private final boolean admin;
   private final boolean groupClaim;

   public PlotClaim(Towny plugin, Player player, Resident resident, List<WorldCoord> selection, boolean claim, boolean admin, boolean groupClaim) {
      this.plugin = plugin;
      this.player = player;
      this.resident = resident;
      this.selection = selection;
      this.claim = claim;
      this.admin = admin;
      this.groupClaim = groupClaim;
   }

   public void run() {
      if (this.player != null) {
         if (this.claim) {
            TownyMessaging.sendMsg((CommandSender)this.player, (Translatable)Translatable.of("msg_process_claim"));
         } else {
            TownyMessaging.sendMsg((CommandSender)this.player, (Translatable)Translatable.of("msg_process_unclaim"));
         }
      }

      if (this.selection == null && !this.claim) {
         this.residentUnclaimAll();
      } else if (this.groupClaim) {
         this.handleGroupClaim((WorldCoord)this.selection.get(0));
      } else if (this.admin) {
         this.adminClaim(this.selection);
      } else if (!this.claim) {
         this.residentUnclaim(this.selection);
      } else if (this.claim) {
         this.residentClaim(this.selection);
      }
   }

   private void handleGroupClaim(WorldCoord worldCoord) {
      TownBlock townBlock = worldCoord.getTownBlockOrNull();
      if (townBlock != null && townBlock.hasPlotObjectGroup()) {
         PlotGroup group = townBlock.getPlotObjectGroup();

         try {
            this.testMaxPlotsOrThrow(group.getTownBlocks().size());
            double groupPrice = group.getPrice();
            if (TownyEconomyHandler.isActive() && groupPrice > 0.0D) {
               EconomyHandler seller = group.hasResident() ? group.getResident() : group.getTown();
               String message = String.format("Plot Group - Buy From %s: %s", group.hasResident() ? "Seller" : "Town", ((EconomyHandler)seller).getName());
               if (seller instanceof Town) {
                  Town town = (Town)seller;
                  double bankcap = town.getBankCap();
                  if (bankcap > 0.0D && groupPrice + town.getAccount().getHoldingBalance() > bankcap) {
                     throw new TownyException(Translatable.of("msg_err_deposit_capped", bankcap));
                  }
               }

               if (!this.resident.getAccount().payTo(groupPrice, (EconomyHandler)seller, message)) {
                  throw new TownyException(Translatable.of("msg_no_money_purchase_plot"));
               }
            }
         } catch (TownyException var11) {
            TownyMessaging.sendErrorMsg((Object)this.player, (String)var11.getMessage(this.player));
            return;
         } catch (Exception var12) {
            TownyMessaging.sendErrorMsg((Object)this.player, (String)var12.getMessage());
            return;
         }

         this.residentGroupClaim(group);
         group.setResident(this.resident);
         group.setPrice(-1.0D);
         TownyMessaging.sendPrefixedTownMessage(townBlock.getTownOrNull(), Translatable.of("msg_player_successfully_bought_group_x", this.player.getName(), group.getName()));
         group.save();
         this.finishWithMessage();
      }
   }

   private void residentGroupClaim(PlotGroup group) {
      Town town = group.getTown();
      Resident owner = group.getResident();
      if (owner != null && group.getPrice() > 0.0D) {
         TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_buy_resident_plot_group", this.resident.getName(), owner.getName(), group.getPrice()));
      }

      Iterator var4 = group.getTownBlocks().iterator();

      while(var4.hasNext()) {
         TownBlock townBlock = (TownBlock)var4.next();
         this.claimTownBlockForResident(townBlock);
      }

   }

   private void residentClaim(List<WorldCoord> selection) {
      Iterator var2 = selection.iterator();

      while(var2.hasNext()) {
         WorldCoord worldCoord = (WorldCoord)var2.next();

         try {
            if (!this.residentClaim(worldCoord)) {
               this.selection.remove(worldCoord);
            }
         } catch (TownyException var5) {
            TownyMessaging.sendErrorMsg((Object)this.player, (String)var5.getMessage(this.player));
         }
      }

      this.finishWithMessage();
   }

   private boolean residentClaim(WorldCoord worldCoord) throws TownyException {
      TownBlock townBlock = worldCoord.getTownBlockOrNull();
      if (townBlock == null) {
         throw new TownyException(Translatable.of("msg_err_not_part_town"));
      } else if (townBlock.getPlotPrice() == -1.0D) {
         throw new TownyException(Translatable.of("msg_err_plot_nfs"));
      } else {
         Town town = townBlock.getTownOrNull();
         if (!townBlock.getType().equals(TownBlockType.EMBASSY) && !town.hasResident(this.resident)) {
            throw new TownyException(Translatable.of("msg_err_not_part_town"));
         } else {
            this.testMaxPlotsOrThrow(1);
            double price = townBlock.getPlotPrice();
            if (TownyEconomyHandler.isActive() && price > 0.0D) {
               EconomyHandler seller = townBlock.hasResident() ? townBlock.getResidentOrNull() : townBlock.getTownOrNull();
               String message = String.format("Plot - Buy From %s: %s", townBlock.hasResident() ? "Seller" : "Town", ((EconomyHandler)seller).getName());
               if (seller instanceof Town) {
                  double bankcap = town.getBankCap();
                  if (bankcap > 0.0D && price + town.getAccount().getHoldingBalance() > bankcap) {
                     throw new TownyException(Translatable.of("msg_err_deposit_capped", bankcap));
                  }
               }

               if (!this.resident.getAccount().payTo(price, (EconomyHandler)seller, message)) {
                  throw new TownyException(Translatable.of("msg_no_money_purchase_plot"));
               }
            }

            Resident owner = townBlock.getResidentOrNull();
            if (owner != null && price > 0.0D) {
               TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_buy_resident_plot", this.resident.getName(), owner.getName(), townBlock.getPlotPrice()));
            }

            this.claimTownBlockForResident(townBlock);
            return true;
         }
      }
   }

   private void claimTownBlockForResident(TownBlock townBlock) {
      townBlock.setResident(this.resident);
      townBlock.setPlotPrice(-1.0D);
      townBlock.setType(townBlock.getType());
      townBlock.save();
      this.plugin.updateCache(townBlock.getWorldCoord());
   }

   private void residentUnclaimAll() {
      this.residentUnclaim((List)(new ArrayList(this.resident.getTownBlocks())).stream().map(TownBlock::getWorldCoord).collect(Collectors.toList()));
   }

   private void residentUnclaim(List<WorldCoord> selection) {
      Iterator var2 = selection.iterator();

      while(var2.hasNext()) {
         WorldCoord coord = (WorldCoord)var2.next();
         if (TownyAPI.getInstance().isTownyWorld(coord.getBukkitWorld()) && !this.residentUnclaim(coord)) {
            TownyMessaging.sendErrorMsg((CommandSender)this.player, (Translatable)Translatable.of("msg_not_own_place"));
            this.selection.remove(coord);
         }
      }

      this.finishWithMessage();
   }

   private boolean residentUnclaim(WorldCoord worldCoord) {
      if (worldCoord.isWilderness()) {
         return false;
      } else {
         TownBlock townBlock = worldCoord.getTownBlockOrNull();
         townBlock.removeResident();
         townBlock.setPlotPrice(townBlock.getTownOrNull().getPlotTypePrice(townBlock.getType()));
         townBlock.setType(townBlock.getType());
         townBlock.save();
         this.plugin.updateCache(worldCoord);
         return true;
      }
   }

   private void adminClaim(List<WorldCoord> selection) {
      Iterator var2 = selection.iterator();

      while(var2.hasNext()) {
         WorldCoord wc = (WorldCoord)var2.next();
         if (!this.adminClaim(wc)) {
            TownyMessaging.sendErrorMsg((CommandSender)this.player, (Translatable)Translatable.of("msg_not_claimed", wc.toString()));
            this.selection.remove(wc);
         }
      }

      this.finishWithMessage();
   }

   private boolean adminClaim(WorldCoord worldCoord) {
      if (worldCoord.isWilderness()) {
         return false;
      } else {
         TownBlock townBlock = worldCoord.getTownBlockOrNull();
         townBlock.setPlotPrice(-1.0D);
         townBlock.setResident(this.resident);
         townBlock.setType(townBlock.getType());
         townBlock.save();
         this.plugin.updateCache(worldCoord);
         TownyMessaging.sendMsg(this.resident, Translatable.of("msg_admin_has_given_you_a_plot", worldCoord.toString()));
         return true;
      }
   }

   private void finishWithMessage() {
      if (this.player != null) {
         if (this.claim) {
            if (this.selection != null && this.selection.size() > 0) {
               TownyMessaging.sendMsg((CommandSender)this.player, (Translatable)Translatable.of("msg_claimed").append(" ").append(this.selection.size() > 5 ? Translatable.of("msg_total_townblocks").forLocale((CommandSender)this.player) + this.selection.size() : Arrays.toString(this.selection.toArray(new WorldCoord[0]))));
            } else {
               TownyMessaging.sendMsg((CommandSender)this.player, (Translatable)Translatable.of("msg_not_claimed_1"));
            }
         } else if (this.selection != null) {
            TownyMessaging.sendMsg((CommandSender)this.player, (Translatable)Translatable.of("msg_unclaimed").append(" ").append(this.selection.size() > 5 ? Translatable.of("msg_total_townblocks").forLocale((CommandSender)this.player) + this.selection.size() : Arrays.toString(this.selection.toArray(new WorldCoord[0]))));
         } else {
            TownyMessaging.sendMsg((CommandSender)this.player, (Translatable)Translatable.of("msg_unclaimed"));
         }

      }
   }

   private void testMaxPlotsOrThrow(int plotsToBuy) throws TownyException {
      int maxPlots = TownySettings.getMaxResidentPlots(this.resident);
      int extraPlots = TownySettings.getMaxResidentExtraPlots(this.resident);
      if (maxPlots != -1) {
         maxPlots += extraPlots;
      }

      if (maxPlots >= 0 && this.resident.getTownBlocks().size() + plotsToBuy > maxPlots) {
         throw new TownyException(Translatable.of("msg_max_plot_own", maxPlots));
      }
   }
}
