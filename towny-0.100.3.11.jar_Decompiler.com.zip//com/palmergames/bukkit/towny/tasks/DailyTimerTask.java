package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.DeleteNationEvent;
import com.palmergames.bukkit.towny.event.DeleteTownEvent;
import com.palmergames.bukkit.towny.event.NewDayEvent;
import com.palmergames.bukkit.towny.event.PreNewDayEvent;
import com.palmergames.bukkit.towny.event.time.dailytaxes.NewDayTaxAndUpkeepPreCollectionEvent;
import com.palmergames.bukkit.towny.event.time.dailytaxes.PreTownPaysNationTaxEvent;
import com.palmergames.bukkit.towny.event.time.dailytaxes.TownPaysNationConqueredTaxEvent;
import com.palmergames.bukkit.towny.object.EconomyHandler;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.permissions.TownyPerms;
import com.palmergames.bukkit.towny.utils.MoneyUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.StringMgmt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DailyTimerTask extends TownyTimerTask {
   private static final Object NEW_DAY_LOCK = new Object();
   private double totalTownUpkeep = 0.0D;
   private double totalNationUpkeep = 0.0D;
   private double taxCollected = 0.0D;
   private double conqueredTaxCollected = 0.0D;
   private final List<String> bankruptedTowns = new ArrayList();
   private final List<String> removedTowns = new ArrayList();
   private final List<String> removedNations = new ArrayList();

   public DailyTimerTask(Towny plugin) {
      super(plugin);
   }

   public void run() {
      synchronized(NEW_DAY_LOCK) {
         this.doNewDay();
      }
   }

   public void doNewDay() {
      long start = System.currentTimeMillis();
      this.totalTownUpkeep = 0.0D;
      this.totalNationUpkeep = 0.0D;
      this.taxCollected = 0.0D;
      this.bankruptedTowns.clear();
      this.removedTowns.clear();
      this.removedNations.clear();
      BukkitTools.fireEvent(new PreNewDayEvent());
      TownyMessaging.sendDebugMsg("New Day");
      if (TownyEconomyHandler.isActive() && TownySettings.isTaxingDaily()) {
         if (!BukkitTools.isEventCancelled(new NewDayTaxAndUpkeepPreCollectionEvent())) {
            TownyMessaging.sendGlobalMessage(Translatable.of("msg_new_day_tax"));
            TownyMessaging.sendDebugMsg("Collecting Town Taxes");
            this.collectTownTaxes();
            TownyMessaging.sendDebugMsg("Collecting Nation Taxes");
            this.collectNationTaxes();
            TownyMessaging.sendDebugMsg("Collecting Town Costs");
            this.collectTownCosts();
            TownyMessaging.sendDebugMsg("Collecting Nation Costs");
            this.collectNationCosts();
         } else {
            TownyMessaging.sendGlobalMessage(Translatable.of("msg_new_day"));
         }
      } else {
         TownyMessaging.sendGlobalMessage(Translatable.of("msg_new_day"));
      }

      if (TownySettings.isDeletingOldResidents()) {
         this.plugin.getScheduler().runAsync((Runnable)(new ResidentPurge((CommandSender)null, TownySettings.getDeleteTime() * 1000L, TownySettings.isDeleteTownlessOnly(), (Town)null)));
      }

      this.plugin.getScheduler().runAsync((Runnable)(new NPCCleanupTask()));
      if (TownySettings.isNewDayDeleting0PlotTowns()) {
         List<String> deletedTowns = new ArrayList();
         Iterator var4 = this.universe.getTowns().iterator();

         while(var4.hasNext()) {
            Town town = (Town)var4.next();
            if (town.exists() && town.getTownBlocks().isEmpty()) {
               deletedTowns.add(town.getName());
               this.removedTowns.add(town.getName());
               this.universe.getDataSource().removeTown(town, DeleteTownEvent.Cause.NO_TOWNBLOCKS);
            }
         }

         if (!deletedTowns.isEmpty()) {
            TownyMessaging.sendGlobalMessage(Translatable.of("msg_the_following_towns_were_deleted_for_having_0_claims", String.join(", ", deletedTowns)));
         }
      }

      Iterator var6 = this.universe.getTowns().iterator();

      while(var6.hasNext()) {
         Town town = (Town)var6.next();
         if (town.exists() && town.isConquered()) {
            if (town.getConqueredDays() == 1) {
               this.plugin.getScheduler().run(() -> {
                  this.unconquer(town);
               });
            } else {
               town.setConqueredDays(town.getConqueredDays() - 1);
            }
         }
      }

      if (TownySettings.isBackingUpDaily()) {
         this.universe.performCleanupAndBackup();
      }

      BukkitTools.fireEvent(new NewDayEvent(this.bankruptedTowns, this.removedTowns, this.removedNations, this.totalTownUpkeep, this.totalNationUpkeep, start));
      TownyMessaging.sendDebugMsg("Finished New Day Code");
      TownyMessaging.sendDebugMsg("Universe Stats:");
      TownyMessaging.sendDebugMsg("    Residents: " + this.universe.getNumResidents());
      TownyMessaging.sendDebugMsg("    Towns: " + this.universe.getTowns().size());
      TownyMessaging.sendDebugMsg("    Nations: " + this.universe.getNumNations());
      var6 = this.universe.getTownyWorlds().iterator();

      while(var6.hasNext()) {
         TownyWorld world = (TownyWorld)var6.next();
         String var10000 = world.getName();
         TownyMessaging.sendDebugMsg("    " + var10000 + " (townblocks): " + world.getTownBlocks().size());
      }

      TownyMessaging.sendDebugMsg("Memory (Java Heap):");
      TownyMessaging.sendDebugMsg(String.format("%8d Mb (max)", Runtime.getRuntime().maxMemory() / 1024L / 1024L));
      TownyMessaging.sendDebugMsg(String.format("%8d Mb (total)", Runtime.getRuntime().totalMemory() / 1024L / 1024L));
      TownyMessaging.sendDebugMsg(String.format("%8d Mb (free)", Runtime.getRuntime().freeMemory() / 1024L / 1024L));
      TownyMessaging.sendDebugMsg(String.format("%8d Mb (used=total-free)", (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024L / 1024L));
      Towny.getPlugin().getLogger().info("Towny DailyTimerTask took " + (System.currentTimeMillis() - start) + "ms to process.");
      if (!NewDayScheduler.isNewDaySchedulerRunning()) {
         this.plugin.getScheduler().runLater((Runnable)(new NewDayScheduler(this.plugin)), 1200L);
      }

   }

   private void unconquer(Town town) {
      town.setConquered(false);
      town.setConqueredDays(0);
   }

   public void collectNationTaxes() {
      List<Nation> nations = new ArrayList(this.universe.getNations());
      ListIterator nationItr = nations.listIterator();

      while(nationItr.hasNext()) {
         this.taxCollected = 0.0D;
         Nation nation = (Nation)nationItr.next();
         if (nation.exists()) {
            this.collectNationTaxes(nation);
         }
      }

   }

   protected void collectNationTaxes(Nation nation) {
      double tax = nation.getTaxes();
      if (tax != 0.0D) {
         if (!(tax < 0.0D) || TownySettings.isNegativeNationTaxAllowed() && !nation.isTaxPercentage()) {
            List<String> newlyDelinquentTowns = new ArrayList();
            List<String> localTownsDestroyed = new ArrayList();
            List<Town> towns = new ArrayList(nation.getTowns());
            ListIterator townItr = towns.listIterator();

            while(true) {
               Town town;
               String result;
               do {
                  do {
                     if (!townItr.hasNext()) {
                        if (newlyDelinquentTowns != null && !newlyDelinquentTowns.isEmpty()) {
                           boolean bankruptcyenabled = TownySettings.isTownBankruptcyEnabled() && TownySettings.doBankruptTownsPayNationTax();
                           String msg1 = bankruptcyenabled ? "msg_town_bankrupt_by_nation_tax" : "msg_couldnt_pay_tax";
                           String msg2 = bankruptcyenabled ? "msg_town_bankrupt_by_nation_tax_multiple" : "msg_couldnt_pay_nation_tax_multiple";
                           if (newlyDelinquentTowns.size() == 1) {
                              TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of(msg1, newlyDelinquentTowns.get(0), Translatable.of("nation_sing")));
                           } else {
                              TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of(msg2).append(StringMgmt.join((Collection)newlyDelinquentTowns, ", ")));
                           }
                        }

                        if (localTownsDestroyed != null && !localTownsDestroyed.isEmpty()) {
                           if (localTownsDestroyed.size() == 1) {
                              TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_town_destroyed_by_nation_tax", localTownsDestroyed.get(0)));
                           } else {
                              TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_town_destroyed_by_nation_tax_multiple").append(StringMgmt.join((Collection)localTownsDestroyed, ", ")));
                           }
                        }

                        if (this.taxCollected != 0.0D) {
                           result = this.taxCollected > 0.0D ? "msg_tax_collected_from_towns" : "msg_tax_paid_to_towns";
                           TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of(result, this.prettyMoney(this.taxCollected)));
                           this.taxCollected = 0.0D;
                        }

                        if (this.conqueredTaxCollected > 0.0D) {
                           TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_tax_collected_from_conquered_towns", this.prettyMoney(this.conqueredTaxCollected)));
                           this.conqueredTaxCollected = 0.0D;
                        }

                        return;
                     }

                     town = (Town)townItr.next();
                  } while(!town.exists());
               } while(town.isCapital() && !TownySettings.doCapitalsPayNationTax());

               if (town.hasUpkeep() && !town.isRuined()) {
                  result = this.processTownPaysNationTax(town, nation);
                  if (!result.isEmpty()) {
                     byte var11 = -1;
                     switch(result.hashCode()) {
                     case 859923415:
                        if (result.equals("delinquent")) {
                           var11 = 1;
                        }
                        break;
                     case 1986762265:
                        if (result.equals("destroyed")) {
                           var11 = 0;
                        }
                     }

                     switch(var11) {
                     case 0:
                        localTownsDestroyed.add(town.getName());
                        break;
                     case 1:
                        newlyDelinquentTowns.add(town.getName());
                     }
                  }
               }
            }
         }
      }
   }

   private String processTownPaysNationTax(Town town, Nation nation) {
      double taxAmount = nation.getTaxes();
      double localConqueredTax = 0.0D;
      if (nation.isTaxPercentage()) {
         taxAmount = town.getAccount().getHoldingBalance() * taxAmount / 100.0D;
         taxAmount = Math.min(taxAmount, nation.getMaxPercentTaxAmount());
      }

      if (town.isConquered()) {
         TownPaysNationConqueredTaxEvent event = new TownPaysNationConqueredTaxEvent(town, nation, nation.getConqueredTax());
         if (!BukkitTools.isEventCancelled(event) && event.getConqueredTax() > 0.0D) {
            localConqueredTax = event.getConqueredTax();
            taxAmount += localConqueredTax;
         }
      }

      PreTownPaysNationTaxEvent event = new PreTownPaysNationTaxEvent(town, nation, taxAmount);
      if (BukkitTools.isEventCancelled(event)) {
         TownyMessaging.sendPrefixedTownMessage(town, event.getCancelMessage());
         return "";
      } else {
         taxAmount = event.getTax();
         if (taxAmount < 0.0D && !town.isConquered()) {
            this.payNationTaxToTown(nation, town, taxAmount);
            return "";
         } else {
            if (nation.getBankCap() != 0.0D && taxAmount + nation.getAccount().getHoldingBalance() > nation.getBankCap()) {
               taxAmount = nation.getBankCap() - nation.getAccount().getHoldingBalance();
            }

            if (taxAmount <= 0.0D) {
               return "";
            } else if (town.getAccount().canPayFromHoldings(taxAmount)) {
               town.getAccount().payTo(taxAmount, nation, String.format("Nation Tax to %s paid by %s.", nation.getName(), town.getName()));
               TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_payed_nation_tax", this.prettyMoney(taxAmount)));
               this.taxCollected += taxAmount;
               if (localConqueredTax > 0.0D) {
                  this.conqueredTaxCollected += localConqueredTax;
               }

               return "";
            } else if (TownySettings.isTownBankruptcyEnabled() && TownySettings.doBankruptTownsPayNationTax()) {
               boolean townWasBankrupt = town.isBankrupt();
               town.getAccount().setDebtCap(MoneyUtil.getEstimatedValueOfTown(town));
               if (town.getAccount().getHoldingBalance() - taxAmount < town.getAccount().getDebtCap() * -1.0D) {
                  if (TownySettings.isNationTaxKickingTownsThatReachDebtCap()) {
                     town.removeNation();
                     TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_your_town_couldnt_pay_the_nation_tax_of", this.prettyMoney(nation.getTaxes())));
                     return "delinquent";
                  }

                  taxAmount = town.getAccount().getDebtCap() - Math.abs(town.getAccount().getHoldingBalance());
               }

               town.getAccount().withdraw(taxAmount, String.format("Nation Tax paid to %s.", nation.getName()));
               nation.getAccount().deposit(taxAmount, String.format("Nation Tax paid by %s.", town.getName()));
               TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_payed_nation_tax_with_debt", this.prettyMoney(taxAmount)));
               this.taxCollected += taxAmount;
               if (localConqueredTax > 0.0D) {
                  this.conqueredTaxCollected += localConqueredTax;
               }

               if (!townWasBankrupt) {
                  town.setOpen(false);
                  town.save();
                  return "delinquent";
               } else {
                  return "";
               }
            } else if (TownySettings.doesNationTaxDeleteConqueredTownsWhichCannotPay() && town.isConquered()) {
               this.universe.getDataSource().removeTown(town, DeleteTownEvent.Cause.UPKEEP);
               return "destroyed";
            } else {
               town.removeNation();
               TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_your_town_couldnt_pay_the_nation_tax_of", this.prettyMoney(taxAmount)));
               return "delinquent";
            }
         }
      }
   }

   private void payNationTaxToTown(Nation nation, Town town, double tax) {
      if (nation.getAccount().canPayFromHoldings(tax)) {
         nation.getAccount().payTo(tax, town, "Nation Tax Payment To Town");
         this.taxCollected += tax;
      }
   }

   public void collectTownTaxes() {
      List<Town> towns = new ArrayList(this.universe.getTowns());
      ListIterator townItr = towns.listIterator();

      while(townItr.hasNext()) {
         this.taxCollected = 0.0D;
         Town town = (Town)townItr.next();
         if (town.exists() && !town.isRuined()) {
            this.collectTownTaxes(town);
         }
      }

   }

   protected void collectTownTaxes(Town town) {
      this.collectTownResidentTax(town);
      String msgSlug;
      if (this.taxCollected != 0.0D) {
         msgSlug = this.taxCollected > 0.0D ? "msg_tax_collected_from_residents" : "msg_tax_paid_to_residents";
         TownyMessaging.sendPrefixedTownMessage(town, Translatable.of(msgSlug, this.prettyMoney(this.taxCollected)));
         this.taxCollected = 0.0D;
      }

      this.collecTownPlotTax(town);
      if (this.taxCollected != 0.0D) {
         msgSlug = this.taxCollected > 0.0D ? "msg_tax_collected_from_plots" : "msg_tax_paid_to_residents_for_plots";
         TownyMessaging.sendPrefixedTownMessage(town, Translatable.of(msgSlug, this.prettyMoney(this.taxCollected)));
         this.taxCollected = 0.0D;
      }

   }

   private void collectTownResidentTax(Town town) {
      double tax = town.getTaxes();
      if (tax != 0.0D) {
         if (!(tax < 0.0D) || TownySettings.isNegativeTownTaxAllowed() && !town.isTaxPercentage()) {
            List<Resident> residents = new ArrayList(town.getResidents());
            ListIterator<Resident> residentItr = residents.listIterator();
            ArrayList removedResidents = new ArrayList();

            while(true) {
               while(true) {
                  Resident resident;
                  do {
                     if (!residentItr.hasNext()) {
                        if (removedResidents != null && !removedResidents.isEmpty()) {
                           if (removedResidents.size() == 1) {
                              TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_couldnt_pay_tax", removedResidents.get(0), Translatable.of("town_sing")));
                           } else {
                              TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_couldnt_pay_town_tax_multiple").append(StringMgmt.join((Collection)removedResidents, ", ")));
                           }
                        }

                        return;
                     }

                     resident = (Resident)residentItr.next();
                  } while(!resident.exists());

                  if (TownyPerms.getResidentPerms(resident).get("towny.tax_exempt") != Boolean.TRUE && !resident.isNPC() && (TownySettings.doMayorsPayTownTax() || !resident.isMayor())) {
                     if (!this.collectTownTaxFromResident(tax, resident, town) && !resident.isMayor()) {
                        removedResidents.add(resident.getName());
                     }
                  } else {
                     TownyMessaging.sendMsg(resident, Translatable.of("msg_tax_exempt"));
                  }
               }
            }
         }
      }
   }

   private boolean collectTownTaxFromResident(double tax, Resident resident, Town town) {
      if (tax < 0.0D) {
         this.payTownTaxToResidents(town, resident, tax);
         return true;
      } else if (town.isTaxPercentage()) {
         tax = resident.getAccount().getHoldingBalance() * tax / 100.0D;
         tax = Math.min(tax, town.getMaxPercentTaxAmount());
         if (town.getBankCap() != 0.0D && tax + town.getAccount().getHoldingBalance() > town.getBankCap()) {
            tax = town.getBankCap() - town.getAccount().getHoldingBalance();
         }

         if (tax == 0.0D) {
            return true;
         } else {
            resident.getAccount().payTo(tax, (EconomyHandler)town, String.format("Town Tax (Percentage) paid by %s.", resident.getName()));
            this.taxCollected += tax;
            return true;
         }
      } else {
         if (town.getBankCap() != 0.0D && tax + town.getAccount().getHoldingBalance() > town.getBankCap()) {
            tax = town.getBankCap() - town.getAccount().getHoldingBalance();
         }

         if (tax == 0.0D) {
            return true;
         } else if (resident.getAccount().canPayFromHoldings(tax)) {
            resident.getAccount().payTo(tax, (EconomyHandler)town, String.format("Town tax (FlatRate) paid by %s.", resident.getName()));
            this.taxCollected += tax;
            return true;
         } else {
            if (!resident.isMayor()) {
               TownyMessaging.sendMsg(resident, Translatable.of("msg_you_couldnt_pay_town_tax", this.prettyMoney(tax), town.getFormattedName()));
               resident.removeTown();
            }

            return false;
         }
      }
   }

   private void payTownTaxToResidents(Town town, Resident resident, double tax) {
      if (town.getAccount().canPayFromHoldings(tax)) {
         town.getAccount().payTo(tax, resident, "Town Tax Payment To Resident");
         this.taxCollected += tax;
      }
   }

   private void collecTownPlotTax(Town town) {
      List<TownBlock> townBlocks = new ArrayList(town.getTownBlocks());
      List<String> lostPlots = new ArrayList();
      ListIterator townBlockItr = townBlocks.listIterator();

      while(true) {
         TownBlock townBlock;
         double tax;
         Resident resident;
         do {
            do {
               do {
                  do {
                     do {
                        do {
                           do {
                              do {
                                 if (!townBlockItr.hasNext()) {
                                    if (lostPlots != null && !lostPlots.isEmpty()) {
                                       if (lostPlots.size() == 1) {
                                          TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_couldnt_pay_plot_taxes", lostPlots.get(0)));
                                       } else {
                                          TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_couldnt_pay_plot_taxes_multiple").append(StringMgmt.join((Collection)lostPlots, ", ")));
                                       }
                                    }

                                    return;
                                 }

                                 townBlock = (TownBlock)townBlockItr.next();
                                 tax = townBlock.getType().getTax(town);
                              } while(!townBlock.isTaxed());
                           } while(!townBlock.hasResident());
                        } while(tax == 0.0D);
                     } while(!TownySettings.isNegativePlotTaxAllowed() && tax < 1.0D);

                     resident = townBlock.getResidentOrNull();
                  } while(resident == null);
               } while(!resident.exists());
            } while(resident.isNPC());
         } while(town.hasResident(resident) && TownyPerms.getResidentPerms(resident).get("towny.tax_exempt") == Boolean.TRUE);

         if (tax < 0.0D) {
            this.payPlotTaxToResidents(Math.abs(tax), resident, town, townBlock.getTypeName());
         } else {
            if (town.getBankCap() != 0.0D && tax + town.getAccount().getHoldingBalance() > town.getBankCap()) {
               tax = town.getBankCap() - town.getAccount().getHoldingBalance();
            }

            if (tax != 0.0D && !this.collectPlotTaxFromResident(tax, resident, town, townBlock) && !lostPlots.contains(resident.getName())) {
               lostPlots.add(resident.getName());
            }
         }
      }
   }

   private boolean collectPlotTaxFromResident(double tax, Resident resident, Town town, TownBlock townBlock) {
      if (resident.getAccount().canPayFromHoldings(tax)) {
         resident.getAccount().payTo(tax, (EconomyHandler)town, String.format("Plot Tax (%s) paid by %s", townBlock.getTypeName(), resident.getName()));
         this.taxCollected += tax;
         return true;
      } else {
         TownyMessaging.sendMsg(resident, Translatable.of("msg_you_couldnt_pay_plot_tax", this.prettyMoney(tax), townBlock.toString()));
         townBlock.removeResident();
         if (TownySettings.doesPlotTaxNonPaymentSetPlotForSale()) {
            townBlock.setPlotPrice(town.getPlotTypePrice(townBlock.getType()));
         } else {
            townBlock.setPlotPrice(-1.0D);
         }

         townBlock.setType(townBlock.getType());
         townBlock.save();
         return false;
      }
   }

   private void payPlotTaxToResidents(double tax, Resident resident, Town town, String typeName) {
      if (town.getAccount().canPayFromHoldings(tax)) {
         town.getAccount().payTo(tax, resident, String.format("Plot Tax Payment To Resident (%s)", typeName));
         this.taxCollected += tax;
      }
   }

   public void collectTownCosts() {
      List<Town> towns = new ArrayList(this.universe.getTowns());
      ListIterator townItr = towns.listIterator();

      while(townItr.hasNext()) {
         Town town = (Town)townItr.next();
         if (town.exists() && town.hasUpkeep() && !town.isRuined()) {
            this.processTownUpkeep(town);
         }
      }

      String msg1 = "msg_bankrupt_town2";
      String msg2 = "msg_bankrupt_town_multiple";
      if (TownySettings.isTownBankruptcyEnabled() && TownySettings.isUpkeepDeletingTownsThatReachDebtCap()) {
         this.plugin.resetCache();
         msg1 = "msg_town_reached_debtcap_and_is_disbanded";
         msg2 = "msg_town_reached_debtcap_and_is_disbanded_multiple";
      }

      if (this.bankruptedTowns != null && !this.bankruptedTowns.isEmpty()) {
         if (this.bankruptedTowns.size() == 1) {
            TownyMessaging.sendGlobalMessage(Translatable.of("msg_town_bankrupt_by_upkeep", this.bankruptedTowns.get(0)));
         } else {
            TownyMessaging.sendGlobalMessage(Translatable.of("msg_town_bankrupt_by_upkeep_multiple").append(StringMgmt.join((Collection)this.bankruptedTowns, ", ")));
         }
      }

      if (this.removedTowns != null && !this.removedTowns.isEmpty()) {
         if (this.removedTowns.size() == 1) {
            TownyMessaging.sendGlobalMessage(Translatable.of(msg1, this.removedTowns.get(0)));
         } else {
            TownyMessaging.sendGlobalMessage(Translatable.of(msg2).append(StringMgmt.join((Collection)this.removedTowns, ", ")));
         }
      }

   }

   private void processTownUpkeep(Town town) {
      double upkeep = TownySettings.getTownUpkeepCost(town);
      double upkeepPenalty = TownySettings.getTownPenaltyUpkeepCost(town);
      if (upkeepPenalty > 0.0D && upkeep > 0.0D) {
         upkeep += upkeepPenalty;
      }

      if (upkeep > 0.0D) {
         this.chargeTownUpkeep(town, upkeep);
      } else if (upkeep < 0.0D) {
         this.payTownNegativeUpkeep(upkeep, town);
      }

      if (town.isNeutral()) {
         double neutralityCost = TownySettings.getTownNeutralityCost(town);
         if (neutralityCost > 0.0D) {
            if ((!town.isBankrupt() || TownySettings.canBankruptTownsPayForNeutrality()) && town.getAccount().withdraw(neutralityCost, "Town Peace Upkeep")) {
               TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_town_paid_for_neutral_status", this.prettyMoney(neutralityCost)));
            } else {
               town.setNeutral(false);
               town.save();
               TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_town_not_peaceful"));
            }
         }
      }

   }

   private void chargeTownUpkeep(Town town, double upkeep) {
      if (town.getAccount().canPayFromHoldings(upkeep)) {
         town.getAccount().withdraw(upkeep, "Town Upkeep");
         this.totalTownUpkeep += upkeep;
         TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_your_town_payed_upkeep", this.prettyMoney(upkeep)));
      } else if (!TownySettings.isTownBankruptcyEnabled()) {
         if (this.universe.getDataSource().removeTown(town, DeleteTownEvent.Cause.UPKEEP)) {
            TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_your_town_couldnt_pay_upkeep", this.prettyMoney(upkeep)));
            this.removedTowns.add(town.getName());
         }

      } else {
         boolean townWasBankrupt = town.isBankrupt();
         town.getAccount().setDebtCap(MoneyUtil.getTownDebtCap(town, upkeep));
         if (town.getAccount().getHoldingBalance() - upkeep < town.getAccount().getDebtCap() * -1.0D) {
            if (TownySettings.isUpkeepDeletingTownsThatReachDebtCap() && this.universe.getDataSource().removeTown(town, DeleteTownEvent.Cause.BANKRUPTCY)) {
               TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_your_town_couldnt_pay_upkeep", this.prettyMoney(upkeep)));
               this.removedTowns.add(town.getName());
               return;
            }

            upkeep = town.getAccount().getDebtCap() - Math.abs(town.getAccount().getHoldingBalance());
         }

         town.getAccount().withdraw(upkeep, "Town Upkeep");
         this.totalTownUpkeep += upkeep;
         TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_your_town_payed_upkeep_with_debt", this.prettyMoney(upkeep)));
         if (!townWasBankrupt) {
            town.setOpen(false);
            town.save();
            this.bankruptedTowns.add(town.getName());
         }

      }
   }

   private void payTownNegativeUpkeep(double upkeep, Town town) {
      upkeep = Math.abs(upkeep);
      if (TownySettings.isUpkeepPayingPlots()) {
         List<TownBlock> plots = new ArrayList(town.getTownBlocks());
         double payment = upkeep / (double)plots.size();
         double townPayment = 0.0D;
         Iterator var9 = plots.iterator();

         while(var9.hasNext()) {
            TownBlock townBlock = (TownBlock)var9.next();
            if (townBlock.hasResident()) {
               Resident resident = townBlock.getResidentOrNull();
               if (resident != null) {
                  resident.getAccount().deposit(payment, "Negative Town Upkeep - Plot income");
               }
            } else {
               townPayment += payment;
            }
         }

         if (townPayment > 0.0D) {
            town.getAccount().deposit(townPayment, "Negative Town Upkeep - Plot income");
         }
      } else {
         town.getAccount().deposit(upkeep, "Negative Town Upkeep");
      }

   }

   public void collectNationCosts() {
      List<Nation> nations = new ArrayList(this.universe.getNations());
      ListIterator nationItr = nations.listIterator();

      while(nationItr.hasNext()) {
         Nation nation = (Nation)nationItr.next();
         if (nation.exists() && nation.getCapital().hasUpkeep()) {
            this.processNationUpkeep(nation);
         }
      }

      if (this.removedNations != null && !this.removedNations.isEmpty()) {
         if (this.removedNations.size() == 1) {
            TownyMessaging.sendGlobalMessage(Translatable.of("msg_bankrupt_nation2", this.removedNations.get(0)));
         } else {
            TownyMessaging.sendGlobalMessage(Translatable.of("msg_bankrupt_nation_multiple").append(StringMgmt.join((Collection)this.removedNations, ", ")));
         }
      }

   }

   private void processNationUpkeep(Nation nation) {
      double upkeep = TownySettings.getNationUpkeepCost(nation);
      if (upkeep > 0.0D) {
         if (nation.getAccount().canPayFromHoldings(upkeep)) {
            nation.getAccount().withdraw(upkeep, "Nation Upkeep");
            this.totalNationUpkeep += upkeep;
            TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_your_nation_payed_upkeep", this.prettyMoney(upkeep)));
         } else {
            List<Player> onlinePlayers = TownyAPI.getInstance().getOnlinePlayersInNation(nation);
            if (this.universe.getDataSource().removeNation(nation, DeleteNationEvent.Cause.UPKEEP)) {
               String formattedUpkeep = this.prettyMoney(upkeep);
               onlinePlayers.forEach((p) -> {
                  TownyMessaging.sendMsg((CommandSender)p, (Translatable)Translatable.of("msg_your_nation_couldnt_pay_upkeep", formattedUpkeep));
               });
               this.removedNations.add(nation.getName());
               return;
            }
         }
      } else if (upkeep < 0.0D) {
         nation.getAccount().withdraw(upkeep, "Negative Nation Upkeep");
      }

      if (nation.isNeutral()) {
         double neutralityCost = TownySettings.getNationNeutralityCost(nation);
         if (neutralityCost > 0.0D) {
            if (!nation.getAccount().withdraw(neutralityCost, "Nation Peace Upkeep")) {
               nation.setNeutral(false);
               nation.save();
               TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_nation_not_peaceful"));
            } else {
               TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_nation_paid_for_neutral_status", this.prettyMoney(neutralityCost)));
            }
         }
      }

   }

   private String prettyMoney(double money) {
      return TownyEconomyHandler.getFormattedBalance(money);
   }
}
