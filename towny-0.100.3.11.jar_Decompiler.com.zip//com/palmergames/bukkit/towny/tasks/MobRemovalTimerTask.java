package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.config.ConfigNodes;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.MobRemovalEvent;
import com.palmergames.bukkit.towny.hooks.PluginIntegrations;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.scheduling.TaskScheduler;
import com.palmergames.bukkit.towny.utils.EntityTypeUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.JavaUtil;
import java.lang.invoke.MethodHandle;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Rabbit;
import org.bukkit.entity.Rabbit.Type;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class MobRemovalTimerTask extends TownyTimerTask {
   public static List<Class<?>> classesOfWorldMobsToRemove = new ArrayList();
   public static List<Class<?>> classesOfWildernessMobsToRemove = new ArrayList();
   public static List<Class<?>> classesOfTownMobsToRemove = new ArrayList();
   private static final Set<String> ignoredSpawnReasons = new HashSet();
   private static boolean isRemovingKillerBunny;
   private static final MethodHandle GET_SPAWN_REASON;

   public MobRemovalTimerTask(Towny plugin) {
      super(plugin);
      populateFields();
   }

   public static boolean isRemovingWorldEntity(LivingEntity livingEntity) {
      return EntityTypeUtil.isInstanceOfAny(classesOfWorldMobsToRemove, livingEntity);
   }

   public static boolean isRemovingWildernessEntity(LivingEntity livingEntity) {
      return EntityTypeUtil.isInstanceOfAny(classesOfWildernessMobsToRemove, livingEntity);
   }

   public static boolean isRemovingTownEntity(LivingEntity livingEntity) {
      return EntityTypeUtil.isInstanceOfAny(classesOfTownMobsToRemove, livingEntity);
   }

   public static boolean isSpawnReasonIgnored(@NotNull Entity entity) {
      return isSpawnReasonIgnored(entity, (SpawnReason)null);
   }

   public static boolean isSpawnReasonIgnored(@NotNull Entity entity, @Nullable SpawnReason spawnReason) {
      if (spawnReason != null && ignoredSpawnReasons.contains(spawnReason.name())) {
         return true;
      } else if (GET_SPAWN_REASON != null && !ignoredSpawnReasons.isEmpty()) {
         try {
            Enum<?> reason = GET_SPAWN_REASON.invoke(entity);
            return ignoredSpawnReasons.contains(reason.name());
         } catch (Throwable var3) {
            return false;
         }
      } else {
         return false;
      }
   }

   public void run() {
      Iterator var1 = Bukkit.getWorlds().iterator();

      while(true) {
         World world;
         TownyWorld townyWorld;
         do {
            if (!var1.hasNext()) {
               return;
            }

            world = (World)var1.next();
            townyWorld = TownyAPI.getInstance().getTownyWorld(world);
         } while(!isRemovingEntities(townyWorld));

         Iterator var4 = world.getLivingEntities().iterator();

         while(var4.hasNext()) {
            LivingEntity entity = (LivingEntity)var4.next();
            checkEntity(this.plugin, townyWorld, entity);
         }
      }
   }

   public static boolean isRemovingEntities(@Nullable TownyWorld world) {
      if (world != null && world.isUsingTowny()) {
         return !world.isForceTownMobs() || !world.hasWorldMobs();
      } else {
         return false;
      }
   }

   public static void checkEntity(@NotNull Towny plugin, @NotNull TownyWorld townyWorld, @NotNull Entity ent) {
      if (ent instanceof LivingEntity) {
         LivingEntity entity = (LivingEntity)ent;
         if (!(entity instanceof Player) && !PluginIntegrations.getInstance().isNPC(entity)) {
            if (!townyWorld.hasWorldMobs() && isRemovingWorldEntity(entity)) {
               removeEntity(plugin, entity);
            } else {
               Runnable runnable = () -> {
                  Location livingEntityLoc = entity.getLocation();
                  TownBlock townBlock = TownyAPI.getInstance().getTownBlock(livingEntityLoc);
                  if (townBlock == null) {
                     if (townyWorld.hasWildernessMobs() || !isRemovingWildernessEntity(entity)) {
                        return;
                     }
                  } else {
                     if (townyWorld.isForceTownMobs() || townBlock.getPermissions().mobs || townBlock.getTownOrNull() != null && townBlock.getTownOrNull().isAdminEnabledMobs()) {
                        return;
                     }

                     if (!isRemovingTownEntity(entity)) {
                        return;
                     }
                  }

                  if (PluginIntegrations.getInstance().checkHostileEliteMobs(entity)) {
                     removeEntity(plugin, entity);
                  } else {
                     if (entity instanceof Rabbit) {
                        Rabbit rabbit = (Rabbit)entity;
                        if (isRemovingKillerBunny && rabbit.getRabbitType() == Type.THE_KILLER_BUNNY) {
                           removeEntity(plugin, entity);
                           return;
                        }
                     }

                     if (!TownySettings.isSkippingRemovalOfNamedMobs() || entity.getCustomName() == null) {
                        if (!isSpawnReasonIgnored(entity)) {
                           removeEntity(plugin, entity);
                        }
                     }
                  }
               };
               if (plugin.getScheduler().isEntityThread(entity)) {
                  runnable.run();
               } else {
                  plugin.getScheduler().run((Entity)entity, (Runnable)runnable);
               }

            }
         }
      }
   }

   private static void removeEntity(@NotNull Towny plugin, @NotNull Entity entity) {
      if (MobRemovalEvent.getHandlerList().getRegisteredListeners().length <= 0 || !BukkitTools.isEventCancelled(new MobRemovalEvent(entity))) {
         if (!plugin.getScheduler().isEntityThread(entity)) {
            TaskScheduler var10000 = plugin.getScheduler();
            Objects.requireNonNull(entity);
            var10000.run(entity, entity::remove);
         } else {
            entity.remove();
         }

      }
   }

   private static void populateFields() {
      classesOfWorldMobsToRemove = EntityTypeUtil.parseLivingEntityClassNames(TownySettings.getWorldMobRemovalEntities(), "WorldMob: ");
      classesOfWildernessMobsToRemove = EntityTypeUtil.parseLivingEntityClassNames(TownySettings.getWildernessMobRemovalEntities(), "WildernessMob: ");
      classesOfTownMobsToRemove = EntityTypeUtil.parseLivingEntityClassNames(TownySettings.getTownMobRemovalEntities(), "TownMob: ");
      isRemovingKillerBunny = TownySettings.isRemovingKillerBunny();
      ignoredSpawnReasons.clear();
      Iterator var0 = TownySettings.getStrArr(ConfigNodes.PROT_MOB_REMOVE_IGNORED_SPAWN_CAUSES).iterator();

      while(var0.hasNext()) {
         String cause = (String)var0.next();
         ignoredSpawnReasons.add(cause.toUpperCase(Locale.ROOT));
      }

   }

   static {
      populateFields();
      TownySettings.addReloadListener(NamespacedKey.fromString("towny:mob-removal-task"), (config) -> {
         populateFields();
      });
      GET_SPAWN_REASON = JavaUtil.getMethodHandle(Entity.class, "getEntitySpawnReason");
   }
}
