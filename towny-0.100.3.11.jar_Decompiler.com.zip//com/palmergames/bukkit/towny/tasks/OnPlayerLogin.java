package com.palmergames.bukkit.towny.tasks;

import com.palmergames.adventure.audience.Audience;
import com.palmergames.adventure.text.event.ClickEvent;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.TownyUpdateChecker;
import com.palmergames.bukkit.towny.event.resident.NewResidentEvent;
import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.permissions.PermissionNodes;
import com.palmergames.bukkit.towny.permissions.TownyPerms;
import com.palmergames.bukkit.towny.utils.ResidentUtil;
import com.palmergames.bukkit.towny.utils.TownRuinUtil;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.logging.Level;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.metadata.MetadataValue;

public class OnPlayerLogin implements Runnable {
   private final Towny plugin;
   private final TownyUniverse universe = TownyUniverse.getInstance();
   private final Player player;

   public OnPlayerLogin(Towny plugin, Player player) {
      this.plugin = plugin;
      this.player = player;
   }

   public void run() {
      Resident resident = this.universe.getResident(this.player.getUniqueId());
      Town town;
      if (resident == null) {
         resident = this.universe.getResident(this.player.getName());
         if (resident != null && !resident.hasUUID()) {
            this.loginExistingResident(resident);
         } else if (resident != null && !resident.getUUID().equals(this.player.getUniqueId())) {
            try {
               this.universe.unregisterResident(resident);
               resident.setUUID(this.player.getUniqueId());
               this.universe.registerResident(resident);
            } catch (AlreadyRegisteredException | NotRegisteredException var10) {
            }

            this.loginExistingResident(resident);
         } else {
            try {
               resident = this.universe.getDataSource().newResident(this.player.getName(), this.player.getUniqueId());
               resident.setRegistered(System.currentTimeMillis());
               this.universe.getDataSource().getHibernatedResidentRegistered(this.player.getUniqueId()).thenAccept((registered) -> {
                  if (registered.isPresent()) {
                     resident.setRegistered((Long)registered.get());
                     resident.save();
                  }

               });
               resident.setLastOnline(System.currentTimeMillis());
               if (!TownySettings.getDefaultTownName().equals("")) {
                  town = TownyUniverse.getInstance().getTown(TownySettings.getDefaultTownName());
                  if (town != null) {
                     try {
                        resident.setTown(town);
                     } catch (AlreadyRegisteredException var7) {
                     }
                  }
               }

               resident.save();
               this.plugin.getScheduler().run((Entity)this.player, (Runnable)(() -> {
                  BukkitTools.fireEvent(new NewResidentEvent(resident));
               }));
            } catch (NotRegisteredException var8) {
               this.plugin.getLogger().log(Level.WARNING, "Could not register resident '" + this.player.getName() + "' (" + this.player.getUniqueId() + ") due to an error, Towny features might be limited for this player until it is resolved", var8);
            } catch (AlreadyRegisteredException var9) {
            }
         }
      } else {
         if (!resident.getName().equals(this.player.getName())) {
            try {
               this.universe.getDataSource().renamePlayer(resident, this.player.getName());
            } catch (NotRegisteredException | AlreadyRegisteredException var6) {
               this.plugin.getLogger().log(Level.WARNING, "An exception occurred when trying to rename " + resident.getName() + " to " + this.player.getName(), var6);
            }
         }

         resident = this.universe.getResident(this.player.getUniqueId());
         this.loginExistingResident(resident);
      }

      if (resident != null) {
         TownyPerms.assignPermissions(resident, this.player);
         Town town = resident.getTownOrNull();
         if (town != null) {
            Nation nation = resident.getNationOrNull();
            if (TownySettings.getShowTownBoardOnLogin() && !town.getBoard().isEmpty()) {
               TownyMessaging.sendTownBoard(this.player, town);
            }

            if (TownySettings.getShowNationBoardOnLogin() && nation != null && !nation.getBoard().isEmpty()) {
               TownyMessaging.sendNationBoard(this.player, nation);
            }

            if (TownyEconomyHandler.isActive() && TownySettings.isTaxingDaily()) {
               TownyEconomyHandler.economyExecutor().execute(() -> {
                  this.bankWarningMessage(resident, town, nation);
               });
            }

            if (TownySettings.isOverClaimingAllowingStolenLand() && town.isOverClaimed()) {
               TownyMessaging.sendMsg(resident, Translatable.literal("§4").append(Translatable.of("msg_warning_your_town_is_overclaimed")));
            }

            if (town.isRuined()) {
               TownyMessaging.sendMsg(resident, Translatable.of("msg_warning_your_town_is_ruined_for_x_more_hours", TownySettings.getTownRuinsMaxDurationHours() - TownRuinUtil.getTimeSinceRuining(town)));
            }
         }

         town = TownyAPI.getInstance().getTown(this.player.getLocation());
         if (town != null && town.hasOutlaw(resident)) {
            ResidentUtil.outlawEnteredTown(resident, town, this.player.getLocation());
         }

         this.plugin.getScheduler().runLater((Entity)this.player, (Runnable)(new SetDefaultModes(this.player.getName(), false)), 1L);
         if (TownyUpdateChecker.shouldShowNotification() && this.player.hasPermission(PermissionNodes.TOWNY_ADMIN_UPDATEALERTS.getNode())) {
            Audience audience = Towny.getAdventure().player(this.player);
            ClickEvent clickEvent = ClickEvent.openUrl(TownyUpdateChecker.getUpdateURL());
            audience.sendMessage(Translatable.of("default_towny_prefix").append(Translatable.of("msg_new_update_available", TownyUpdateChecker.getNewVersion(), Towny.getPlugin().getVersion())).locale((CommandSender)this.player).component().clickEvent(clickEvent));
            audience.sendMessage(Translatable.of("default_towny_prefix").append(Translatable.of("msg_click_to_download")).locale((CommandSender)this.player).component().clickEvent(clickEvent));
         }
      }

   }

   private void loginExistingResident(Resident resident) {
      this.plugin.getScheduler().runLater((Entity)this.player, (Runnable)(() -> {
         if (this.player.getMetadata("vanished").stream().noneMatch(MetadataValue::asBoolean)) {
            resident.setLastOnline(System.currentTimeMillis());
         }

         if (!resident.hasUUID()) {
            resident.setUUID(this.player.getUniqueId());

            try {
               TownyUniverse.getInstance().registerResidentUUID(resident);
            } catch (AlreadyRegisteredException var3) {
               this.plugin.getLogger().log(Level.WARNING, "uuid for resident " + resident.getName() + " was already registered! (" + this.player.getUniqueId() + ")", var3);
            }
         }

         resident.save();
      }), 5L);
   }

   private void bankWarningMessage(Resident resident, Town town, Nation nation) {
      double upkeep;
      if (town.hasUpkeep()) {
         upkeep = TownySettings.getTownUpkeepCost(town);
         if (upkeep > 0.0D && !town.getAccount().canPayFromHoldings(upkeep)) {
            if (TownySettings.isTownBankruptcyEnabled()) {
               Translatable msg = !town.isBankrupt() ? Translatable.of("msg_warning_bankrupt", town.getName()) : Translatable.of("msg_your_town_is_bankrupt");
               TownyMessaging.sendMsg(resident, msg);
            } else {
               TownyMessaging.sendMsg(resident, Translatable.of("msg_warning_delete", town.getName()));
            }

            TownyMessaging.sendMsg(resident, Translatable.of("msg_warning_town_deposit_hint"));
         }
      }

      if (nation != null) {
         upkeep = TownySettings.getNationUpkeepCost(nation);
         if (upkeep > 0.0D && !nation.getAccount().canPayFromHoldings(upkeep)) {
            TownyMessaging.sendMsg(resident, Translatable.of("msg_warning_delete", nation.getName()));
            TownyMessaging.sendMsg(resident, Translatable.of("msg_warning_nation_deposit_hint"));
         }
      }

   }
}
