package com.palmergames.bukkit.towny.tasks;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.ArrayList;
import java.util.Iterator;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.Nullable;

public class ResidentPurge implements Runnable {
   private final CommandSender sender;
   private final long deleteTime;
   private final boolean townless;
   private final Town town;
   private final boolean removeTown;

   public ResidentPurge(CommandSender sender, long deleteTime, boolean townless, @Nullable Town town, boolean removeTown) {
      this.deleteTime = deleteTime;
      this.townless = townless;
      this.sender = sender;
      this.town = town;
      this.removeTown = removeTown;
   }

   public ResidentPurge(CommandSender sender, long deleteTime, boolean townless, @Nullable Town town) {
      this(sender, deleteTime, townless, town, TownySettings.isDeletingOldResidentsRemovingTownOnly());
   }

   public void run() {
      int count = 0;
      this.message(Translatable.of("msg_scanning_for_old_residents"));
      TownyUniverse townyUniverse = TownyUniverse.getInstance();
      ArrayList residentList;
      if (this.town != null) {
         residentList = new ArrayList(this.town.getResidents());
      } else {
         residentList = new ArrayList(townyUniverse.getResidents());
      }

      Iterator var4 = residentList.iterator();

      while(true) {
         Resident resident;
         do {
            do {
               do {
                  do {
                     if (!var4.hasNext()) {
                        this.message(Translatable.of("msg_purge_complete", count));
                        return;
                     }

                     resident = (Resident)var4.next();
                  } while(resident.isNPC());
               } while(System.currentTimeMillis() - resident.getLastOnline() <= this.deleteTime);
            } while(BukkitTools.isOnline(resident.getName()));
         } while(this.townless && resident.hasTown());

         ++count;
         this.message(Translatable.of("msg_deleting_resident", resident.getName()));
         if (this.removeTown) {
            resident.removeTown();
         } else {
            townyUniverse.getDataSource().removeResident(resident);
         }
      }
   }

   private void message(Translatable msg) {
      if (this.sender != null) {
         TownyMessaging.sendMsg(this.sender, msg);
      } else {
         TownyMessaging.sendMsg(msg);
      }

   }
}
