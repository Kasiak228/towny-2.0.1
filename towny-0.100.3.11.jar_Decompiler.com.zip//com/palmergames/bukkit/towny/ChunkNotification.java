package com.palmergames.bukkit.towny;

import com.palmergames.bukkit.config.ConfigNodes;
import com.palmergames.bukkit.towny.object.District;
import com.palmergames.bukkit.towny.object.PlayerCache;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.utils.CombatUtil;
import com.palmergames.bukkit.towny.utils.PlayerCacheUtil;
import com.palmergames.bukkit.util.Colors;
import com.palmergames.util.StringMgmt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.bukkit.entity.Player;

public class ChunkNotification {
   public static String notificationFormat = "§6 ~ %s";
   public static String notificationSplitter = "§7 - ";
   public static String areaWildernessNotificationFormat = "§2%s";
   public static String areaWildernessPvPNotificationFormat = "§2%s";
   public static String areaTownNotificationFormat = "§2%s";
   public static String areaTownPvPNotificationFormat = "§2%s";
   public static String ownerNotificationFormat = "§a%s";
   public static String noOwnerNotificationFormat = "§a%s";
   public static String plotNotificationSplitter = " ";
   public static String plotNotificationFormat = "%s";
   public static String homeBlockNotification = "§b[Home]";
   public static String outpostBlockNotification = "§b[Outpost]";
   public static String forSaleNotificationFormat = "§e[For Sale by %s: %s]";
   public static String notForSaleNotificationFormat = "§e[Not For Sale]";
   public static String plotTypeNotificationFormat = "§6[%s]";
   public static String groupNotificationFormat = "§f[%s]";
   public static String districtNotificationFormat = "<dark_green>[%s]";
   WorldCoord from;
   WorldCoord to;
   boolean fromWild = false;
   boolean toWild = false;
   boolean toForSale = false;
   boolean fromForSale = false;
   boolean toHomeBlock = false;
   boolean toOutpostBlock = false;
   boolean toPlotGroupBlock = false;
   boolean toDistrictBlock = false;
   TownBlock fromTownBlock;
   TownBlock toTownBlock = null;
   Town fromTown = null;
   Town toTown = null;
   Resident fromResident = null;
   Resident toResident = null;
   TownBlockType fromPlotType = null;
   TownBlockType toPlotType = null;
   PlotGroup fromPlotGroup = null;
   PlotGroup toPlotGroup = null;
   District fromDistrict = null;
   District toDistrict = null;

   public static void loadFormatStrings() {
      notificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_FORMAT));
      notificationSplitter = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_SPLITTER));
      areaWildernessNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_AREA_WILDERNESS));
      areaWildernessPvPNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_AREA_WILDERNESS_PVP));
      areaTownNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_AREA_TOWN));
      areaTownPvPNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_AREA_TOWN_PVP));
      ownerNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_OWNER));
      noOwnerNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_NO_OWNER));
      plotNotificationSplitter = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_PLOT_SPLITTER));
      plotNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_PLOT_FORMAT));
      homeBlockNotification = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_PLOT_HOMEBLOCK));
      outpostBlockNotification = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_PLOT_OUTPOSTBLOCK));
      forSaleNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_PLOT_FORSALEBY));
      notForSaleNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_PLOT_NOTFORSALE));
      plotTypeNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_PLOT_TYPE));
      groupNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_GROUP));
      districtNotificationFormat = Colors.translateColorCodes(TownySettings.getString(ConfigNodes.NOTIFICATION_DISTRICT));
   }

   public ChunkNotification(WorldCoord from, WorldCoord to) {
      this.from = from;
      this.to = to;
      if (from.hasTownBlock()) {
         this.fromTownBlock = from.getTownBlockOrNull();
         this.fromPlotType = this.fromTownBlock.getType();
         this.fromForSale = this.fromTownBlock.getPlotPrice() != -1.0D;
         if (this.fromTownBlock.hasPlotObjectGroup()) {
            this.fromPlotGroup = this.fromTownBlock.getPlotObjectGroup();
            this.fromForSale = this.fromPlotGroup.getPrice() != -1.0D;
         }

         if (this.fromTownBlock.hasDistrict()) {
            this.fromDistrict = this.fromTownBlock.getDistrict();
         }

         this.fromTown = this.fromTownBlock.getTownOrNull();
         this.fromResident = this.fromTownBlock.getResidentOrNull();
      } else {
         this.fromWild = true;
      }

      if (to.hasTownBlock()) {
         this.toTownBlock = to.getTownBlockOrNull();
         this.toPlotType = this.toTownBlock.getType();
         this.toTown = this.toTownBlock.getTownOrNull();
         this.toResident = this.toTownBlock.getResidentOrNull();
         this.toForSale = this.toTownBlock.getPlotPrice() != -1.0D;
         this.toHomeBlock = this.toTownBlock.isHomeBlock();
         this.toOutpostBlock = this.toTownBlock.isOutpost();
         this.toPlotGroupBlock = this.toTownBlock.hasPlotObjectGroup();
         if (this.toPlotGroupBlock) {
            this.toPlotGroup = this.toTownBlock.getPlotObjectGroup();
            this.toForSale = this.toPlotGroup.getPrice() != -1.0D;
         }

         this.toDistrictBlock = this.toTownBlock.hasDistrict();
         if (this.toDistrictBlock) {
            this.toDistrict = this.toTownBlock.getDistrict();
         }
      } else {
         this.toWild = true;
      }

   }

   public String getNotificationString(Resident resident) {
      if (notificationFormat.length() == 0) {
         return null;
      } else {
         List<String> outputContent = this.getNotificationContent(resident);
         return outputContent.size() == 0 ? null : String.format(notificationFormat, StringMgmt.join((Collection)outputContent, notificationSplitter));
      }
   }

   public List<String> getNotificationContent(Resident resident) {
      List<String> out = new ArrayList();
      if (!this.to.getTownyWorld().isUsingTowny()) {
         return out;
      } else {
         String output = this.getAreaNotification(resident);
         if (output != null && output.length() > 0) {
            out.add(output);
         }

         output = this.getAreaPvPNotification(resident);
         if (output != null && output.length() > 0) {
            out.add(output);
         }

         if (!resident.hasMode("ignoreplots")) {
            output = this.getOwnerOrPlotNameNotification(resident);
            if (output != null && output.length() > 0) {
               out.add(output);
            }
         }

         output = this.getTownPVPNotification(resident);
         if (output != null && output.length() > 0) {
            out.add(output);
         }

         if (!resident.hasMode("ignoreplots")) {
            output = this.getPlotNotification();
            if (output != null && output.length() > 0) {
               out.add(output);
            }
         }

         return out;
      }
   }

   public String getAreaNotification(Resident resident) {
      Player player;
      TownyWorld toWorld;
      Town nearestTown;
      if (this.fromWild ^ this.toWild || !this.fromWild && !this.toWild && this.fromTown != null && this.toTown != null && this.fromTown != this.toTown) {
         if (this.toWild) {
            if (TownySettings.getNationZonesEnabled() && TownySettings.getNationZonesShowNotifications()) {
               player = resident.getPlayer();
               toWorld = this.to.getTownyWorld();
               if (PlayerCacheUtil.fetchTownBlockStatus(player, this.to).equals(PlayerCache.TownBlockStatus.NATION_ZONE)) {
                  nearestTown = null;
                  nearestTown = toWorld.getClosestTownWithNationFromCoord(this.to.getCoord(), nearestTown);
                  return String.format(areaWildernessNotificationFormat, Translatable.of("nation_zone_this_area_under_protection_of", toWorld.getFormattedUnclaimedZoneName(), nearestTown.getNationOrNull().getName()).forLocale(resident));
               }
            }

            return String.format(areaWildernessNotificationFormat, this.to.getTownyWorld().getFormattedUnclaimedZoneName());
         } else {
            return TownySettings.isNotificationsTownNamesVerbose() ? String.format(areaTownNotificationFormat, this.toTown.getFormattedName()) : String.format(areaTownNotificationFormat, this.toTown);
         }
      } else {
         if (this.fromWild && this.toWild && TownySettings.getNationZonesEnabled() && TownySettings.getNationZonesShowNotifications()) {
            player = resident.getPlayer();
            toWorld = this.to.getTownyWorld();
            if (PlayerCacheUtil.fetchTownBlockStatus(player, this.to).equals(PlayerCache.TownBlockStatus.NATION_ZONE) && PlayerCacheUtil.fetchTownBlockStatus(player, this.from).equals(PlayerCache.TownBlockStatus.UNCLAIMED_ZONE)) {
               nearestTown = null;
               nearestTown = toWorld.getClosestTownWithNationFromCoord(this.to.getCoord(), nearestTown);
               return String.format(areaWildernessNotificationFormat, Translatable.of("nation_zone_this_area_under_protection_of", toWorld.getFormattedUnclaimedZoneName(), nearestTown.getNationOrNull().getName()).forLocale(resident));
            }

            if (PlayerCacheUtil.fetchTownBlockStatus(player, this.to).equals(PlayerCache.TownBlockStatus.UNCLAIMED_ZONE) && PlayerCacheUtil.fetchTownBlockStatus(player, this.from).equals(PlayerCache.TownBlockStatus.NATION_ZONE)) {
               return String.format(areaWildernessNotificationFormat, this.to.getTownyWorld().getFormattedUnclaimedZoneName());
            }
         }

         return null;
      }
   }

   public String getAreaPvPNotification(Resident resident) {
      return (this.fromWild ^ this.toWild || !this.fromWild && !this.toWild && this.fromTown != null && this.toTown != null && this.fromTown != this.toTown) && this.toWild ? String.format(areaWildernessPvPNotificationFormat, this.to.getTownyWorld().isPVP() && this.testWorldPVP() ? " " + Translatable.of("status_title_pvp").forLocale(resident) : "") : null;
   }

   public String getOwnerOrPlotNameNotification(Resident resident) {
      if (this.toWild) {
         return null;
      } else if (this.fromResident == this.toResident && (this.fromTownBlock == null || this.fromTownBlock.getName().equalsIgnoreCase(this.toTownBlock.getName())) && (this.fromTownBlock == null || !this.fromTownBlock.hasPlotObjectGroup() || this.toTownBlock.hasPlotObjectGroup())) {
         return null;
      } else if (this.toResident != null) {
         String resName = TownySettings.isNotificationOwnerShowingVerboseName() ? this.toResident.getFormattedName() : this.toResident.getName();
         return String.format(ownerNotificationFormat, Colors.translateColorCodes(this.toTownBlock.getName().isEmpty() ? resName : StringMgmt.remUnderscore(this.toTownBlock.getName())));
      } else {
         return String.format(noOwnerNotificationFormat, this.toTownBlock.getName().isEmpty() ? Translatable.of("UNCLAIMED_PLOT_NAME").forLocale(resident) : Colors.translateColorCodes(StringMgmt.remUnderscore(this.toTownBlock.getName())));
      }
   }

   public String getTownPVPNotification(Resident resident) {
      return !this.toWild && (this.fromWild || this.toTownBlock.getPermissions().pvp != this.fromTownBlock.getPermissions().pvp) ? String.format(areaTownPvPNotificationFormat, !CombatUtil.preventPvP(this.to.getTownyWorld(), this.toTownBlock) ? Translatable.of("status_title_pvp").forLocale(resident) : Translatable.of("status_title_nopvp").forLocale(resident)) : null;
   }

   private boolean testWorldPVP() {
      return this.to.getTownyWorld().isPVP();
   }

   public String getPlotNotification() {
      if (plotNotificationFormat.length() == 0) {
         return null;
      } else {
         List<String> outputContent = this.getPlotNotificationContent();
         return outputContent.size() == 0 ? null : String.format(plotNotificationFormat, StringMgmt.join((Collection)outputContent, plotNotificationSplitter));
      }
   }

   public List<String> getPlotNotificationContent() {
      List<String> out = new ArrayList();
      String output = this.getHomeblockNotification();
      if (output != null && output.length() > 0) {
         out.add(output);
      }

      output = this.getOutpostblockNotification();
      if (output != null && output.length() > 0) {
         out.add(output);
      }

      output = this.getForSaleNotification();
      if (output != null && output.length() > 0) {
         out.add(output);
      }

      output = this.getPlotTypeNotification();
      if (output != null && output.length() > 0) {
         out.add(output);
      }

      output = this.getGroupNotification();
      if (output != null && output.length() > 0) {
         out.add(output);
      }

      output = this.getDistrictNotification();
      if (output != null && output.length() > 0) {
         out.add(output);
      }

      return out;
   }

   public String getHomeblockNotification() {
      return this.toHomeBlock ? homeBlockNotification : null;
   }

   public String getOutpostblockNotification() {
      return this.toOutpostBlock ? outpostBlockNotification : null;
   }

   public String getForSaleNotification() {
      if (this.toForSale && this.toPlotGroupBlock && this.fromPlotGroup != this.toPlotGroup) {
         return String.format(forSaleNotificationFormat, this.getOwner(), this.getCost(this.toTownBlock.getPlotObjectGroup().getPrice()));
      } else if (this.toForSale && !this.toPlotGroupBlock) {
         return String.format(forSaleNotificationFormat, this.getOwner(), this.getCost(this.toTownBlock.getPlotPrice()));
      } else {
         return !this.toForSale && this.fromForSale && !this.toWild ? notForSaleNotificationFormat : null;
      }
   }

   private String getOwner() {
      return this.toTownBlock.hasResident() ? this.toTownBlock.getResidentOrNull().getName() : this.toTownBlock.getTownOrNull().getName();
   }

   private String getCost(double cost) {
      return TownyEconomyHandler.isActive() ? TownyEconomyHandler.getFormattedBalance(cost) : "$ 0";
   }

   public String getGroupNotification() {
      return this.toPlotGroupBlock && this.fromPlotGroup != this.toPlotGroup ? String.format(groupNotificationFormat, StringMgmt.remUnderscore(this.toTownBlock.getPlotObjectGroup().getName())) : null;
   }

   public String getDistrictNotification() {
      return this.toDistrictBlock && this.fromDistrict != this.toDistrict ? String.format(districtNotificationFormat, StringMgmt.remUnderscore(this.toDistrict.getName())) : null;
   }

   public String getPlotTypeNotification() {
      return this.toPlotType != null && !this.toPlotType.equals(this.fromPlotType) && !TownBlockType.RESIDENTIAL.equals(this.toPlotType) ? String.format(plotTypeNotificationFormat, StringMgmt.capitalize(this.toPlotType.getName())) : null;
   }
}
