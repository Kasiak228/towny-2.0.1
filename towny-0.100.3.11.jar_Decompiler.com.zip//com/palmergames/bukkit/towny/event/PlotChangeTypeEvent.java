package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PlotChangeTypeEvent extends Event {
   public static final HandlerList handlers = new HandlerList();
   private final TownBlockType oldType;
   private final TownBlockType newType;
   private final TownBlock townBlock;

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public PlotChangeTypeEvent(TownBlockType oldType, TownBlockType newType, TownBlock townBlock) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.newType = newType;
      this.oldType = oldType;
      this.townBlock = townBlock;
   }

   public TownBlockType getNewType() {
      return this.newType;
   }

   public TownBlockType getOldType() {
      return this.oldType == null ? TownBlockType.WILDS : this.oldType;
   }

   public TownBlock getTownBlock() {
      return this.townBlock;
   }
}
