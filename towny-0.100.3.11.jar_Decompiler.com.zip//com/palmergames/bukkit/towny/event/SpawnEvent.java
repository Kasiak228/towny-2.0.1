package com.palmergames.bukkit.towny.event;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public abstract class SpawnEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Location from;
   private final Location to;
   private final Player player;

   public SpawnEvent(Player player, Location from, Location to) {
      this.player = player;
      this.to = to;
      this.from = from;
   }

   public Location getFrom() {
      return this.from;
   }

   public Location getTo() {
      return this.to;
   }

   public Player getPlayer() {
      return this.player;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
