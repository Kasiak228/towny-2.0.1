package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownyObject;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownyObjectFormattedNameEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final TownyObject object;
   private String prefix;
   private String postfix;

   public TownyObjectFormattedNameEvent(TownyObject object, String prefix, String postfix) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.object = object;
      this.prefix = prefix;
      this.postfix = postfix;
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void setPrefix(String prefix) {
      this.prefix = prefix;
   }

   public String getPostfix() {
      return this.postfix;
   }

   public void setPostfix(String postfix) {
      this.postfix = postfix;
   }

   public TownyObject getTownyObject() {
      return this.object;
   }

   public boolean isResident() {
      return this.object instanceof Resident;
   }

   public boolean isTown() {
      return this.object instanceof Town;
   }

   public boolean isNation() {
      return this.object instanceof Nation;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public HandlerList getHandlers() {
      return handlers;
   }
}
