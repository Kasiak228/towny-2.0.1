package com.palmergames.bukkit.towny.event;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class NewDayEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final List<String> bankruptTowns;
   private final List<String> fallenTowns;
   private final List<String> fallenNations;
   private final double townUpkeepCollected;
   private final double nationUpkeepCollected;
   private final long time;

   public NewDayEvent(List<String> bankruptTowns, List<String> removedTowns, List<String> fallenNations, double townUpkeepCollected, double nationUpkeepCollected, long time) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.bankruptTowns = bankruptTowns;
      this.fallenTowns = removedTowns;
      this.fallenNations = fallenNations;
      this.townUpkeepCollected = townUpkeepCollected;
      this.nationUpkeepCollected = nationUpkeepCollected;
      this.time = time;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public List<String> getBankruptedTowns() {
      return this.bankruptTowns;
   }

   public List<String> getFallenTowns() {
      return this.fallenTowns;
   }

   public List<String> getFallenNations() {
      return this.fallenNations;
   }

   public double getTownUpkeepCollected() {
      return this.townUpkeepCollected;
   }

   public double getNationUpkeepCollected() {
      return this.nationUpkeepCollected;
   }

   public long getTime() {
      return this.time;
   }
}
