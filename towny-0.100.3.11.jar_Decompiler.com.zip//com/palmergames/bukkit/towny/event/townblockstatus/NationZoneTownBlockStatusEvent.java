package com.palmergames.bukkit.towny.event.townblockstatus;

import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.Bukkit;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class NationZoneTownBlockStatusEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private boolean isCancelled;
   private Town town;

   public NationZoneTownBlockStatusEvent(Town town) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.town = town;
   }

   public Town getTown() {
      return this.town;
   }

   public boolean isCancelled() {
      return this.isCancelled;
   }

   public void setCancelled(boolean cancel) {
      this.isCancelled = cancel;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public HandlerList getHandlers() {
      return handlers;
   }
}
