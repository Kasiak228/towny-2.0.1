package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.WorldCoord;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;

public class TownSpawnEvent extends SpawnEvent {
   private final Town fromTown;
   private final Town toTown;

   public TownSpawnEvent(Player player, Location from, Location to, boolean cancelled, String cancelMessage) {
      super(player, from, to);
      this.fromTown = WorldCoord.parseWorldCoord(from).getTownOrNull();
      this.toTown = WorldCoord.parseWorldCoord(to).getTownOrNull();
      this.setCancelled(cancelled);
      this.setCancelMessage(cancelMessage);
   }

   public Town getToTown() {
      return this.toTown;
   }

   @Nullable
   public Town getFromTown() {
      return this.fromTown;
   }
}
