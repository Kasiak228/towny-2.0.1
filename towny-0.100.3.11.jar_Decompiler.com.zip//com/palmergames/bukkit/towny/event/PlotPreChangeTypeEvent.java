package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class PlotPreChangeTypeEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final TownBlockType newType;
   private final TownBlock townBlock;
   private final Resident resident;

   public PlotPreChangeTypeEvent(TownBlockType newType, TownBlock townBlock, Resident resident) {
      this.newType = newType;
      this.townBlock = townBlock;
      this.resident = resident;
   }

   public TownBlockType getNewType() {
      return this.newType;
   }

   public TownBlockType getOldType() {
      return this.townBlock.getType();
   }

   public TownBlock getTownBlock() {
      return this.townBlock;
   }

   public Resident getResident() {
      return this.resident;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
