package com.palmergames.bukkit.towny.event.player;

import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.bukkit.event.entity.PlayerDeathEvent;

public class PlayerKilledPlayerEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private Player killer;
   private Player victim;
   private Resident killerRes;
   private Resident victimRes;
   private Location location;
   private PlayerDeathEvent deathEvent;

   public PlayerKilledPlayerEvent(Player killer, Player victim, Resident killerRes, Resident victimRes, Location location, PlayerDeathEvent event) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.killer = killer;
      this.victim = victim;
      this.killerRes = killerRes;
      this.victimRes = victimRes;
      this.location = location;
      this.deathEvent = event;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Player getKiller() {
      return this.killer;
   }

   public Player getVictim() {
      return this.victim;
   }

   public Resident getKillerRes() {
      return this.killerRes;
   }

   public Resident getVictimRes() {
      return this.victimRes;
   }

   public Location getLocation() {
      return this.location;
   }

   public PlayerDeathEvent getPlayerDeathEvent() {
      return this.deathEvent;
   }
}
