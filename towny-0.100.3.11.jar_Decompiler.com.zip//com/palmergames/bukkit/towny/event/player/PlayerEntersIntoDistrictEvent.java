package com.palmergames.bukkit.towny.event.player;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.District;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.WorldCoord;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerMoveEvent;
import org.jetbrains.annotations.Nullable;

public class PlayerEntersIntoDistrictEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final District enteredDistrict;
   private final PlayerMoveEvent pme;
   private final WorldCoord from;
   private final WorldCoord to;
   private final Player player;

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public PlayerEntersIntoDistrictEvent(Player player, WorldCoord to, WorldCoord from, District enteredDistrict, PlayerMoveEvent pme) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.enteredDistrict = enteredDistrict;
      this.player = player;
      this.from = from;
      this.pme = pme;
      this.to = to;
   }

   public Player getPlayer() {
      return this.player;
   }

   @Nullable
   public Resident getResident() {
      return TownyAPI.getInstance().getResident(this.player);
   }

   public PlayerMoveEvent getPlayerMoveEvent() {
      return this.pme;
   }

   public District getEnteredDistrict() {
      return this.enteredDistrict;
   }

   public WorldCoord getFrom() {
      return this.from;
   }

   public WorldCoord getTo() {
      return this.to;
   }
}
