package com.palmergames.bukkit.towny.event.player;

import com.palmergames.bukkit.towny.object.Translatable;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PlayerDeniedBedUseEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private Translatable denialMessage;
   private boolean isCancelled = false;
   private final Player player;
   private final Location location;
   private final boolean consideredEnemy;

   public PlayerDeniedBedUseEvent(Player player, Location location, boolean consideredEnemy, Translatable denialMessage) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.player = player;
      this.location = location;
      this.consideredEnemy = consideredEnemy;
      this.setDenialMessage(denialMessage);
   }

   public boolean isCancelled() {
      return this.isCancelled;
   }

   public void setCancelled(boolean cancel) {
      this.isCancelled = cancel;
   }

   public Translatable getDenialMessage() {
      return this.denialMessage;
   }

   public void setDenialMessage(Translatable cancelMessage) {
      this.denialMessage = cancelMessage;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Player getPlayer() {
      return this.player;
   }

   public Location getLocation() {
      return this.location;
   }

   public boolean isConsideredEnemy() {
      return this.consideredEnemy;
   }
}
