package com.palmergames.bukkit.towny.event.player;

import com.palmergames.bukkit.towny.object.PlayerCache;
import com.palmergames.bukkit.towny.object.WorldCoord;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PlayerCacheGetTownBlockStatusEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private PlayerCache.TownBlockStatus townBlockStatus;
   private final Player player;
   private final WorldCoord worldCoord;

   public PlayerCacheGetTownBlockStatusEvent(Player player, WorldCoord worldCoord, PlayerCache.TownBlockStatus townBlockStatus) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.player = player;
      this.worldCoord = worldCoord;
      this.townBlockStatus = townBlockStatus;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Player getPlayer() {
      return this.player;
   }

   public WorldCoord getWorldCoord() {
      return this.worldCoord;
   }

   public PlayerCache.TownBlockStatus getTownBlockStatus() {
      return this.townBlockStatus;
   }

   public void setTownBlockStatus(PlayerCache.TownBlockStatus townBlockStatus) {
      this.townBlockStatus = townBlockStatus;
   }
}
