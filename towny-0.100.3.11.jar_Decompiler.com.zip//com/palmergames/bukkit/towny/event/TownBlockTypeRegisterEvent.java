package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownBlockTypeHandler;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownBlockTypeRegisterEvent extends Event {
   private static final HandlerList handlers = new HandlerList();

   public TownBlockTypeRegisterEvent() {
      super(!Bukkit.isPrimaryThread());
   }

   public void registerType(@NotNull TownBlockType type) throws TownyException {
      TownBlockTypeHandler.registerType(type);
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
