package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownPreClaimEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final TownBlock townBlock;
   private final Town town;
   private final Player player;
   private boolean isHomeblock = false;
   private boolean isOutpost = false;
   private boolean isOverClaim = false;

   public TownPreClaimEvent(Town town, TownBlock townBlock, Player player, boolean isOutpost, boolean isHomeblock, boolean isOverClaim) {
      this.town = town;
      this.townBlock = townBlock;
      this.player = player;
      this.isOutpost = isOutpost;
      this.isHomeblock = isHomeblock;
      this.isOverClaim = isOverClaim;
      this.setCancelMessage(Translation.of("msg_claim_error"));
   }

   public boolean isOverClaim() {
      return this.isOverClaim;
   }

   public boolean isOutpost() {
      return this.isOutpost;
   }

   public boolean isHomeBlock() {
      return this.isHomeblock;
   }

   public TownBlock getTownBlock() {
      return this.townBlock;
   }

   public Town getTown() {
      return this.town;
   }

   public Player getPlayer() {
      return this.player;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
