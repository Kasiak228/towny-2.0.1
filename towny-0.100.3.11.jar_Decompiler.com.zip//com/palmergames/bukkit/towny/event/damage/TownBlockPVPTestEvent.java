package com.palmergames.bukkit.towny.event.damage;

import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.Nullable;

public class TownBlockPVPTestEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final TownBlock townBlock;
   private boolean pvp;

   public TownBlockPVPTestEvent(TownBlock townBlock, boolean pvp) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.townBlock = townBlock;
      this.setPvp(pvp);
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public TownBlock getTownBlock() {
      return this.townBlock;
   }

   @Nullable
   public Town getTown() {
      return this.townBlock.getTownOrNull();
   }

   public boolean isPvp() {
      return this.pvp;
   }

   public void setPvp(boolean pvp) {
      this.pvp = pvp;
   }
}
