package com.palmergames.bukkit.towny.event.damage;

import com.palmergames.bukkit.towny.object.TownyWorld;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class WildernessPVPTestEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final TownyWorld world;
   private boolean pvp;

   public WildernessPVPTestEvent(TownyWorld world, boolean pvp) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.world = world;
      this.setPvp(pvp);
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public TownyWorld getWorld() {
      return this.world;
   }

   public boolean isPvp() {
      return this.pvp;
   }

   public void setPvp(boolean pvp) {
      this.pvp = pvp;
   }
}
