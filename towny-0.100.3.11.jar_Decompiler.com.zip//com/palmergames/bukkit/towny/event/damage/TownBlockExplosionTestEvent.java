package com.palmergames.bukkit.towny.event.damage;

import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownBlockExplosionTestEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Town town;
   private final TownBlock townBlock;
   private boolean explosion;

   public TownBlockExplosionTestEvent(TownBlock townBlock, Town town, boolean explosion) {
      this.town = town;
      this.townBlock = townBlock;
      this.setExplosion(explosion);
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   @NotNull
   public TownBlock getTownBlock() {
      return this.townBlock;
   }

   @NotNull
   public Town getTown() {
      return this.town;
   }

   public boolean isExplosion() {
      return this.explosion;
   }

   public void setExplosion(boolean explosion) {
      this.explosion = explosion;
   }
}
