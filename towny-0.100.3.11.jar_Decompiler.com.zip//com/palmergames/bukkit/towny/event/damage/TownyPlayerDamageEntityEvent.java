package com.palmergames.bukkit.towny.event.damage;

import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class TownyPlayerDamageEntityEvent extends TownyDamageEvent {
   private static final HandlerList handlers = new HandlerList();
   private final Player player;

   public TownyPlayerDamageEntityEvent(Location location, Entity harmedEntity, DamageCause cause, TownBlock townblock, boolean cancelled, Player player) {
      super(location, harmedEntity, cause, townblock, cancelled);
      this.player = player;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public Player getAttackingPlayer() {
      return this.player;
   }
}
