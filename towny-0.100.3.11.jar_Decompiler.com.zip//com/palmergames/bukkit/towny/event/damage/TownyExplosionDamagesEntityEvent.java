package com.palmergames.bukkit.towny.event.damage;

import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.event.HandlerList;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class TownyExplosionDamagesEntityEvent extends TownyDamageEvent {
   private static final HandlerList handlers = new HandlerList();

   public TownyExplosionDamagesEntityEvent(Location location, Entity harmedEntity, DamageCause cause, TownBlock townblock, boolean cancelled) {
      super(location, harmedEntity, cause, townblock, cancelled);
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public HandlerList getHandlers() {
      return handlers;
   }
}
