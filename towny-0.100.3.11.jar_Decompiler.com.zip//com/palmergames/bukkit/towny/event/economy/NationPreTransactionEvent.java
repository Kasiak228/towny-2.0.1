package com.palmergames.bukkit.towny.event.economy;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.economy.transaction.Transaction;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class NationPreTransactionEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Nation nation;
   private final Transaction transaction;

   public NationPreTransactionEvent(Nation nation, Transaction transaction) {
      this.nation = nation;
      this.transaction = transaction;
   }

   public Nation getNation() {
      return this.nation;
   }

   public Transaction getTransaction() {
      return this.transaction;
   }

   public int getNewBalance() {
      switch(this.transaction.getType()) {
      case DEPOSIT:
         return (int)(this.nation.getAccount().getHoldingBalance() + this.transaction.getAmount());
      case WITHDRAW:
         return (int)(this.nation.getAccount().getHoldingBalance() - this.transaction.getAmount());
      default:
         return 0;
      }
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
