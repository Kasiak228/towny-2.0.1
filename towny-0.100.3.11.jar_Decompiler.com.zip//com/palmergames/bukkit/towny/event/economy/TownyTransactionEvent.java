package com.palmergames.bukkit.towny.event.economy;

import com.palmergames.bukkit.towny.object.economy.transaction.Transaction;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownyTransactionEvent extends Event {
   private final Transaction transaction;
   private static final HandlerList handlers = new HandlerList();

   public TownyTransactionEvent(Transaction transaction) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.transaction = transaction;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Transaction getTransaction() {
      return this.transaction;
   }
}
