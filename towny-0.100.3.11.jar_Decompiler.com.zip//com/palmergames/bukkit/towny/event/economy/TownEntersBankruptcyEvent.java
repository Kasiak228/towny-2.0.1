package com.palmergames.bukkit.towny.event.economy;

import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.economy.BankAccount;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownEntersBankruptcyEvent extends Event {
   private final Town town;
   private static final HandlerList handlers = new HandlerList();

   public TownEntersBankruptcyEvent(Town town) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.town = town;
   }

   public Town getTown() {
      return this.town;
   }

   public BankAccount getTownBankAccount() {
      return this.town.getAccount();
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
