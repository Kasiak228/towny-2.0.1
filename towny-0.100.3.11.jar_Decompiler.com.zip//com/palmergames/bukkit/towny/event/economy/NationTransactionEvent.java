package com.palmergames.bukkit.towny.event.economy;

import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.economy.BankAccount;
import com.palmergames.bukkit.towny.object.economy.transaction.Transaction;

public class NationTransactionEvent extends BankTransactionEvent {
   final Nation nation;

   public NationTransactionEvent(Nation nation, Transaction transaction) {
      super(nation.getAccount(), transaction);
      this.nation = nation;
   }

   public Nation getNation() {
      return this.nation;
   }

   public BankAccount getNationBankAccount() {
      return this.nation.getAccount();
   }
}
