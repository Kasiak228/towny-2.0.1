package com.palmergames.bukkit.towny.event.economy;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.economy.transaction.Transaction;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownPreTransactionEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Town town;
   private final Transaction transaction;

   public TownPreTransactionEvent(Town town, Transaction transaction) {
      this.town = town;
      this.transaction = transaction;
   }

   public Town getTown() {
      return this.town;
   }

   public Transaction getTransaction() {
      return this.transaction;
   }

   public int getNewBalance() {
      switch(this.transaction.getType()) {
      case DEPOSIT:
         return (int)(this.town.getAccount().getHoldingBalance() + this.transaction.getAmount());
      case WITHDRAW:
         return (int)(this.town.getAccount().getHoldingBalance() - this.transaction.getAmount());
      default:
         return 0;
      }
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
