package com.palmergames.bukkit.towny.event.economy;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.economy.transaction.Transaction;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownyPreTransactionEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Transaction transaction;

   public TownyPreTransactionEvent(Transaction transaction) {
      this.transaction = transaction;
   }

   public Transaction getTransaction() {
      return this.transaction;
   }

   public double getNewBalance() {
      double var10000;
      switch(this.transaction.getType()) {
      case ADD:
      case DEPOSIT:
         var10000 = this.transaction.getReceivingAccount().getHoldingBalance() + this.transaction.getAmount();
         break;
      case SUBTRACT:
      case WITHDRAW:
         var10000 = this.transaction.getReceivingAccount().getHoldingBalance() - this.transaction.getAmount();
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
