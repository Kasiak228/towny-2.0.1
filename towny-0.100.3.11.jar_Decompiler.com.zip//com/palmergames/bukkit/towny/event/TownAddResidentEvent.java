package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownAddResidentEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Resident resident;
   private final Town town;

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public TownAddResidentEvent(Resident resident, Town town) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.resident = resident;
      this.town = town;
   }

   public Resident getResident() {
      return this.resident;
   }

   public Town getTown() {
      return this.town;
   }

   @Nullable
   public Resident getMayor() {
      return this.town.hasMayor() ? this.town.getMayor() : null;
   }
}
