package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PreDeleteNationEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Nation nation;
   private final DeleteNationEvent.Cause cause;
   private final CommandSender sender;

   public PreDeleteNationEvent(@NotNull Nation nation, @NotNull DeleteNationEvent.Cause cause, @Nullable CommandSender sender) {
      this.nation = nation;
      this.cause = cause;
      this.sender = sender;
   }

   public String getNationName() {
      return this.nation.getName();
   }

   public Nation getNation() {
      return this.nation;
   }

   @NotNull
   public DeleteNationEvent.Cause getCause() {
      return this.cause;
   }

   @Nullable
   public CommandSender getSender() {
      return this.sender;
   }

   @Nullable
   public Resident getSenderResident() {
      CommandSender var2 = this.sender;
      Resident var10000;
      if (var2 instanceof Player) {
         Player player = (Player)var2;
         var10000 = TownyAPI.getInstance().getResident(player);
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
