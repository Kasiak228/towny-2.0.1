package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.inviteobjects.PlayerJoinTownInvite;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownInvitePlayerEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final PlayerJoinTownInvite invite;

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public TownInvitePlayerEvent(PlayerJoinTownInvite invite) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.invite = invite;
   }

   public PlayerJoinTownInvite getInvite() {
      return this.invite;
   }
}
