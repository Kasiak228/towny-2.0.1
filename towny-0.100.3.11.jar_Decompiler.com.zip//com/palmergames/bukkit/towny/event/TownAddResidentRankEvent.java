package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownAddResidentRankEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Resident resident;
   private final String rank;
   private final Town town;

   public TownAddResidentRankEvent(Resident resident, String rank, Town town) {
      this.resident = resident;
      this.rank = rank;
      this.town = town;
      this.setCancelMessage(Translation.of("msg_err_command_disable"));
   }

   public Resident getResident() {
      return this.resident;
   }

   public String getRank() {
      return this.rank;
   }

   public Town getTown() {
      return this.town;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
