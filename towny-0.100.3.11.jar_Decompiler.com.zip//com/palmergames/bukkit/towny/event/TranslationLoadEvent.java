package com.palmergames.bukkit.towny.event;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TranslationLoadEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Map<String, Map<String, String>> addedTranslations = new HashMap();

   public TranslationLoadEvent() {
      super(!Bukkit.isPrimaryThread());
   }

   public void addTranslation(@NotNull String locale, @NotNull String key, @NotNull String value) {
      this.addedTranslations.computeIfAbsent(locale, (k) -> {
         return new HashMap();
      });
      ((Map)this.addedTranslations.get(locale)).put(key, value);
   }

   public Map<String, Map<String, String>> getAddedTranslations() {
      return this.addedTranslations;
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
