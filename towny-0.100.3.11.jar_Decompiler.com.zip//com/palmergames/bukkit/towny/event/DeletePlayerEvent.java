package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Resident;
import java.util.UUID;
import org.bukkit.event.HandlerList;

public class DeletePlayerEvent extends TownyObjDeleteEvent {
   private static final HandlerList handlers = new HandlerList();

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public DeletePlayerEvent(Resident resident) {
      super(resident.getName(), resident.getUUID(), resident.getRegistered());
   }

   public String getPlayerName() {
      return this.name;
   }

   public UUID getPlayerUUID() {
      return this.uuid;
   }

   public long getRegistered() {
      return this.registered;
   }
}
