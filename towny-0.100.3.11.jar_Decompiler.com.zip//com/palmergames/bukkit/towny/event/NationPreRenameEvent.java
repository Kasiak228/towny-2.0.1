package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class NationPreRenameEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final String oldName;
   private final String newName;
   private final Nation nation;

   public NationPreRenameEvent(Nation nation, String newName) {
      this.oldName = nation.getName();
      this.nation = nation;
      this.newName = newName;
      this.setCancelMessage(Translation.of("msg_err_rename_cancelled"));
   }

   public String getOldName() {
      return this.oldName;
   }

   public String getNewName() {
      return this.newName;
   }

   public Nation getNation() {
      return this.nation;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
