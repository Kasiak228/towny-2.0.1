package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.WorldCoord;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class ChunkNotificationEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private final Player player;
   private String message;
   private final WorldCoord toCoord;
   private final WorldCoord fromCoord;
   private boolean isCancelled = false;

   public ChunkNotificationEvent(Player player, String message, WorldCoord toCoord, WorldCoord fromCoord) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.player = player;
      this.setMessage(message);
      this.toCoord = toCoord;
      this.fromCoord = fromCoord;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public boolean isCancelled() {
      return this.isCancelled;
   }

   public void setCancelled(boolean cancelled) {
      this.isCancelled = cancelled;
   }

   public Player getPlayer() {
      return this.player;
   }

   public String getMessage() {
      return this.message;
   }

   public void setMessage(String message) {
      this.message = message;
   }

   public WorldCoord getToCoord() {
      return this.toCoord;
   }

   public WorldCoord getFromCoord() {
      return this.fromCoord;
   }
}
