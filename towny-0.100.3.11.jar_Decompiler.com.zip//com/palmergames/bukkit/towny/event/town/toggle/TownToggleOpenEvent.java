package com.palmergames.bukkit.towny.event.town.toggle;

import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.command.CommandSender;

public class TownToggleOpenEvent extends TownToggleStateEvent {
   public TownToggleOpenEvent(CommandSender sender, Town town, boolean admin, boolean newState) {
      super(sender, town, admin, town.isOpen(), newState);
   }
}
