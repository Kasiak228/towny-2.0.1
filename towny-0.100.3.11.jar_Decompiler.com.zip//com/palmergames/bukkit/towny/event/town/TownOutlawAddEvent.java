package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.command.CommandSender;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownOutlawAddEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Town town;
   private final Resident outlawedResident;
   private final CommandSender sender;

   public TownOutlawAddEvent(CommandSender sender, Resident outlawedResident, Town town) {
      this.town = town;
      this.outlawedResident = outlawedResident;
      this.sender = sender;
      this.setCancelMessage(Translation.of("msg_err_command_disable"));
   }

   public Town getTown() {
      return this.town;
   }

   public Resident getOutlawedResident() {
      return this.outlawedResident;
   }

   @NotNull
   public CommandSender getSender() {
      return this.sender;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
