package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownCalculateTownLevelNumberEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private int townLevelNumber;
   private final Town town;

   public TownCalculateTownLevelNumberEvent(Town town, int predeterminedLevelNumber) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.town = town;
      this.townLevelNumber = predeterminedLevelNumber;
   }

   public Town getTown() {
      return this.town;
   }

   public void setTownLevelNumber(int value) {
      this.townLevelNumber = value;
   }

   public int getTownLevelNumber() {
      return this.townLevelNumber;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
