package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TownSetSpawnEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Town town;
   private final Player player;
   private final Location oldSpawn;
   private Location newSpawn;

   public TownSetSpawnEvent(Town town, Player player, Location newSpawn) {
      this.town = town;
      this.player = player;
      this.oldSpawn = town.getSpawnOrNull();
      this.newSpawn = newSpawn;
      this.setCancelMessage(Translation.of("msg_err_command_disable"));
   }

   @NotNull
   public Town getTown() {
      return this.town;
   }

   @NotNull
   public Player getPlayer() {
      return this.player;
   }

   @Nullable
   public Location getOldSpawn() {
      return this.oldSpawn;
   }

   @NotNull
   public Location getNewSpawn() {
      return this.newSpawn;
   }

   public void setNewSpawn(@NotNull Location newSpawn) {
      this.newSpawn = newSpawn;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
