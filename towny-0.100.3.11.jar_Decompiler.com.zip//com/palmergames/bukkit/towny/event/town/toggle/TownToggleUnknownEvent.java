package com.palmergames.bukkit.towny.event.town.toggle;

import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.command.CommandSender;

public class TownToggleUnknownEvent extends TownToggleEvent {
   private final String[] args;

   public TownToggleUnknownEvent(CommandSender sender, Town town, boolean admin, String[] args) {
      super(sender, town, admin);
      this.args = args;
      this.setCancelled(true);
      this.setCancelMessage(Translation.of("msg_err_invalid_property", args[0]));
   }

   public String[] getArgs() {
      return this.args;
   }
}
