package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.WorldCoord;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TownUnclaimEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Town town;
   private final WorldCoord worldCoord;
   private boolean isOverClaim;

   public TownUnclaimEvent(Town town, WorldCoord worldCoord, boolean isOverClaim) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.town = town;
      this.worldCoord = worldCoord;
      this.isOverClaim = isOverClaim;
   }

   @NotNull
   public HandlerList getHandlers() {
      return getHandlerList();
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public boolean isOverClaim() {
      return this.isOverClaim;
   }

   @Nullable
   public Town getTown() {
      return this.town;
   }

   public WorldCoord getWorldCoord() {
      return this.worldCoord;
   }
}
