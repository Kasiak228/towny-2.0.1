package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.towny.object.WorldCoord;
import java.util.List;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownPreUnclaimCmdEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Town town;
   private final Resident resident;
   private final TownyWorld townyWorld;
   private final List<WorldCoord> worldCoords;

   public TownPreUnclaimCmdEvent(Town town, Resident resident, TownyWorld world, List<WorldCoord> selection) {
      this.town = town;
      this.resident = resident;
      this.townyWorld = world;
      this.worldCoords = selection;
      this.setCancelMessage(Translation.of("msg_err_town_unclaim_canceled"));
   }

   public Town getTown() {
      return this.town;
   }

   public Resident getResident() {
      return this.resident;
   }

   public TownyWorld getTownyWorld() {
      return this.townyWorld;
   }

   public List<WorldCoord> getUnclaimSelection() {
      return this.worldCoords;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
