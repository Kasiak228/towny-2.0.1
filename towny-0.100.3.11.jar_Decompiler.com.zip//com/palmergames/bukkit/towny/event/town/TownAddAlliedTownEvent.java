package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownAddAlliedTownEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Town town;
   private final Town newAlly;

   public TownAddAlliedTownEvent(Town town, Town newAlly) {
      this.town = town;
      this.newAlly = newAlly;
      this.setCancelMessage("A town alliance was cancelled by another plugin.");
   }

   public Town getTown() {
      return this.town;
   }

   public Town getNewAlly() {
      return this.newAlly;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
