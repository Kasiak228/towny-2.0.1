package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownPreSetHomeBlockEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Town town;
   private final TownBlock townBlock;
   private final Player player;

   public TownPreSetHomeBlockEvent(Town town, TownBlock townBlock, Player player) {
      this.town = town;
      this.townBlock = townBlock;
      this.player = player;
      this.setCancelMessage(Translation.of("msg_err_homeblock_has_not_been_set"));
   }

   public Town getTown() {
      return this.town;
   }

   public TownBlock getTownBlock() {
      return this.townBlock;
   }

   public Player getPlayer() {
      return this.player;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
