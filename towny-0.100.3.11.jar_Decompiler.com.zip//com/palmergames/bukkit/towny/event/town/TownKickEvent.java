package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownKickEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Resident kickedResident;
   private final Object kicker;

   public TownKickEvent(Resident kickedResident, Object kicker) {
      this.kickedResident = kickedResident;
      this.kicker = kicker;
      this.setCancelMessage(Translation.of("msg_err_command_disable"));
   }

   public Resident getKickedResident() {
      return this.kickedResident;
   }

   public Town getTown() {
      return TownyAPI.getInstance().getResidentTownOrNull(this.kickedResident);
   }

   public Object getKicker() {
      return this.kicker;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
