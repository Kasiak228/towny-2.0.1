package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownAddEnemiedTownEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Town town;
   private final Town newEnemy;

   public TownAddEnemiedTownEvent(Town town, Town newAlly) {
      this.town = town;
      this.newEnemy = newAlly;
      this.setCancelMessage("A town enemying another town was cancelled by another plugin.");
   }

   public Town getTown() {
      return this.town;
   }

   public Town getNewEnemy() {
      return this.newEnemy;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
