package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.object.Town;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownMergeEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Town remainingTown;
   private final String succumbingTownName;
   private final UUID succumbingTownUUID;

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public TownMergeEvent(Town remainingTown, String succumbingTownName, UUID succumbingTownUUID) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.remainingTown = remainingTown;
      this.succumbingTownName = succumbingTownName;
      this.succumbingTownUUID = succumbingTownUUID;
   }

   public String getSuccumbingTownName() {
      return this.succumbingTownName;
   }

   public UUID getSuccumbingTownUUID() {
      return this.succumbingTownUUID;
   }

   public Town getRemainingTown() {
      return this.remainingTown;
   }
}
