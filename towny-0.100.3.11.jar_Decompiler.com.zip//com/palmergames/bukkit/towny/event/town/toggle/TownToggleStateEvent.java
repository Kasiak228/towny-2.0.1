package com.palmergames.bukkit.towny.event.town.toggle;

import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.command.CommandSender;

abstract class TownToggleStateEvent extends TownToggleEvent {
   private final boolean currState;
   private final boolean newState;

   TownToggleStateEvent(CommandSender sender, Town town, boolean admin, boolean currState, boolean newState) {
      super(sender, town, admin);
      this.currState = currState;
      this.newState = newState;
   }

   public boolean getCurrentState() {
      return this.currState;
   }

   public boolean getFutureState() {
      return this.newState;
   }
}
