package com.palmergames.bukkit.towny.event.town.toggle;

import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.command.CommandSender;

public class TownTogglePVPEvent extends TownToggleStateEvent {
   public TownTogglePVPEvent(CommandSender sender, Town town, boolean admin, boolean newState) {
      super(sender, town, admin, town.isPVP(), newState);
   }
}
