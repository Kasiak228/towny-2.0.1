package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownReclaimedEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Town town;
   private final Resident resident;

   public TownReclaimedEvent(Town town, Resident resident) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.town = town;
      this.resident = resident;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Town getTown() {
      return this.town;
   }

   public Resident getResident() {
      return this.resident;
   }
}
