package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.command.CommandSender;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownTrustTownAddEvent extends CancellableTownyEvent {
   private final Town town;
   private final Town trustTown;
   private final CommandSender sender;
   private static final HandlerList handlers = new HandlerList();

   public TownTrustTownAddEvent(CommandSender sender, Town trustTown, Town town) {
      this.town = town;
      this.trustTown = trustTown;
      this.sender = sender;
      this.setCancelMessage(Translation.of("msg_err_command_disable"));
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Town getTown() {
      return this.town;
   }

   public Town getTrustedTown() {
      return this.trustTown;
   }

   @NotNull
   public CommandSender getSender() {
      return this.sender;
   }
}
