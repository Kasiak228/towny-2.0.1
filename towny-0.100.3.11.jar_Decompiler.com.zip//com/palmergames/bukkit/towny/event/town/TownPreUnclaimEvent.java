package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TownPreUnclaimEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final TownBlock townBlock;
   private final Town town;

   public TownPreUnclaimEvent(Town town, TownBlock townBlock) {
      this.town = town;
      this.townBlock = townBlock;
      if (this.town == null) {
         this.setCancelMessage(Translation.of("msg_area_not_recog"));
         this.setCancelled(true);
      } else {
         this.setCancelMessage(Translation.of("msg_err_town_unclaim_canceled"));
      }

   }

   @Nullable
   public Town getTown() {
      return this.town;
   }

   public TownBlock getTownBlock() {
      return this.townBlock;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
