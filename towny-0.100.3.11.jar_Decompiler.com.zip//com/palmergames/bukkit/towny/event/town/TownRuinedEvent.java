package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownRuinedEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Town town;
   private final String oldMayorName;

   public TownRuinedEvent(Town town, String oldMayorName) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.town = town;
      this.oldMayorName = oldMayorName;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Town getTown() {
      return this.town;
   }

   public String getOldMayorName() {
      return this.oldMayorName;
   }
}
