package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.event.DeleteTownEvent;
import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.command.CommandSender;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TownPreRuinedEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Town town;
   private final DeleteTownEvent.Cause cause;
   private final CommandSender sender;

   public TownPreRuinedEvent(Town town, DeleteTownEvent.Cause cause, CommandSender sender) {
      this.town = town;
      this.cause = cause;
      this.sender = sender;
      this.setCancelMessage("");
   }

   public Town getTown() {
      return this.town;
   }

   @NotNull
   public DeleteTownEvent.Cause getCause() {
      return this.cause;
   }

   @Nullable
   public CommandSender getSender() {
      return this.sender;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
