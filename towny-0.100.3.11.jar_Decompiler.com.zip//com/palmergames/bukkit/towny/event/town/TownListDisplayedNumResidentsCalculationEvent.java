package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownListDisplayedNumResidentsCalculationEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private int displayedValue;
   private final Town town;

   public TownListDisplayedNumResidentsCalculationEvent(int displayedValue, Town town) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.displayedValue = displayedValue;
      this.town = town;
   }

   public Town getTown() {
      return this.town;
   }

   public void setDisplayedValue(int value) {
      this.displayedValue = value;
   }

   public int getDisplayedValue() {
      return this.displayedValue;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
