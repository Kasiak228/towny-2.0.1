package com.palmergames.bukkit.towny.event.town;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.invites.Invite;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownPreInvitePlayerEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Invite invite;

   public TownPreInvitePlayerEvent(Invite invite) {
      this.invite = invite;
      this.setCancelMessage("You cannot invite this player to your town.");
   }

   public Invite getInvite() {
      return this.invite;
   }

   public Resident getInvitedResident() {
      return (Resident)this.invite.getReceiver();
   }

   public Town getTown() {
      return (Town)this.invite.getSender();
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
