package com.palmergames.bukkit.towny.event.deathprice;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.economy.Account;
import org.bukkit.entity.Player;

public class PlayerPaysDeathPriceEvent extends DeathPriceEvent {
   public PlayerPaysDeathPriceEvent(Account payer, double amount, Resident deadResident, Player killer) {
      super(payer, amount, deadResident, killer);
   }

   public Player getKiller() {
      return this.killer;
   }
}
