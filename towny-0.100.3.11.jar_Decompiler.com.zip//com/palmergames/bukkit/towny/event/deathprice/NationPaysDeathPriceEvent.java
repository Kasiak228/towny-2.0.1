package com.palmergames.bukkit.towny.event.deathprice;

import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.economy.Account;
import org.bukkit.entity.Player;

public class NationPaysDeathPriceEvent extends DeathPriceEvent {
   protected final Nation nation;

   public NationPaysDeathPriceEvent(Account payer, double amount, Resident deadResident, Player killer, Nation nation) {
      super(payer, amount, deadResident, killer);
      this.nation = nation;
   }

   public Nation getNation() {
      return this.nation;
   }
}
