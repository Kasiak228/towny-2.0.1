package com.palmergames.bukkit.towny.event.deathprice;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.economy.Account;
import org.bukkit.entity.Player;

public class TownPaysDeathPriceEvent extends DeathPriceEvent {
   protected final Town town;

   public TownPaysDeathPriceEvent(Account payer, double amount, Resident deadResident, Player killer, Town town) {
      super(payer, amount, deadResident, killer);
      this.town = town;
   }

   public Town getTown() {
      return this.town;
   }
}
