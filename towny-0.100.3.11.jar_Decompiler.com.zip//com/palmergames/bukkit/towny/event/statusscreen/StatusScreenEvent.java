package com.palmergames.bukkit.towny.event.statusscreen;

import com.palmergames.adventure.text.Component;
import com.palmergames.bukkit.towny.object.statusscreens.StatusScreen;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class StatusScreenEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final StatusScreen screen;
   private int addedLineCount = 0;

   public StatusScreenEvent(StatusScreen screen) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.screen = screen;
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public StatusScreen getStatusScreen() {
      return this.screen;
   }

   public CommandSender getCommandSender() {
      return this.screen.getCommandSender();
   }

   public void addLines(List<String> lines) {
      Iterator var2 = lines.iterator();

      while(var2.hasNext()) {
         String line = (String)var2.next();
         this.addLine(line);
      }

   }

   public void addLine(String line) {
      this.addLine(this.getNextKey(), line);
   }

   public void addLine(String key, String line) {
      this.screen.addComponentOf(key, "\n" + line);
   }

   public void addLines(Collection<Component> lines) {
      Iterator var2 = lines.iterator();

      while(var2.hasNext()) {
         Component line = (Component)var2.next();
         this.addLine(line);
      }

   }

   public void addLine(Component line) {
      this.addLine(this.getNextKey(), line);
   }

   public void addLine(String key, Component line) {
      this.screen.addComponentOf(key, Component.newline().append(line));
   }

   private String getNextKey() {
      return String.format("eventAddedLine-%d", ++this.addedLineCount);
   }
}
