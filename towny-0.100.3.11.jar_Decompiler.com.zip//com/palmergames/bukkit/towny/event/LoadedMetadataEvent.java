package com.palmergames.bukkit.towny.event;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class LoadedMetadataEvent extends Event {
   private static final HandlerList handlers = new HandlerList();

   public LoadedMetadataEvent() {
      super(!Bukkit.getServer().isPrimaryThread());
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
