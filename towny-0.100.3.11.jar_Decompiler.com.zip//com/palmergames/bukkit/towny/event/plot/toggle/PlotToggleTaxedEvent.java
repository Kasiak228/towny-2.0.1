package com.palmergames.bukkit.towny.event.plot.toggle;

import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.entity.Player;

public class PlotToggleTaxedEvent extends PlotToggleEvent {
   public PlotToggleTaxedEvent(TownBlock townBlock, Player player, boolean futureState) {
      super(townBlock, player, futureState);
   }
}
