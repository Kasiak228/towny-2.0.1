package com.palmergames.bukkit.towny.event.plot.group;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class PlotGroupAddEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final PlotGroup plotGroup;
   private final TownBlock townBlock;
   private final Player player;

   public PlotGroupAddEvent(PlotGroup group, TownBlock townBlock, Player player) {
      this.plotGroup = group;
      this.townBlock = townBlock;
      this.player = player;
   }

   @NotNull
   public PlotGroup getPlotGroup() {
      return this.plotGroup;
   }

   @NotNull
   public TownBlock getTownBlock() {
      return this.townBlock;
   }

   @NotNull
   public Player getPlayer() {
      return this.player;
   }

   @NotNull
   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
