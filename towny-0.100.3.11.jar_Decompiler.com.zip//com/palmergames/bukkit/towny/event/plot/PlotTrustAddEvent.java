package com.palmergames.bukkit.towny.event.plot;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.Translation;
import java.util.Collections;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class PlotTrustAddEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final List<TownBlock> townBlocks;
   private final Resident trustedResident;
   private final Player player;

   public PlotTrustAddEvent(TownBlock townBlock, Resident trustedResident, Player player) {
      this(Collections.singletonList(townBlock), trustedResident, player);
   }

   public PlotTrustAddEvent(List<TownBlock> townBlocks, Resident trustedResident, Player player) {
      this.townBlocks = townBlocks;
      this.trustedResident = trustedResident;
      this.player = player;
      this.setCancelMessage(Translation.of("msg_err_command_disable"));
   }

   public List<TownBlock> getTownBlocks() {
      return this.townBlocks;
   }

   public Resident getTrustedResident() {
      return this.trustedResident;
   }

   public Player getPlayer() {
      return this.player;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
