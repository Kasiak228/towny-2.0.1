package com.palmergames.bukkit.towny.event.plot.changeowner;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.event.Cancellable;

public class PlotPreUnclaimEvent extends PlotChangeOwnerEvent implements Cancellable {
   private boolean cancelled;
   private String cancelMessage = "";

   public PlotPreUnclaimEvent(Resident oldResident, Resident newResident, TownBlock townBlock) {
      super(oldResident, newResident, townBlock);
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean cancelled) {
      this.cancelled = cancelled;
   }

   public String getCancelMessage() {
      return this.cancelMessage;
   }

   public void setCancelMessage(String cancelMessage) {
      this.cancelMessage = cancelMessage;
   }
}
