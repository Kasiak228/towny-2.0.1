package com.palmergames.bukkit.towny.event.plot.district;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.District;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class DistrictDeletedEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final District district;
   private final Player player;
   private final DistrictDeletedEvent.Cause deletionCause;

   public DistrictDeletedEvent(@NotNull District district, @Nullable Player player, @NotNull DistrictDeletedEvent.Cause deletionCause) {
      this.district = district;
      this.player = player;
      this.deletionCause = deletionCause;
   }

   @NotNull
   public District getDistrict() {
      return this.district;
   }

   @Nullable
   public Player getPlayer() {
      return this.player;
   }

   public DistrictDeletedEvent.Cause getDeletionCause() {
      return this.deletionCause;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }

   public static enum Cause {
      UNKNOWN,
      DELETED,
      NO_TOWNBLOCKS,
      TOWN_DELETED;

      // $FF: synthetic method
      private static DistrictDeletedEvent.Cause[] $values() {
         return new DistrictDeletedEvent.Cause[]{UNKNOWN, DELETED, NO_TOWNBLOCKS, TOWN_DELETED};
      }
   }
}
