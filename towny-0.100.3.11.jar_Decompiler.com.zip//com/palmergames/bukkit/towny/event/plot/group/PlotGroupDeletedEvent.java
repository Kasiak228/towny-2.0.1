package com.palmergames.bukkit.towny.event.plot.group;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.PlotGroup;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlotGroupDeletedEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final PlotGroup plotGroup;
   private final Player player;
   private final PlotGroupDeletedEvent.Cause deletionCause;

   public PlotGroupDeletedEvent(@NotNull PlotGroup group, @Nullable Player player, @NotNull PlotGroupDeletedEvent.Cause deletionCause) {
      this.plotGroup = group;
      this.player = player;
      this.deletionCause = deletionCause;
   }

   @NotNull
   public PlotGroup getPlotGroup() {
      return this.plotGroup;
   }

   @Nullable
   public Player getPlayer() {
      return this.player;
   }

   public PlotGroupDeletedEvent.Cause getDeletionCause() {
      return this.deletionCause;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }

   public static enum Cause {
      UNKNOWN,
      DELETED,
      NO_TOWNBLOCKS,
      TOWN_DELETED;

      // $FF: synthetic method
      private static PlotGroupDeletedEvent.Cause[] $values() {
         return new PlotGroupDeletedEvent.Cause[]{UNKNOWN, DELETED, NO_TOWNBLOCKS, TOWN_DELETED};
      }
   }
}
