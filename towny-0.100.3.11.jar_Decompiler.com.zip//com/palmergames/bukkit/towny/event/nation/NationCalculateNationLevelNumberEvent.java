package com.palmergames.bukkit.towny.event.nation;

import com.palmergames.bukkit.towny.object.Nation;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class NationCalculateNationLevelNumberEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private int nationLevelNumber;
   private final Nation nation;

   public NationCalculateNationLevelNumberEvent(Nation nation, int predeterminedLevelNumber) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.nation = nation;
      this.nationLevelNumber = predeterminedLevelNumber;
   }

   public Nation getNation() {
      return this.nation;
   }

   public void setNationlevelNumber(int value) {
      this.nationLevelNumber = value;
   }

   public int getNationLevelNumber() {
      return this.nationLevelNumber;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
