package com.palmergames.bukkit.towny.event.nation;

import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class NationTownLeaveEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final String townName;
   private final Town town;
   private final String nationName;
   private final Nation nation;

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public NationTownLeaveEvent(Nation nation, Town town) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.townName = town.getName();
      this.town = town;
      this.nation = nation;
      this.nationName = nation.getName();
   }

   public String getTownName() {
      return this.townName;
   }

   public String getNationName() {
      return this.nationName;
   }

   public Town getTown() {
      return this.town;
   }

   public Nation getNation() {
      return this.nation;
   }
}
