package com.palmergames.bukkit.towny.event.nation.toggle;

import com.palmergames.bukkit.towny.object.Nation;
import org.bukkit.command.CommandSender;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

abstract class NationToggleStateEvent extends NationToggleEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final boolean oldState;
   private final boolean newState;

   public NationToggleStateEvent(CommandSender sender, Nation nation, boolean admin, boolean oldState, boolean newState) {
      super(sender, nation, admin);
      this.oldState = oldState;
      this.newState = newState;
   }

   public boolean getCurrentState() {
      return this.oldState;
   }

   public boolean getFutureState() {
      return this.newState;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
