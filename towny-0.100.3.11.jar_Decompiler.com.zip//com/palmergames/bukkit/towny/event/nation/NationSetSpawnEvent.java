package com.palmergames.bukkit.towny.event.nation;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class NationSetSpawnEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final Nation nation;
   private final Player player;
   private final Location oldSpawn;
   private Location newSpawn;

   public NationSetSpawnEvent(Nation nation, Player player, Location newSpawn) {
      this.nation = nation;
      this.player = player;
      this.oldSpawn = nation.getSpawnOrNull();
      this.newSpawn = newSpawn;
      this.setCancelMessage(Translation.of("msg_err_command_disable"));
   }

   @NotNull
   public Nation getNation() {
      return this.nation;
   }

   @NotNull
   public Player getPlayer() {
      return this.player;
   }

   @Nullable
   public Location getOldSpawn() {
      return this.oldSpawn;
   }

   @NotNull
   public Location getNewSpawn() {
      return this.newSpawn;
   }

   public void setNewSpawn(@NotNull Location newSpawn) {
      this.newSpawn = newSpawn;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
