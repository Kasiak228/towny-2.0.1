package com.palmergames.bukkit.towny.event.nation.toggle;

import com.palmergames.bukkit.towny.object.Nation;
import org.bukkit.command.CommandSender;

public class NationToggleOpenEvent extends NationToggleStateEvent {
   public NationToggleOpenEvent(CommandSender sender, Nation nation, boolean admin, boolean newState) {
      super(sender, nation, admin, nation.isOpen(), newState);
   }
}
