package com.palmergames.bukkit.towny.event.nation;

import com.palmergames.bukkit.towny.event.CancellableTownyEvent;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class NationPreTownLeaveEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final String townName;
   private final Town town;
   private final String nationName;
   private final Nation nation;

   public NationPreTownLeaveEvent(Nation nation, Town town) {
      this.townName = town.getName();
      this.town = town;
      this.nation = nation;
      this.nationName = nation.getName();
      this.setCancelMessage(Translation.of("msg_err_command_disable"));
   }

   public String getTownName() {
      return this.townName;
   }

   public String getNationName() {
      return this.nationName;
   }

   public Town getTown() {
      return this.town;
   }

   public Nation getNation() {
      return this.nation;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
