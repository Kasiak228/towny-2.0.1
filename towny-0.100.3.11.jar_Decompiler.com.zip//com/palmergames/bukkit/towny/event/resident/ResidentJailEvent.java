package com.palmergames.bukkit.towny.event.resident;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.jail.JailReason;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ResidentJailEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Resident resident;
   private final JailReason reason;
   private final Player sender;

   public ResidentJailEvent(Resident resident, JailReason reason, Player sender) {
      this.resident = resident;
      this.reason = reason;
      this.sender = sender;
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Resident getResident() {
      return this.resident;
   }

   public Jail getJail() {
      return this.resident.getJail();
   }

   public int getJailCell() {
      return this.resident.getJailCell();
   }

   public int getJailHours() {
      return this.resident.getJailHours();
   }

   public Town getJailTown() {
      return this.getJail().getTown();
   }

   public String getJailTownName() {
      return this.getJailTown().getName();
   }

   public Location getJailSpawnLocation() {
      return this.resident.getJailSpawn();
   }

   public double getBailAmount() {
      return this.resident.getJailBailCost();
   }

   public JailReason getJailReason() {
      return this.reason;
   }

   @Nullable
   public Player getPlayerThatSentResidentToJail() {
      return this.sender;
   }
}
