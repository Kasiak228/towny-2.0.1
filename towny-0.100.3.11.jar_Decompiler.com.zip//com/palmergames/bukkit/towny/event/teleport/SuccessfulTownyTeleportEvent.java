package com.palmergames.bukkit.towny.event.teleport;

import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class SuccessfulTownyTeleportEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Resident resident;
   private final Location teleportLocation;
   private final double teleportCost;

   public SuccessfulTownyTeleportEvent(Resident resident, Location loc, double cost) {
      super(!Bukkit.isPrimaryThread());
      this.resident = resident;
      this.teleportLocation = loc;
      this.teleportCost = cost;
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public Resident getResident() {
      return this.resident;
   }

   public Location getTeleportLocation() {
      return this.teleportLocation;
   }

   public double getTeleportCost() {
      return this.teleportCost;
   }
}
