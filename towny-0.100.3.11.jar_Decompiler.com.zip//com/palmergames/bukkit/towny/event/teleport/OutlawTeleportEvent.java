package com.palmergames.bukkit.towny.event.teleport;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class OutlawTeleportEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private boolean isCancelled = false;
   private Resident outlaw;
   private Town town;
   private Location outlawLocation;

   public OutlawTeleportEvent(Resident outlaw, Town town, Location loc) {
      super(!Bukkit.isPrimaryThread());
      this.outlaw = outlaw;
      this.town = town;
      this.outlawLocation = loc;
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public boolean isCancelled() {
      return this.isCancelled;
   }

   public void setCancelled(boolean cancelled) {
      this.isCancelled = cancelled;
   }

   public Resident getOutlaw() {
      return this.outlaw;
   }

   public Town getTown() {
      return this.town;
   }

   @Nullable
   public Town getOutlawTownOrNull() {
      return this.outlaw.getTownOrNull();
   }

   public Location getOutlawLocation() {
      return this.outlawLocation;
   }
}
