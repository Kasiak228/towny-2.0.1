package com.palmergames.bukkit.towny.event.teleport;

import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class CancelledTownyTeleportEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private final Resident resident;
   private final Location location;
   private final double teleportCost;
   private final CancelledTownyTeleportEvent.CancelledTeleportReason reason;

   public CancelledTownyTeleportEvent(Resident resident, Location location, double teleportCost, CancelledTownyTeleportEvent.CancelledTeleportReason reason) {
      super(!Bukkit.isPrimaryThread());
      this.resident = resident;
      this.location = location;
      this.teleportCost = teleportCost;
      this.reason = reason;
   }

   public Resident getResident() {
      return this.resident;
   }

   public Location getLocation() {
      return this.location;
   }

   public double getTeleportCost() {
      return this.teleportCost;
   }

   public CancelledTownyTeleportEvent.CancelledTeleportReason getReason() {
      return this.reason;
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public static enum CancelledTeleportReason {
      MOVEMENT,
      DAMAGE,
      UNKNOWN;

      // $FF: synthetic method
      private static CancelledTownyTeleportEvent.CancelledTeleportReason[] $values() {
         return new CancelledTownyTeleportEvent.CancelledTeleportReason[]{MOVEMENT, DAMAGE, UNKNOWN};
      }
   }
}
