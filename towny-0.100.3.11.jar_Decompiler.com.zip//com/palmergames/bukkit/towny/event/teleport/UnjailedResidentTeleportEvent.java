package com.palmergames.bukkit.towny.event.teleport;

import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.Location;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class UnjailedResidentTeleportEvent extends Event implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private boolean isCancelled = false;
   private final Resident resident;
   private Location location;

   public UnjailedResidentTeleportEvent(Resident resident, Location location) {
      this.resident = resident;
      this.setLocation(location);
   }

   public Resident getResident() {
      return this.resident;
   }

   public Location getLocation() {
      return this.location;
   }

   public void setLocation(Location location) {
      this.location = location;
   }

   public boolean isCancelled() {
      return this.isCancelled;
   }

   public void setCancelled(boolean cancelled) {
      this.isCancelled = cancelled;
   }

   @NotNull
   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
