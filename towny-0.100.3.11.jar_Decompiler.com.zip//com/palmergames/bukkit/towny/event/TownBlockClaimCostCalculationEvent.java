package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class TownBlockClaimCostCalculationEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private double price;
   private final Town town;
   private final int plotAmount;

   public TownBlockClaimCostCalculationEvent(Town town, double price, int plotAmount) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.town = town;
      this.price = price;
      this.plotAmount = plotAmount;
   }

   public Town getTown() {
      return this.town;
   }

   public void setPrice(double value) {
      this.price = value;
   }

   public double getPrice() {
      return this.price;
   }

   public int getAmountOfRequestedTownBlocks() {
      return this.plotAmount;
   }

   public int getNumberOfAlreadyClaimedTownBlocks() {
      return this.town.getTownBlocks().size();
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}
