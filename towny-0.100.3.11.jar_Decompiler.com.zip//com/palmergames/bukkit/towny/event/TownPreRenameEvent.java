package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translation;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class TownPreRenameEvent extends CancellableTownyEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private final String oldName;
   private final String newName;
   private final Town town;

   public TownPreRenameEvent(Town town, String newName) {
      this.oldName = town.getName();
      this.town = town;
      this.newName = newName;
      this.setCancelMessage(Translation.of("msg_err_rename_cancelled"));
   }

   public String getOldName() {
      return this.oldName;
   }

   public String getNewName() {
      return this.newName;
   }

   public Town getTown() {
      return this.town;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
