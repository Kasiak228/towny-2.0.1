package com.palmergames.bukkit.towny.event;

import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.WorldCoord;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class NationSpawnEvent extends SpawnEvent {
   private static final HandlerList HANDLER_LIST = new HandlerList();
   private Nation toNation;
   private Nation fromNation;

   public NationSpawnEvent(Player player, Location from, Location to, boolean cancelled, String cancelMessage) {
      super(player, from, to);
      TownBlock fromTownBlock = WorldCoord.parseWorldCoord(from).getTownBlockOrNull();
      TownBlock toTownBlock = WorldCoord.parseWorldCoord(to).getTownBlockOrNull();
      if (fromTownBlock != null) {
         this.fromNation = fromTownBlock.getTownOrNull().getNationOrNull();
      }

      if (toTownBlock != null) {
         this.toNation = toTownBlock.getTownOrNull().getNationOrNull();
      }

      this.setCancelled(cancelled);
      this.setCancelMessage(cancelMessage);
   }

   public Nation getToNation() {
      return this.toNation;
   }

   @Nullable
   public Nation getFromNation() {
      return this.fromNation;
   }

   public static HandlerList getHandlerList() {
      return HANDLER_LIST;
   }

   @NotNull
   public HandlerList getHandlers() {
      return HANDLER_LIST;
   }
}
