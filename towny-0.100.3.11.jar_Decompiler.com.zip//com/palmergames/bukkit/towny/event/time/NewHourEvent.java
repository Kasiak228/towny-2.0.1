package com.palmergames.bukkit.towny.event.time;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class NewHourEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private long time;

   public NewHourEvent(long time) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.time = time;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public long getTime() {
      return this.time;
   }
}
