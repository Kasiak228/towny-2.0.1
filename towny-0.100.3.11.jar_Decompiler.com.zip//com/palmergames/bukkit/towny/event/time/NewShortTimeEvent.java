package com.palmergames.bukkit.towny.event.time;

import com.palmergames.bukkit.towny.TownySettings;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class NewShortTimeEvent extends Event {
   private static final HandlerList handlers = new HandlerList();
   private long time;

   public NewShortTimeEvent(long time) {
      super(!Bukkit.getServer().isPrimaryThread());
      this.time = time;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public long getTime() {
      return this.time;
   }

   public long getShortTaskPeriod() {
      return TownySettings.getShortInterval();
   }
}
