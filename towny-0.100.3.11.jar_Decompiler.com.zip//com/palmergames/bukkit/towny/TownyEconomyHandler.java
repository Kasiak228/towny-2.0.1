package com.palmergames.bukkit.towny;

import com.palmergames.bukkit.config.ConfigNodes;
import com.palmergames.bukkit.towny.event.economy.TownyPreTransactionEvent;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.economy.Account;
import com.palmergames.bukkit.towny.object.economy.TownyServerAccount;
import com.palmergames.bukkit.towny.object.economy.TownyServerAccountEconomyHandler;
import com.palmergames.bukkit.towny.object.economy.adapter.EconomyAdapter;
import com.palmergames.bukkit.towny.object.economy.adapter.ReserveEconomyAdapter;
import com.palmergames.bukkit.towny.object.economy.adapter.VaultEconomyAdapter;
import com.palmergames.bukkit.towny.object.economy.transaction.Transaction;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.Colors;
import java.util.UUID;
import java.util.concurrent.Executor;
import net.milkbowl.vault.economy.Economy;
import net.tnemc.core.Reserve;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.jetbrains.annotations.Nullable;

public class TownyEconomyHandler {
   private static Towny plugin = null;
   private static EconomyAdapter economy = null;
   private static TownyEconomyHandler.EcoType Type;
   private static String version;
   private static final Executor ECONOMY_EXECUTOR;

   public static String getServerAccount() {
      return TownySettings.getString(ConfigNodes.ECO_CLOSED_ECONOMY_SERVER_ACCOUNT);
   }

   @Nullable
   public static UUID getTownyObjectUUID(String accountName) {
      if (accountName.equalsIgnoreCase(getServerAccount())) {
         return TownyServerAccount.getUUID();
      } else {
         String name;
         if (accountName.startsWith(TownySettings.getNPCPrefix())) {
            name = accountName.substring(TownySettings.getNPCPrefix().length());
            Resident resident = TownyAPI.getInstance().getResident(name);
            return resident != null ? resident.getUUID() : null;
         } else if (accountName.startsWith(TownySettings.getTownAccountPrefix())) {
            name = accountName.substring(TownySettings.getTownAccountPrefix().length());
            Town town = TownyAPI.getInstance().getTown(name);
            return town != null ? town.getUUID() : null;
         } else if (accountName.startsWith(TownySettings.getNationAccountPrefix())) {
            name = accountName.substring(TownySettings.getNationAccountPrefix().length());
            Nation nation = TownyAPI.getInstance().getNation(name);
            return nation != null ? nation.getUUID() : null;
         } else {
            return null;
         }
      }
   }

   public static void initialize(Towny plugin) {
      TownyEconomyHandler.plugin = plugin;
   }

   public static TownyServerAccount initializeTownyServerAccount() {
      TownyServerAccountEconomyHandler economyHandler = new TownyServerAccount();
      TownyServerAccount account = new TownyServerAccount(economyHandler);
      return account;
   }

   public static TownyEconomyHandler.EcoType getType() {
      return Type;
   }

   public static boolean isActive() {
      return Type != TownyEconomyHandler.EcoType.NONE && TownySettings.isUsingEconomy();
   }

   public static String getVersion() {
      return version;
   }

   private static void setVersion(String version) {
      TownyEconomyHandler.version = version;
   }

   public static boolean setupEconomy() {
      try {
         RegisteredServiceProvider<Economy> vaultEcoProvider = plugin.getServer().getServicesManager().getRegistration(Economy.class);
         if (vaultEcoProvider != null) {
            economy = new VaultEconomyAdapter((Economy)vaultEcoProvider.getProvider());
            setVersion(String.format("%s %s", ((Economy)vaultEcoProvider.getProvider()).getName(), "via Vault"));
            Type = TownyEconomyHandler.EcoType.VAULT;
            return true;
         }
      } catch (NoClassDefFoundError var2) {
      }

      Plugin economyProvider = plugin.getServer().getPluginManager().getPlugin("Reserve");
      if (economyProvider != null && ((Reserve)economyProvider).economyProvided()) {
         economy = new ReserveEconomyAdapter(((Reserve)economyProvider).economy());
         setVersion(String.format("%s %s", ((Reserve)economyProvider).economy().name(), "via Reserve"));
         Type = TownyEconomyHandler.EcoType.RESERVE;
         return true;
      } else {
         return false;
      }
   }

   public static void removeAccount(String accountName) {
      economy.deleteAccount(accountName);
   }

   public static double getBalance(String accountName, World world) {
      checkNewAccount(accountName);
      return economy.getBalance(accountName, world);
   }

   public static boolean hasEnough(String accountName, double amount, World world) {
      return getBalance(accountName, world) >= amount;
   }

   private static boolean runPreChecks(Transaction transaction, String accountName) {
      TownyPreTransactionEvent preEvent = new TownyPreTransactionEvent(transaction);
      if (BukkitTools.isEventCancelled(preEvent) && transaction.getSendingPlayer() != null) {
         TownyMessaging.sendErrorMsg((Object)transaction.getSendingPlayer(), (String)preEvent.getCancelMessage());
         return false;
      } else {
         checkNewAccount(accountName);
         return true;
      }
   }

   public static boolean subtract(Account account, double amount, World world) {
      if (!runPreChecks(Transaction.subtract(amount).paidBy(account).build(), account.getName())) {
         return false;
      } else {
         return economy.subtract(account.getName(), amount, world);
      }
   }

   public static boolean add(Account account, double amount, World world) {
      if (!runPreChecks(Transaction.add(amount).paidTo(account).build(), account.getName())) {
         return false;
      } else {
         return economy.add(account.getName(), amount, world);
      }
   }

   public static boolean setBalance(String accountName, double amount, World world) {
      checkNewAccount(accountName);
      return economy.setBalance(accountName, amount, world);
   }

   public static String getFormattedBalance(double balance) {
      if (!isActive()) {
         return String.valueOf(balance);
      } else {
         String formattedBalance = economy.getFormattedBalance(balance);
         return formattedBalance != null ? Colors.translateColorCodes(formattedBalance) : Colors.translateColorCodes(String.format("%.2f", balance));
      }
   }

   private static void checkNewAccount(String accountName) {
      if (!economy.hasAccount(accountName)) {
         economy.newAccount(accountName);
      }

   }

   public static boolean hasAccount(String accountName) {
      return economy.hasAccount(accountName);
   }

   public static boolean isEssentials() {
      return getVersion().startsWith("EssentialsX Economy") || getVersion().startsWith("Essentials Economy");
   }

   public static Executor economyExecutor() {
      return ECONOMY_EXECUTOR;
   }

   static {
      Type = TownyEconomyHandler.EcoType.NONE;
      version = "";
      ECONOMY_EXECUTOR = (runnable) -> {
         if (TownySettings.isEconomyAsync() && plugin.getScheduler().isTickThread()) {
            plugin.getScheduler().runAsync(runnable);
         } else if (!TownySettings.isEconomyAsync() && !plugin.getScheduler().isTickThread()) {
            plugin.getScheduler().run(runnable);
         } else {
            runnable.run();
         }

      };
   }

   public static enum EcoType {
      NONE,
      VAULT,
      RESERVE;

      // $FF: synthetic method
      private static TownyEconomyHandler.EcoType[] $values() {
         return new TownyEconomyHandler.EcoType[]{NONE, VAULT, RESERVE};
      }
   }
}
