package com.palmergames.bukkit.towny.db;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.DeleteNationEvent;
import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.EmptyNationException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.exceptions.initialization.TownyInitException;
import com.palmergames.bukkit.towny.object.District;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.PermissionData;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Position;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockTypeHandler;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.metadata.MetadataLoader;
import com.palmergames.bukkit.towny.tasks.CooldownTimerTask;
import com.palmergames.bukkit.towny.utils.MapUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.hikaricp.HikariConfig;
import com.palmergames.hikaricp.HikariDataSource;
import com.palmergames.hikaricp.pool.HikariPool;
import com.palmergames.util.FileMgmt;
import com.palmergames.util.StringMgmt;
import java.io.File;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.jetbrains.annotations.ApiStatus.Internal;

public final class TownySQLSource extends TownyDatabaseHandler {
   private final String tb_prefix;
   private final HikariDataSource hikariDataSource;

   public TownySQLSource(Towny plugin, TownyUniverse universe) {
      super(plugin, universe);
      if (!FileMgmt.checkOrCreateFolders(this.rootFolderPath, this.dataFolderPath, this.dataFolderPath + File.separator + "plot-block-data") || !FileMgmt.checkOrCreateFiles(this.dataFolderPath + File.separator + "regen.txt", this.dataFolderPath + File.separator + "snapshot_queue.txt")) {
         TownyMessaging.sendErrorMsg("Could not create flatfile default files and folders.");
      }

      this.tb_prefix = TownySettings.getSQLTablePrefix().toUpperCase();
      String var10000 = TownySettings.getSQLHostName();
      String dsn = "jdbc:mysql://" + var10000 + ":" + TownySettings.getSQLPort() + "/" + TownySettings.getSQLDBName() + TownySettings.getSQLFlags();
      HikariConfig config = new HikariConfig();
      config.setPoolName("Towny MySQL");
      config.setJdbcUrl(dsn);
      config.setUsername(TownySettings.getSQLUsername());
      config.setPassword(TownySettings.getSQLPassword());
      config.addDataSourceProperty("cachePrepStmts", "true");
      config.addDataSourceProperty("prepStmtCacheSize", "250");
      config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
      config.addDataSourceProperty("useServerPrepStmts", "true");
      config.addDataSourceProperty("useLocalSessionState", "true");
      config.addDataSourceProperty("rewriteBatchedStatements", "true");
      config.addDataSourceProperty("cacheResultSetMetadata", "true");
      config.addDataSourceProperty("cacheServerConfiguration", "true");
      config.addDataSourceProperty("elideSetAutoCommits", "true");
      config.addDataSourceProperty("maintainTimeStats", "false");
      config.addDataSourceProperty("cacheCallableStmts", "true");
      config.setMaximumPoolSize(TownySettings.getMaxPoolSize());
      config.setMaxLifetime((long)TownySettings.getMaxLifetime());
      config.setConnectionTimeout((long)TownySettings.getConnectionTimeout());

      try {
         Driver driver;
         try {
            driver = (Driver)Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
         } catch (ClassNotFoundException var9) {
            driver = (Driver)Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
         }

         DriverManager.registerDriver(driver);
      } catch (Exception var10) {
         plugin.getLogger().severe("Driver error: " + var10);
      }

      try {
         this.hikariDataSource = new HikariDataSource(config);
         Connection connection = this.getConnection();

         try {
            TownyMessaging.sendDebugMsg("Connected to the database");
            SQLSchema.initTables(connection);
         } catch (Throwable var11) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var8) {
                  var11.addSuppressed(var8);
               }
            }

            throw var11;
         }

         if (connection != null) {
            connection.close();
         }

      } catch (HikariPool.PoolInitializationException | SQLException var12) {
         throw new TownyInitException("Failed to connect to the database", TownyInitException.TownyError.DATABASE, var12);
      }
   }

   public void finishTasks() {
      super.finishTasks();
      if (this.hikariDataSource != null) {
         this.hikariDataSource.close();
      }

   }

   /** @deprecated */
   @Deprecated(
      forRemoval = true
   )
   public boolean getContext() {
      return this.isReady();
   }

   public boolean isReady() {
      return this.hikariDataSource != null && this.hikariDataSource.isRunning();
   }

   public Connection getConnection() throws SQLException {
      return this.hikariDataSource.getConnection();
   }

   public boolean updateDB(String tb_name, Map<String, ?> args, List<String> keys) {
      this.queryQueue.add(new SQLTask(this, tb_name, args, keys));
      return true;
   }

   @Internal
   public boolean queueUpdateDB(String tb_name, Map<String, ?> args, List<String> keys) {
      PreparedStatement stmt = null;
      List<Object> parameters = new ArrayList();
      int rs = 0;

      Logger var10000;
      String var10001;
      try {
         Connection connection = this.getConnection();

         try {
            StringBuilder code;
            String[] aKeys;
            String var10002;
            if (keys == null) {
               parameters.addAll(args.values());
               aKeys = (String[])args.keySet().toArray(new String[0]);
               var10002 = this.tb_prefix;
               code = new StringBuilder("REPLACE INTO " + var10002 + tb_name.toUpperCase() + " ");
               StringBuilder keycode = new StringBuilder("(");
               StringBuilder valuecode = new StringBuilder(" VALUES (");

               for(int count = 0; count < args.size(); ++count) {
                  keycode.append("`").append(aKeys[count]).append("`");
                  valuecode.append("?");
                  if (count < args.size() - 1) {
                     keycode.append(", ");
                     valuecode.append(",");
                  } else {
                     keycode.append(")");
                     valuecode.append(")");
                  }
               }

               code.append(keycode);
               code.append(valuecode);
            } else {
               aKeys = (String[])args.keySet().toArray(new String[0]);
               var10002 = this.tb_prefix;
               code = new StringBuilder("UPDATE " + var10002 + tb_name.toUpperCase() + " SET ");

               int count;
               for(count = 0; count < args.size(); ++count) {
                  code.append("`").append(aKeys[count]).append("` = ?");
                  parameters.add(args.get(aKeys[count]));
                  if (count < args.size() - 1) {
                     code.append(",");
                  }
               }

               code.append(" WHERE ");

               for(count = 0; count < keys.size(); ++count) {
                  code.append("`").append((String)keys.get(count)).append("` = ?");
                  parameters.add(args.get(keys.get(count)));
                  if (count < keys.size() - 1) {
                     code.append(" AND ");
                  }
               }
            }

            stmt = connection.prepareStatement(code.toString());

            for(int count = 0; count < parameters.size(); ++count) {
               Object element = parameters.get(count);
               if (element instanceof String) {
                  stmt.setString(count + 1, (String)element);
               } else if (element instanceof Boolean) {
                  stmt.setString(count + 1, (Boolean)element ? "1" : "0");
               } else {
                  stmt.setObject(count + 1, element.toString());
               }
            }

            rs = stmt.executeUpdate();
         } catch (Throwable var24) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var23) {
                  var24.addSuppressed(var23);
               }
            }

            throw var24;
         }

         if (connection != null) {
            connection.close();
         }
      } catch (SQLException var25) {
         var10000 = Towny.getPlugin().getLogger();
         var10001 = var25.getMessage();
         var10000.warning("SQL: " + var10001 + " --> " + stmt.toString());
      } finally {
         try {
            if (stmt != null) {
               stmt.close();
            }

            if (rs == 0) {
               return this.updateDB(tb_name, args, (List)null);
            }
         } catch (SQLException var22) {
            var10000 = Towny.getPlugin().getLogger();
            var10001 = var22.getMessage();
            var10000.warning("SQL closing: " + var10001 + " --> " + stmt.toString());
         }

      }

      return rs != 0;
   }

   @Internal
   public boolean DeleteDB(String tb_name, HashMap<String, Object> args) {
      this.queryQueue.add(new SQLTask(this, tb_name, args));
      return true;
   }

   @Internal
   public boolean queueDeleteDB(String tb_name, Map<String, ?> args) {
      try {
         String var10002 = this.tb_prefix;
         StringBuilder wherecode = new StringBuilder("DELETE FROM " + var10002 + tb_name.toUpperCase() + " WHERE ");
         Iterator i = args.entrySet().iterator();

         while(i.hasNext()) {
            Entry<String, ?> me = (Entry)i.next();
            wherecode.append("`").append((String)me.getKey()).append("` = ?");
            wherecode.append(i.hasNext() ? " AND " : "");
         }

         Connection connection = this.getConnection();

         int rs;
         try {
            PreparedStatement statement = connection.prepareStatement(wherecode.toString());

            try {
               Object[] values = args.values().stream().toArray();

               for(int count = 0; count < values.length; ++count) {
                  Object object = values[count];
                  if (object instanceof String) {
                     statement.setString(count + 1, (String)object);
                  } else if (object instanceof Boolean) {
                     statement.setBoolean(count + 1, (Boolean)object);
                  } else {
                     statement.setObject(count + 1, object);
                  }
               }

               rs = statement.executeUpdate();
            } catch (Throwable var13) {
               if (statement != null) {
                  try {
                     statement.close();
                  } catch (Throwable var12) {
                     var13.addSuppressed(var12);
                  }
               }

               throw var13;
            }

            if (statement != null) {
               statement.close();
            }
         } catch (Throwable var14) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var11) {
                  var14.addSuppressed(var11);
               }
            }

            throw var14;
         }

         if (connection != null) {
            connection.close();
         }

         if (rs == 0) {
            TownyMessaging.sendDebugMsg("SQL: delete returned 0: " + wherecode);
         }
      } catch (SQLException var15) {
         Towny.getPlugin().getLogger().warning("SQL: Error delete : " + var15.getMessage());
      }

      return false;
   }

   public boolean cleanup() {
      try {
         Connection connection = this.getConnection();

         try {
            SQLSchema.cleanup(connection);
         } catch (Throwable var5) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (connection != null) {
            connection.close();
         }
      } catch (SQLException var6) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred when cleaning up SQL schema.", var6);
      }

      return true;
   }

   public boolean loadTownBlockList() {
      TownyMessaging.sendDebugMsg("Loading TownBlock List");

      try {
         Connection connection = this.getConnection();

         boolean var18;
         try {
            Statement s = connection.createStatement();

            try {
               ResultSet rs = s.executeQuery("SELECT world,x,z FROM " + this.tb_prefix + "TOWNBLOCKS");

               try {
                  int total;
                  for(total = 0; rs.next(); ++total) {
                     String worldName = rs.getString("world");
                     TownyWorld world = this.universe.getWorld(worldName);
                     if (world == null) {
                        throw new Exception("World " + worldName + " not registered!");
                     }

                     int x = Integer.parseInt(rs.getString("x"));
                     int z = Integer.parseInt(rs.getString("z"));
                     TownBlock townBlock = new TownBlock(x, z, world);
                     this.universe.addTownBlock(townBlock);
                  }

                  TownyMessaging.sendDebugMsg("Loaded " + total + " townblocks.");
                  var18 = true;
               } catch (Throwable var13) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var12) {
                        var13.addSuppressed(var12);
                     }
                  }

                  throw var13;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var14) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var11) {
                     var14.addSuppressed(var11);
                  }
               }

               throw var14;
            }

            if (s != null) {
               s.close();
            }
         } catch (Throwable var15) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var10) {
                  var15.addSuppressed(var10);
               }
            }

            throw var15;
         }

         if (connection != null) {
            connection.close();
         }

         return var18;
      } catch (SQLException var16) {
         this.plugin.getLogger().warning("SQL: town block list error: " + var16.getMessage());
      } catch (Exception var17) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: townblock list unknown error", var17);
      }

      return false;
   }

   public boolean loadResidentList() {
      TownyMessaging.sendDebugMsg("Loading Resident List");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         try {
            Statement s = connection.createStatement();

            try {
               ResultSet rs = s.executeQuery("SELECT name FROM " + this.tb_prefix + "RESIDENTS");

               try {
                  while(rs.next()) {
                     try {
                        this.newResident(rs.getString("name"));
                     } catch (AlreadyRegisteredException var9) {
                     }
                  }

                  var4 = true;
               } catch (Throwable var10) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var8) {
                        var10.addSuppressed(var8);
                     }
                  }

                  throw var10;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var11) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var7) {
                     var11.addSuppressed(var7);
                  }
               }

               throw var11;
            }

            if (s != null) {
               s.close();
            }
         } catch (Throwable var12) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var6) {
                  var12.addSuppressed(var6);
               }
            }

            throw var12;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (Exception var13) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: resident list unknown error", var13);
         return false;
      }
   }

   public boolean loadTownList() {
      TownyMessaging.sendDebugMsg("Loading Town List");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         try {
            Statement s = connection.createStatement();

            try {
               ResultSet rs = s.executeQuery("SELECT name FROM " + this.tb_prefix + "TOWNS");

               try {
                  while(rs.next()) {
                     try {
                        this.universe.newTownInternal(rs.getString("name"));
                     } catch (AlreadyRegisteredException var9) {
                     }
                  }

                  var4 = true;
               } catch (Throwable var10) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var8) {
                        var10.addSuppressed(var8);
                     }
                  }

                  throw var10;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var11) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var7) {
                     var11.addSuppressed(var7);
                  }
               }

               throw var11;
            }

            if (s != null) {
               s.close();
            }
         } catch (Throwable var12) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var6) {
                  var12.addSuppressed(var6);
               }
            }

            throw var12;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var13) {
         TownyMessaging.sendErrorMsg("SQL: town list sql error : " + var13.getMessage());
      } catch (Exception var14) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: town list unknown error", var14);
      }

      return false;
   }

   public boolean loadNationList() {
      TownyMessaging.sendDebugMsg("Loading Nation List");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         try {
            Statement s = connection.createStatement();

            try {
               ResultSet rs = s.executeQuery("SELECT name FROM " + this.tb_prefix + "NATIONS");

               try {
                  while(rs.next()) {
                     try {
                        this.newNation(rs.getString("name"));
                     } catch (AlreadyRegisteredException var9) {
                     }
                  }

                  var4 = true;
               } catch (Throwable var10) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var8) {
                        var10.addSuppressed(var8);
                     }
                  }

                  throw var10;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var11) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var7) {
                     var11.addSuppressed(var7);
                  }
               }

               throw var11;
            }

            if (s != null) {
               s.close();
            }
         } catch (Throwable var12) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var6) {
                  var12.addSuppressed(var6);
               }
            }

            throw var12;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var13) {
         TownyMessaging.sendErrorMsg("SQL: nation list sql error : " + var13.getMessage());
      } catch (Exception var14) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: nation list unknown error", var14);
      }

      return false;
   }

   public boolean loadWorldList() {
      TownyMessaging.sendDebugMsg("Loading World List");
      Iterator var1 = Bukkit.getServer().getWorlds().iterator();

      while(var1.hasNext()) {
         World world = (World)var1.next();
         this.universe.registerTownyWorld(new TownyWorld(world.getName(), world.getUID()));
      }

      try {
         Connection connection = this.getConnection();

         try {
            Statement s = connection.createStatement();

            try {
               ResultSet rs = s.executeQuery("SELECT name FROM " + this.tb_prefix + "WORLDS");

               try {
                  while(rs.next()) {
                     String name = rs.getString("name");
                     if (this.universe.getWorld(name) == null) {
                        UUID uuid = null;

                        try {
                           uuid = UUID.fromString(rs.getString("uuid"));
                        } catch (NullPointerException | SQLException | IllegalArgumentException var11) {
                        }

                        if (uuid != null) {
                           this.universe.registerTownyWorld(new TownyWorld(rs.getString("name"), uuid));
                        } else {
                           try {
                              this.newWorld(rs.getString("name"));
                           } catch (AlreadyRegisteredException var10) {
                           }
                        }
                     }
                  }
               } catch (Throwable var12) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var9) {
                        var12.addSuppressed(var9);
                     }
                  }

                  throw var12;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var13) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var8) {
                     var13.addSuppressed(var8);
                  }
               }

               throw var13;
            }

            if (s != null) {
               s.close();
            }
         } catch (Throwable var14) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var7) {
                  var14.addSuppressed(var7);
               }
            }

            throw var14;
         }

         if (connection != null) {
            connection.close();
         }
      } catch (SQLException var15) {
         TownyMessaging.sendErrorMsg("SQL: world list sql error : " + var15.getMessage());
      } catch (Exception var16) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: world list unknown error", var16);
      }

      return true;
   }

   public boolean loadPlotGroupList() {
      TownyMessaging.sendDebugMsg("Loading PlotGroup List");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         try {
            Statement s = connection.createStatement();

            try {
               ResultSet rs = s.executeQuery("SELECT groupID FROM " + this.tb_prefix + "PLOTGROUPS");

               try {
                  while(rs.next()) {
                     try {
                        this.universe.newPlotGroupInternal(UUID.fromString(rs.getString("groupID")));
                     } catch (IllegalArgumentException var9) {
                        this.plugin.getLogger().log(Level.WARNING, "ID for plot group is not a valid uuid, skipped loading plot group {}", rs.getString("groupID"));
                     }
                  }

                  var4 = true;
               } catch (Throwable var10) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var8) {
                        var10.addSuppressed(var8);
                     }
                  }

                  throw var10;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var11) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var7) {
                     var11.addSuppressed(var7);
                  }
               }

               throw var11;
            }

            if (s != null) {
               s.close();
            }
         } catch (Throwable var12) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var6) {
                  var12.addSuppressed(var6);
               }
            }

            throw var12;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var13) {
         this.plugin.getLogger().log(Level.SEVERE, "An exception occurred while loading plot group list", var13);
         return false;
      }
   }

   public boolean loadDistrictList() {
      TownyMessaging.sendDebugMsg("Loading District List");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         try {
            Statement s = connection.createStatement();

            try {
               ResultSet rs = s.executeQuery("SELECT uuid FROM " + this.tb_prefix + "DISTRICTS");

               try {
                  while(rs.next()) {
                     try {
                        this.universe.newDistrictInternal(UUID.fromString(rs.getString("uuid")));
                     } catch (IllegalArgumentException var9) {
                        this.plugin.getLogger().log(Level.WARNING, "ID for district is not a valid uuid, skipped loading district {}", rs.getString("uuid"));
                     }
                  }

                  var4 = true;
               } catch (Throwable var10) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var8) {
                        var10.addSuppressed(var8);
                     }
                  }

                  throw var10;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var11) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var7) {
                     var11.addSuppressed(var7);
                  }
               }

               throw var11;
            }

            if (s != null) {
               s.close();
            }
         } catch (Throwable var12) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var6) {
                  var12.addSuppressed(var6);
               }
            }

            throw var12;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var13) {
         this.plugin.getLogger().log(Level.SEVERE, "An exception occurred while loading district list", var13);
         return false;
      }
   }

   public boolean loadJailList() {
      TownyMessaging.sendDebugMsg("Loading Jail List");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         try {
            Statement s = connection.createStatement();

            try {
               ResultSet rs = s.executeQuery("SELECT uuid FROM " + this.tb_prefix + "JAILS");

               try {
                  while(rs.next()) {
                     this.universe.newJailInternal(rs.getString("uuid"));
                  }

                  var4 = true;
               } catch (Throwable var9) {
                  if (rs != null) {
                     try {
                        rs.close();
                     } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                     }
                  }

                  throw var9;
               }

               if (rs != null) {
                  rs.close();
               }
            } catch (Throwable var10) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var7) {
                     var10.addSuppressed(var7);
                  }
               }

               throw var10;
            }

            if (s != null) {
               s.close();
            }
         } catch (Throwable var11) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var6) {
                  var11.addSuppressed(var6);
               }
            }

            throw var11;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (Exception var12) {
         this.plugin.getLogger().log(Level.SEVERE, "An exception occurred while loading jail list", var12);
         return false;
      }
   }

   public boolean loadResidents() {
      TownyMessaging.sendDebugMsg("Loading Residents");

      try {
         Connection connection = this.getConnection();

         label120: {
            boolean var6;
            try {
               label121: {
                  Statement s;
                  label122: {
                     s = connection.createStatement();

                     try {
                        ResultSet rs = s.executeQuery("SELECT * FROM " + this.tb_prefix + "RESIDENTS");

                        label104: {
                           try {
                              while(rs.next()) {
                                 String residentName;
                                 try {
                                    residentName = rs.getString("name");
                                 } catch (SQLException var10) {
                                    this.plugin.getLogger().log(Level.SEVERE, "Loading Error: Error fetching a resident name from SQL Database. Skipping loading resident..", var10);
                                    continue;
                                 }

                                 Resident resident = this.universe.getResident(residentName);
                                 if (resident == null) {
                                    this.plugin.getLogger().severe(String.format("Loading Error: Could not fetch resident '%s' from Towny universe while loading from SQL DB.", residentName));
                                 } else if (!this.loadResident(resident, rs)) {
                                    this.plugin.getLogger().severe("Loading Error: Could not read resident data '" + resident.getName() + "'.");
                                    var6 = false;
                                    break label104;
                                 }
                              }
                           } catch (Throwable var11) {
                              if (rs != null) {
                                 try {
                                    rs.close();
                                 } catch (Throwable var9) {
                                    var11.addSuppressed(var9);
                                 }
                              }

                              throw var11;
                           }

                           if (rs != null) {
                              rs.close();
                           }
                           break label122;
                        }

                        if (rs != null) {
                           rs.close();
                        }
                     } catch (Throwable var12) {
                        if (s != null) {
                           try {
                              s.close();
                           } catch (Throwable var8) {
                              var12.addSuppressed(var8);
                           }
                        }

                        throw var12;
                     }

                     if (s != null) {
                        s.close();
                     }
                     break label121;
                  }

                  if (s != null) {
                     s.close();
                  }
                  break label120;
               }
            } catch (Throwable var13) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var7) {
                     var13.addSuppressed(var7);
                  }
               }

               throw var13;
            }

            if (connection != null) {
               connection.close();
            }

            return var6;
         }

         if (connection != null) {
            connection.close();
         }
      } catch (SQLException var14) {
         TownyMessaging.sendErrorMsg("SQL: Load resident sql error : " + var14.getMessage());
      }

      return true;
   }

   public boolean loadResident(Resident resident) {
      return true;
   }

   private boolean loadResident(Resident resident, ResultSet rs) {
      try {
         UUID uuid;
         String var10000;
         try {
            if (rs.getString("uuid") != null && !rs.getString("uuid").isEmpty()) {
               uuid = UUID.fromString(rs.getString("uuid"));
               if (this.universe.hasResident(uuid)) {
                  Resident olderRes = this.universe.getResident(uuid);
                  if (resident.getLastOnline() <= olderRes.getLastOnline()) {
                     var10000 = resident.getName();
                     TownyMessaging.sendDebugMsg("Deleting resident : " + var10000 + " which is a dupe of " + olderRes.getName());

                     try {
                        this.universe.unregisterResident(resident);
                     } catch (NotRegisteredException var22) {
                     }

                     this.deleteResident(resident);
                     return true;
                  }

                  var10000 = olderRes.getName();
                  TownyMessaging.sendDebugMsg("Deleting : " + var10000 + " which is a dupe of " + resident.getName());

                  try {
                     this.universe.unregisterResident(olderRes);
                  } catch (NotRegisteredException var24) {
                  }

                  if (olderRes.hasTown()) {
                     try {
                        olderRes.getTown().removeResident(olderRes);
                     } catch (NotRegisteredException var23) {
                     }
                  }

                  this.deleteResident(olderRes);
               }

               resident.setUUID(uuid);
               this.universe.registerResidentUUID(resident);
            }
         } catch (SQLException var25) {
            this.plugin.getLogger().log(Level.WARNING, "Could not get uuid column on the residents table", var25);
         }

         try {
            resident.setLastOnline(rs.getLong("lastOnline"));
         } catch (SQLException var21) {
            this.plugin.getLogger().log(Level.WARNING, "Could not get lastOnline column on the residents table", var21);
         }

         try {
            resident.setRegistered(rs.getLong("registered"));
         } catch (SQLException var20) {
            this.plugin.getLogger().log(Level.WARNING, "Could not get registered column on the residents table", var20);
         }

         try {
            resident.setJoinedTownAt(rs.getLong("joinedTownAt"));
         } catch (SQLException var19) {
            this.plugin.getLogger().log(Level.WARNING, "Could not get joinedTownAt column on the residents table", var19);
         }

         try {
            resident.setNPC(rs.getBoolean("isNPC"));
         } catch (SQLException var18) {
            this.plugin.getLogger().log(Level.WARNING, "Could not get isNPC column on the residents table", var18);
         }

         if (rs.getString("jailUUID") != null && !rs.getString("jailUUID").isEmpty()) {
            uuid = UUID.fromString(rs.getString("jailUUID"));
            if (this.universe.hasJail(uuid)) {
               resident.setJail(this.universe.getJail(uuid));
            }
         }

         if (resident.isJailed()) {
            try {
               if (rs.getString("jailCell") != null && !rs.getString("jailCell").isEmpty()) {
                  resident.setJailCell(rs.getInt("jailCell"));
               }
            } catch (SQLException var17) {
               this.plugin.getLogger().log(Level.WARNING, "Could not get jailCell column on the residents table", var17);
            }

            try {
               if (rs.getString("jailHours") != null && !rs.getString("jailHours").isEmpty()) {
                  resident.setJailHours(rs.getInt("jailHours"));
               }
            } catch (SQLException var16) {
               this.plugin.getLogger().log(Level.WARNING, "Could not get jailHours column on the residents table", var16);
            }

            try {
               if (rs.getString("jailBail") != null && !rs.getString("jailBail").isEmpty()) {
                  resident.setJailBailCost(rs.getDouble("jailBail"));
               }
            } catch (SQLException var15) {
               this.plugin.getLogger().log(Level.WARNING, "Could not get jailBail column on the residents table", var15);
            }
         }

         String line;
         try {
            line = rs.getString("about");
            if (line != null) {
               resident.setAbout(line);
            }
         } catch (SQLException var14) {
            this.plugin.getLogger().log(Level.WARNING, "Could not get about column on the residents table", var14);
         }

         String search;
         try {
            line = rs.getString("friends");
            if (line != null) {
               search = line.contains("#") ? "#" : ",";
               List<Resident> friends = TownyAPI.getInstance().getResidents(line.split(search));
               Iterator var6 = friends.iterator();

               while(var6.hasNext()) {
                  Resident friend = (Resident)var6.next();
                  resident.addFriend(friend);
               }
            }
         } catch (SQLException var26) {
            this.plugin.getLogger().log(Level.WARNING, "Could not get friends column on the residents table", var26);
         }

         try {
            resident.setPermissions(rs.getString("protectionStatus").replaceAll("#", ","));
         } catch (SQLException var13) {
            this.plugin.getLogger().log(Level.WARNING, "Could not get protectionStatus column on the residents table", var13);
         }

         try {
            line = rs.getString("metadata");
            if (line != null && !line.isEmpty()) {
               MetadataLoader.getInstance().deserializeMetadata(resident, line);
            }
         } catch (SQLException var12) {
         }

         line = rs.getString("town");
         if (line != null && !line.isEmpty()) {
            Town town = this.universe.getTown(line);
            if (town == null) {
               var10000 = resident.getName();
               TownyMessaging.sendErrorMsg("Loading Error: " + var10000 + " tried to load the town " + line + " which is invalid, removing town from the resident.");
               resident.setTown((Town)null, false);
            } else {
               resident.setTown(town, false);

               try {
                  resident.setTitle(rs.getString("title"));
               } catch (SQLException var11) {
                  this.plugin.getLogger().log(Level.WARNING, "Could not get title column on the residents table", var11);
               }

               try {
                  resident.setSurname(rs.getString("surname"));
               } catch (SQLException var10) {
                  this.plugin.getLogger().log(Level.WARNING, "Could not get surname column on the residents table", var10);
               }

               try {
                  line = rs.getString("town-ranks");
                  if (line != null && !line.isEmpty()) {
                     search = line.contains("#") ? "#" : ",";
                     resident.setTownRanks(Arrays.asList(line.split(search)));
                  }
               } catch (Exception var9) {
               }

               try {
                  line = rs.getString("nation-ranks");
                  if (line != null && !line.isEmpty()) {
                     search = line.contains("#") ? "#" : ",";
                     resident.setNationRanks(Arrays.asList(line.split(search)));
                  }
               } catch (Exception var8) {
               }
            }
         }

         return true;
      } catch (SQLException var27) {
         TownyMessaging.sendErrorMsg("SQL: Load resident sql error : " + var27.getMessage());
      } catch (Exception var28) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Load resident unknown error", var28);
      }

      return false;
   }

   public boolean loadTowns() {
      TownyMessaging.sendDebugMsg("Loading Towns");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         label106: {
            try {
               Statement s;
               label108: {
                  s = connection.createStatement();

                  try {
                     ResultSet rs = s.executeQuery("SELECT * FROM " + this.tb_prefix + "TOWNS ");

                     label92: {
                        try {
                           while(rs.next()) {
                              if (!this.loadTown(rs)) {
                                 this.plugin.getLogger().warning("Loading Error: Could not read town data properly.");
                                 var4 = false;
                                 break label92;
                              }
                           }
                        } catch (Throwable var9) {
                           if (rs != null) {
                              try {
                                 rs.close();
                              } catch (Throwable var8) {
                                 var9.addSuppressed(var8);
                              }
                           }

                           throw var9;
                        }

                        if (rs != null) {
                           rs.close();
                        }
                        break label108;
                     }

                     if (rs != null) {
                        rs.close();
                     }
                  } catch (Throwable var10) {
                     if (s != null) {
                        try {
                           s.close();
                        } catch (Throwable var7) {
                           var10.addSuppressed(var7);
                        }
                     }

                     throw var10;
                  }

                  if (s != null) {
                     s.close();
                  }
                  break label106;
               }

               if (s != null) {
                  s.close();
               }
            } catch (Throwable var11) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var6) {
                     var11.addSuppressed(var6);
                  }
               }

               throw var11;
            }

            if (connection != null) {
               connection.close();
            }

            return true;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var12) {
         TownyMessaging.sendErrorMsg("SQL: Load Town sql Error - " + var12.getMessage());
         return false;
      }
   }

   public boolean loadTown(Town town) {
      return true;
   }

   private boolean loadTown(ResultSet rs) {
      String name = null;

      try {
         Town town = this.universe.getTown(rs.getString("name"));
         if (town == null) {
            TownyMessaging.sendErrorMsg("SQL: Load Town " + rs.getString("name") + ". Town was not registered properly on load!");
            return false;
         }

         name = town.getName();
         TownyMessaging.sendDebugMsg("Loading town " + name);

         try {
            Resident res = this.universe.getResident(rs.getString("mayor"));
            if (res == null) {
               throw new TownyException();
            }

            town.forceSetMayor(res);
         } catch (TownyException var25) {
            var25.getMessage();
            if (town.getResidents().size() == 0) {
               this.deleteTown(town);
               return true;
            }

            town.findNewMayor();
         }

         town.setBoard(rs.getString("townBoard"));
         String line = rs.getString("tag");
         if (line != null) {
            town.setTag(line);
         }

         line = rs.getString("founder");
         if (line != null) {
            town.setFounder(line);
         }

         town.setPermissions(rs.getString("protectionStatus").replaceAll("#", ","));
         town.setBonusBlocks(rs.getInt("bonus"));
         town.setManualTownLevel(rs.getInt("manualTownLevel"));
         town.setTaxPercentage(rs.getBoolean("taxpercent"));
         town.setTaxes((double)rs.getFloat("taxes"));
         town.setMaxPercentTaxAmount((double)rs.getFloat("maxPercentTaxAmount"));
         town.setHasUpkeep(rs.getBoolean("hasUpkeep"));
         town.setHasUnlimitedClaims(rs.getBoolean("hasUnlimitedClaims"));
         town.setVisibleOnTopLists(rs.getBoolean("visibleOnTopLists"));
         town.setPlotPrice((double)rs.getFloat("plotPrice"));
         town.setPlotTax((double)rs.getFloat("plotTax"));
         town.setEmbassyPlotPrice((double)rs.getFloat("embassyPlotPrice"));
         town.setEmbassyPlotTax((double)rs.getFloat("embassyPlotTax"));
         town.setCommercialPlotPrice((double)rs.getFloat("commercialPlotPrice"));
         town.setCommercialPlotTax((double)rs.getFloat("commercialPlotTax"));
         town.setSpawnCost((double)rs.getFloat("spawnCost"));
         town.setOpen(rs.getBoolean("open"));
         town.setPublic(rs.getBoolean("public"));
         town.setConquered(rs.getBoolean("conquered"), false);
         town.setAdminDisabledPVP(rs.getBoolean("admindisabledpvp"));
         town.setAdminEnabledPVP(rs.getBoolean("adminenabledpvp"));
         town.setAdminEnabledMobs(rs.getBoolean("adminEnabledMobs"));
         town.setAllowedToWar(rs.getBoolean("allowedToWar"));
         town.setJoinedNationAt(rs.getLong("joinedNationAt"));
         town.setMovedHomeBlockAt(rs.getLong("movedHomeBlockAt"));
         line = rs.getString("forSale");
         if (line != null) {
            town.setForSale(Boolean.getBoolean(line));
         }

         line = rs.getString("forSalePrice");
         if (line != null) {
            town.setForSalePrice(Double.parseDouble(line));
         }

         town.setPurchasedBlocks(rs.getInt("purchased"));
         town.setNationZoneOverride(rs.getInt("nationZoneOverride"));
         town.setNationZoneEnabled(rs.getBoolean("nationZoneEnabled"));
         line = rs.getString("maxPercentTaxAmount");
         if (line != null) {
            town.setMaxPercentTaxAmount(Double.parseDouble(line));
         } else {
            town.setMaxPercentTaxAmount(TownySettings.getMaxTownTaxPercentAmount());
         }

         line = rs.getString("homeBlock");
         String[] tokens;
         String search;
         int x;
         int z;
         if (line != null) {
            search = line.contains("#") ? "#" : ",";
            tokens = line.split(search);
            if (tokens.length == 3) {
               TownyWorld world = this.universe.getWorld(tokens[0]);
               if (world == null) {
                  TownyMessaging.sendErrorMsg("[Warning] " + town.getName() + " homeBlock tried to load invalid world.");
               } else {
                  try {
                     x = Integer.parseInt(tokens[1]);
                     z = Integer.parseInt(tokens[2]);
                     TownBlock homeBlock = this.universe.getTownBlock(new WorldCoord(world.getName(), x, z));
                     town.forceSetHomeBlock(homeBlock);
                  } catch (NumberFormatException var22) {
                     TownyMessaging.sendErrorMsg("[Warning] " + town.getName() + " homeBlock tried to load invalid location.");
                  } catch (NotRegisteredException var23) {
                     TownyMessaging.sendErrorMsg("[Warning] " + town.getName() + " homeBlock tried to load invalid TownBlock.");
                  } catch (TownyException var24) {
                     TownyMessaging.sendErrorMsg("[Warning] " + town.getName() + " does not have a home block.");
                  }
               }
            }
         }

         line = rs.getString("spawn");
         Logger var10000;
         String var10001;
         if (line != null) {
            search = line.contains("#") ? "#" : ",";
            tokens = line.split(search);
            if (tokens.length >= 4) {
               try {
                  town.spawnPosition(Position.deserialize(tokens));
               } catch (IllegalArgumentException var21) {
                  var10000 = this.plugin.getLogger();
                  var10001 = town.getName();
                  var10000.warning("Failed to load spawn location for town " + var10001 + ": " + var21.getMessage());
               }
            }
         }

         line = rs.getString("outpostSpawns");
         String spawn;
         String[] jails;
         String[] var30;
         int var35;
         if (line != null) {
            jails = line.split(";");
            var30 = jails;
            z = jails.length;

            for(var35 = 0; var35 < z; ++var35) {
               spawn = var30[var35];
               search = line.contains("#") ? "#" : ",";
               tokens = spawn.split(search);
               if (tokens.length >= 4) {
                  try {
                     town.forceAddOutpostSpawn(Position.deserialize(tokens));
                  } catch (IllegalArgumentException var20) {
                     var10000 = this.plugin.getLogger();
                     var10001 = town.getName();
                     var10000.warning("Failed to load an outpost spawn location for town " + var10001 + ": " + var20.getMessage());
                  }
               }
            }
         }

         line = rs.getString("jailSpawns");
         if (line != null) {
            jails = line.split(";");
            var30 = jails;
            z = jails.length;

            for(var35 = 0; var35 < z; ++var35) {
               spawn = var30[var35];
               search = line.contains("#") ? "#" : ",";
               tokens = spawn.split(search);
               if (tokens.length >= 4) {
                  try {
                     Position pos = Position.deserialize(tokens);
                     TownBlock tb = this.universe.getTownBlock(pos.worldCoord());
                     if (tb != null) {
                        Jail jail = new Jail(UUID.randomUUID(), town, tb, Collections.singleton(pos));
                        this.universe.registerJail(jail);
                        town.addJail(jail);
                        tb.setJail(jail);
                        jail.save();
                     }
                  } catch (IllegalArgumentException var19) {
                     var10000 = this.plugin.getLogger();
                     var10001 = town.getName();
                     var10000.warning("Failed to load a legacy jail spawn location for town " + var10001 + ": " + var19.getMessage());
                  }
               }
            }
         }

         line = rs.getString("outlaws");
         if (line != null) {
            search = line.contains("#") ? "#" : ",";
            tokens = line.split(search);
            jails = tokens;
            x = tokens.length;

            for(z = 0; z < x; ++z) {
               String token = jails[z];
               if (!token.isEmpty()) {
                  Resident resident = this.universe.getResident(token);
                  if (resident != null) {
                     town.addOutlaw(resident);
                  } else {
                     this.plugin.getLogger().warning(String.format("Loading Error: Cannot load outlaw with name '%s' for town '%s'! Skipping adding outlaw to town...", token, town.getName()));
                  }
               }
            }
         }

         try {
            town.setUUID(UUID.fromString(rs.getString("uuid")));
         } catch (NullPointerException | IllegalArgumentException var18) {
            town.setUUID(UUID.randomUUID());
         }

         this.universe.registerTownUUID(town);
         int conqueredDays = rs.getInt("conqueredDays");
         town.setConqueredDays(conqueredDays);

         try {
            long registered = rs.getLong("registered");
            town.setRegistered(registered);
         } catch (Exception var17) {
            town.setRegistered(0L);
         }

         try {
            line = rs.getString("metadata");
            if (line != null && !line.isEmpty()) {
               MetadataLoader.getInstance().deserializeMetadata(town, line);
            }
         } catch (SQLException var16) {
         }

         try {
            line = rs.getString("nation");
            if (line != null && !line.isEmpty()) {
               Nation nation = this.universe.getNation(line);
               if (nation != null) {
                  town.setNation(nation, false);
               }
            }
         } catch (SQLException var15) {
         }

         town.setRuined(rs.getBoolean("ruined"));
         town.setRuinedTime(rs.getLong("ruinedTime"));
         town.setNeutral(rs.getBoolean("neutral"));
         town.setDebtBalance((double)rs.getFloat("debtBalance"));
         line = rs.getString("primaryJail");
         if (line != null && !line.isEmpty()) {
            UUID uuid = UUID.fromString(line);
            if (this.universe.hasJail(uuid)) {
               town.setPrimaryJail(this.universe.getJail(uuid));
            }
         }

         line = rs.getString("trustedResidents");
         if (line != null && !line.isEmpty()) {
            search = line.contains("#") ? "#" : ",";
            Iterator var36 = TownyAPI.getInstance().getResidents(this.toUUIDArray(line.split(search))).iterator();

            while(var36.hasNext()) {
               Resident resident = (Resident)var36.next();
               town.addTrustedResident(resident);
            }
         }

         line = rs.getString("trustedTowns");
         List uuids;
         if (line != null && !line.isEmpty()) {
            search = line.contains("#") ? "#" : ",";
            uuids = (List)Arrays.stream(line.split(search)).map(UUID::fromString).collect(Collectors.toList());
            town.loadTrustedTowns(TownyAPI.getInstance().getTowns(uuids));
         }

         line = rs.getString("mapColorHexCode");
         if (line != null) {
            town.setMapColorHexCode(line);
         } else {
            town.setMapColorHexCode(MapUtil.generateRandomTownColourAsHexCode());
         }

         line = rs.getString("allies");
         if (line != null && !line.isEmpty()) {
            search = line.contains("#") ? "#" : ",";
            uuids = (List)Arrays.stream(line.split(search)).map((uuidx) -> {
               return UUID.fromString(uuidx);
            }).collect(Collectors.toList());
            town.loadAllies(TownyAPI.getInstance().getTowns(uuids));
         }

         line = rs.getString("enemies");
         if (line != null && !line.isEmpty()) {
            search = line.contains("#") ? "#" : ",";
            uuids = (List)Arrays.stream(line.split(search)).map((uuidx) -> {
               return UUID.fromString(uuidx);
            }).collect(Collectors.toList());
            town.loadEnemies(TownyAPI.getInstance().getTowns(uuids));
         }

         line = rs.getString("visibleOnTopLists");
         if (line != null && !line.isEmpty()) {
            town.setVisibleOnTopLists(rs.getBoolean("visibleOnTopLists"));
         }

         return true;
      } catch (SQLException var26) {
         TownyMessaging.sendErrorMsg("SQL: Load Town " + name + " sql Error - " + var26.getMessage());
      } catch (Exception var27) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Load Town " + name + " unknown Error - ", var27);
      }

      return false;
   }

   public boolean loadNations() {
      try {
         Connection connection = this.getConnection();

         boolean var4;
         label104: {
            try {
               Statement s;
               label106: {
                  s = connection.createStatement();

                  try {
                     ResultSet rs = s.executeQuery("SELECT * FROM " + this.tb_prefix + "NATIONS");

                     label91: {
                        try {
                           while(rs.next()) {
                              if (!this.loadNation(rs)) {
                                 this.plugin.getLogger().warning("Loading Error: Could not properly read nation data.");
                                 var4 = false;
                                 break label91;
                              }
                           }
                        } catch (Throwable var9) {
                           if (rs != null) {
                              try {
                                 rs.close();
                              } catch (Throwable var8) {
                                 var9.addSuppressed(var8);
                              }
                           }

                           throw var9;
                        }

                        if (rs != null) {
                           rs.close();
                        }
                        break label106;
                     }

                     if (rs != null) {
                        rs.close();
                     }
                  } catch (Throwable var10) {
                     if (s != null) {
                        try {
                           s.close();
                        } catch (Throwable var7) {
                           var10.addSuppressed(var7);
                        }
                     }

                     throw var10;
                  }

                  if (s != null) {
                     s.close();
                  }
                  break label104;
               }

               if (s != null) {
                  s.close();
               }
            } catch (Throwable var11) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var6) {
                     var11.addSuppressed(var6);
                  }
               }

               throw var11;
            }

            if (connection != null) {
               connection.close();
            }

            return true;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var12) {
         TownyMessaging.sendErrorMsg("SQL: Load Nation sql error " + var12.getMessage());
         return false;
      }
   }

   public boolean loadNation(Nation nation) {
      return true;
   }

   private boolean loadNation(ResultSet rs) {
      String name = null;

      try {
         Nation nation = this.universe.getNation(rs.getString("name"));
         if (nation == null) {
            this.plugin.getLogger().warning(String.format("Error: The nation with the name '%s' was not registered and cannot be loaded!", rs.getString("name")));
            return false;
         }

         name = nation.getName();
         TownyMessaging.sendDebugMsg("Loading nation " + nation.getName());
         Town town = this.universe.getTown(rs.getString("capital"));
         if (town != null) {
            try {
               nation.forceSetCapital(town);
            } catch (EmptyNationException var17) {
               this.plugin.getLogger().warning("The nation " + nation.getName() + " could not load a capital city and is being disbanded.");
               this.removeNation(nation, DeleteNationEvent.Cause.LOAD);
               return true;
            }
         } else {
            TownyMessaging.sendDebugMsg("Nation " + name + " could not set capital to " + rs.getString("capital") + ", selecting a new capital...");
            if (!nation.findNewCapital()) {
               this.plugin.getLogger().warning("The nation " + nation.getName() + " could not load a capital city and is being disbanded.");
               this.removeNation(nation, DeleteNationEvent.Cause.LOAD);
               return true;
            }
         }

         String line = rs.getString("nationBoard");
         if (line != null) {
            nation.setBoard(rs.getString("nationBoard"));
         } else {
            nation.setBoard("");
         }

         line = rs.getString("mapColorHexCode");
         if (line != null) {
            nation.setMapColorHexCode(line);
         } else {
            nation.setMapColorHexCode(MapUtil.generateRandomNationColourAsHexCode());
         }

         nation.setTag(rs.getString("tag"));
         line = rs.getString("allies");
         String search;
         List enemies;
         Iterator var9;
         Nation enemy;
         if (line != null) {
            search = line.contains("#") ? "#" : ",";
            enemies = TownyAPI.getInstance().getNations(line.split(search));
            var9 = enemies.iterator();

            while(var9.hasNext()) {
               enemy = (Nation)var9.next();
               nation.addAlly(enemy);
            }
         }

         line = rs.getString("enemies");
         if (line != null) {
            search = line.contains("#") ? "#" : ",";
            enemies = TownyAPI.getInstance().getNations(line.split(search));
            var9 = enemies.iterator();

            while(var9.hasNext()) {
               enemy = (Nation)var9.next();
               nation.addEnemy(enemy);
            }
         }

         nation.setSpawnCost((double)rs.getFloat("spawnCost"));
         nation.setNeutral(rs.getBoolean("neutral"));

         try {
            nation.setUUID(UUID.fromString(rs.getString("uuid")));
         } catch (NullPointerException | IllegalArgumentException var16) {
            nation.setUUID(UUID.randomUUID());
         }

         this.universe.registerNationUUID(nation);
         line = rs.getString("nationSpawn");
         if (line != null) {
            search = line.contains("#") ? "#" : ",";
            String[] tokens = line.split(search);
            if (tokens.length >= 4) {
               try {
                  nation.spawnPosition(Position.deserialize(tokens));
               } catch (IllegalArgumentException var15) {
                  Logger var10000 = this.plugin.getLogger();
                  String var10001 = nation.getName();
                  var10000.warning("Failed to load nation spawn location for nation " + var10001 + ": " + var15.getMessage());
               }
            }
         }

         nation.setPublic(rs.getBoolean("isPublic"));
         nation.setOpen(rs.getBoolean("isOpen"));
         nation.setTaxPercentage(rs.getBoolean("taxpercent"));
         nation.setTaxes(rs.getDouble("taxes"));
         line = rs.getString("maxPercentTaxAmount");
         if (line != null) {
            nation.setMaxPercentTaxAmount(Double.parseDouble(line));
         } else {
            nation.setMaxPercentTaxAmount(TownySettings.getMaxNationTaxPercentAmount());
         }

         try {
            line = rs.getString("registered");
            if (line != null) {
               nation.setRegistered(Long.parseLong(line));
            } else {
               nation.setRegistered(0L);
            }
         } catch (SQLException var13) {
         } catch (NullPointerException | NumberFormatException var14) {
            nation.setRegistered(0L);
         }

         try {
            line = rs.getString("metadata");
            if (line != null && !line.isEmpty()) {
               MetadataLoader.getInstance().deserializeMetadata(nation, line);
            }
         } catch (SQLException var12) {
         }

         try {
            line = rs.getString("conqueredTax");
            if (line != null && !line.isEmpty()) {
               nation.setConqueredTax(Double.parseDouble(line));
            }
         } catch (SQLException var11) {
         }

         line = rs.getString("sanctionedTowns");
         if (line != null) {
            nation.loadSanctionedTowns(line.split("#"));
         }

         return true;
      } catch (SQLException var18) {
         TownyMessaging.sendErrorMsg("SQL: Load Nation " + name + " SQL Error - " + var18.getMessage());
      } catch (TownyException var19) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Load Nation " + name + " unknown Error - ", var19);
      }

      return false;
   }

   public boolean loadWorlds() {
      try {
         Connection connection = this.getConnection();

         boolean var4;
         label104: {
            try {
               Statement s;
               label106: {
                  s = connection.createStatement();

                  try {
                     ResultSet rs = s.executeQuery("SELECT * FROM " + this.tb_prefix + "WORLDS");

                     label91: {
                        try {
                           while(rs.next()) {
                              if (!this.loadWorld(rs)) {
                                 this.plugin.getLogger().warning("Loading Error: Could not read properly world data.");
                                 var4 = false;
                                 break label91;
                              }
                           }
                        } catch (Throwable var9) {
                           if (rs != null) {
                              try {
                                 rs.close();
                              } catch (Throwable var8) {
                                 var9.addSuppressed(var8);
                              }
                           }

                           throw var9;
                        }

                        if (rs != null) {
                           rs.close();
                        }
                        break label106;
                     }

                     if (rs != null) {
                        rs.close();
                     }
                  } catch (Throwable var10) {
                     if (s != null) {
                        try {
                           s.close();
                        } catch (Throwable var7) {
                           var10.addSuppressed(var7);
                        }
                     }

                     throw var10;
                  }

                  if (s != null) {
                     s.close();
                  }
                  break label104;
               }

               if (s != null) {
                  s.close();
               }
            } catch (Throwable var11) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var6) {
                     var11.addSuppressed(var6);
                  }
               }

               throw var11;
            }

            if (connection != null) {
               connection.close();
            }

            return true;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var12) {
         TownyMessaging.sendErrorMsg("SQL: Error reading worlds from SQL database!");
         return false;
      }
   }

   public boolean loadWorld(TownyWorld world) {
      try {
         Connection connection = this.getConnection();

         boolean var5;
         label110: {
            try {
               PreparedStatement ps;
               label102: {
                  ps = connection.prepareStatement("SELECT * FROM " + this.tb_prefix + "WORLDS WHERE name=?");

                  try {
                     ps.setString(1, world.getName());
                     ResultSet rs = ps.executeQuery();

                     label87: {
                        try {
                           if (rs.next()) {
                              var5 = this.loadWorld(rs);
                              break label87;
                           }
                        } catch (Throwable var10) {
                           if (rs != null) {
                              try {
                                 rs.close();
                              } catch (Throwable var9) {
                                 var10.addSuppressed(var9);
                              }
                           }

                           throw var10;
                        }

                        if (rs != null) {
                           rs.close();
                        }
                        break label102;
                     }

                     if (rs != null) {
                        rs.close();
                     }
                  } catch (Throwable var11) {
                     if (ps != null) {
                        try {
                           ps.close();
                        } catch (Throwable var8) {
                           var11.addSuppressed(var8);
                        }
                     }

                     throw var11;
                  }

                  if (ps != null) {
                     ps.close();
                  }
                  break label110;
               }

               if (ps != null) {
                  ps.close();
               }
            } catch (Throwable var12) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var7) {
                     var12.addSuppressed(var7);
                  }
               }

               throw var12;
            }

            if (connection != null) {
               connection.close();
            }

            return false;
         }

         if (connection != null) {
            connection.close();
         }

         return var5;
      } catch (SQLException var13) {
         String var10000 = world.getName();
         TownyMessaging.sendErrorMsg("SQL: Load world sql error (" + var10000 + ")" + var13.getMessage());
         return false;
      }
   }

   private boolean loadWorld(ResultSet rs) {
      String worldName = null;

      try {
         worldName = rs.getString("name");
         TownyWorld world = this.universe.getWorld(worldName);
         if (world == null) {
            throw new Exception("World " + worldName + " not registered!");
         }

         TownyMessaging.sendDebugMsg("Loading world " + world.getName());
         String line = rs.getString("uuid");
         if (line != null && !line.isEmpty()) {
            try {
               world.setUUID(UUID.fromString(line));
            } catch (IllegalArgumentException var59) {
               UUID uuid = BukkitTools.getWorldUUID(worldName);
               if (uuid != null) {
                  world.setUUID(uuid);
               }
            }
         } else {
            UUID uuid = BukkitTools.getWorldUUID(worldName);
            if (uuid != null) {
               world.setUUID(uuid);
            }
         }

         boolean result = rs.getBoolean("claimable");

         try {
            world.setClaimable(result);
         } catch (Exception var48) {
         }

         result = rs.getBoolean("pvp");

         try {
            world.setPVP(result);
         } catch (Exception var47) {
         }

         result = rs.getBoolean("forcepvp");

         try {
            world.setForcePVP(result);
         } catch (Exception var46) {
         }

         result = rs.getBoolean("friendlyFire");

         try {
            world.setFriendlyFire(result);
         } catch (Exception var45) {
         }

         result = rs.getBoolean("forcetownmobs");

         try {
            world.setForceTownMobs(result);
         } catch (Exception var44) {
         }

         result = rs.getBoolean("wildernessmobs");

         try {
            world.setWildernessMobs(result);
         } catch (Exception var43) {
         }

         result = rs.getBoolean("worldmobs");

         try {
            world.setWorldMobs(result);
         } catch (Exception var42) {
         }

         result = rs.getBoolean("firespread");

         try {
            world.setFire(result);
         } catch (Exception var41) {
         }

         result = rs.getBoolean("forcefirespread");

         try {
            world.setForceFire(result);
         } catch (Exception var40) {
         }

         result = rs.getBoolean("explosions");

         try {
            world.setExpl(result);
         } catch (Exception var39) {
         }

         result = rs.getBoolean("forceexplosions");

         try {
            world.setForceExpl(result);
         } catch (Exception var38) {
         }

         result = rs.getBoolean("endermanprotect");

         try {
            world.setEndermanProtect(result);
         } catch (Exception var37) {
         }

         result = rs.getBoolean("disablecreaturetrample");

         try {
            world.setDisableCreatureTrample(result);
         } catch (Exception var36) {
         }

         result = rs.getBoolean("unclaimedZoneBuild");

         try {
            world.setUnclaimedZoneBuild(result);
         } catch (Exception var35) {
         }

         result = rs.getBoolean("unclaimedZoneDestroy");

         try {
            world.setUnclaimedZoneDestroy(result);
         } catch (Exception var34) {
         }

         result = rs.getBoolean("unclaimedZoneSwitch");

         try {
            world.setUnclaimedZoneSwitch(result);
         } catch (Exception var33) {
         }

         result = rs.getBoolean("unclaimedZoneItemUse");

         try {
            world.setUnclaimedZoneItemUse(result);
         } catch (Exception var32) {
         }

         line = rs.getString("unclaimedZoneName");

         try {
            world.setUnclaimedZoneName(line);
         } catch (Exception var31) {
         }

         line = rs.getString("unclaimedZoneIgnoreIds");
         String search;
         int var11;
         int var12;
         String split;
         ArrayList materials;
         String[] var63;
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     materials.add(split);
                  }
               }

               world.setUnclaimedZoneIgnore(materials);
            } catch (Exception var58) {
            }
         }

         result = rs.getBoolean("isDeletingEntitiesOnUnclaim");

         try {
            world.setDeletingEntitiesOnUnclaim(result);
         } catch (Exception var30) {
         }

         line = rs.getString("unclaimDeleteEntityTypes");
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     materials.add(split);
                  }
               }

               world.setUnclaimDeleteEntityTypes(materials);
            } catch (Exception var57) {
            }
         }

         result = rs.getBoolean("usingPlotManagementDelete");

         try {
            world.setUsingPlotManagementDelete(result);
         } catch (Exception var29) {
         }

         line = rs.getString("plotManagementDeleteIds");
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     materials.add(split);
                  }
               }

               world.setPlotManagementDeleteIds(materials);
            } catch (Exception var56) {
            }
         }

         result = rs.getBoolean("usingPlotManagementMayorDelete");

         try {
            world.setUsingPlotManagementMayorDelete(result);
         } catch (Exception var28) {
         }

         line = rs.getString("plotManagementMayorDelete");
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     try {
                        materials.add(split.toUpperCase().trim());
                     } catch (NumberFormatException var27) {
                     }
                  }
               }

               world.setPlotManagementMayorDelete(materials);
            } catch (Exception var55) {
            }
         }

         result = rs.getBoolean("usingPlotManagementRevert");

         try {
            world.setUsingPlotManagementRevert(result);
         } catch (Exception var26) {
         }

         line = rs.getString("plotManagementIgnoreIds");
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     materials.add(split);
                  }
               }

               world.setPlotManagementIgnoreIds(materials);
            } catch (Exception var54) {
            }
         }

         result = rs.getBoolean("usingPlotManagementWildRegen");

         try {
            world.setUsingPlotManagementWildEntityRevert(result);
         } catch (Exception var25) {
         }

         line = rs.getString("revertOnUnclaimWhitelistMaterials");
         if (line != null) {
            try {
               materials = new ArrayList();
               var63 = line.split("#");
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     try {
                        materials.add(split.trim());
                     } catch (NumberFormatException var24) {
                     }
                  }
               }

               world.setRevertOnUnclaimWhitelistMaterials(materials);
            } catch (Exception var53) {
            }
         }

         line = rs.getString("plotManagementWildRegenEntities");
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     try {
                        materials.add(split.trim());
                     } catch (NumberFormatException var23) {
                     }
                  }
               }

               world.setPlotManagementWildRevertEntities(materials);
            } catch (Exception var52) {
            }
         }

         line = rs.getString("plotManagementWildRegenBlockWhitelist");
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     try {
                        materials.add(split.trim());
                     } catch (NumberFormatException var22) {
                     }
                  }
               }

               world.setPlotManagementWildRevertBlockWhitelist(materials);
            } catch (Exception var51) {
            }
         }

         line = rs.getString("wildRegenBlocksToNotOverwrite");
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     try {
                        materials.add(split.trim());
                     } catch (NumberFormatException var21) {
                     }
                  }
               }

               world.setWildRevertMaterialsToNotOverwrite(materials);
            } catch (Exception var50) {
            }
         }

         long resultLong = rs.getLong("plotManagementWildRegenSpeed");

         try {
            world.setPlotManagementWildRevertDelay(resultLong);
         } catch (Exception var20) {
         }

         result = rs.getBoolean("usingPlotManagementWildRegenBlocks");

         try {
            world.setUsingPlotManagementWildBlockRevert(result);
         } catch (Exception var19) {
         }

         line = rs.getString("plotManagementWildRegenBlocks");
         if (line != null) {
            try {
               materials = new ArrayList();
               search = line.contains("#") ? "#" : ",";
               var63 = line.split(search);
               var11 = var63.length;

               for(var12 = 0; var12 < var11; ++var12) {
                  split = var63[var12];
                  if (!split.isEmpty()) {
                     try {
                        materials.add(split.trim());
                     } catch (NumberFormatException var18) {
                     }
                  }
               }

               world.setPlotManagementWildRevertMaterials(materials);
            } catch (Exception var49) {
            }
         }

         result = rs.getBoolean("usingTowny");

         try {
            world.setUsingTowny(result);
         } catch (Exception var17) {
         }

         result = rs.getBoolean("warAllowed");

         try {
            world.setWarAllowed(result);
         } catch (Exception var16) {
         }

         try {
            line = rs.getString("metadata");
            if (line != null && !line.isEmpty()) {
               MetadataLoader.getInstance().deserializeMetadata(world, line);
            }
         } catch (SQLException var15) {
         }

         return true;
      } catch (SQLException var60) {
         TownyMessaging.sendErrorMsg("SQL: Load world sql error (" + (worldName != null ? worldName : "NULL") + ")" + var60.getMessage());
      } catch (Exception var61) {
         TownyMessaging.sendErrorMsg(var61.getMessage());
      }

      return false;
   }

   public boolean loadTownBlocks() {
      String line = "";
      TownyMessaging.sendDebugMsg("Loading Town Blocks.");
      TownBlock townBlock = null;

      try {
         Connection connection = this.getConnection();

         label332: {
            boolean outpost;
            try {
               label333: {
                  Statement s;
                  label334: {
                     s = connection.createStatement();

                     try {
                        label335: {
                           ResultSet rs = s.executeQuery("SELECT * FROM " + this.tb_prefix + "TOWNBLOCKS");

                           label318: {
                              try {
                                 while(true) {
                                    if (!rs.next()) {
                                       break label318;
                                    }

                                    String worldName = rs.getString("world");
                                    int x = rs.getInt("x");
                                    int z = rs.getInt("z");
                                    if (this.universe.hasTownyWorld(worldName)) {
                                       try {
                                          townBlock = this.universe.getTownBlock(new WorldCoord(worldName, x, z));
                                       } catch (NotRegisteredException var33) {
                                          TownyMessaging.sendErrorMsg("Loading Error: Exception while fetching townblock: " + worldName + " " + x + " " + z + " from memory!");
                                          outpost = false;
                                          break;
                                       }

                                       line = rs.getString("name");
                                       if (line != null) {
                                          try {
                                             townBlock.setName(line.trim());
                                          } catch (Exception var31) {
                                          }
                                       }

                                       line = rs.getString("town");
                                       if (line != null) {
                                          Town town = this.universe.getTown(line.trim());
                                          if (town == null) {
                                             TownyMessaging.sendErrorMsg("TownBlock file contains unregistered Town: " + line + " , deleting " + townBlock.getWorld().getName() + "," + townBlock.getX() + "," + townBlock.getZ());
                                             this.universe.removeTownBlock(townBlock);
                                             this.deleteTownBlock(townBlock);
                                             continue;
                                          }

                                          townBlock.setTown(town, false);

                                          try {
                                             town.addTownBlock(townBlock);
                                             TownyWorld townyWorld = townBlock.getWorld();
                                             if (townyWorld != null && !townyWorld.hasTown(town)) {
                                                townyWorld.addTown(town);
                                             }
                                          } catch (AlreadyRegisteredException var30) {
                                          }
                                       }

                                       line = rs.getString("resident");
                                       if (line != null && !line.isEmpty()) {
                                          Resident res = this.universe.getResident(line.trim());
                                          if (res != null) {
                                             townBlock.setResident(res, false);
                                          } else {
                                             TownyMessaging.sendErrorMsg(String.format("Error fetching resident '%s' for townblock '%s'!", line.trim(), townBlock.toString()));
                                          }
                                       }

                                       line = rs.getString("type");
                                       if (line != null) {
                                          townBlock.setType(TownBlockTypeHandler.getTypeInternal(line));
                                       }

                                       line = rs.getString("price");
                                       if (line != null) {
                                          try {
                                             townBlock.setPlotPrice((double)Float.parseFloat(line.trim()));
                                          } catch (Exception var29) {
                                          }
                                       }

                                       boolean taxed = rs.getBoolean("taxed");

                                       try {
                                          townBlock.setTaxed(taxed);
                                       } catch (Exception var28) {
                                       }

                                       line = rs.getString("typeName");
                                       if (line != null) {
                                          townBlock.setType(TownBlockTypeHandler.getTypeInternal(line));
                                       }

                                       outpost = rs.getBoolean("outpost");

                                       try {
                                          townBlock.setOutpost(outpost);
                                       } catch (Exception var27) {
                                       }

                                       line = rs.getString("permissions");
                                       if (line != null && !line.isEmpty()) {
                                          try {
                                             townBlock.setPermissions(line.trim().replaceAll("#", ","));
                                          } catch (Exception var26) {
                                          }
                                       }

                                       boolean result = rs.getBoolean("changed");

                                       try {
                                          townBlock.setChanged(result);
                                       } catch (Exception var25) {
                                       }

                                       townBlock.setClaimedAt(rs.getLong("claimedAt"));
                                       line = rs.getString("minTownMembershipDays");
                                       if (line != null && !line.isEmpty()) {
                                          townBlock.setMinTownMembershipDays(Integer.valueOf(line));
                                       }

                                       line = rs.getString("maxTownMembershipDays");
                                       if (line != null && !line.isEmpty()) {
                                          townBlock.setMaxTownMembershipDays(Integer.valueOf(line));
                                       }

                                       try {
                                          line = rs.getString("metadata");
                                          if (line != null && !line.isEmpty()) {
                                             MetadataLoader.getInstance().deserializeMetadata(townBlock, line);
                                          }
                                       } catch (SQLException var24) {
                                       }

                                       UUID districtID;
                                       try {
                                          line = rs.getString("groupID");
                                          if (line != null && !line.isEmpty()) {
                                             try {
                                                districtID = UUID.fromString(line.trim());
                                                PlotGroup group = this.universe.getGroup(districtID);
                                                if (group != null) {
                                                   townBlock.setPlotObjectGroup(group);
                                                   if (group.getPermissions() == null && townBlock.getPermissions() != null) {
                                                      group.setPermissions(townBlock.getPermissions());
                                                   }

                                                   if (townBlock.hasResident()) {
                                                      group.setResident(townBlock.getResidentOrNull());
                                                   }
                                                }
                                             } catch (Exception var22) {
                                             }
                                          }
                                       } catch (SQLException var23) {
                                       }

                                       try {
                                          line = rs.getString("districtID");
                                          if (line != null && !line.isEmpty()) {
                                             try {
                                                districtID = UUID.fromString(line.trim());
                                                District district = this.universe.getDistrict(districtID);
                                                if (district != null) {
                                                   townBlock.setDistrict(district);
                                                }
                                             } catch (Exception var20) {
                                             }
                                          }
                                       } catch (SQLException var21) {
                                       }

                                       line = rs.getString("trustedResidents");
                                       Iterator var44;
                                       if (line != null && !line.isEmpty() && townBlock.getTrustedResidents().isEmpty()) {
                                          String search = line.contains("#") ? "#" : ",";
                                          var44 = TownyAPI.getInstance().getResidents(this.toUUIDArray(line.split(search))).iterator();

                                          while(var44.hasNext()) {
                                             Resident resident = (Resident)var44.next();
                                             townBlock.addTrustedResident(resident);
                                          }

                                          if (townBlock.hasPlotObjectGroup() && townBlock.getPlotObjectGroup().getTrustedResidents().isEmpty() && townBlock.getTrustedResidents().size() > 0) {
                                             townBlock.getPlotObjectGroup().setTrustedResidents(townBlock.getTrustedResidents());
                                          }
                                       }

                                       line = rs.getString("customPermissionData");
                                       if (line != null && !line.isEmpty() && townBlock.getPermissionOverrides().isEmpty()) {
                                          Map<String, String> map = (Map)(new Gson()).fromJson(line, (new TypeToken<Map<String, String>>() {
                                          }).getType());
                                          var44 = map.entrySet().iterator();

                                          while(var44.hasNext()) {
                                             Entry entry = (Entry)var44.next();

                                             Resident resident;
                                             try {
                                                resident = TownyAPI.getInstance().getResident(UUID.fromString((String)entry.getKey()));
                                             } catch (IllegalArgumentException var32) {
                                                continue;
                                             }

                                             if (resident != null) {
                                                townBlock.getPermissionOverrides().put(resident, new PermissionData((String)entry.getValue()));
                                             }
                                          }

                                          if (townBlock.hasPlotObjectGroup() && townBlock.getPlotObjectGroup().getPermissionOverrides().isEmpty() && townBlock.getPermissionOverrides().size() > 0) {
                                             townBlock.getPlotObjectGroup().setPermissionOverrides(townBlock.getPermissionOverrides());
                                          }
                                       }
                                    }
                                 }
                              } catch (Throwable var34) {
                                 if (rs != null) {
                                    try {
                                       rs.close();
                                    } catch (Throwable var19) {
                                       var34.addSuppressed(var19);
                                    }
                                 }

                                 throw var34;
                              }

                              if (rs != null) {
                                 rs.close();
                              }
                              break label335;
                           }

                           if (rs != null) {
                              rs.close();
                           }
                           break label334;
                        }
                     } catch (Throwable var35) {
                        if (s != null) {
                           try {
                              s.close();
                           } catch (Throwable var18) {
                              var35.addSuppressed(var18);
                           }
                        }

                        throw var35;
                     }

                     if (s != null) {
                        s.close();
                     }
                     break label333;
                  }

                  if (s != null) {
                     s.close();
                  }
                  break label332;
               }
            } catch (Throwable var36) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var17) {
                     var36.addSuppressed(var17);
                  }
               }

               throw var36;
            }

            if (connection != null) {
               connection.close();
            }

            return outpost;
         }

         if (connection != null) {
            connection.close();
         }

         return true;
      } catch (SQLException var37) {
         this.plugin.getLogger().log(Level.WARNING, "Loading Error: Exception while reading TownBlock: " + (townBlock != null ? townBlock : "NULL") + " at line: " + line + " in the sql database", var37);
         return false;
      }
   }

   public boolean loadPlotGroups() {
      TownyMessaging.sendDebugMsg("Loading plot groups.");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         label106: {
            try {
               Statement s;
               label108: {
                  s = connection.createStatement();

                  try {
                     ResultSet rs = s.executeQuery("SELECT * FROM " + this.tb_prefix + "PLOTGROUPS ");

                     label92: {
                        try {
                           while(rs.next()) {
                              if (!this.loadPlotGroup(rs)) {
                                 this.plugin.getLogger().warning("Loading Error: Could not read plotgroup data properly.");
                                 var4 = false;
                                 break label92;
                              }
                           }
                        } catch (Throwable var9) {
                           if (rs != null) {
                              try {
                                 rs.close();
                              } catch (Throwable var8) {
                                 var9.addSuppressed(var8);
                              }
                           }

                           throw var9;
                        }

                        if (rs != null) {
                           rs.close();
                        }
                        break label108;
                     }

                     if (rs != null) {
                        rs.close();
                     }
                  } catch (Throwable var10) {
                     if (s != null) {
                        try {
                           s.close();
                        } catch (Throwable var7) {
                           var10.addSuppressed(var7);
                        }
                     }

                     throw var10;
                  }

                  if (s != null) {
                     s.close();
                  }
                  break label106;
               }

               if (s != null) {
                  s.close();
               }
            } catch (Throwable var11) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var6) {
                     var11.addSuppressed(var6);
                  }
               }

               throw var11;
            }

            if (connection != null) {
               connection.close();
            }

            return true;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var12) {
         TownyMessaging.sendErrorMsg("SQL: Load PlotGroup sql Error - " + var12.getMessage());
         return false;
      }
   }

   public boolean loadDistricts() {
      TownyMessaging.sendDebugMsg("Loading districts.");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         label106: {
            try {
               Statement s;
               label108: {
                  s = connection.createStatement();

                  try {
                     ResultSet rs = s.executeQuery("SELECT * FROM " + this.tb_prefix + "DISTRICTS ");

                     label92: {
                        try {
                           while(rs.next()) {
                              if (!this.loadDistrict(rs)) {
                                 this.plugin.getLogger().warning("Loading Error: Could not read district data properly.");
                                 var4 = false;
                                 break label92;
                              }
                           }
                        } catch (Throwable var9) {
                           if (rs != null) {
                              try {
                                 rs.close();
                              } catch (Throwable var8) {
                                 var9.addSuppressed(var8);
                              }
                           }

                           throw var9;
                        }

                        if (rs != null) {
                           rs.close();
                        }
                        break label108;
                     }

                     if (rs != null) {
                        rs.close();
                     }
                  } catch (Throwable var10) {
                     if (s != null) {
                        try {
                           s.close();
                        } catch (Throwable var7) {
                           var10.addSuppressed(var7);
                        }
                     }

                     throw var10;
                  }

                  if (s != null) {
                     s.close();
                  }
                  break label106;
               }

               if (s != null) {
                  s.close();
               }
            } catch (Throwable var11) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var6) {
                     var11.addSuppressed(var6);
                  }
               }

               throw var11;
            }

            if (connection != null) {
               connection.close();
            }

            return true;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var12) {
         TownyMessaging.sendErrorMsg("SQL: Load District sql Error - " + var12.getMessage());
         return false;
      }
   }

   public boolean loadCooldowns() {
      try {
         Connection connection = this.getConnection();

         try {
            String var10001 = this.tb_prefix;
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + var10001 + TownySQLSource.TownyDBTableType.COOLDOWN.tableName());

            try {
               ResultSet resultSet = statement.executeQuery();

               try {
                  while(resultSet.next()) {
                     CooldownTimerTask.getCooldowns().put(resultSet.getString("key"), resultSet.getLong("expiry"));
                  }
               } catch (Throwable var9) {
                  if (resultSet != null) {
                     try {
                        resultSet.close();
                     } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                     }
                  }

                  throw var9;
               }

               if (resultSet != null) {
                  resultSet.close();
               }
            } catch (Throwable var10) {
               if (statement != null) {
                  try {
                     statement.close();
                  } catch (Throwable var7) {
                     var10.addSuppressed(var7);
                  }
               }

               throw var10;
            }

            if (statement != null) {
               statement.close();
            }
         } catch (Throwable var11) {
            if (connection != null) {
               try {
                  connection.close();
               } catch (Throwable var6) {
                  var11.addSuppressed(var6);
               }
            }

            throw var11;
         }

         if (connection != null) {
            connection.close();
         }

         return true;
      } catch (SQLException var12) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred when loading cooldowns", var12);
         return false;
      }
   }

   public boolean saveCooldowns() {
      Iterator var1 = CooldownTimerTask.getCooldowns().entrySet().iterator();

      while(var1.hasNext()) {
         Entry<String, Long> entry = (Entry)var1.next();
         Map<String, Object> data = new HashMap();
         data.put("key", entry.getKey());
         data.put("expiry", entry.getValue());
         this.queueUpdateDB(TownySQLSource.TownyDBTableType.COOLDOWN.tableName(), data, Collections.singletonList("key"));
      }

      return true;
   }

   private boolean loadPlotGroup(ResultSet rs) {
      String line = null;
      String uuid = null;

      try {
         PlotGroup group = this.universe.getGroup(UUID.fromString(rs.getString("groupID")));
         if (group == null) {
            TownyMessaging.sendErrorMsg("SQL: A plot group was not registered properly on load!");
            return true;
         } else {
            uuid = group.getUUID().toString();
            line = rs.getString("groupName");
            if (line != null) {
               try {
                  group.setName(line.trim());
               } catch (Exception var7) {
               }
            }

            line = rs.getString("town");
            if (line != null) {
               Town town = this.universe.getTown(line.trim());
               if (town == null) {
                  this.deletePlotGroup(group);
                  return true;
               }

               group.setTown(town);
            }

            line = rs.getString("groupPrice");
            if (line != null) {
               try {
                  group.setPrice((double)Float.parseFloat(line.trim()));
               } catch (Exception var6) {
               }
            }

            line = rs.getString("metadata");
            if (line != null) {
               MetadataLoader.getInstance().deserializeMetadata(group, line);
            }

            return true;
         }
      } catch (SQLException var8) {
         this.plugin.getLogger().log(Level.WARNING, "Loading Error: Exception while reading plot group: " + uuid + " at line: " + line + " in the sql database", var8);
         return false;
      }
   }

   public boolean loadPlotGroup(PlotGroup group) {
      return true;
   }

   private boolean loadDistrict(ResultSet rs) {
      String line = null;
      String uuidString = null;

      try {
         District district = this.universe.getDistrict(UUID.fromString(rs.getString("uuid")));
         if (district == null) {
            TownyMessaging.sendErrorMsg("SQL: A district was not registered properly on load!");
            return true;
         } else {
            uuidString = district.getUUID().toString();
            line = rs.getString("districtName");
            if (line != null) {
               try {
                  district.setName(line.trim());
               } catch (Exception var7) {
               }
            }

            line = rs.getString("town");
            if (line != null) {
               UUID uuid = UUID.fromString(line.trim());
               if (uuid == null) {
                  this.deleteDistrict(district);
                  return true;
               }

               Town town = this.universe.getTown(uuid);
               if (town == null) {
                  this.deleteDistrict(district);
                  return true;
               }

               district.setTown(town);
            }

            line = rs.getString("metadata");
            if (line != null) {
               MetadataLoader.getInstance().deserializeMetadata(district, line);
            }

            return true;
         }
      } catch (SQLException var8) {
         this.plugin.getLogger().log(Level.WARNING, "Loading Error: Exception while reading district: " + uuidString + " at line: " + line + " in the sql database", var8);
         return false;
      }
   }

   public boolean loadDistrict(District district) {
      return true;
   }

   public boolean loadJails() {
      TownyMessaging.sendDebugMsg("Loading Jails");

      try {
         Connection connection = this.getConnection();

         boolean var4;
         label106: {
            try {
               Statement s;
               label108: {
                  s = connection.createStatement();

                  try {
                     ResultSet rs = s.executeQuery("SELECT * FROM " + this.tb_prefix + "JAILS ");

                     label92: {
                        try {
                           while(rs.next()) {
                              if (!this.loadJail(rs)) {
                                 this.plugin.getLogger().warning("Loading Error: Could not read jail data properly.");
                                 var4 = false;
                                 break label92;
                              }
                           }
                        } catch (Throwable var9) {
                           if (rs != null) {
                              try {
                                 rs.close();
                              } catch (Throwable var8) {
                                 var9.addSuppressed(var8);
                              }
                           }

                           throw var9;
                        }

                        if (rs != null) {
                           rs.close();
                        }
                        break label108;
                     }

                     if (rs != null) {
                        rs.close();
                     }
                  } catch (Throwable var10) {
                     if (s != null) {
                        try {
                           s.close();
                        } catch (Throwable var7) {
                           var10.addSuppressed(var7);
                        }
                     }

                     throw var10;
                  }

                  if (s != null) {
                     s.close();
                  }
                  break label106;
               }

               if (s != null) {
                  s.close();
               }
            } catch (Throwable var11) {
               if (connection != null) {
                  try {
                     connection.close();
                  } catch (Throwable var6) {
                     var11.addSuppressed(var6);
                  }
               }

               throw var11;
            }

            if (connection != null) {
               connection.close();
            }

            return true;
         }

         if (connection != null) {
            connection.close();
         }

         return var4;
      } catch (SQLException var12) {
         TownyMessaging.sendErrorMsg("SQL: Load Jail sql Error - " + var12.getMessage());
         return false;
      }
   }

   public boolean loadJail(Jail jail) {
      return true;
   }

   private boolean loadJail(ResultSet rs) {
      String uuid = null;

      try {
         Jail jail = this.universe.getJail(UUID.fromString(rs.getString("uuid")));
         if (jail == null) {
            TownyMessaging.sendErrorMsg("SQL: A jail was not registered properly on load!");
            return true;
         }

         uuid = jail.getUUID().toString();
         String line = rs.getString("townBlock");
         String[] tokens;
         UUID var10000;
         if (line != null) {
            tokens = line.split("#");
            WorldCoord wc = null;

            try {
               wc = new WorldCoord(tokens[0], Integer.parseInt(tokens[1].trim()), Integer.parseInt(tokens[2].trim()));
               if (wc.isWilderness() || wc.getTownOrNull() == null) {
                  throw new NumberFormatException();
               }
            } catch (NumberFormatException var13) {
               var10000 = jail.getUUID();
               TownyMessaging.sendErrorMsg("Jail " + var10000 + " tried to load invalid townblock " + line + " deleting jail.");
               this.removeJail(jail);
               this.deleteJail(jail);
               return true;
            }

            TownBlock tb = wc.getTownBlockOrNull();
            Town town = tb.getTownOrNull();
            jail.setTownBlock(tb);
            jail.setTown(town);
            tb.setJail(jail);
            town.addJail(jail);
         }

         line = rs.getString("spawns");
         if (line != null) {
            String[] jails = line.split(";");
            String[] var17 = jails;
            int var18 = jails.length;

            for(int var9 = 0; var9 < var18; ++var9) {
               String spawn = var17[var9];
               tokens = spawn.split("#");
               if (tokens.length >= 4) {
                  try {
                     jail.addJailCell(Position.deserialize(tokens));
                  } catch (IllegalArgumentException var12) {
                     var10000 = jail.getUUID();
                     TownyMessaging.sendErrorMsg("Jail " + var10000 + " tried to load invalid spawn " + line + " skipping: " + var12.getMessage());
                  }
               }
            }

            if (jail.getJailCellLocations().size() < 1) {
               var10000 = jail.getUUID();
               TownyMessaging.sendErrorMsg("Jail " + var10000 + " loaded with zero spawns " + line + " deleting jail.");
               this.removeJail(jail);
               this.deleteJail(jail);
               return true;
            }
         }

         return true;
      } catch (SQLException var14) {
         TownyMessaging.sendErrorMsg("SQL: Load Jail " + uuid + " sql Error - " + var14.getMessage());
      } catch (Exception var15) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Load Jail " + uuid + " unknown Error - ", var15);
      }

      return false;
   }

   public synchronized boolean saveResident(Resident resident) {
      TownyMessaging.sendDebugMsg("Saving Resident " + resident.getName());

      try {
         HashMap<String, Object> res_hm = new HashMap();
         res_hm.put("name", resident.getName());
         res_hm.put("uuid", resident.hasUUID() ? resident.getUUID().toString() : "");
         res_hm.put("lastOnline", resident.getLastOnline());
         res_hm.put("registered", resident.getRegistered());
         res_hm.put("joinedTownAt", resident.getJoinedTownAt());
         res_hm.put("isNPC", resident.isNPC());
         res_hm.put("jailUUID", resident.isJailed() ? resident.getJail().getUUID() : "");
         res_hm.put("jailCell", resident.getJailCell());
         res_hm.put("jailHours", resident.getJailHours());
         res_hm.put("jailBail", resident.getJailBailCost());
         res_hm.put("title", resident.getTitle());
         res_hm.put("surname", resident.getSurname());
         if (!TownySettings.getDefaultResidentAbout().equals(resident.getAbout())) {
            res_hm.put("about", resident.getAbout());
         }

         res_hm.put("town", resident.hasTown() ? resident.getTown().getName() : "");
         res_hm.put("town-ranks", resident.hasTown() ? StringMgmt.join((Collection)resident.getTownRanks(), "#") : "");
         res_hm.put("nation-ranks", resident.hasTown() ? StringMgmt.join((Collection)resident.getNationRanks(), "#") : "");
         res_hm.put("friends", StringMgmt.join((Collection)resident.getFriends(), "#"));
         res_hm.put("protectionStatus", resident.getPermissions().toString().replaceAll(",", "#"));
         if (resident.hasMeta()) {
            res_hm.put("metadata", this.serializeMetadata(resident));
         } else {
            res_hm.put("metadata", "");
         }

         this.updateDB("RESIDENTS", res_hm, Collections.singletonList("name"));
         return true;
      } catch (Exception var3) {
         TownyMessaging.sendErrorMsg("SQL: Save Resident unknown error " + var3.getMessage());
         return false;
      }
   }

   public synchronized boolean saveHibernatedResident(UUID uuid, long registered) {
      TownyMessaging.sendDebugMsg("Saving Hibernated Resident " + uuid);

      try {
         HashMap<String, Object> res_hm = new HashMap();
         res_hm.put("uuid", uuid);
         res_hm.put("registered", registered);
         this.updateDB("HIBERNATEDRESIDENTS", res_hm, Collections.singletonList("uuid"));
         return true;
      } catch (Exception var5) {
         TownyMessaging.sendErrorMsg("SQL: Save Hibernated Resident unknown error " + var5.getMessage());
         return false;
      }
   }

   public synchronized boolean saveTown(Town town) {
      TownyMessaging.sendDebugMsg("Saving town " + town.getName());

      try {
         HashMap<String, Object> twn_hm = new HashMap();
         twn_hm.put("name", town.getName());
         twn_hm.put("outlaws", StringMgmt.join(town.getOutlaws(), "#"));
         twn_hm.put("mayor", town.hasMayor() ? town.getMayor().getName() : "");
         twn_hm.put("nation", town.hasNation() ? town.getNationOrNull().getName() : "");
         twn_hm.put("townBoard", town.getBoard());
         twn_hm.put("tag", town.getTag());
         twn_hm.put("founder", town.getFounder());
         twn_hm.put("protectionStatus", town.getPermissions().toString().replaceAll(",", "#"));
         twn_hm.put("bonus", town.getBonusBlocks());
         twn_hm.put("manualTownLevel", town.getManualTownLevel());
         twn_hm.put("purchased", town.getPurchasedBlocks());
         twn_hm.put("nationZoneOverride", town.getNationZoneOverride());
         twn_hm.put("nationZoneEnabled", town.isNationZoneEnabled());
         twn_hm.put("commercialPlotPrice", town.getCommercialPlotPrice());
         twn_hm.put("commercialPlotTax", town.getCommercialPlotTax());
         twn_hm.put("embassyPlotPrice", town.getEmbassyPlotPrice());
         twn_hm.put("embassyPlotTax", town.getEmbassyPlotTax());
         twn_hm.put("spawnCost", town.getSpawnCost());
         twn_hm.put("plotPrice", town.getPlotPrice());
         twn_hm.put("plotTax", town.getPlotTax());
         twn_hm.put("taxes", town.getTaxes());
         twn_hm.put("hasUpkeep", town.hasUpkeep());
         twn_hm.put("hasUnlimitedClaims", town.hasUnlimitedClaims());
         twn_hm.put("visibleOnTopLists", town.isVisibleOnTopLists());
         twn_hm.put("taxpercent", town.isTaxPercentage());
         twn_hm.put("maxPercentTaxAmount", town.getMaxPercentTaxAmount());
         twn_hm.put("open", town.isOpen());
         twn_hm.put("public", town.isPublic());
         twn_hm.put("conquered", town.isConquered());
         twn_hm.put("conqueredDays", town.getConqueredDays());
         twn_hm.put("admindisabledpvp", town.isAdminDisabledPVP());
         twn_hm.put("adminenabledpvp", town.isAdminEnabledPVP());
         twn_hm.put("adminEnabledMobs", town.isAdminEnabledMobs());
         twn_hm.put("allowedToWar", town.isAllowedToWar());
         twn_hm.put("joinedNationAt", town.getJoinedNationAt());
         twn_hm.put("mapColorHexCode", town.getMapColorHexCode());
         twn_hm.put("movedHomeBlockAt", town.getMovedHomeBlockAt());
         twn_hm.put("forSale", town.isForSale());
         twn_hm.put("forSalePrice", town.getForSalePrice());
         if (town.hasMeta()) {
            twn_hm.put("metadata", this.serializeMetadata(town));
         } else {
            twn_hm.put("metadata", "");
         }

         twn_hm.put("homeblock", town.hasHomeBlock() ? town.getHomeBlock().getWorld().getName() + "#" + town.getHomeBlock().getX() + "#" + town.getHomeBlock().getZ() : "");
         Position spawnPos = town.spawnPosition();
         twn_hm.put("spawn", spawnPos != null ? String.join("#", spawnPos.serialize()) : "");
         StringBuilder outpostArray = new StringBuilder();
         if (town.hasOutpostSpawn()) {
            Iterator var5 = town.getOutpostSpawns().iterator();

            while(var5.hasNext()) {
               Position spawn = (Position)var5.next();
               outpostArray.append(String.join("#", spawn.serialize())).append(";");
            }
         }

         twn_hm.put("outpostSpawns", outpostArray.toString());
         if (town.hasValidUUID()) {
            twn_hm.put("uuid", town.getUUID());
         } else {
            twn_hm.put("uuid", UUID.randomUUID());
         }

         twn_hm.put("registered", town.getRegistered());
         twn_hm.put("ruined", town.isRuined());
         twn_hm.put("ruinedTime", town.getRuinedTime());
         twn_hm.put("neutral", town.isNeutral());
         twn_hm.put("debtBalance", town.getDebtBalance());
         if (town.getPrimaryJail() != null) {
            twn_hm.put("primaryJail", town.getPrimaryJail().getUUID());
         }

         twn_hm.put("trustedResidents", StringMgmt.join((Collection)this.toUUIDList(town.getTrustedResidents()), "#"));
         twn_hm.put("trustedTowns", StringMgmt.join((Collection)town.getTrustedTownsUUIDS(), "#"));
         twn_hm.put("allies", StringMgmt.join((Collection)town.getAlliesUUIDs(), "#"));
         twn_hm.put("enemies", StringMgmt.join((Collection)town.getEnemiesUUIDs(), "#"));
         this.updateDB("TOWNS", twn_hm, Collections.singletonList("name"));
         return true;
      } catch (Exception var7) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Save Town unknown error", var7);
         return false;
      }
   }

   public synchronized boolean savePlotGroup(PlotGroup group) {
      TownyMessaging.sendDebugMsg("Saving group " + group.getName());

      try {
         HashMap<String, Object> pltgrp_hm = new HashMap();
         pltgrp_hm.put("groupID", group.getUUID().toString());
         pltgrp_hm.put("groupName", group.getName());
         pltgrp_hm.put("groupPrice", group.getPrice());
         pltgrp_hm.put("town", group.getTown().getName());
         pltgrp_hm.put("metadata", this.serializeMetadata(group));
         this.updateDB("PLOTGROUPS", pltgrp_hm, Collections.singletonList("groupID"));
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Save Plot groups unknown error", var3);
      }

      return false;
   }

   public boolean saveDistrict(District district) {
      TownyMessaging.sendDebugMsg("Saving district " + district.getName());

      try {
         HashMap<String, Object> pltgrp_hm = new HashMap();
         pltgrp_hm.put("uuid", district.getUUID().toString());
         pltgrp_hm.put("districtName", district.getName());
         pltgrp_hm.put("town", district.getTown().getUUID().toString());
         pltgrp_hm.put("metadata", this.serializeMetadata(district));
         this.updateDB("DISTRICTS", pltgrp_hm, Collections.singletonList("uuid"));
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Save Districts unknown error", var3);
      }

      return false;
   }

   public synchronized boolean saveNation(Nation nation) {
      TownyMessaging.sendDebugMsg("Saving nation " + nation.getName());

      try {
         HashMap<String, Object> nat_hm = new HashMap();
         nat_hm.put("name", nation.getName());
         nat_hm.put("capital", nation.hasCapital() ? nation.getCapital().getName() : "");
         nat_hm.put("nationBoard", nation.getBoard());
         nat_hm.put("mapColorHexCode", nation.getMapColorHexCode());
         nat_hm.put("tag", nation.hasTag() ? nation.getTag() : "");
         nat_hm.put("allies", StringMgmt.join((Collection)nation.getAllies(), "#"));
         nat_hm.put("enemies", StringMgmt.join((Collection)nation.getEnemies(), "#"));
         nat_hm.put("taxes", nation.getTaxes());
         nat_hm.put("taxpercent", nation.isTaxPercentage());
         nat_hm.put("maxPercentTaxAmount", nation.getMaxPercentTaxAmount());
         nat_hm.put("spawnCost", nation.getSpawnCost());
         nat_hm.put("neutral", nation.isNeutral());
         Position spawnPos = nation.spawnPosition();
         nat_hm.put("nationSpawn", spawnPos != null ? String.join("#", spawnPos.serialize()) : "");
         if (nation.hasValidUUID()) {
            nat_hm.put("uuid", nation.getUUID());
         } else {
            nat_hm.put("uuid", UUID.randomUUID());
         }

         nat_hm.put("registered", nation.getRegistered());
         nat_hm.put("isPublic", nation.isPublic());
         nat_hm.put("isOpen", nation.isOpen());
         if (nation.hasMeta()) {
            nat_hm.put("metadata", this.serializeMetadata(nation));
         } else {
            nat_hm.put("metadata", "");
         }

         nat_hm.put("conqueredTax", nation.getConqueredTax());
         nat_hm.put("sanctionedTowns", StringMgmt.join((Collection)nation.getSanctionedTownsForSaving(), "#"));
         this.updateDB("NATIONS", nat_hm, Collections.singletonList("name"));
      } catch (Exception var4) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Save Nation unknown error", var4);
      }

      return false;
   }

   public synchronized boolean saveWorld(TownyWorld world) {
      TownyMessaging.sendDebugMsg("Saving world " + world.getName());

      try {
         HashMap<String, Object> nat_hm = new HashMap();
         nat_hm.put("name", world.getName());
         nat_hm.put("uuid", world.getUUID());
         nat_hm.put("pvp", world.isPVP());
         nat_hm.put("forcepvp", world.isForcePVP());
         nat_hm.put("friendlyFire", world.isFriendlyFireEnabled());
         nat_hm.put("claimable", world.isClaimable());
         nat_hm.put("worldmobs", world.hasWorldMobs());
         nat_hm.put("wildernessmobs", world.hasWildernessMobs());
         nat_hm.put("forcetownmobs", world.isForceTownMobs());
         nat_hm.put("firespread", world.isFire());
         nat_hm.put("forcefirespread", world.isForceFire());
         nat_hm.put("explosions", world.isExpl());
         nat_hm.put("forceexplosions", world.isForceExpl());
         nat_hm.put("endermanprotect", world.isEndermanProtect());
         nat_hm.put("disablecreaturetrample", world.isDisableCreatureTrample());
         nat_hm.put("unclaimedZoneBuild", world.getUnclaimedZoneBuild());
         nat_hm.put("unclaimedZoneDestroy", world.getUnclaimedZoneDestroy());
         nat_hm.put("unclaimedZoneSwitch", world.getUnclaimedZoneSwitch());
         nat_hm.put("unclaimedZoneItemUse", world.getUnclaimedZoneItemUse());
         if (world.getUnclaimedZoneName() != null) {
            nat_hm.put("unclaimedZoneName", world.getUnclaimedZoneName());
         }

         if (world.getUnclaimedZoneIgnoreMaterials() != null) {
            nat_hm.put("unclaimedZoneIgnoreIds", StringMgmt.join(world.getUnclaimedZoneIgnoreMaterials(), "#"));
         }

         nat_hm.put("isDeletingEntitiesOnUnclaim", world.isDeletingEntitiesOnUnclaim());
         if (world.getUnclaimDeleteEntityTypes() != null) {
            nat_hm.put("unclaimDeleteEntityTypes", StringMgmt.join(BukkitTools.convertKeyedToString(world.getUnclaimDeleteEntityTypes()), "#"));
         }

         nat_hm.put("usingPlotManagementDelete", world.isUsingPlotManagementDelete());
         if (world.getPlotManagementDeleteIds() != null) {
            nat_hm.put("plotManagementDeleteIds", StringMgmt.join(world.getPlotManagementDeleteIds(), "#"));
         }

         nat_hm.put("usingPlotManagementMayorDelete", world.isUsingPlotManagementMayorDelete());
         if (world.getPlotManagementMayorDelete() != null) {
            nat_hm.put("plotManagementMayorDelete", StringMgmt.join(world.getPlotManagementMayorDelete(), "#"));
         }

         nat_hm.put("usingPlotManagementRevert", world.isUsingPlotManagementRevert());
         if (world.getPlotManagementIgnoreIds() != null) {
            nat_hm.put("plotManagementIgnoreIds", StringMgmt.join(world.getPlotManagementIgnoreIds(), "#"));
         }

         if (world.getRevertOnUnclaimWhitelistMaterials() != null) {
            nat_hm.put("revertOnUnclaimWhitelistMaterials", StringMgmt.join(world.getRevertOnUnclaimWhitelistMaterials(), "#"));
         }

         nat_hm.put("usingPlotManagementWildRegen", world.isUsingPlotManagementWildEntityRevert());
         if (world.getPlotManagementWildRevertEntities() != null) {
            nat_hm.put("PlotManagementWildRegenEntities", StringMgmt.join(BukkitTools.convertKeyedToString(world.getPlotManagementWildRevertEntities()), "#"));
         }

         if (world.getPlotManagementWildRevertBlockWhitelist() != null) {
            nat_hm.put("PlotManagementWildRegenBlockWhitelist", StringMgmt.join(world.getPlotManagementWildRevertBlockWhitelist(), "#"));
         }

         if (world.getWildRevertMaterialsToNotOverwrite() != null) {
            nat_hm.put("wildRegenBlocksToNotOverwrite", StringMgmt.join(world.getWildRevertMaterialsToNotOverwrite(), "#"));
         }

         nat_hm.put("plotManagementWildRegenSpeed", world.getPlotManagementWildRevertDelay());
         nat_hm.put("usingPlotManagementWildRegenBlocks", world.isUsingPlotManagementWildBlockRevert());
         if (world.getPlotManagementWildRevertBlocks() != null) {
            nat_hm.put("PlotManagementWildRegenBlocks", StringMgmt.join(world.getPlotManagementWildRevertBlocks(), "#"));
         }

         nat_hm.put("usingTowny", world.isUsingTowny());
         nat_hm.put("warAllowed", world.isWarAllowed());
         if (world.hasMeta()) {
            nat_hm.put("metadata", this.serializeMetadata(world));
         } else {
            nat_hm.put("metadata", "");
         }

         this.updateDB("WORLDS", nat_hm, Collections.singletonList("name"));
         return true;
      } catch (Exception var3) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Save world unknown error (" + world.getName() + ")", var3);
         return false;
      }
   }

   public synchronized boolean saveTownBlock(TownBlock townBlock) {
      String var10000 = townBlock.getWorld().getName();
      TownyMessaging.sendDebugMsg("Saving town block " + var10000 + ":" + townBlock.getX() + "x" + townBlock.getZ());

      try {
         HashMap<String, Object> tb_hm = new HashMap();
         tb_hm.put("world", townBlock.getWorld().getName());
         tb_hm.put("x", townBlock.getX());
         tb_hm.put("z", townBlock.getZ());
         tb_hm.put("name", townBlock.getName());
         tb_hm.put("price", townBlock.getPlotPrice());
         tb_hm.put("taxed", townBlock.isTaxed());
         tb_hm.put("town", townBlock.getTown().getName());
         tb_hm.put("resident", townBlock.hasResident() ? townBlock.getResidentOrNull().getName() : "");
         tb_hm.put("typeName", townBlock.getTypeName());
         tb_hm.put("outpost", townBlock.isOutpost());
         tb_hm.put("permissions", townBlock.isChanged() ? townBlock.getPermissions().toString().replaceAll(",", "#") : "");
         tb_hm.put("changed", townBlock.isChanged());
         tb_hm.put("claimedAt", townBlock.getClaimedAt());
         tb_hm.put("minTownMembershipDays", townBlock.getMinTownMembershipDays());
         tb_hm.put("maxTownMembershipDays", townBlock.getMaxTownMembershipDays());
         if (townBlock.hasPlotObjectGroup()) {
            tb_hm.put("groupID", townBlock.getPlotObjectGroup().getUUID().toString());
         } else {
            tb_hm.put("groupID", "");
         }

         if (townBlock.hasDistrict()) {
            tb_hm.put("districtID", townBlock.getDistrict().getUUID().toString());
         } else {
            tb_hm.put("districtID", "");
         }

         if (townBlock.hasMeta()) {
            tb_hm.put("metadata", this.serializeMetadata(townBlock));
         } else {
            tb_hm.put("metadata", "");
         }

         tb_hm.put("trustedResidents", StringMgmt.join((Collection)this.toUUIDList(townBlock.getTrustedResidents()), "#"));
         Map<String, String> stringMap = new HashMap();
         Iterator var4 = townBlock.getPermissionOverrides().entrySet().iterator();

         while(var4.hasNext()) {
            Entry<Resident, PermissionData> entry = (Entry)var4.next();
            stringMap.put(((Resident)entry.getKey()).getUUID().toString(), ((PermissionData)entry.getValue()).toString());
         }

         tb_hm.put("customPermissionData", (new Gson()).toJson(stringMap));
         this.updateDB("TOWNBLOCKS", tb_hm, Arrays.asList("world", "x", "z"));
      } catch (Exception var6) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Save TownBlock unknown error", var6);
      }

      return true;
   }

   public synchronized boolean saveJail(Jail jail) {
      TownyMessaging.sendDebugMsg("Saving jail " + jail.getUUID());

      try {
         HashMap<String, Object> jail_hm = new HashMap();
         jail_hm.put("uuid", jail.getUUID());
         String var10002 = jail.getTownBlock().getWorld().getName();
         jail_hm.put("townBlock", var10002 + "#" + jail.getTownBlock().getX() + "#" + jail.getTownBlock().getZ());
         StringBuilder jailCellArray = new StringBuilder();
         if (jail.hasCells()) {
            Iterator var4 = jail.getJailCellPositions().iterator();

            while(var4.hasNext()) {
               Position cell = (Position)var4.next();
               jailCellArray.append(String.join("#", cell.serialize())).append(";");
            }
         }

         jail_hm.put("spawns", jailCellArray);
         this.updateDB("JAILS", jail_hm, Collections.singletonList("uuid"));
         return true;
      } catch (Exception var6) {
         this.plugin.getLogger().log(Level.WARNING, "SQL: Save jail unknown error", var6);
         return true;
      }
   }

   public void deleteResident(Resident resident) {
      HashMap<String, Object> res_hm = new HashMap();
      res_hm.put("name", resident.getName());
      this.DeleteDB("RESIDENTS", res_hm);
   }

   public void deleteHibernatedResident(UUID uuid) {
      HashMap<String, Object> res_hm = new HashMap();
      res_hm.put("uuid", uuid);
      this.DeleteDB("HIBERNATEDRESIDENTS", res_hm);
   }

   public void deleteTown(Town town) {
      HashMap<String, Object> twn_hm = new HashMap();
      twn_hm.put("name", town.getName());
      this.DeleteDB("TOWNS", twn_hm);
   }

   public void deleteNation(Nation nation) {
      HashMap<String, Object> nat_hm = new HashMap();
      nat_hm.put("name", nation.getName());
      this.DeleteDB("NATIONS", nat_hm);
   }

   public void deleteWorld(TownyWorld world) {
   }

   public void deleteTownBlock(TownBlock townBlock) {
      HashMap<String, Object> twn_hm = new HashMap();
      twn_hm.put("world", townBlock.getWorld().getName());
      twn_hm.put("x", townBlock.getX());
      twn_hm.put("z", townBlock.getZ());
      this.DeleteDB("TOWNBLOCKS", twn_hm);
   }

   public void deletePlotGroup(PlotGroup group) {
      HashMap<String, Object> pltgrp_hm = new HashMap();
      pltgrp_hm.put("groupID", group.getUUID());
      this.DeleteDB("PLOTGROUPS", pltgrp_hm);
   }

   public void deleteDistrict(District district) {
      HashMap<String, Object> district_hm = new HashMap();
      district_hm.put("uuid", district.getUUID());
      this.DeleteDB("DISTRICTS", district_hm);
   }

   public void deleteJail(Jail jail) {
      HashMap<String, Object> jail_hm = new HashMap();
      jail_hm.put("uuid", jail.getUUID());
      this.DeleteDB("JAILS", jail_hm);
   }

   public CompletableFuture<Optional<Long>> getHibernatedResidentRegistered(UUID uuid) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            Connection connection = this.getConnection();

            Optional var6;
            label80: {
               try {
                  PreparedStatement preparedStatement;
                  label82: {
                     preparedStatement = connection.prepareStatement("SELECT * FROM " + this.tb_prefix + "HIBERNATEDRESIDENTS WHERE uuid = ? LIMIT 1");

                     try {
                        preparedStatement.setString(1, uuid.toString());
                        ResultSet resultSet = preparedStatement.executeQuery();
                        String registered;
                        if (resultSet.next() && (registered = resultSet.getString("registered")) != null && !registered.isEmpty()) {
                           var6 = Optional.of(Long.parseLong(registered));
                           break label82;
                        }

                        var6 = Optional.empty();
                     } catch (Throwable var9) {
                        if (preparedStatement != null) {
                           try {
                              preparedStatement.close();
                           } catch (Throwable var8) {
                              var9.addSuppressed(var8);
                           }
                        }

                        throw var9;
                     }

                     if (preparedStatement != null) {
                        preparedStatement.close();
                     }
                     break label80;
                  }

                  if (preparedStatement != null) {
                     preparedStatement.close();
                  }
               } catch (Throwable var10) {
                  if (connection != null) {
                     try {
                        connection.close();
                     } catch (Throwable var7) {
                        var10.addSuppressed(var7);
                     }
                  }

                  throw var10;
               }

               if (connection != null) {
                  connection.close();
               }

               return var6;
            }

            if (connection != null) {
               connection.close();
            }

            return var6;
         } catch (Exception var11) {
            return Optional.empty();
         }
      });
   }

   public HikariDataSource getHikariDataSource() {
      return this.hikariDataSource;
   }

   public static enum TownyDBTableType {
      JAIL("JAILS", "SELECT uuid FROM ", "uuid"),
      PLOTGROUP("PLOTGROUPS", "SELECT groupID FROM ", "groupID"),
      DISTRICT("DISTRICTS", "SELECT uuid FROM ", "uuid"),
      RESIDENT("RESIDENTS", "SELECT name FROM ", "name"),
      HIBERNATED_RESIDENT("HIBERNATEDRESIDENTS", "", "uuid"),
      TOWN("TOWNS", "SELECT name FROM ", "name"),
      NATION("NATIONS", "SELECT name FROM ", "name"),
      WORLD("WORLDS", "SELECT name FROM ", "name"),
      TOWNBLOCK("TOWNBLOCKS", "SELECT world,x,z FROM ", "name"),
      COOLDOWN("COOLDOWNS", "SELECT * FROM ", "key");

      private final String tableName;
      private String queryString;
      private String primaryKey;

      private TownyDBTableType(String tableName, String queryString, String primaryKey) {
         this.tableName = tableName;
         this.queryString = queryString;
         this.primaryKey = primaryKey;
      }

      public String tableName() {
         return this.tableName;
      }

      private String getSingular() {
         return this.tableName.substring(0, this.tableName.length() - 1).toLowerCase(Locale.ROOT);
      }

      public String getSaveLocation(String rowKeyName) {
         return TownySettings.getSQLTablePrefix() + this.tableName + File.separator + rowKeyName;
      }

      public String getLoadErrorMsg(UUID uuid) {
         return "Loading Error: Could not read the " + this.getSingular() + " with UUID '" + uuid + "' from the " + this.tableName + " table.";
      }

      // $FF: synthetic method
      private static TownySQLSource.TownyDBTableType[] $values() {
         return new TownySQLSource.TownyDBTableType[]{JAIL, PLOTGROUP, DISTRICT, RESIDENT, HIBERNATED_RESIDENT, TOWN, NATION, WORLD, TOWNBLOCK, COOLDOWN};
      }
   }
}
