package com.palmergames.bukkit.towny.db;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class SQLSchema {
   private static final String SQLDB_NAME = TownySettings.getSQLDBName();
   private static final String TABLE_PREFIX;
   private static final int MYSQL_DUPLICATE_COLUMN_ERR = 1060;

   public static void initTables(Connection cntx) {
      initTable(cntx, TownySQLSource.TownyDBTableType.WORLD);
      updateTable(cntx, TownySQLSource.TownyDBTableType.WORLD, getWorldColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.NATION);
      updateTable(cntx, TownySQLSource.TownyDBTableType.NATION, getNationColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.TOWN);
      updateTable(cntx, TownySQLSource.TownyDBTableType.TOWN, getTownColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.RESIDENT);
      updateTable(cntx, TownySQLSource.TownyDBTableType.RESIDENT, getResidentColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.TOWNBLOCK);
      updateTable(cntx, TownySQLSource.TownyDBTableType.TOWNBLOCK, getTownBlockColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.PLOTGROUP);
      updateTable(cntx, TownySQLSource.TownyDBTableType.PLOTGROUP, getPlotGroupColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.DISTRICT);
      updateTable(cntx, TownySQLSource.TownyDBTableType.DISTRICT, getDistrictColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.JAIL);
      updateTable(cntx, TownySQLSource.TownyDBTableType.JAIL, getJailsColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.HIBERNATED_RESIDENT);
      updateTable(cntx, TownySQLSource.TownyDBTableType.HIBERNATED_RESIDENT, getHibernatedResidentsColumns());
      initTable(cntx, TownySQLSource.TownyDBTableType.COOLDOWN);
      updateTable(cntx, TownySQLSource.TownyDBTableType.COOLDOWN, getCooldownColumns());
   }

   private static void initTable(Connection cntx, TownySQLSource.TownyDBTableType tableType) {
      try {
         Statement s = cntx.createStatement();

         try {
            s.executeUpdate(fetchTableSchema(tableType));
            TownyMessaging.sendDebugMsg("Table " + tableType.tableName() + " is ok!");
         } catch (Throwable var6) {
            if (s != null) {
               try {
                  s.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (s != null) {
            s.close();
         }
      } catch (SQLException var7) {
         String var10000 = tableType.tableName();
         TownyMessaging.sendErrorMsg("Error Creating table " + var10000 + " : " + var7.getMessage());
      }

   }

   private static String fetchTableSchema(TownySQLSource.TownyDBTableType tableType) {
      String var10000;
      switch(tableType) {
      case TOWNBLOCK:
         var10000 = fetchCreateTownBlocksStatement();
         break;
      case JAIL:
         var10000 = fetchCreateUUIDStatement(tableType);
         break;
      case PLOTGROUP:
         var10000 = fetchCreatePlotGroupStatement(tableType);
         break;
      case DISTRICT:
         var10000 = fetchCreateUUIDStatement(tableType);
         break;
      case COOLDOWN:
         var10000 = fetchCreateCooldownsStatement(tableType);
         break;
      case WORLD:
         var10000 = fetchCreateWorldStatemnt(tableType);
         break;
      case HIBERNATED_RESIDENT:
         var10000 = fetchCreateUUIDStatement(tableType);
         break;
      default:
         var10000 = fetchCreateNamedStatement(tableType);
      }

      return var10000;
   }

   private static String fetchCreateNamedStatement(TownySQLSource.TownyDBTableType tableType) {
      String var10000 = TABLE_PREFIX;
      return "CREATE TABLE IF NOT EXISTS " + var10000 + tableType.tableName() + " (`name` VARCHAR(32) NOT NULL,PRIMARY KEY (`name`))";
   }

   private static String fetchCreatePlotGroupStatement(TownySQLSource.TownyDBTableType tableType) {
      String var10000 = TABLE_PREFIX;
      return "CREATE TABLE IF NOT EXISTS " + var10000 + tableType.tableName() + " (`groupID` VARCHAR(36) NOT NULL,PRIMARY KEY (`groupID`))";
   }

   private static String fetchCreateUUIDStatement(TownySQLSource.TownyDBTableType tableType) {
      String var10000 = TABLE_PREFIX;
      return "CREATE TABLE IF NOT EXISTS " + var10000 + tableType.tableName() + " (`uuid` VARCHAR(36) NOT NULL,PRIMARY KEY (`uuid`))";
   }

   private static String fetchCreateTownBlocksStatement() {
      return "CREATE TABLE IF NOT EXISTS " + TABLE_PREFIX + "TOWNBLOCKS (`world` VARCHAR(36) NOT NULL,`x` mediumint NOT NULL,`z` mediumint NOT NULL,PRIMARY KEY (`world`,`x`,`z`))";
   }

   private static String fetchCreateCooldownsStatement(TownySQLSource.TownyDBTableType tableType) {
      String var10000 = TABLE_PREFIX;
      return "CREATE TABLE IF NOT EXISTS " + var10000 + tableType.tableName() + " (`key` varchar(200) not null, primary key (`key`))";
   }

   private static String fetchCreateWorldStatemnt(TownySQLSource.TownyDBTableType tableType) {
      String var10000 = TABLE_PREFIX;
      return "CREATE TABLE IF NOT EXISTS " + var10000 + tableType.tableName() + " (`name` VARCHAR(64) NOT NULL,PRIMARY KEY (`name`))";
   }

   private static void updateTable(Connection cntx, TownySQLSource.TownyDBTableType tableType, List<String> columns) {
      String var10000 = SQLDB_NAME;
      String update = "ALTER TABLE `" + var10000 + "`.`" + TABLE_PREFIX + tableType.tableName() + "` ADD COLUMN ";
      Iterator var4 = columns.iterator();

      while(var4.hasNext()) {
         String column = (String)var4.next();

         try {
            PreparedStatement ps = cntx.prepareStatement(update + column);

            try {
               ps.executeUpdate();
            } catch (Throwable var10) {
               if (ps != null) {
                  try {
                     ps.close();
                  } catch (Throwable var9) {
                     var10.addSuppressed(var9);
                  }
               }

               throw var10;
            }

            if (ps != null) {
               ps.close();
            }
         } catch (SQLException var11) {
            if (var11.getErrorCode() != 1060) {
               var10000 = tableType.tableName();
               TownyMessaging.sendErrorMsg("Error updating table " + var10000 + ":" + var11.getMessage());
            }
         }
      }

      TownyMessaging.sendDebugMsg("Table " + tableType.tableName() + " is updated!");
   }

   private static List<String> getJailsColumns() {
      List<String> columns = new ArrayList();
      columns.add("`townBlock` mediumtext NOT NULL");
      columns.add("`spawns`  mediumtext DEFAULT NULL");
      return columns;
   }

   private static List<String> getPlotGroupColumns() {
      List<String> columns = new ArrayList();
      columns.add("`groupName` mediumtext NOT NULL");
      columns.add("`groupPrice` float DEFAULT NULL");
      columns.add("`town` VARCHAR(32) NOT NULL");
      columns.add("`metadata` text DEFAULT NULL");
      return columns;
   }

   private static List<String> getDistrictColumns() {
      List<String> columns = new ArrayList();
      columns.add("`districtName` mediumtext NOT NULL");
      columns.add("`town` VARCHAR(36) NOT NULL");
      columns.add("`metadata` text DEFAULT NULL");
      return columns;
   }

   private static List<String> getResidentColumns() {
      List<String> columns = new ArrayList();
      columns.add("`town` mediumtext");
      columns.add("`town-ranks` mediumtext");
      columns.add("`nation-ranks` mediumtext");
      columns.add("`lastOnline` BIGINT NOT NULL");
      columns.add("`registered` BIGINT NOT NULL");
      columns.add("`joinedTownAt` BIGINT NOT NULL");
      columns.add("`isNPC` bool NOT NULL DEFAULT '0'");
      columns.add("`jailUUID` VARCHAR(36) DEFAULT NULL");
      columns.add("`jailCell` mediumint");
      columns.add("`jailHours` mediumint");
      columns.add("`jailBail` float DEFAULT NULL");
      columns.add("`title` mediumtext");
      columns.add("`surname` mediumtext");
      columns.add("`protectionStatus` mediumtext");
      columns.add("`friends` mediumtext");
      columns.add("`metadata` text DEFAULT NULL");
      columns.add("`uuid` VARCHAR(36) NOT NULL");
      columns.add("`about` mediumtext DEFAULT NULL");
      return columns;
   }

   private static List<String> getHibernatedResidentsColumns() {
      List<String> columns = new ArrayList();
      columns.add("`registered` BIGINT DEFAULT NULL");
      return columns;
   }

   private static List<String> getTownColumns() {
      List<String> columns = new ArrayList();
      columns.add("`mayor` mediumtext");
      columns.add("`nation` mediumtext");
      columns.add("`townBoard` mediumtext DEFAULT NULL");
      columns.add("`tag` mediumtext DEFAULT NULL");
      columns.add("`founder` mediumtext DEFAULT NULL");
      columns.add("`protectionStatus` mediumtext DEFAULT NULL");
      columns.add("`bonus` int(11) DEFAULT 0");
      columns.add("`purchased` int(11)  DEFAULT 0");
      columns.add("`taxpercent` bool NOT NULL DEFAULT '0'");
      columns.add("`maxPercentTaxAmount` float DEFAULT NULL");
      columns.add("`taxes` float DEFAULT 0");
      columns.add("`hasUpkeep` bool NOT NULL DEFAULT '0'");
      columns.add("`plotPrice` float DEFAULT NULL");
      columns.add("`plotTax` float DEFAULT NULL");
      columns.add("`commercialPlotPrice` float DEFAULT NULL");
      columns.add("`commercialPlotTax` float NOT NULL");
      columns.add("`embassyPlotPrice` float NOT NULL");
      columns.add("`embassyPlotTax` float NOT NULL");
      columns.add("`open` bool NOT NULL DEFAULT '0'");
      columns.add("`public` bool NOT NULL DEFAULT '0'");
      columns.add("`adminEnabledMobs` bool NOT NULL DEFAULT '0'");
      columns.add("`admindisabledpvp` bool NOT NULL DEFAULT '0'");
      columns.add("`adminenabledpvp` bool NOT NULL DEFAULT '0'");
      columns.add("`allowedToWar` bool NOT NULL DEFAULT '1'");
      columns.add("`homeblock` mediumtext NOT NULL");
      columns.add("`spawn` mediumtext NOT NULL");
      columns.add("`outpostSpawns` mediumtext DEFAULT NULL");
      columns.add("`jailSpawns` mediumtext DEFAULT NULL");
      columns.add("`outlaws` mediumtext DEFAULT NULL");
      columns.add("`uuid` VARCHAR(36) DEFAULT NULL");
      columns.add("`registered` BIGINT DEFAULT NULL");
      columns.add("`spawnCost` float NOT NULL");
      columns.add("`mapColorHexCode` mediumtext DEFAULT NULL");
      columns.add("`metadata` text DEFAULT NULL");
      columns.add("`conqueredDays` mediumint");
      columns.add("`conquered` bool NOT NULL DEFAULT '0'");
      columns.add("`ruined` bool NOT NULL DEFAULT '0'");
      columns.add("`ruinedTime` BIGINT DEFAULT '0'");
      columns.add("`neutral` bool NOT NULL DEFAULT '0'");
      columns.add("`debtBalance` float NOT NULL");
      columns.add("`joinedNationAt` BIGINT NOT NULL");
      columns.add("`primaryJail` VARCHAR(36) DEFAULT NULL");
      columns.add("`movedHomeBlockAt` BIGINT NOT NULL");
      columns.add("`trustedResidents` mediumtext DEFAULT NULL");
      columns.add("`trustedTowns` mediumtext NOT NULL");
      columns.add("`nationZoneOverride` int(11) DEFAULT 0");
      columns.add("`nationZoneEnabled` bool NOT NULL DEFAULT '1'");
      columns.add("`allies` mediumtext NOT NULL");
      columns.add("`enemies` mediumtext NOT NULL");
      columns.add("`hasUnlimitedClaims` bool NOT NULL DEFAULT '0'");
      columns.add("`manualTownLevel` BIGINT DEFAULT '-1'");
      columns.add("`forSale` bool NOT NULL DEFAULT '0'");
      columns.add("`forSalePrice` float NOT NULL");
      columns.add("`visibleOnTopLists` bool NOT NULL DEFAULT '1'");
      return columns;
   }

   private static List<String> getNationColumns() {
      List<String> columns = new ArrayList();
      columns.add("`capital` mediumtext NOT NULL");
      columns.add("`tag` mediumtext NOT NULL");
      columns.add("`allies` mediumtext NOT NULL");
      columns.add("`enemies` mediumtext NOT NULL");
      columns.add("`taxes` float NOT NULL");
      columns.add("`taxpercent` bool NOT NULL DEFAULT '0'");
      columns.add("`maxPercentTaxAmount` float DEFAULT NULL");
      columns.add("`spawnCost` float NOT NULL");
      columns.add("`neutral` bool NOT NULL DEFAULT '0'");
      columns.add("`uuid` VARCHAR(36) DEFAULT NULL");
      columns.add("`registered` BIGINT DEFAULT NULL");
      columns.add("`nationBoard` mediumtext DEFAULT NULL");
      columns.add("`mapColorHexCode` mediumtext DEFAULT NULL");
      columns.add("`nationSpawn` mediumtext DEFAULT NULL");
      columns.add("`isPublic` bool NOT NULL DEFAULT '1'");
      columns.add("`isOpen` bool NOT NULL DEFAULT '1'");
      columns.add("`metadata` text DEFAULT NULL");
      columns.add("`conqueredTax` float NOT NULL");
      columns.add("`sanctionedTowns` mediumtext DEFAULT NULL");
      return columns;
   }

   private static List<String> getWorldColumns() {
      List<String> columns = new ArrayList();
      columns.add("`uuid` VARCHAR(36) DEFAULT NULL");
      columns.add("`claimable` bool NOT NULL DEFAULT '0'");
      columns.add("`pvp` bool NOT NULL DEFAULT '0'");
      columns.add("`forcepvp` bool NOT NULL DEFAULT '0'");
      columns.add("`forcetownmobs` bool NOT NULL DEFAULT '0'");
      columns.add("`friendlyFire` bool NOT NULL DEFAULT '0'");
      columns.add("`worldmobs` bool NOT NULL DEFAULT '0'");
      columns.add("`wildernessmobs` bool NOT NULL DEFAULT '0'");
      columns.add("`firespread` bool NOT NULL DEFAULT '0'");
      columns.add("`forcefirespread` bool NOT NULL DEFAULT '0'");
      columns.add("`explosions` bool NOT NULL DEFAULT '0'");
      columns.add("`forceexplosions` bool NOT NULL DEFAULT '0'");
      columns.add("`endermanprotect` bool NOT NULL DEFAULT '0'");
      columns.add("`disablecreaturetrample` bool NOT NULL DEFAULT '0'");
      columns.add("`unclaimedZoneBuild` bool NOT NULL DEFAULT '0'");
      columns.add("`unclaimedZoneDestroy` bool NOT NULL DEFAULT '0'");
      columns.add("`unclaimedZoneSwitch` bool NOT NULL DEFAULT '0'");
      columns.add("`unclaimedZoneItemUse` bool NOT NULL DEFAULT '0'");
      columns.add("`unclaimedZoneName` mediumtext NOT NULL");
      columns.add("`unclaimedZoneIgnoreIds` mediumtext NOT NULL");
      columns.add("`usingPlotManagementDelete` bool NOT NULL DEFAULT '0'");
      columns.add("`plotManagementDeleteIds` mediumtext NOT NULL");
      columns.add("`isDeletingEntitiesOnUnclaim` bool NOT NULL DEFAULT '0'");
      columns.add("`unclaimDeleteEntityTypes` mediumtext NOT NULL");
      columns.add("`usingPlotManagementMayorDelete` bool NOT NULL DEFAULT '0'");
      columns.add("`plotManagementMayorDelete` mediumtext NOT NULL");
      columns.add("`usingPlotManagementRevert` bool NOT NULL DEFAULT '0'");
      columns.add("`plotManagementIgnoreIds` mediumtext NOT NULL");
      columns.add("`revertOnUnclaimWhitelistMaterials` mediumtext NOT NULL");
      columns.add("`usingPlotManagementWildRegen` bool NOT NULL DEFAULT '0'");
      columns.add("`plotManagementWildRegenEntities` mediumtext NOT NULL");
      columns.add("`plotManagementWildRegenBlockWhitelist` mediumtext NOT NULL");
      columns.add("`wildRegenBlocksToNotOverwrite` mediumtext NOT NULL");
      columns.add("`plotManagementWildRegenSpeed` long NOT NULL");
      columns.add("`usingPlotManagementWildRegenBlocks` bool NOT NULL DEFAULT '0'");
      columns.add("`plotManagementWildRegenBlocks` mediumtext NOT NULL");
      columns.add("`usingTowny` bool NOT NULL DEFAULT '0'");
      columns.add("`warAllowed` bool NOT NULL DEFAULT '0'");
      columns.add("`metadata` text DEFAULT NULL");
      return columns;
   }

   private static List<String> getTownBlockColumns() {
      List<String> columns = new ArrayList();
      columns.add("`name` mediumtext");
      columns.add("`price` float DEFAULT '-1'");
      columns.add("`taxed` bool NOT NULL DEFAULT '1'");
      columns.add("`town` mediumtext");
      columns.add("`resident` mediumtext");
      columns.add("`type` TINYINT NOT  NULL DEFAULT '0'");
      columns.add("`typeName` mediumtext");
      columns.add("`outpost` bool NOT NULL DEFAULT '0'");
      columns.add("`permissions` mediumtext NOT NULL");
      columns.add("`locked` bool NOT NULL DEFAULT '0'");
      columns.add("`changed` bool NOT NULL DEFAULT '0'");
      columns.add("`metadata` text DEFAULT NULL");
      columns.add("`groupID` VARCHAR(36) DEFAULT NULL");
      columns.add("`districtID` VARCHAR(36) DEFAULT NULL");
      columns.add("`claimedAt` BIGINT NOT NULL");
      columns.add("`trustedResidents` mediumtext DEFAULT NULL");
      columns.add("`customPermissionData` mediumtext DEFAULT NULL");
      columns.add("`minTownMembershipDays` SMALLINT NOT NULL DEFAULT '-1'");
      columns.add("`maxTownMembershipDays` SMALLINT NOT NULL DEFAULT '-1'");
      return columns;
   }

   private static List<String> getCooldownColumns() {
      List<String> columns = new ArrayList();
      columns.add("`key` varchar(200) NOT NULL");
      columns.add("`expiry` BIGINT NOT NULL");
      return columns;
   }

   public static void cleanup(Connection connection) {
      List<SQLSchema.ColumnUpdate> cleanups = new ArrayList();
      cleanups.add(SQLSchema.ColumnUpdate.update("TOWNS", "residents"));
      cleanups.add(SQLSchema.ColumnUpdate.update("NATIONS", "assistants"));
      cleanups.add(SQLSchema.ColumnUpdate.update("NATIONS", "towns"));
      cleanups.add(SQLSchema.ColumnUpdate.update("WORLDS", "towns"));
      cleanups.add(SQLSchema.ColumnUpdate.update("WORLDS", "plotManagementRevertSpeed"));
      cleanups.add(SQLSchema.ColumnUpdate.update("PLOTGROUPS", "claimedAt"));
      cleanups.add(SQLSchema.ColumnUpdate.update("RESIDENTS", "isJailed"));
      cleanups.add(SQLSchema.ColumnUpdate.update("RESIDENTS", "JailSpawn"));
      cleanups.add(SQLSchema.ColumnUpdate.update("RESIDENTS", "JailDays"));
      cleanups.add(SQLSchema.ColumnUpdate.update("RESIDENTS", "JailTown"));
      cleanups.add(SQLSchema.ColumnUpdate.update("TOWNS", "jailSpawns"));
      cleanups.add(SQLSchema.ColumnUpdate.update("WORLDS", "disableplayertrample"));
      cleanups.add(SQLSchema.ColumnUpdate.update("TOWNS", "assistants"));
      Iterator var2 = cleanups.iterator();

      while(var2.hasNext()) {
         SQLSchema.ColumnUpdate update = (SQLSchema.ColumnUpdate)var2.next();
         dropColumn(connection, update.table(), update.column());
      }

   }

   private static void dropColumn(Connection cntx, String table, String column) {
      try {
         Statement s = cntx.createStatement();

         label54: {
            try {
               DatabaseMetaData md = cntx.getMetaData();
               ResultSet rs = md.getColumns((String)null, (String)null, table, column);
               if (!rs.next()) {
                  break label54;
               }

               String update = "ALTER TABLE `" + SQLDB_NAME + "`.`" + table + "` DROP COLUMN `" + column + "`";
               s.executeUpdate(update);
               TownyMessaging.sendDebugMsg("Table " + table + " has dropped the " + column + " column.");
            } catch (Throwable var8) {
               if (s != null) {
                  try {
                     s.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (s != null) {
               s.close();
            }

            return;
         }

         if (s != null) {
            s.close();
         }

         return;
      } catch (SQLException var9) {
         if (var9.getErrorCode() != 1060) {
            TownyMessaging.sendErrorMsg("Error updating table " + table + ":" + var9.getMessage());
         }
      }

   }

   static {
      TABLE_PREFIX = TownySettings.getSQLTablePrefix().toUpperCase(Locale.ROOT);
   }

   private static record ColumnUpdate(String table, String column) {
      private ColumnUpdate(String table, String column) {
         this.table = table;
         this.column = column;
      }

      private static SQLSchema.ColumnUpdate update(String table, String column) {
         return new SQLSchema.ColumnUpdate(SQLSchema.TABLE_PREFIX + table, column);
      }

      public String table() {
         return this.table;
      }

      public String column() {
         return this.column;
      }
   }
}
