package com.palmergames.bukkit.towny.db;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.DeleteNationEvent;
import com.palmergames.bukkit.towny.event.DeleteTownEvent;
import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.EmptyNationException;
import com.palmergames.bukkit.towny.exceptions.EmptyTownException;
import com.palmergames.bukkit.towny.exceptions.InvalidNameException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.District;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.PermissionData;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Position;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockTypeHandler;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.metadata.MetadataLoader;
import com.palmergames.bukkit.towny.tasks.CooldownTimerTask;
import com.palmergames.bukkit.towny.tasks.DeleteFileTask;
import com.palmergames.bukkit.towny.utils.MapUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.FileMgmt;
import com.palmergames.util.StringMgmt;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;

public final class TownyFlatFileSource extends TownyDatabaseHandler {
   private final String newLine = System.lineSeparator();

   public TownyFlatFileSource(Towny plugin, TownyUniverse universe) {
      super(plugin, universe);
      if (!FileMgmt.checkOrCreateFolders(this.rootFolderPath, this.dataFolderPath, this.dataFolderPath + File.separator + "residents", this.dataFolderPath + File.separator + "residents" + File.separator + "deleted", this.dataFolderPath + File.separator + "residents" + File.separator + "hibernated", this.dataFolderPath + File.separator + "towns", this.dataFolderPath + File.separator + "towns" + File.separator + "deleted", this.dataFolderPath + File.separator + "nations", this.dataFolderPath + File.separator + "nations" + File.separator + "deleted", this.dataFolderPath + File.separator + "worlds", this.dataFolderPath + File.separator + "worlds" + File.separator + "deleted", this.dataFolderPath + File.separator + "townblocks", this.dataFolderPath + File.separator + "plotgroups", this.dataFolderPath + File.separator + "plotgroups" + File.separator + "deleted", this.dataFolderPath + File.separator + "districts", this.dataFolderPath + File.separator + "districts" + File.separator + "deleted", this.dataFolderPath + File.separator + "jails", this.dataFolderPath + File.separator + "jails" + File.separator + "deleted")) {
         TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_cannot_create_defaults"));
      }

   }

   public String getResidentFilename(Resident resident) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "residents" + File.separator + resident.getName() + ".txt";
   }

   public String getHibernatedResidentFilename(UUID uuid) {
      return this.dataFolderPath + File.separator + "residents" + File.separator + "hibernated" + File.separator + uuid + ".txt";
   }

   public String getTownFilename(Town town) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "towns" + File.separator + town.getName() + ".txt";
   }

   public String getNationFilename(Nation nation) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "nations" + File.separator + nation.getName() + ".txt";
   }

   public String getWorldFilename(TownyWorld world) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "worlds" + File.separator + world.getName() + ".txt";
   }

   public String getTownBlockFilename(TownBlock townBlock) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "townblocks" + File.separator + townBlock.getWorld().getName() + File.separator + townBlock.getX() + "_" + townBlock.getZ() + "_" + TownySettings.getTownBlockSize() + ".data";
   }

   public String getPlotGroupFilename(PlotGroup group) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "plotgroups" + File.separator + group.getUUID() + ".data";
   }

   public String getDistrictFilename(District district) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "districts" + File.separator + district.getUUID() + ".data";
   }

   public String getJailFilename(Jail jail) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "jails" + File.separator + jail.getUUID() + ".txt";
   }

   public boolean loadTownBlockList() {
      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_townblock_list"));
      File townblocksFolder = new File(this.dataFolderPath + File.separator + "townblocks");
      File[] worldFolders = townblocksFolder.listFiles(File::isDirectory);
      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_folders_found", worldFolders.length));
      boolean mismatched = false;
      int mismatchedCount = 0;

      try {
         File[] var5 = worldFolders;
         int var6 = worldFolders.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            File worldfolder = var5[var7];
            String worldName = worldfolder.getName();
            if (BukkitTools.getWorld(worldName) == null) {
               Towny.getPlugin().getScheduler().runAsyncLater(() -> {
                  if (BukkitTools.getWorld(worldName) == null) {
                     Towny.getPlugin().getLogger().warning("Your towny\\data\\townblocks\\ folder contains a folder named '" + worldName + "' which doesn't appear to exist on your Bukkit server!");
                     Towny.getPlugin().getLogger().warning("Towny will load the townblocks regardless, but if this world no longer exists please delete the folder.");
                  }

               }, 20L);
            }

            TownyWorld world = this.universe.getWorld(worldName);
            if (world == null) {
               this.newWorld(worldName);
               world = this.universe.getWorld(worldName);
            }

            File worldFolder = new File(this.dataFolderPath + File.separator + "townblocks" + File.separator + worldName);
            File[] townBlockFiles = worldFolder.listFiles((file) -> {
               return file.getName().endsWith(".data");
            });
            int total = 0;
            File[] var14 = townBlockFiles;
            int var15 = townBlockFiles.length;

            for(int var16 = 0; var16 < var15; ++var16) {
               File townBlockFile = var14[var16];
               String[] coords = townBlockFile.getName().split("_");
               String[] size = coords[2].split("\\.");
               if (Integer.parseInt(size[0]) != TownySettings.getTownBlockSize()) {
                  mismatched = true;
                  ++mismatchedCount;
               } else {
                  int x = Integer.parseInt(coords[0]);
                  int z = Integer.parseInt(coords[1]);
                  TownBlock townBlock = new TownBlock(x, z, world);
                  this.universe.addTownBlock(townBlock);
                  ++total;
               }
            }

            TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_world_loaded_townblocks", worldName, total));
         }

         if (mismatched) {
            TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_mismatched_townblock_size", mismatchedCount));
         }

         return true;
      } catch (Exception var23) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred while loading the flatfile townblock list", var23);
         return false;
      }
   }

   public boolean loadPlotGroupList() {
      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_group_list"));
      File[] plotGroupFiles = this.receiveObjectFiles("plotgroups", ".data");
      if (plotGroupFiles == null) {
         return true;
      } else {
         File[] var2 = plotGroupFiles;
         int var3 = plotGroupFiles.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            File plotGroup = var2[var4];
            this.universe.newPlotGroupInternal(UUID.fromString(plotGroup.getName().replace(".data", "")));
         }

         return true;
      }
   }

   public boolean loadDistrictList() {
      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_district_list"));
      File[] districtFiles = this.receiveObjectFiles("districts", ".data");
      if (districtFiles == null) {
         return true;
      } else {
         File[] var2 = districtFiles;
         int var3 = districtFiles.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            File districtFile = var2[var4];
            this.universe.newDistrictInternal(UUID.fromString(districtFile.getName().replace(".data", "")));
         }

         return true;
      }
   }

   public boolean loadResidentList() {
      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_resident_list"));
      List<String> residents = this.receiveListFromLegacyFile("residents.txt");
      File[] residentFiles = this.receiveObjectFiles("residents", ".txt");
      File[] var3 = residentFiles;
      int var4 = residentFiles.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         File resident = var3[var5];
         String name = resident.getName().replace(".txt", "");
         if (!residents.isEmpty() && !residents.contains(name)) {
            TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_removing_resident_not_found", resident.getName()));
            this.deleteFile(resident.getAbsolutePath());
         } else {
            try {
               this.newResident(name);
            } catch (NotRegisteredException var9) {
               this.plugin.getLogger().log(Level.WARNING, "Resident " + name + " has an invalid name", var9);
               return false;
            } catch (AlreadyRegisteredException var10) {
            }
         }
      }

      if (!residents.isEmpty()) {
         this.deleteFile(this.dataFolderPath + File.separator + "residents.txt");
      }

      return true;
   }

   public boolean loadTownList() {
      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_town_list"));
      List<String> towns = this.receiveListFromLegacyFile("towns.txt");
      File[] townFiles = this.receiveObjectFiles("towns", ".txt");
      List<File> rejectedTowns = new ArrayList();
      File[] var4 = townFiles;
      int var5 = townFiles.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         File town = var4[var6];
         String name = town.getName().replace(".txt", "");
         if (!towns.isEmpty() && !towns.contains(name)) {
            TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_removing_town_not_found", town.getName()));
            this.deleteFile(town.getAbsolutePath());
         } else {
            try {
               this.universe.newTownInternal(name);
            } catch (InvalidNameException | AlreadyRegisteredException var11) {
               rejectedTowns.add(town);
            }
         }
      }

      if (!towns.isEmpty()) {
         this.deleteFile(this.dataFolderPath + File.separator + "towns.txt");
      }

      Iterator var12 = rejectedTowns.iterator();

      while(var12.hasNext()) {
         File town = (File)var12.next();
         String name = town.getName().replace(".txt", "");
         String newName = this.generateReplacementName(true);
         this.universe.getReplacementNameMap().put(name, newName);
         TownyMessaging.sendErrorMsg(String.format("The town %s tried to load an invalid name, attempting to rename it to %s.", name, newName));

         try {
            this.universe.newTownInternal(newName);
         } catch (InvalidNameException | AlreadyRegisteredException var10) {
            this.plugin.getLogger().log(Level.WARNING, "exception occurred while registering town '" + newName + "' internally", var10);
            return false;
         }

         File newFile = new File(town.getParent(), newName + ".txt");
         town.renameTo(newFile);
      }

      return true;
   }

   public boolean loadNationList() {
      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_nation_list"));
      List<String> nations = this.receiveListFromLegacyFile("nations.txt");
      File[] nationFiles = this.receiveObjectFiles("nations", ".txt");
      List<File> rejectedNations = new ArrayList();
      File[] var4 = nationFiles;
      int var5 = nationFiles.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         File nation = var4[var6];
         String name = nation.getName().replace(".txt", "");
         if (!nations.isEmpty() && !nations.contains(name)) {
            TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_removing_nation_not_found", nation.getName()));
            this.deleteFile(nation.getAbsolutePath());
         } else {
            try {
               this.newNation(name);
            } catch (NotRegisteredException | AlreadyRegisteredException var11) {
               rejectedNations.add(nation);
            }
         }
      }

      if (!nations.isEmpty()) {
         this.deleteFile(this.dataFolderPath + File.separator + "nations.txt");
      }

      Iterator var12 = rejectedNations.iterator();

      while(var12.hasNext()) {
         File nation = (File)var12.next();
         String name = nation.getName().replace(".txt", "");
         String newName = this.generateReplacementName(false);
         this.universe.getReplacementNameMap().put(name, newName);
         TownyMessaging.sendErrorMsg(String.format("The nation %s tried to load an invalid name, attempting to rename it to %s.", name, newName));

         try {
            this.newNation(newName);
         } catch (NotRegisteredException | AlreadyRegisteredException var10) {
            this.plugin.getLogger().log(Level.WARNING, "exception occurred while registering nation '" + newName + "' internally", var10);
            return false;
         }

         File newFile = new File(nation.getParent(), newName + ".txt");
         nation.renameTo(newFile);
      }

      return true;
   }

   public boolean loadWorldList() {
      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_server_world_list"));
      Iterator var1 = Bukkit.getServer().getWorlds().iterator();

      while(var1.hasNext()) {
         World world = (World)var1.next();
         this.universe.registerTownyWorld(new TownyWorld(world.getName(), world.getUID()));
      }

      TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_world_list"));
      File[] var10 = this.receiveObjectFiles("worlds", ".txt");
      int var11 = var10.length;

      for(int var3 = 0; var3 < var11; ++var3) {
         File worldFile = var10[var3];
         String name = worldFile.getName().replace(".txt", "");
         if (this.universe.getWorld(name) == null) {
            UUID uuid = null;

            try {
               uuid = UUID.fromString((String)FileMgmt.loadFileIntoHashMap(worldFile).getOrDefault("uuid", ""));
            } catch (IllegalArgumentException var8) {
            }

            if (uuid != null) {
               this.universe.registerTownyWorld(new TownyWorld(name, uuid));
            } else {
               try {
                  this.newWorld(name);
               } catch (AlreadyRegisteredException var9) {
               }
            }
         }
      }

      return true;
   }

   public boolean loadJailList() {
      TownyMessaging.sendDebugMsg("Loading Jail List");
      File[] jailFiles = this.receiveObjectFiles("jails", ".txt");
      if (jailFiles == null) {
         return true;
      } else {
         File[] var2 = jailFiles;
         int var3 = jailFiles.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            File jail = var2[var4];
            String uuid = jail.getName().replace(".txt", "");
            this.universe.newJailInternal(uuid);
         }

         return true;
      }
   }

   private List<String> receiveListFromLegacyFile(String listFile) {
      ArrayList list = new ArrayList();

      try {
         BufferedReader fin = new BufferedReader(new InputStreamReader(new FileInputStream(this.dataFolderPath + File.separator + listFile), StandardCharsets.UTF_8));

         String line;
         try {
            while((line = fin.readLine()) != null && !line.equals("")) {
               list.add(line);
            }
         } catch (Throwable var8) {
            try {
               fin.close();
            } catch (Throwable var7) {
               var8.addSuppressed(var7);
            }

            throw var8;
         }

         fin.close();
      } catch (Exception var9) {
      }

      return list;
   }

   private File[] receiveObjectFiles(String folder, String extension) {
      return (new File(this.dataFolderPath + File.separator + folder)).listFiles((file) -> {
         return file.getName().toLowerCase(Locale.ROOT).endsWith(extension);
      });
   }

   public boolean loadResident(Resident resident) {
      boolean save = true;
      String line = null;
      String path = this.getResidentFilename(resident);
      File fileResident = new File(path);
      if (fileResident.exists() && fileResident.isFile()) {
         TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_resident", resident.getName()));

         boolean var7;
         try {
            HashMap<String, String> keys = FileMgmt.loadFileIntoHashMap(fileResident);
            line = (String)keys.get("lastOnline");
            if (line != null) {
               resident.setLastOnline(Long.parseLong(line));
            }

            line = (String)keys.get("uuid");
            if (line != null) {
               UUID uuid = UUID.fromString(line);
               if (this.universe.hasResident(uuid)) {
                  Resident olderRes = this.universe.getResident(uuid);
                  if (resident.getLastOnline() <= olderRes.getLastOnline()) {
                     TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_deleting_duplicate", resident.getName(), olderRes.getName()));

                     try {
                        this.universe.unregisterResident(resident);
                     } catch (NotRegisteredException var21) {
                     }

                     this.deleteResident(resident);
                     save = false;
                     boolean var34 = true;
                     return var34;
                  }

                  TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_deleting_duplicate", olderRes.getName(), resident.getName()));

                  try {
                     this.universe.unregisterResident(olderRes);
                  } catch (NotRegisteredException var26) {
                  }

                  Town olderResTown = olderRes.getTownOrNull();
                  if (olderResTown != null) {
                     try {
                        olderResTown.removeResident(olderRes);
                     } catch (EmptyTownException var25) {
                        try {
                           this.universe.unregisterTown(olderResTown);
                        } catch (NotRegisteredException var24) {
                        }

                        this.deleteTown(olderResTown);
                     }
                  }

                  this.deleteResident(olderRes);
               }

               resident.setUUID(uuid);
               this.universe.registerResidentUUID(resident);
            }

            line = (String)keys.get("about");
            if (line != null) {
               resident.setAbout(line);
            }

            line = (String)keys.get("registered");
            if (line != null) {
               resident.setRegistered(Long.parseLong(line));
            } else {
               resident.setRegistered(resident.getLastOnline());
            }

            line = (String)keys.get("isNPC");
            if (line != null) {
               resident.setNPC(Boolean.parseBoolean(line));
            }

            line = (String)keys.get("jail");
            if (line != null && this.universe.hasJail(UUID.fromString(line))) {
               resident.setJail(this.universe.getJail(UUID.fromString(line)));
            }

            if (resident.isJailed()) {
               line = (String)keys.get("jailCell");
               if (line != null) {
                  resident.setJailCell(Integer.parseInt(line));
               }

               line = (String)keys.get("jailHours");
               if (line != null) {
                  resident.setJailHours(Integer.parseInt(line));
               }

               line = (String)keys.get("jailBail");
               if (line != null) {
                  resident.setJailBailCost(Double.parseDouble(line));
               }
            }

            line = (String)keys.get("friends");
            if (line != null) {
               List<Resident> friends = TownyAPI.getInstance().getResidents(line.split(","));
               Iterator var32 = friends.iterator();

               while(var32.hasNext()) {
                  Resident friend = (Resident)var32.next();
                  resident.addFriend(friend);
               }
            }

            line = (String)keys.get("protectionStatus");
            if (line != null) {
               resident.setPermissions(line);
            }

            line = (String)keys.get("metadata");
            if (line != null && !line.isEmpty()) {
               MetadataLoader.getInstance().deserializeMetadata(resident, line.trim());
            }

            line = (String)keys.get("town");
            if (line == null) {
               return true;
            }

            Town town = null;
            if (this.universe.hasTown(line)) {
               town = this.universe.getTown(line);
            } else if (this.universe.getReplacementNameMap().containsKey(line)) {
               town = this.universe.getTown((String)this.universe.getReplacementNameMap().get(line));
            } else {
               TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_resident_tried_load_invalid_town", resident.getName(), line));
            }

            if (town != null) {
               resident.setTown(town, false);
               line = (String)keys.get("title");
               if (line != null) {
                  resident.setTitle(line);
               }

               line = (String)keys.get("surname");
               if (line != null) {
                  resident.setSurname(line);
               }

               try {
                  line = (String)keys.get("town-ranks");
                  if (line != null) {
                     resident.setTownRanks(Arrays.asList(line.split(",")));
                  }
               } catch (Exception var23) {
               }

               try {
                  line = (String)keys.get("nation-ranks");
                  if (line != null) {
                     resident.setNationRanks(Arrays.asList(line.split(",")));
                  }
               } catch (Exception var22) {
               }

               line = (String)keys.get("joinedTownAt");
               if (line != null) {
                  resident.setJoinedTownAt(Long.parseLong(line));
                  return true;
               }
            }

            return true;
         } catch (Exception var27) {
            this.plugin.getLogger().log(Level.WARNING, Translation.of("flatfile_err_reading_resident_at_line", resident.getName(), line, resident.getName()), var27);
            var7 = false;
         } finally {
            if (save) {
               this.saveResident(resident);
            }

         }

         return var7;
      } else {
         return false;
      }
   }

   public boolean loadTown(Town town) {
      String line = null;
      String path = this.getTownFilename(town);
      File fileTown = new File(path);
      if (fileTown.exists() && fileTown.isFile()) {
         TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_town", town.getName()));

         boolean var7;
         try {
            HashMap<String, String> keys = FileMgmt.loadFileIntoHashMap(fileTown);
            line = (String)keys.get("mayor");
            Resident res;
            if (line != null) {
               try {
                  res = this.universe.getResident(line);
                  if (res == null) {
                     throw new TownyException();
                  }

                  town.forceSetMayor(res);
               } catch (TownyException var97) {
                  if (town.getResidents().isEmpty()) {
                     this.removeTown(town, DeleteTownEvent.Cause.LOAD, (CommandSender)null, false);
                  } else {
                     town.findNewMayor();
                  }

                  boolean var8 = true;
                  return var8;
               }
            }

            line = (String)keys.get("outlaws");
            String[] tokens;
            int z;
            String[] jails;
            int x;
            if (line != null) {
               tokens = line.split(",");
               jails = tokens;
               x = tokens.length;

               for(z = 0; z < x; ++z) {
                  String token = jails[z];
                  if (!token.isEmpty()) {
                     TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_town_fetch_outlaw", token));
                     Resident outlaw = this.universe.getResident(token);
                     if (outlaw != null) {
                        try {
                           town.addOutlaw(outlaw);
                        } catch (AlreadyRegisteredException var96) {
                           TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_reading_outlaw_of_town_duplicate", town.getName(), token));
                        }
                     } else {
                        TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_reading_outlaw_of_town_not_exist", town.getName(), token));
                     }
                  }
               }
            }

            line = (String)keys.get("townBoard");
            if (line != null) {
               town.setBoard(line);
            }

            line = (String)keys.get("founder");
            if (line != null) {
               town.setFounder(line);
            }

            line = (String)keys.get("tag");
            if (line != null) {
               town.setTag(line);
            }

            line = (String)keys.get("protectionStatus");
            if (line != null) {
               town.setPermissions(line);
            }

            line = (String)keys.get("bonusBlocks");
            if (line != null) {
               try {
                  town.setBonusBlocks(Integer.parseInt(line));
               } catch (Exception var95) {
                  town.setBonusBlocks(0);
               }
            }

            line = (String)keys.get("purchasedBlocks");
            if (line != null) {
               try {
                  town.setPurchasedBlocks(Integer.parseInt(line));
               } catch (Exception var94) {
                  town.setPurchasedBlocks(0);
               }
            }

            line = (String)keys.get("plotPrice");
            if (line != null) {
               try {
                  town.setPlotPrice(Double.parseDouble(line));
               } catch (Exception var93) {
                  town.setPlotPrice(0.0D);
               }
            }

            line = (String)keys.get("hasUpkeep");
            if (line != null) {
               try {
                  town.setHasUpkeep(Boolean.parseBoolean(line));
               } catch (Exception var92) {
               }
            }

            line = (String)keys.get("hasUnlimitedClaims");
            if (line != null) {
               try {
                  town.setHasUnlimitedClaims(Boolean.parseBoolean(line));
               } catch (Exception var91) {
               }
            }

            line = (String)keys.get("visibleOnTopLists");
            if (line != null) {
               try {
                  town.setVisibleOnTopLists(Boolean.parseBoolean(line));
               } catch (Exception var90) {
               }
            }

            line = (String)keys.get("taxpercent");
            if (line != null) {
               try {
                  town.setTaxPercentage(Boolean.parseBoolean(line));
               } catch (Exception var89) {
               }
            }

            line = (String)keys.get("maxPercentTaxAmount");
            if (line != null) {
               town.setMaxPercentTaxAmount(Double.parseDouble(line));
            } else {
               town.setMaxPercentTaxAmount(TownySettings.getMaxTownTaxPercentAmount());
            }

            line = (String)keys.get("taxes");
            if (line != null) {
               try {
                  town.setTaxes(Double.parseDouble(line));
               } catch (Exception var88) {
                  town.setTaxes(0.0D);
               }
            }

            line = (String)keys.get("plotTax");
            if (line != null) {
               try {
                  town.setPlotTax(Double.parseDouble(line));
               } catch (Exception var87) {
                  town.setPlotTax(0.0D);
               }
            }

            line = (String)keys.get("commercialPlotPrice");
            if (line != null) {
               try {
                  town.setCommercialPlotPrice(Double.parseDouble(line));
               } catch (Exception var86) {
                  town.setCommercialPlotPrice(0.0D);
               }
            }

            line = (String)keys.get("commercialPlotTax");
            if (line != null) {
               try {
                  town.setCommercialPlotTax(Double.parseDouble(line));
               } catch (Exception var85) {
                  town.setCommercialPlotTax(0.0D);
               }
            }

            line = (String)keys.get("embassyPlotPrice");
            if (line != null) {
               try {
                  town.setEmbassyPlotPrice(Double.parseDouble(line));
               } catch (Exception var84) {
                  town.setEmbassyPlotPrice(0.0D);
               }
            }

            line = (String)keys.get("embassyPlotTax");
            if (line != null) {
               try {
                  town.setEmbassyPlotTax(Double.parseDouble(line));
               } catch (Exception var83) {
                  town.setEmbassyPlotTax(0.0D);
               }
            }

            line = (String)keys.get("spawnCost");
            if (line != null) {
               try {
                  town.setSpawnCost(Double.parseDouble(line));
               } catch (Exception var82) {
                  town.setSpawnCost(TownySettings.getSpawnTravelCost());
               }
            }

            line = (String)keys.get("adminDisabledPvP");
            if (line != null) {
               try {
                  town.setAdminDisabledPVP(Boolean.parseBoolean(line));
               } catch (Exception var81) {
               }
            }

            line = (String)keys.get("adminEnabledPvP");
            if (line != null) {
               try {
                  town.setAdminEnabledPVP(Boolean.parseBoolean(line));
               } catch (Exception var80) {
               }
            }

            line = (String)keys.get("adminEnabledMobs");
            if (line != null) {
               try {
                  town.setAdminEnabledMobs(Boolean.parseBoolean(line));
               } catch (Exception var79) {
               }
            }

            line = (String)keys.get("allowedToWar");
            if (line != null) {
               try {
                  town.setAllowedToWar(Boolean.parseBoolean(line));
               } catch (Exception var78) {
               }
            }

            line = (String)keys.get("open");
            if (line != null) {
               try {
                  town.setOpen(Boolean.parseBoolean(line));
               } catch (Exception var77) {
               }
            }

            line = (String)keys.get("public");
            if (line != null) {
               try {
                  town.setPublic(Boolean.parseBoolean(line));
               } catch (Exception var76) {
               }
            }

            line = (String)keys.get("forSale");
            if (line != null) {
               try {
                  town.setForSale(Boolean.parseBoolean(line));
               } catch (Exception var75) {
               }
            }

            line = (String)keys.get("forSalePrice");
            if (line != null) {
               try {
                  town.setForSalePrice(Double.parseDouble(line));
               } catch (Exception var74) {
               }
            }

            line = (String)keys.get("conquered");
            if (line != null) {
               try {
                  town.setConquered(Boolean.parseBoolean(line), false);
               } catch (Exception var73) {
               }
            }

            line = (String)keys.get("conqueredDays");
            if (line != null) {
               town.setConqueredDays(Integer.parseInt(line));
            }

            line = (String)keys.get("joinedNationAt");
            if (line != null) {
               try {
                  town.setJoinedNationAt(Long.parseLong(line));
               } catch (Exception var72) {
               }
            }

            line = (String)keys.get("movedHomeBlockAt");
            if (line != null) {
               try {
                  town.setMovedHomeBlockAt(Long.parseLong(line));
               } catch (Exception var71) {
               }
            }

            line = (String)keys.get("homeBlock");
            if (line != null) {
               tokens = line.split(",");
               if (tokens.length == 3) {
                  TownyWorld world = this.universe.getWorld(tokens[0]);
                  if (world == null) {
                     TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_homeblock_load_invalid_world", town.getName()));
                  } else {
                     try {
                        x = Integer.parseInt(tokens[1]);
                        z = Integer.parseInt(tokens[2]);
                        TownBlock homeBlock = this.universe.getTownBlock(new WorldCoord(world.getName(), x, z));
                        town.forceSetHomeBlock(homeBlock);
                     } catch (NumberFormatException var68) {
                        TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_homeblock_load_invalid_location", town.getName()));
                     } catch (NotRegisteredException var69) {
                        TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_homeblock_load_invalid_townblock", town.getName()));
                     } catch (TownyException var70) {
                        TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_town_homeblock_not_exist", town.getName()));
                     }
                  }
               }
            }

            line = (String)keys.get("spawn");
            Logger var10000;
            String var10001;
            if (line != null) {
               tokens = line.split(",");
               if (tokens.length >= 4) {
                  try {
                     town.spawnPosition(Position.deserialize(tokens));
                  } catch (IllegalArgumentException var67) {
                     var10000 = this.plugin.getLogger();
                     var10001 = town.getName();
                     var10000.warning("Failed to load spawn location for town " + var10001 + ": " + var67.getMessage());
                  }
               }
            }

            line = (String)keys.get("outpostspawns");
            String[] var104;
            int var109;
            String spawn;
            if (line != null) {
               jails = line.split(";");
               var104 = jails;
               z = jails.length;

               for(var109 = 0; var109 < z; ++var109) {
                  spawn = var104[var109];
                  tokens = spawn.split(",");
                  if (tokens.length >= 4) {
                     try {
                        town.forceAddOutpostSpawn(Position.deserialize(tokens));
                     } catch (IllegalArgumentException var66) {
                        var10000 = this.plugin.getLogger();
                        var10001 = town.getName();
                        var10000.warning("Failed to load an outpost spawn location for town " + var10001 + ": " + var66.getMessage());
                     }
                  }
               }
            }

            line = (String)keys.get("jailspawns");
            if (line != null) {
               jails = line.split(";");
               var104 = jails;
               z = jails.length;

               for(var109 = 0; var109 < z; ++var109) {
                  spawn = var104[var109];
                  tokens = spawn.split(",");
                  if (tokens.length >= 4) {
                     try {
                        Position position = Position.deserialize(tokens);
                        TownBlock tb = this.universe.getTownBlockOrNull(position.worldCoord());
                        if (tb != null) {
                           Jail jail = new Jail(UUID.randomUUID(), town, tb, Collections.singleton(position));
                           this.universe.registerJail(jail);
                           town.addJail(jail);
                           tb.setJail(jail);
                           jail.save();
                        }
                     } catch (IllegalArgumentException var65) {
                        var10000 = this.plugin.getLogger();
                        var10001 = town.getName();
                        var10000.warning("Failed to load a legacy jail spawn location for town " + var10001 + ": " + var65.getMessage());
                     }
                  }
               }
            }

            line = (String)keys.get("uuid");
            UUID uuid;
            if (line != null) {
               res = null;

               try {
                  uuid = UUID.fromString(line);
               } catch (IllegalArgumentException var64) {
                  uuid = UUID.randomUUID();
               }

               town.setUUID(uuid);
               this.universe.registerTownUUID(town);
            }

            line = (String)keys.get("registered");
            if (line != null) {
               try {
                  town.setRegistered(Long.parseLong(line));
               } catch (Exception var63) {
                  town.setRegistered(0L);
               }
            }

            line = (String)keys.get("metadata");
            if (line != null && !line.isEmpty()) {
               MetadataLoader.getInstance().deserializeMetadata(town, line.trim());
            }

            line = (String)keys.get("manualTownLevel");
            if (line != null) {
               town.setManualTownLevel(Integer.parseInt(line));
            }

            line = (String)keys.get("nation");
            if (line != null && !line.isEmpty()) {
               Nation nation = null;
               if (this.universe.hasNation(line)) {
                  nation = this.universe.getNation(line);
               } else if (this.universe.getReplacementNameMap().containsKey(line)) {
                  nation = this.universe.getNation((String)this.universe.getReplacementNameMap().get(line));
               }

               if (nation != null) {
                  town.setNation(nation, false);
               }
            }

            line = (String)keys.get("ruined");
            if (line != null) {
               try {
                  town.setRuined(Boolean.parseBoolean(line));
               } catch (Exception var62) {
                  town.setRuined(false);
               }
            }

            line = (String)keys.get("ruinedTime");
            if (line != null) {
               try {
                  town.setRuinedTime(Long.parseLong(line));
               } catch (Exception var61) {
                  town.setRuinedTime(0L);
               }
            }

            line = (String)keys.get("neutral");
            if (line != null) {
               town.setNeutral(Boolean.parseBoolean(line));
            }

            line = (String)keys.get("debtBalance");
            if (line != null) {
               try {
                  town.setDebtBalance(Double.parseDouble(line));
               } catch (Exception var60) {
                  town.setDebtBalance(0.0D);
               }
            }

            line = (String)keys.get("primaryJail");
            if (line != null) {
               uuid = UUID.fromString(line);
               if (this.universe.hasJail(uuid)) {
                  town.setPrimaryJail(this.universe.getJail(uuid));
               }
            }

            line = (String)keys.get("trustedResidents");
            if (line != null && !line.isEmpty()) {
               Iterator var111 = TownyAPI.getInstance().getResidents(this.toUUIDArray(line.split(","))).iterator();

               while(var111.hasNext()) {
                  Resident resident = (Resident)var111.next();
                  town.addTrustedResident(resident);
               }
            }

            line = (String)keys.get("trustedTowns");
            List uuids;
            if (line != null && !line.isEmpty()) {
               uuids = (List)Arrays.stream(line.split(",")).map(UUID::fromString).collect(Collectors.toList());
               town.loadTrustedTowns(TownyAPI.getInstance().getTowns(uuids));
            }

            line = (String)keys.get("mapColorHexCode");
            if (line != null) {
               try {
                  town.setMapColorHexCode(line);
               } catch (Exception var59) {
                  town.setMapColorHexCode(MapUtil.generateRandomTownColourAsHexCode());
               }
            } else {
               town.setMapColorHexCode(MapUtil.generateRandomTownColourAsHexCode());
            }

            line = (String)keys.get("nationZoneOverride");
            if (line != null) {
               try {
                  town.setNationZoneOverride(Integer.parseInt(line));
               } catch (Exception var58) {
               }
            }

            line = (String)keys.get("nationZoneEnabled");
            if (line != null) {
               town.setNationZoneEnabled(Boolean.parseBoolean(line));
            }

            line = (String)keys.get("allies");
            if (line != null && !line.isEmpty()) {
               uuids = (List)Arrays.stream(line.split(",")).map((uuidx) -> {
                  return UUID.fromString(uuidx);
               }).collect(Collectors.toList());
               town.loadAllies(TownyAPI.getInstance().getTowns(uuids));
            }

            line = (String)keys.get("enemies");
            if (line != null && !line.isEmpty()) {
               uuids = (List)Arrays.stream(line.split(",")).map((uuidx) -> {
                  return UUID.fromString(uuidx);
               }).collect(Collectors.toList());
               town.loadEnemies(TownyAPI.getInstance().getTowns(uuids));
            }

            return true;
         } catch (Exception var98) {
            this.plugin.getLogger().log(Level.WARNING, Translation.of("flatfile_err_reading_town_file_at_line", town.getName(), line, town.getName()), var98);
            var7 = false;
         } finally {
            if (town.exists()) {
               this.saveTown(town);
            }

         }

         return var7;
      } else {
         return false;
      }
   }

   public boolean loadNation(Nation nation) {
      String line = "";
      String path = this.getNationFilename(nation);
      File fileNation = new File(path);
      if (fileNation.exists() && fileNation.isFile()) {
         TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_nation", nation.getName()));

         try {
            HashMap<String, String> keys = FileMgmt.loadFileIntoHashMap(fileNation);
            line = (String)keys.get("capital");
            String cantLoadCapital = Translation.of("flatfile_err_nation_could_not_load_capital_disband", nation.getName());
            if (line != null) {
               Town town = this.universe.getTown(line);
               if (town != null) {
                  try {
                     nation.forceSetCapital(town);
                  } catch (EmptyNationException var35) {
                     this.plugin.getLogger().warning(cantLoadCapital);
                     this.removeNation(nation, DeleteNationEvent.Cause.LOAD);
                     boolean var10 = true;
                     return var10;
                  }
               } else {
                  TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_cannot_set_capital_try_next", nation.getName(), line));
                  if (!nation.findNewCapital()) {
                     this.plugin.getLogger().warning(cantLoadCapital);
                     this.removeNation(nation, DeleteNationEvent.Cause.LOAD);
                     boolean var9 = true;
                     return var9;
                  }
               }
            } else {
               TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_undefined_capital_select_new", nation.getName()));
               if (!nation.findNewCapital()) {
                  this.plugin.getLogger().warning(cantLoadCapital);
                  this.removeNation(nation, DeleteNationEvent.Cause.LOAD);
                  boolean var40 = true;
                  return var40;
               }
            }

            line = (String)keys.get("nationBoard");
            if (line != null) {
               try {
                  nation.setBoard(line);
               } catch (Exception var34) {
                  nation.setBoard("");
               }
            }

            line = (String)keys.get("mapColorHexCode");
            if (line != null) {
               try {
                  nation.setMapColorHexCode(line);
               } catch (Exception var33) {
                  nation.setMapColorHexCode(MapUtil.generateRandomNationColourAsHexCode());
               }
            } else {
               nation.setMapColorHexCode(MapUtil.generateRandomNationColourAsHexCode());
            }

            line = (String)keys.get("tag");
            if (line != null) {
               nation.setTag(line);
            }

            line = (String)keys.get("allies");
            List enemies;
            Iterator var41;
            Nation enemy;
            if (line != null) {
               enemies = TownyAPI.getInstance().getNations(line.split(","));
               var41 = enemies.iterator();

               while(var41.hasNext()) {
                  enemy = (Nation)var41.next();
                  nation.addAlly(enemy);
               }
            }

            line = (String)keys.get("enemies");
            if (line != null) {
               enemies = TownyAPI.getInstance().getNations(line.split(","));
               var41 = enemies.iterator();

               while(var41.hasNext()) {
                  enemy = (Nation)var41.next();
                  nation.addEnemy(enemy);
               }
            }

            line = (String)keys.get("spawnCost");
            if (line != null) {
               try {
                  nation.setSpawnCost(Double.parseDouble(line));
               } catch (Exception var32) {
                  nation.setSpawnCost(TownySettings.getSpawnTravelCost());
               }
            }

            line = (String)keys.get("neutral");
            if (line != null) {
               nation.setNeutral(Boolean.parseBoolean(line));
            }

            line = (String)keys.get("uuid");
            if (line != null) {
               try {
                  nation.setUUID(UUID.fromString(line));
               } catch (IllegalArgumentException var31) {
                  nation.setUUID(UUID.randomUUID());
               }

               this.universe.registerNationUUID(nation);
            }

            line = (String)keys.get("registered");
            if (line != null) {
               try {
                  nation.setRegistered(Long.parseLong(line));
               } catch (Exception var30) {
                  nation.setRegistered(0L);
               }
            }

            line = (String)keys.get("nationSpawn");
            if (line != null) {
               String[] tokens = line.split(",");
               if (tokens.length >= 4) {
                  try {
                     nation.spawnPosition(Position.deserialize(tokens));
                  } catch (IllegalArgumentException var29) {
                     Logger var10000 = this.plugin.getLogger();
                     String var10001 = nation.getName();
                     var10000.warning("Failed to load nation spawn location for nation " + var10001 + ": " + var29.getMessage());
                  }
               }
            }

            line = (String)keys.get("isPublic");
            if (line != null) {
               try {
                  nation.setPublic(Boolean.parseBoolean(line));
               } catch (Exception var28) {
               }
            }

            line = (String)keys.get("isOpen");
            if (line != null) {
               try {
                  nation.setOpen(Boolean.parseBoolean(line));
               } catch (Exception var27) {
               }
            }

            line = (String)keys.get("taxpercent");
            if (line != null) {
               try {
                  nation.setTaxPercentage(Boolean.parseBoolean(line));
               } catch (Exception var26) {
               }
            }

            line = (String)keys.get("maxPercentTaxAmount");
            if (line != null) {
               nation.setMaxPercentTaxAmount(Double.parseDouble(line));
            } else {
               nation.setMaxPercentTaxAmount(TownySettings.getMaxNationTaxPercentAmount());
            }

            line = (String)keys.get("taxes");
            if (line != null) {
               try {
                  nation.setTaxes(Double.parseDouble(line));
               } catch (Exception var25) {
                  nation.setTaxes(0.0D);
               }
            }

            line = (String)keys.get("metadata");
            if (line != null && !line.isEmpty()) {
               MetadataLoader.getInstance().deserializeMetadata(nation, line.trim());
            }

            line = (String)keys.get("conqueredTax");
            if (line != null && !line.isEmpty()) {
               nation.setConqueredTax(Double.parseDouble(line));
            }

            line = (String)keys.get("sanctionedTowns");
            if (line != null) {
               nation.loadSanctionedTowns(line.split("#"));
            }

            return true;
         } catch (Exception var36) {
            this.plugin.getLogger().log(Level.WARNING, Translation.of("flatfile_err_reading_nation_file_at_line", nation.getName(), line, nation.getName()), var36);
            boolean var7 = false;
            return var7;
         } finally {
            this.saveNation(nation);
         }
      } else {
         return false;
      }
   }

   public boolean loadWorld(TownyWorld world) {
      String line = "";
      String path = this.getWorldFilename(world);
      if (!FileMgmt.checkOrCreateFile(path)) {
         TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_exception_reading_file", path));
      }

      File fileWorld = new File(path);
      if (fileWorld.exists() && fileWorld.isFile()) {
         TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_loading_world", world.getName()));

         boolean var6;
         try {
            HashMap<String, String> keys = FileMgmt.loadFileIntoHashMap(fileWorld);
            line = (String)keys.get("uuid");
            if (line != null && !line.isEmpty()) {
               try {
                  world.setUUID(UUID.fromString(line));
               } catch (IllegalArgumentException var90) {
               }
            }

            line = (String)keys.get("claimable");
            if (line != null) {
               try {
                  world.setClaimable(Boolean.parseBoolean(line));
               } catch (Exception var89) {
               }
            }

            line = (String)keys.get("pvp");
            if (line != null) {
               try {
                  world.setPVP(Boolean.parseBoolean(line));
               } catch (Exception var88) {
               }
            }

            line = (String)keys.get("forcepvp");
            if (line != null) {
               try {
                  world.setForcePVP(Boolean.parseBoolean(line));
               } catch (Exception var87) {
               }
            }

            line = (String)keys.get("friendlyFire");
            if (line != null) {
               try {
                  world.setFriendlyFire(Boolean.parseBoolean(line));
               } catch (Exception var86) {
               }
            }

            line = (String)keys.get("forcetownmobs");
            if (line != null) {
               try {
                  world.setForceTownMobs(Boolean.parseBoolean(line));
               } catch (Exception var85) {
               }
            }

            line = (String)keys.get("wildernessmobs");
            if (line != null) {
               try {
                  world.setWildernessMobs(Boolean.parseBoolean(line));
               } catch (Exception var84) {
               }
            }

            line = (String)keys.get("worldmobs");
            if (line != null) {
               try {
                  world.setWorldMobs(Boolean.parseBoolean(line));
               } catch (Exception var83) {
               }
            }

            line = (String)keys.get("firespread");
            if (line != null) {
               try {
                  world.setFire(Boolean.parseBoolean(line));
               } catch (Exception var82) {
               }
            }

            line = (String)keys.get("forcefirespread");
            if (line != null) {
               try {
                  world.setForceFire(Boolean.parseBoolean(line));
               } catch (Exception var81) {
               }
            }

            line = (String)keys.get("explosions");
            if (line != null) {
               try {
                  world.setExpl(Boolean.parseBoolean(line));
               } catch (Exception var80) {
               }
            }

            line = (String)keys.get("forceexplosions");
            if (line != null) {
               try {
                  world.setForceExpl(Boolean.parseBoolean(line));
               } catch (Exception var79) {
               }
            }

            line = (String)keys.get("endermanprotect");
            if (line != null) {
               try {
                  world.setEndermanProtect(Boolean.parseBoolean(line));
               } catch (Exception var78) {
               }
            }

            line = (String)keys.get("disablecreaturetrample");
            if (line != null) {
               try {
                  world.setDisableCreatureTrample(Boolean.parseBoolean(line));
               } catch (Exception var77) {
               }
            }

            line = (String)keys.get("unclaimedZoneBuild");
            if (line != null) {
               try {
                  world.setUnclaimedZoneBuild(Boolean.parseBoolean(line));
               } catch (Exception var76) {
               }
            }

            line = (String)keys.get("unclaimedZoneDestroy");
            if (line != null) {
               try {
                  world.setUnclaimedZoneDestroy(Boolean.parseBoolean(line));
               } catch (Exception var75) {
               }
            }

            line = (String)keys.get("unclaimedZoneSwitch");
            if (line != null) {
               try {
                  world.setUnclaimedZoneSwitch(Boolean.parseBoolean(line));
               } catch (Exception var74) {
               }
            }

            line = (String)keys.get("unclaimedZoneItemUse");
            if (line != null) {
               try {
                  world.setUnclaimedZoneItemUse(Boolean.parseBoolean(line));
               } catch (Exception var73) {
               }
            }

            line = (String)keys.get("unclaimedZoneName");
            if (line != null) {
               try {
                  world.setUnclaimedZoneName(line);
               } catch (Exception var72) {
               }
            }

            line = (String)keys.get("unclaimedZoneIgnoreIds");
            ArrayList mats;
            String[] var7;
            int var8;
            int var9;
            String s;
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        mats.add(s);
                     }
                  }

                  world.setUnclaimedZoneIgnore(mats);
               } catch (Exception var91) {
               }
            }

            line = (String)keys.get("isDeletingEntitiesOnUnclaim");
            if (line != null) {
               try {
                  world.setDeletingEntitiesOnUnclaim(Boolean.parseBoolean(line));
               } catch (Exception var71) {
               }
            }

            line = (String)keys.get("unclaimDeleteEntityTypes");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        mats.add(s);
                     }
                  }

                  world.setUnclaimDeleteEntityTypes(mats);
               } catch (Exception var92) {
               }
            }

            line = (String)keys.get("usingPlotManagementDelete");
            if (line != null) {
               try {
                  world.setUsingPlotManagementDelete(Boolean.parseBoolean(line));
               } catch (Exception var70) {
               }
            }

            line = (String)keys.get("plotManagementDeleteIds");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        mats.add(s);
                     }
                  }

                  world.setPlotManagementDeleteIds(mats);
               } catch (Exception var93) {
               }
            }

            line = (String)keys.get("usingPlotManagementMayorDelete");
            if (line != null) {
               try {
                  world.setUsingPlotManagementMayorDelete(Boolean.parseBoolean(line));
               } catch (Exception var69) {
               }
            }

            line = (String)keys.get("plotManagementMayorDelete");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        try {
                           mats.add(s.toUpperCase().trim());
                        } catch (NumberFormatException var68) {
                        }
                     }
                  }

                  world.setPlotManagementMayorDelete(mats);
               } catch (Exception var94) {
               }
            }

            line = (String)keys.get("usingPlotManagementRevert");
            if (line != null) {
               try {
                  world.setUsingPlotManagementRevert(Boolean.parseBoolean(line));
               } catch (Exception var67) {
               }
            }

            line = (String)keys.get("plotManagementIgnoreIds");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        mats.add(s);
                     }
                  }

                  world.setPlotManagementIgnoreIds(mats);
               } catch (Exception var95) {
               }
            }

            line = (String)keys.get("revertOnUnclaimWhitelistMaterials");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split("#");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        mats.add(s);
                     }
                  }

                  world.setRevertOnUnclaimWhitelistMaterials(mats);
               } catch (Exception var96) {
               }
            }

            line = (String)keys.get("usingPlotManagementWildRegen");
            if (line != null) {
               try {
                  world.setUsingPlotManagementWildEntityRevert(Boolean.parseBoolean(line));
               } catch (Exception var66) {
               }
            }

            line = (String)keys.get("PlotManagementWildRegenEntities");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        try {
                           mats.add(s.trim());
                        } catch (NumberFormatException var65) {
                        }
                     }
                  }

                  world.setPlotManagementWildRevertEntities(mats);
               } catch (Exception var97) {
               }
            }

            line = (String)keys.get("PlotManagementWildRegenBlockWhitelist");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        try {
                           mats.add(s.trim());
                        } catch (NumberFormatException var64) {
                        }
                     }
                  }

                  world.setPlotManagementWildRevertBlockWhitelist(mats);
               } catch (Exception var98) {
               }
            }

            line = (String)keys.get("wildRegenBlocksToNotOverwrite");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        try {
                           mats.add(s.trim());
                        } catch (NumberFormatException var63) {
                        }
                     }
                  }

                  world.setWildRevertMaterialsToNotOverwrite(mats);
               } catch (Exception var99) {
               }
            }

            line = (String)keys.get("usingPlotManagementWildRegenDelay");
            if (line != null) {
               try {
                  world.setPlotManagementWildRevertDelay(Long.parseLong(line));
               } catch (Exception var62) {
               }
            }

            line = (String)keys.get("usingPlotManagementWildRegenBlocks");
            if (line != null) {
               try {
                  world.setUsingPlotManagementWildBlockRevert(Boolean.parseBoolean(line));
               } catch (Exception var61) {
               }
            }

            line = (String)keys.get("PlotManagementWildRegenBlocks");
            if (line != null) {
               try {
                  mats = new ArrayList();
                  var7 = line.split(",");
                  var8 = var7.length;

                  for(var9 = 0; var9 < var8; ++var9) {
                     s = var7[var9];
                     if (!s.isEmpty()) {
                        try {
                           mats.add(s.trim());
                        } catch (NumberFormatException var60) {
                        }
                     }
                  }

                  world.setPlotManagementWildRevertMaterials(mats);
               } catch (Exception var100) {
               }
            }

            line = (String)keys.get("usingTowny");
            if (line != null) {
               try {
                  world.setUsingTowny(Boolean.parseBoolean(line));
               } catch (Exception var59) {
               }
            }

            line = (String)keys.get("warAllowed");
            if (line != null) {
               try {
                  world.setWarAllowed(Boolean.parseBoolean(line));
               } catch (Exception var58) {
               }
            }

            line = (String)keys.get("metadata");
            if (line != null && !line.isEmpty()) {
               MetadataLoader.getInstance().deserializeMetadata(world, line.trim());
            }

            return true;
         } catch (Exception var101) {
            TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_exception_reading_world_file_at_line", path, line, world.getName()));
            var6 = false;
         } finally {
            this.saveWorld(world);
         }

         return var6;
      } else {
         TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_file_error_reading_world_file_at_line", world.getName(), line, world.getName()));
         return false;
      }
   }

   public boolean loadPlotGroup(PlotGroup group) {
      String line = "";
      String path = this.getPlotGroupFilename(group);
      File groupFile = new File(path);
      if (groupFile.exists() && groupFile.isFile()) {
         try {
            HashMap<String, String> keys = FileMgmt.loadFileIntoHashMap(groupFile);
            line = (String)keys.get("groupName");
            if (line != null) {
               group.setName(line.trim());
            }

            line = (String)keys.get("town");
            if (line != null && !line.isEmpty()) {
               Town town = this.universe.getTown(line.trim());
               if (town == null) {
                  TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_group_file_missing_town_delete", path));
                  this.deletePlotGroup(group);
                  TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_missing_file_delete_group_entry", path));
                  return true;
               }

               group.setTown(town);
            } else {
               TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_could_not_add_to_town"));
               this.deletePlotGroup(group);
            }

            line = (String)keys.get("groupPrice");
            if (line != null && !line.isEmpty()) {
               group.setPrice(Double.parseDouble(line.trim()));
            }

            line = (String)keys.get("metadata");
            if (line != null) {
               MetadataLoader.getInstance().deserializeMetadata(group, line.trim());
            }
         } catch (Exception var7) {
            TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_exception_reading_group_file_at_line", path, line));
            return false;
         }
      } else {
         TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_missing_file_delete_groups_entry", path));
      }

      return true;
   }

   public boolean loadDistrict(District district) {
      String line = "";
      String path = this.getDistrictFilename(district);
      File districtFile = new File(path);
      if (districtFile.exists() && districtFile.isFile()) {
         try {
            HashMap<String, String> keys = FileMgmt.loadFileIntoHashMap(districtFile);
            line = (String)keys.get("districtName");
            if (line != null) {
               district.setName(line.trim());
            }

            line = (String)keys.get("town");
            if (line != null && !line.isEmpty()) {
               UUID uuid = UUID.fromString(line.trim());
               if (uuid == null) {
                  TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_missing_file_delete_district_entry", path));
                  this.deleteDistrict(district);
                  return true;
               }

               Town town = this.universe.getTown(uuid);
               if (town == null) {
                  TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_district_file_missing_town_delete", path));
                  this.deleteDistrict(district);
                  TownyMessaging.sendDebugMsg(Translation.of("flatfile_dbg_missing_file_delete_district_entry", path));
                  return true;
               }

               district.setTown(town);
            } else {
               TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_could_not_add_to_town"));
               this.deleteDistrict(district);
            }

            line = (String)keys.get("metadata");
            if (line != null) {
               MetadataLoader.getInstance().deserializeMetadata(district, line.trim());
            }
         } catch (Exception var8) {
            TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_exception_reading_district_file_at_line", path, line));
            return false;
         }
      }

      return true;
   }

   public boolean loadTownBlocks() {
      String line = "";
      List<TownBlock> toSave = new ArrayList();
      Iterator var4 = this.universe.getTownBlocks().values().iterator();

      while(true) {
         while(var4.hasNext()) {
            TownBlock townBlock = (TownBlock)var4.next();
            String path = this.getTownBlockFilename(townBlock);
            File fileTownBlock = new File(path);
            if (fileTownBlock.exists() && fileTownBlock.isFile()) {
               try {
                  HashMap<String, String> keys = FileMgmt.loadFileIntoHashMap(fileTownBlock);
                  line = (String)keys.get("town");
                  if (line == null) {
                     TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_townblock_file_missing_town_delete", path));
                     this.universe.removeTownBlock(townBlock);
                     this.deleteTownBlock(townBlock);
                  } else if (line.isEmpty()) {
                     TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_townblock_file_missing_town_delete", path));
                     this.universe.removeTownBlock(townBlock);
                     this.deleteTownBlock(townBlock);
                  } else {
                     Town town = null;
                     if (this.universe.hasTown(line.trim())) {
                        town = this.universe.getTown(line.trim());
                     } else if (this.universe.getReplacementNameMap().containsKey(line.trim())) {
                        town = this.universe.getTown((String)this.universe.getReplacementNameMap().get(line.trim()));
                        toSave.add(townBlock);
                     }

                     if (town == null) {
                        TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_townblock_file_contains_unregistered_town_delete", line, path));
                        this.universe.removeTownBlock(townBlock);
                        this.deleteTownBlock(townBlock);
                     } else {
                        townBlock.setTown(town, false);

                        try {
                           town.addTownBlock(townBlock);
                           TownyWorld townyWorld = townBlock.getWorld();
                           if (townyWorld != null && !townyWorld.hasTown(town)) {
                              townyWorld.addTown(town);
                           }
                        } catch (AlreadyRegisteredException var22) {
                        }

                        line = (String)keys.get("name");
                        if (line != null) {
                           try {
                              townBlock.setName(line.trim());
                           } catch (Exception var21) {
                           }
                        }

                        line = (String)keys.get("resident");
                        if (line != null && !line.isEmpty()) {
                           Resident res = this.universe.getResident(line.trim());
                           if (res != null) {
                              townBlock.setResident(res, false);
                           } else {
                              TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_invalid_townblock_resident", townBlock.toString()));
                           }
                        }

                        line = (String)keys.get("type");
                        if (line != null) {
                           townBlock.setType(TownBlockTypeHandler.getTypeInternal(line));
                        }

                        line = (String)keys.get("price");
                        if (line != null) {
                           try {
                              townBlock.setPlotPrice(Double.parseDouble(line.trim()));
                           } catch (Exception var20) {
                           }
                        }

                        line = (String)keys.get("taxed");
                        if (line != null) {
                           try {
                              townBlock.setTaxed(Boolean.parseBoolean(line));
                           } catch (Exception var19) {
                           }
                        }

                        line = (String)keys.get("outpost");
                        if (line != null) {
                           try {
                              townBlock.setOutpost(Boolean.parseBoolean(line));
                           } catch (Exception var18) {
                           }
                        }

                        line = (String)keys.get("permissions");
                        if (line != null && !line.isEmpty()) {
                           try {
                              townBlock.setPermissions(line.trim());
                           } catch (Exception var17) {
                           }
                        }

                        line = (String)keys.get("changed");
                        if (line != null) {
                           try {
                              townBlock.setChanged(Boolean.parseBoolean(line.trim()));
                           } catch (Exception var16) {
                           }
                        }

                        line = (String)keys.get("claimedAt");
                        if (line != null) {
                           try {
                              townBlock.setClaimedAt(Long.parseLong(line));
                           } catch (Exception var15) {
                           }
                        }

                        line = (String)keys.get("minTownMembershipDays");
                        if (line != null && !line.isEmpty()) {
                           townBlock.setMinTownMembershipDays(Integer.valueOf(line));
                        }

                        line = (String)keys.get("maxTownMembershipDays");
                        if (line != null && !line.isEmpty()) {
                           townBlock.setMaxTownMembershipDays(Integer.valueOf(line));
                        }

                        line = (String)keys.get("metadata");
                        if (line != null && !line.isEmpty()) {
                           MetadataLoader.getInstance().deserializeMetadata(townBlock, line.trim());
                        }

                        line = (String)keys.get("groupID");
                        UUID groupID = null;
                        if (line != null && !line.isEmpty()) {
                           groupID = UUID.fromString(line.trim());
                        }

                        if (groupID != null) {
                           PlotGroup group = this.universe.getGroup(groupID);
                           if (group != null) {
                              townBlock.setPlotObjectGroup(group);
                              if (group.getPermissions() == null && townBlock.getPermissions() != null) {
                                 group.setPermissions(townBlock.getPermissions());
                              }

                              if (townBlock.hasResident()) {
                                 group.setResident(townBlock.getResidentOrNull());
                              }
                           } else {
                              townBlock.removePlotObjectGroup();
                           }
                        }

                        line = (String)keys.get("districtID");
                        UUID districtID = null;
                        if (line != null && !line.isEmpty()) {
                           districtID = UUID.fromString(line.trim());
                        }

                        if (districtID != null) {
                           District district = this.universe.getDistrict(districtID);
                           if (district != null) {
                              townBlock.setDistrict(district);
                           } else {
                              townBlock.removeDistrict();
                           }
                        }

                        line = (String)keys.get("trustedResidents");
                        if (line != null && !line.isEmpty() && townBlock.getTrustedResidents().isEmpty()) {
                           Iterator var29 = TownyAPI.getInstance().getResidents(this.toUUIDArray(line.split(","))).iterator();

                           while(var29.hasNext()) {
                              Resident resident = (Resident)var29.next();
                              townBlock.addTrustedResident(resident);
                           }

                           if (townBlock.hasPlotObjectGroup() && townBlock.getPlotObjectGroup().getTrustedResidents().isEmpty() && townBlock.getTrustedResidents().size() > 0) {
                              townBlock.getPlotObjectGroup().setTrustedResidents(townBlock.getTrustedResidents());
                           }
                        }

                        line = (String)keys.get("customPermissionData");
                        if (line != null && !line.isEmpty() && townBlock.getPermissionOverrides().isEmpty()) {
                           Map<String, String> map = (Map)(new Gson()).fromJson(line, Map.class);
                           Iterator var31 = map.entrySet().iterator();

                           while(var31.hasNext()) {
                              Entry entry = (Entry)var31.next();

                              Resident resident;
                              try {
                                 resident = TownyAPI.getInstance().getResident(UUID.fromString((String)entry.getKey()));
                              } catch (IllegalArgumentException var23) {
                                 continue;
                              }

                              if (resident != null) {
                                 townBlock.getPermissionOverrides().put(resident, new PermissionData((String)entry.getValue()));
                              }
                           }

                           if (townBlock.hasPlotObjectGroup() && townBlock.getPlotObjectGroup().getPermissionOverrides().isEmpty() && townBlock.getPermissionOverrides().size() > 0) {
                              townBlock.getPlotObjectGroup().setPermissionOverrides(townBlock.getPermissionOverrides());
                           }
                        }
                     }
                  }
               } catch (Exception var24) {
                  TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_exception_reading_townblock_file_at_line", path, line));
                  return false;
               }
            } else {
               TownyMessaging.sendErrorMsg(Translation.of("flatfile_err_townblock_file_unknown_err", path));
               this.universe.removeTownBlock(townBlock);
               this.deleteTownBlock(townBlock);
            }
         }

         if (!toSave.isEmpty()) {
            toSave.forEach(TownBlock::save);
         }

         return true;
      }
   }

   public boolean loadJail(Jail jail) {
      String line = "";
      String path = this.getJailFilename(jail);
      File jailFile = new File(path);
      if (jailFile.exists() && jailFile.isFile()) {
         HashMap<String, String> keys = FileMgmt.loadFileIntoHashMap(jailFile);
         line = (String)keys.get("townblock");
         String[] tokens;
         UUID var10000;
         if (line != null) {
            tokens = line.split(",");
            WorldCoord wc = null;

            try {
               wc = new WorldCoord(tokens[0], Integer.parseInt(tokens[1].trim()), Integer.parseInt(tokens[2].trim()));
               if (wc.isWilderness() || wc.getTownOrNull() == null) {
                  throw new NumberFormatException();
               }
            } catch (NumberFormatException var14) {
               var10000 = jail.getUUID();
               TownyMessaging.sendErrorMsg("Jail " + var10000 + " tried to load invalid townblock " + line + " deleting jail.");
               this.removeJail(jail);
               this.deleteJail(jail);
               return true;
            }

            TownBlock tb = wc.getTownBlockOrNull();
            Town town = tb.getTownOrNull();
            jail.setTownBlock(tb);
            jail.setTown(town);
            tb.setJail(jail);
            town.addJail(jail);
         }

         line = (String)keys.get("spawns");
         if (line != null) {
            String[] jails = line.split(";");
            String[] var16 = jails;
            int var17 = jails.length;

            for(int var10 = 0; var10 < var17; ++var10) {
               String spawn = var16[var10];
               tokens = spawn.split(",");
               if (tokens.length >= 4) {
                  try {
                     jail.addJailCell(Position.deserialize(tokens));
                  } catch (IllegalArgumentException var13) {
                     var10000 = jail.getUUID();
                     TownyMessaging.sendErrorMsg("Jail " + var10000 + " tried to load invalid spawn " + line + " skipping.");
                  }
               }
            }

            if (jail.getJailCellCount() == 0) {
               var10000 = jail.getUUID();
               TownyMessaging.sendErrorMsg("Jail " + var10000 + " loaded with zero spawns " + line + " deleting jail.");
               this.removeJail(jail);
               this.deleteJail(jail);
               return true;
            }
         }
      }

      return true;
   }

   public boolean saveResident(Resident resident) {
      List<String> list = new ArrayList();
      if (resident.hasUUID()) {
         list.add("uuid=" + resident.getUUID());
      }

      list.add("lastOnline=" + resident.getLastOnline());
      list.add("registered=" + resident.getRegistered());
      list.add("joinedTownAt=" + resident.getJoinedTownAt());
      list.add("isNPC=" + resident.isNPC());
      if (resident.isJailed()) {
         list.add("jail=" + resident.getJail().getUUID());
         list.add("jailCell=" + resident.getJailCell());
         list.add("jailHours=" + resident.getJailHours());
         list.add("jailBail=" + resident.getJailBailCost());
      }

      list.add("title=" + resident.getTitle());
      list.add("surname=" + resident.getSurname());
      if (!TownySettings.getDefaultResidentAbout().equals(resident.getAbout())) {
         list.add("about=" + resident.getAbout());
      }

      List var10001;
      if (resident.hasTown()) {
         list.add("town=" + resident.getTownOrNull().getName());
         var10001 = resident.getTownRanks();
         list.add("town-ranks=" + StringMgmt.join((Collection)var10001, ","));
         var10001 = resident.getNationRanks();
         list.add("nation-ranks=" + StringMgmt.join((Collection)var10001, ","));
      }

      var10001 = resident.getFriends();
      list.add("friends=" + StringMgmt.join((Collection)var10001, ","));
      list.add("");
      list.add("protectionStatus=" + resident.getPermissions().toString());
      String var3 = this.serializeMetadata(resident);
      list.add("metadata=" + var3);
      this.queryQueue.add(new FlatFileSaveTask(list, this.getResidentFilename(resident)));
      return true;
   }

   public boolean saveHibernatedResident(UUID uuid, long registered) {
      List<String> list = new ArrayList();
      list.add("registered=" + registered);
      this.queryQueue.add(new FlatFileSaveTask(list, this.getHibernatedResidentFilename(uuid)));
      return true;
   }

   public boolean saveTown(Town town) {
      List<String> list = new ArrayList();
      list.add("name=" + town.getName());
      if (town.hasMayor()) {
         list.add("mayor=" + town.getMayor().getName());
      }

      if (town.hasNation()) {
         list.add("nation=" + town.getNationOrNull().getName());
      }

      list.add(this.newLine);
      list.add("townBoard=" + town.getBoard());
      list.add("tag=" + town.getTag());
      list.add("founder=" + town.getFounder());
      list.add("protectionStatus=" + town.getPermissions().toString());
      list.add("bonusBlocks=" + town.getBonusBlocks());
      list.add("purchasedBlocks=" + town.getPurchasedBlocks());
      list.add("taxpercent=" + town.isTaxPercentage());
      list.add("maxPercentTaxAmount=" + town.getMaxPercentTaxAmount());
      list.add("taxes=" + town.getTaxes());
      list.add("plotPrice=" + town.getPlotPrice());
      list.add("plotTax=" + town.getPlotTax());
      list.add("commercialPlotPrice=" + town.getCommercialPlotPrice());
      list.add("commercialPlotTax=" + town.getCommercialPlotTax());
      list.add("embassyPlotPrice=" + town.getEmbassyPlotPrice());
      list.add("embassyPlotTax=" + town.getEmbassyPlotTax());
      list.add("spawnCost=" + town.getSpawnCost());
      list.add("hasUpkeep=" + town.hasUpkeep());
      list.add("hasUnlimitedClaims=" + town.hasUnlimitedClaims());
      list.add("visibleOnTopLists=" + town.isVisibleOnTopLists());
      list.add("open=" + town.isOpen());
      list.add("adminDisabledPvP=" + town.isAdminDisabledPVP());
      list.add("adminEnabledPvP=" + town.isAdminEnabledPVP());
      list.add("adminEnabledMobs=" + town.isAdminEnabledMobs());
      list.add("allowedToWar=" + town.isAllowedToWar());
      list.add("public=" + town.isPublic());
      list.add("conquered=" + town.isConquered());
      list.add("conqueredDays=" + town.getConqueredDays());
      if (town.hasValidUUID()) {
         list.add("uuid=" + town.getUUID());
      } else {
         list.add("uuid=" + UUID.randomUUID());
      }

      list.add("registered=" + town.getRegistered());
      list.add("joinedNationAt=" + town.getJoinedNationAt());
      list.add("movedHomeBlockAt=" + town.getMovedHomeBlockAt());
      list.add("forSale=" + town.isForSale());
      list.add("forSalePrice=" + town.getForSalePrice());
      String var10001;
      if (town.hasHomeBlock()) {
         try {
            var10001 = town.getHomeBlock().getWorld().getName();
            list.add("homeBlock=" + var10001 + "," + town.getHomeBlock().getX() + "," + town.getHomeBlock().getZ());
         } catch (TownyException var7) {
         }
      }

      Position spawnPos = town.spawnPosition();
      if (spawnPos != null) {
         list.add("spawn=" + String.join(",", spawnPos.serialize()));
      }

      StringBuilder outpostArray = new StringBuilder("outpostspawns=");
      if (town.hasOutpostSpawn()) {
         Iterator var5 = town.getOutpostSpawns().iterator();

         while(var5.hasNext()) {
            Position spawn = (Position)var5.next();
            outpostArray.append(String.join(",", spawn.serialize())).append(";");
         }
      }

      list.add(outpostArray.toString());
      Collection var8 = town.getOutlaws();
      list.add("outlaws=" + StringMgmt.join(var8, ","));
      var10001 = this.serializeMetadata(town);
      list.add("metadata=" + var10001);
      list.add("manualTownLevel=" + town.getManualTownLevel());
      list.add("ruined=" + town.isRuined());
      list.add("ruinedTime=" + town.getRuinedTime());
      list.add("neutral=" + town.isNeutral());
      list.add("debtBalance=" + town.getDebtBalance());
      if (town.getPrimaryJail() != null) {
         list.add("primaryJail=" + town.getPrimaryJail().getUUID());
      }

      List var9 = this.toUUIDList(town.getTrustedResidents());
      list.add("trustedResidents=" + StringMgmt.join((Collection)var9, ","));
      var9 = town.getTrustedTownsUUIDS();
      list.add("trustedTowns=" + StringMgmt.join((Collection)var9, ","));
      list.add("mapColorHexCode=" + town.getMapColorHexCode());
      list.add("nationZoneOverride=" + town.getNationZoneOverride());
      list.add("nationZoneEnabled=" + town.isNationZoneEnabled());
      var9 = town.getAlliesUUIDs();
      list.add("allies=" + StringMgmt.join((Collection)var9, ","));
      var9 = town.getEnemiesUUIDs();
      list.add("enemies=" + StringMgmt.join((Collection)var9, ","));
      this.queryQueue.add(new FlatFileSaveTask(list, this.getTownFilename(town)));
      return true;
   }

   public boolean savePlotGroup(PlotGroup group) {
      ArrayList list = new ArrayList();

      try {
         list.add("groupName=" + group.getName());
         list.add("groupPrice=" + group.getPrice());
         list.add("town=" + group.getTown().getName());
         String var10001 = this.serializeMetadata(group);
         list.add("metadata=" + var10001);
      } catch (Exception var4) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred while saving plot group " + (String)Optional.ofNullable(group).map((g) -> {
            return g.getUUID().toString();
         }).orElse("null") + ": ", var4);
      }

      this.queryQueue.add(new FlatFileSaveTask(list, this.getPlotGroupFilename(group)));
      return true;
   }

   public boolean saveDistrict(District district) {
      ArrayList list = new ArrayList();

      try {
         list.add("districtName=" + district.getName());
         list.add("town=" + district.getTown().getUUID().toString());
         String var10001 = this.serializeMetadata(district);
         list.add("metadata=" + var10001);
      } catch (Exception var4) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred while saving district " + (String)Optional.ofNullable(district).map((g) -> {
            return g.getUUID().toString();
         }).orElse("null") + ": ", var4);
      }

      this.queryQueue.add(new FlatFileSaveTask(list, this.getDistrictFilename(district)));
      return true;
   }

   public boolean saveNation(Nation nation) {
      List<String> list = new ArrayList();
      if (nation.hasCapital()) {
         list.add("capital=" + nation.getCapital().getName());
      }

      list.add("nationBoard=" + nation.getBoard());
      list.add("mapColorHexCode=" + nation.getMapColorHexCode());
      if (nation.hasTag()) {
         list.add("tag=" + nation.getTag());
      }

      List var10001 = nation.getAllies();
      list.add("allies=" + StringMgmt.join((Collection)var10001, ","));
      var10001 = nation.getEnemies();
      list.add("enemies=" + StringMgmt.join((Collection)var10001, ","));
      list.add("taxpercent=" + nation.isTaxPercentage());
      list.add("maxPercentTaxAmount=" + nation.getMaxPercentTaxAmount());
      list.add("taxes=" + nation.getTaxes());
      list.add("spawnCost=" + nation.getSpawnCost());
      list.add("neutral=" + nation.isNeutral());
      if (nation.hasValidUUID()) {
         list.add("uuid=" + nation.getUUID());
      } else {
         list.add("uuid=" + UUID.randomUUID());
      }

      list.add("registered=" + nation.getRegistered());
      Position spawnPos = nation.spawnPosition();
      if (spawnPos != null) {
         list.add("nationSpawn=" + String.join(",", spawnPos.serialize()));
      }

      list.add("isPublic=" + nation.isPublic());
      list.add("isOpen=" + nation.isOpen());
      String var4 = this.serializeMetadata(nation);
      list.add("metadata=" + var4);
      list.add("conqueredTax=" + nation.getConqueredTax());
      var10001 = nation.getSanctionedTownsForSaving();
      list.add("sanctionedTowns=" + StringMgmt.join((Collection)var10001, "#"));
      this.queryQueue.add(new FlatFileSaveTask(list, this.getNationFilename(nation)));
      return true;
   }

   public boolean saveWorld(TownyWorld world) {
      List<String> list = new ArrayList();
      list.add("name=" + world.getName());
      if (world.getUUID() != null) {
         list.add("uuid=" + world.getUUID());
      }

      list.add("pvp=" + world.isPVP());
      list.add("forcepvp=" + world.isForcePVP());
      list.add("friendlyFire=" + world.isFriendlyFireEnabled());
      list.add("# Can players found towns and claim plots in this world?");
      list.add("claimable=" + world.isClaimable());
      list.add("worldmobs=" + world.hasWorldMobs());
      list.add("wildernessmobs=" + world.hasWildernessMobs());
      list.add("forcetownmobs=" + world.isForceTownMobs());
      list.add("firespread=" + world.isFire());
      list.add("forcefirespread=" + world.isForceFire());
      list.add("explosions=" + world.isExpl());
      list.add("forceexplosions=" + world.isForceExpl());
      list.add("endermanprotect=" + world.isEndermanProtect());
      list.add("disablecreaturetrample=" + world.isDisableCreatureTrample());
      list.add("");
      list.add("# Unclaimed Zone settings.");
      if (world.getUnclaimedZoneBuild() != null) {
         list.add("unclaimedZoneBuild=" + world.getUnclaimedZoneBuild());
      }

      if (world.getUnclaimedZoneDestroy() != null) {
         list.add("unclaimedZoneDestroy=" + world.getUnclaimedZoneDestroy());
      }

      if (world.getUnclaimedZoneSwitch() != null) {
         list.add("unclaimedZoneSwitch=" + world.getUnclaimedZoneSwitch());
      }

      if (world.getUnclaimedZoneItemUse() != null) {
         list.add("unclaimedZoneItemUse=" + world.getUnclaimedZoneItemUse());
      }

      if (world.getUnclaimedZoneName() != null) {
         list.add("unclaimedZoneName=" + world.getUnclaimedZoneName());
      }

      list.add("");
      list.add("# The following are blocks that will bypass the above build, destroy, switch and itemuse settings.");
      Collection var10001;
      if (world.getUnclaimedZoneIgnoreMaterials() != null) {
         var10001 = world.getUnclaimedZoneIgnoreMaterials();
         list.add("unclaimedZoneIgnoreIds=" + StringMgmt.join(var10001, ","));
      }

      list.add("");
      list.add("# The following settings control what blocks are deleted upon a townblock being unclaimed");
      list.add("usingPlotManagementDelete=" + world.isUsingPlotManagementDelete());
      if (world.getPlotManagementDeleteIds() != null) {
         var10001 = world.getPlotManagementDeleteIds();
         list.add("plotManagementDeleteIds=" + StringMgmt.join(var10001, ","));
      }

      list.add("");
      list.add("# The following settings control what EntityTypes are deleted upon a townblock being unclaimed");
      list.add("# Valid EntityTypes are listed here: https://hub.spigotmc.org/javadocs/bukkit/org/bukkit/entity/EntityType.html");
      list.add("isDeletingEntitiesOnUnclaim=" + world.isDeletingEntitiesOnUnclaim());
      if (world.getUnclaimDeleteEntityTypes() != null) {
         var10001 = BukkitTools.convertKeyedToString(world.getUnclaimDeleteEntityTypes());
         list.add("unclaimDeleteEntityTypes=" + StringMgmt.join(var10001, ","));
      }

      list.add("");
      list.add("# The following settings control what blocks are deleted upon a mayor issuing a '/plot clear' command");
      list.add("usingPlotManagementMayorDelete=" + world.isUsingPlotManagementMayorDelete());
      if (world.getPlotManagementMayorDelete() != null) {
         var10001 = world.getPlotManagementMayorDelete();
         list.add("plotManagementMayorDelete=" + StringMgmt.join(var10001, ","));
      }

      list.add("");
      list.add("# If enabled when a town claims a townblock a snapshot will be taken at the time it is claimed.");
      list.add("# When the townblock is unclaimed its blocks will begin to revert to the original snapshot.");
      list.add("usingPlotManagementRevert=" + world.isUsingPlotManagementRevert());
      list.add("# Any block Id's listed here will not be respawned. Instead it will revert to air. This list also world on the WildRegen settings below.");
      if (world.getPlotManagementIgnoreIds() != null) {
         var10001 = world.getPlotManagementIgnoreIds();
         list.add("plotManagementIgnoreIds=" + StringMgmt.join(var10001, ","));
      }

      if (world.getRevertOnUnclaimWhitelistMaterials() != null) {
         var10001 = world.getRevertOnUnclaimWhitelistMaterials();
         list.add("revertOnUnclaimWhitelistMaterials=" + StringMgmt.join(var10001, "#"));
      }

      list.add("");
      list.add("# The following settings control which entities/blocks' explosions are reverted in the wilderness.");
      list.add("# If enabled any damage caused by entity explosions will repair itself.");
      list.add("usingPlotManagementWildRegen=" + world.isUsingPlotManagementWildEntityRevert());
      list.add("# The list of entities whose explosions would be reverted.");
      if (world.getPlotManagementWildRevertEntities() != null) {
         var10001 = BukkitTools.convertKeyedToString(world.getPlotManagementWildRevertEntities());
         list.add("PlotManagementWildRegenEntities=" + StringMgmt.join(var10001, ","));
      }

      list.add("# If enabled any damage caused by block explosions will repair itself.");
      list.add("usingPlotManagementWildRegenBlocks=" + world.isUsingPlotManagementWildBlockRevert());
      list.add("# The list of blocks whose explosions would be reverted.");
      if (world.getPlotManagementWildRevertBlocks() != null) {
         var10001 = world.getPlotManagementWildRevertBlocks();
         list.add("PlotManagementWildRegenBlocks=" + StringMgmt.join(var10001, ","));
      }

      list.add("# The list of blocks to regenerate. (if empty all blocks will regenerate)");
      if (world.getPlotManagementWildRevertBlockWhitelist() != null) {
         var10001 = world.getPlotManagementWildRevertBlockWhitelist();
         list.add("PlotManagementWildRegenBlockWhitelist=" + StringMgmt.join(var10001, ","));
      }

      list.add("# The list of blocks to that should not get replaced when an explosion is reverted in the wilderness, ie: a chest placed in a creeper hole that is reverting.");
      if (world.getWildRevertMaterialsToNotOverwrite() != null) {
         var10001 = world.getWildRevertMaterialsToNotOverwrite();
         list.add("wildRegenBlocksToNotOverwrite=" + StringMgmt.join(var10001, ","));
      }

      list.add("# The delay after which the explosion reverts will begin.");
      list.add("usingPlotManagementWildRegenDelay=" + world.getPlotManagementWildRevertDelay());
      list.add("");
      list.add("# This setting is used to enable or disable Towny in this world.");
      list.add("usingTowny=" + world.isUsingTowny());
      list.add("");
      list.add("# This setting is used to enable or disable Event war in this world.");
      list.add("warAllowed=" + world.isWarAllowed());
      list.add("");
      String var3 = this.serializeMetadata(world);
      list.add("metadata=" + var3);
      this.queryQueue.add(new FlatFileSaveTask(list, this.getWorldFilename(world)));
      return true;
   }

   public boolean saveTownBlock(TownBlock townBlock) {
      if (!townBlock.hasTown()) {
         return false;
      } else {
         String var10000 = this.dataFolderPath;
         FileMgmt.checkOrCreateFolder(var10000 + File.separator + "townblocks" + File.separator + townBlock.getWorld().getName());
         List<String> list = new ArrayList();
         list.add("name=" + townBlock.getName());
         list.add("price=" + townBlock.getPlotPrice());
         list.add("taxed=" + townBlock.isTaxed());
         list.add("town=" + townBlock.getTownOrNull().getName());
         if (townBlock.hasResident()) {
            list.add("resident=" + townBlock.getResidentOrNull().getName());
         }

         list.add("type=" + townBlock.getTypeName());
         list.add("outpost=" + townBlock.isOutpost());
         if (townBlock.isChanged()) {
            list.add("permissions=" + townBlock.getPermissions().toString());
         }

         list.add("changed=" + townBlock.isChanged());
         list.add("claimedAt=" + townBlock.getClaimedAt());
         if (townBlock.hasMinTownMembershipDays()) {
            list.add("minTownMembershipDays=" + townBlock.getMinTownMembershipDays());
         }

         if (townBlock.hasMaxTownMembershipDays()) {
            list.add("maxTownMembershipDays=" + townBlock.getMaxTownMembershipDays());
         }

         String var10001 = this.serializeMetadata(townBlock);
         list.add("metadata=" + var10001);
         StringBuilder groupID = new StringBuilder();
         if (townBlock.hasPlotObjectGroup()) {
            groupID.append(townBlock.getPlotObjectGroup().getUUID());
         }

         list.add("groupID=" + groupID);
         StringBuilder districtID = new StringBuilder();
         if (townBlock.hasDistrict()) {
            districtID.append(townBlock.getDistrict().getUUID());
         }

         list.add("districtID=" + districtID);
         List var8 = this.toUUIDList(townBlock.getTrustedResidents());
         list.add("trustedResidents=" + StringMgmt.join((Collection)var8, ","));
         Map<String, String> stringMap = new HashMap();
         Iterator var6 = townBlock.getPermissionOverrides().entrySet().iterator();

         while(var6.hasNext()) {
            Entry<Resident, PermissionData> entry = (Entry)var6.next();
            stringMap.put(((Resident)entry.getKey()).getUUID().toString(), ((PermissionData)entry.getValue()).toString());
         }

         list.add("customPermissionData=" + (new Gson()).toJson(stringMap));
         this.queryQueue.add(new FlatFileSaveTask(list, this.getTownBlockFilename(townBlock)));
         return true;
      }
   }

   public boolean saveJail(Jail jail) {
      List<String> list = new ArrayList();
      list.add("townblock=" + jail.getTownBlock().getWorldCoord().toString());
      StringBuilder jailArray = new StringBuilder("spawns=");
      Iterator var4 = jail.getJailCellPositions().iterator();

      while(var4.hasNext()) {
         Position spawn = (Position)var4.next();
         jailArray.append(String.join(",", spawn.serialize())).append(";");
      }

      list.add(jailArray.toString());
      this.queryQueue.add(new FlatFileSaveTask(list, this.getJailFilename(jail)));
      return true;
   }

   public void deleteResident(Resident resident) {
      File file = new File(this.getResidentFilename(resident));
      this.queryQueue.add(new DeleteFileTask(file, false));
   }

   public void deleteHibernatedResident(UUID uuid) {
      File file = new File(this.getHibernatedResidentFilename(uuid));
      this.queryQueue.add(new DeleteFileTask(file, true));
   }

   public void deleteTown(Town town) {
      File file = new File(this.getTownFilename(town));
      this.queryQueue.add(new DeleteFileTask(file, false));
   }

   public void deleteNation(Nation nation) {
      File file = new File(this.getNationFilename(nation));
      this.queryQueue.add(new DeleteFileTask(file, false));
   }

   public void deleteWorld(TownyWorld world) {
      File file = new File(this.getWorldFilename(world));
      this.queryQueue.add(new DeleteFileTask(file, false));
   }

   public void deleteTownBlock(TownBlock townBlock) {
      File file = new File(this.getTownBlockFilename(townBlock));
      if (file.exists()) {
         this.queryQueue.add(() -> {
            FileMgmt.moveTownBlockFile(file, "deleted", townBlock.hasTown() ? townBlock.getTownOrNull().getName() : "");
         });
      }
   }

   public void deletePlotGroup(PlotGroup group) {
      File file = new File(this.getPlotGroupFilename(group));
      this.queryQueue.add(new DeleteFileTask(file, false));
   }

   public void deleteDistrict(District district) {
      File file = new File(this.getDistrictFilename(district));
      this.queryQueue.add(new DeleteFileTask(file, false));
   }

   public void deleteJail(Jail jail) {
      File file = new File(this.getJailFilename(jail));
      this.queryQueue.add(new DeleteFileTask(file, false));
   }

   public CompletableFuture<Optional<Long>> getHibernatedResidentRegistered(UUID uuid) {
      return CompletableFuture.supplyAsync(() -> {
         File hibernatedFile = new File(this.getHibernatedResidentFilename(uuid));
         if (!hibernatedFile.exists()) {
            return Optional.empty();
         } else {
            Map<String, String> keys = FileMgmt.loadFileIntoHashMap(hibernatedFile);
            String registered = (String)keys.get("registered");
            if (registered != null && !registered.isEmpty()) {
               try {
                  return Optional.of(Long.parseLong(registered));
               } catch (NumberFormatException var6) {
                  return Optional.empty();
               }
            } else {
               return Optional.empty();
            }
         }
      });
   }

   public boolean loadCooldowns() {
      Path cooldownsFile = Paths.get(this.dataFolderPath).resolve("cooldowns.json");
      if (!Files.exists(cooldownsFile, new LinkOption[0])) {
         return true;
      } else {
         String data;
         try {
            data = Files.readString(cooldownsFile);
         } catch (IOException var6) {
            this.plugin.getLogger().log(Level.WARNING, "An exception occurred when reading cooldowns.json", var6);
            return true;
         }

         try {
            CooldownTimerTask.getCooldowns().putAll((Map)(new Gson()).fromJson(data, (new TypeToken<Map<String, Long>>() {
            }).getType()));
         } catch (JsonSyntaxException var4) {
            this.plugin.getLogger().log(Level.WARNING, "Could not load saved cooldowns due to a json syntax exception", var4);
         } catch (NullPointerException var5) {
         }

         return true;
      }
   }

   public boolean saveCooldowns() {
      JsonObject object = new JsonObject();
      Iterator var2 = CooldownTimerTask.getCooldowns().entrySet().iterator();

      while(var2.hasNext()) {
         Entry<String, Long> cooldown = (Entry)var2.next();
         object.addProperty((String)cooldown.getKey(), (Number)cooldown.getValue());
      }

      this.queryQueue.add(() -> {
         try {
            Files.writeString(Paths.get(this.dataFolderPath).resolve("cooldowns.json"), (new GsonBuilder()).setPrettyPrinting().create().toJson(object), new OpenOption[]{StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING});
         } catch (IOException var3) {
            this.plugin.getLogger().log(Level.WARNING, "An exception occurred when writing cooldowns.json", var3);
         }

      });
      return true;
   }

   public static enum elements {
      VER,
      NOVALUE;

      public static TownyFlatFileSource.elements fromString(String str) {
         try {
            return valueOf(str);
         } catch (Exception var2) {
            return NOVALUE;
         }
      }

      // $FF: synthetic method
      private static TownyFlatFileSource.elements[] $values() {
         return new TownyFlatFileSource.elements[]{VER, NOVALUE};
      }
   }
}
