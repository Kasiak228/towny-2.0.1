package com.palmergames.bukkit.towny.db;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.DeleteNationEvent;
import com.palmergames.bukkit.towny.event.DeletePlayerEvent;
import com.palmergames.bukkit.towny.event.DeleteTownEvent;
import com.palmergames.bukkit.towny.event.NationRemoveTownEvent;
import com.palmergames.bukkit.towny.event.PreDeleteNationEvent;
import com.palmergames.bukkit.towny.event.PreDeleteTownEvent;
import com.palmergames.bukkit.towny.event.RenameNationEvent;
import com.palmergames.bukkit.towny.event.RenameResidentEvent;
import com.palmergames.bukkit.towny.event.RenameTownEvent;
import com.palmergames.bukkit.towny.event.town.TownPreRuinedEvent;
import com.palmergames.bukkit.towny.event.town.TownPreUnclaimEvent;
import com.palmergames.bukkit.towny.event.town.TownUnclaimEvent;
import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.InvalidNameException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.invites.Invite;
import com.palmergames.bukkit.towny.invites.InviteHandler;
import com.palmergames.bukkit.towny.object.District;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownyObject;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.object.economy.BankAccount;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.jail.UnJailReason;
import com.palmergames.bukkit.towny.object.metadata.DataFieldIO;
import com.palmergames.bukkit.towny.regen.PlotBlockData;
import com.palmergames.bukkit.towny.regen.TownyRegenAPI;
import com.palmergames.bukkit.towny.regen.WorldCoordEntityRemover;
import com.palmergames.bukkit.towny.regen.WorldCoordMaterialRemover;
import com.palmergames.bukkit.towny.scheduling.ScheduledTask;
import com.palmergames.bukkit.towny.tasks.CooldownTimerTask;
import com.palmergames.bukkit.towny.tasks.DeleteFileTask;
import com.palmergames.bukkit.towny.utils.JailUtil;
import com.palmergames.bukkit.towny.utils.TownRuinUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.NameValidation;
import com.palmergames.util.FileMgmt;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class TownyDatabaseHandler extends TownyDataSource {
   public static final SimpleDateFormat BACKUP_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH_mm_ssZ");
   final String rootFolderPath;
   final String dataFolderPath;
   final String settingsFolderPath;
   final String logFolderPath;
   final String backupFolderPath;
   protected final Queue<Runnable> queryQueue = new ConcurrentLinkedQueue();
   private final ScheduledTask task;

   protected TownyDatabaseHandler(Towny plugin, TownyUniverse universe) {
      super(plugin, universe);
      this.rootFolderPath = universe.getRootFolder();
      this.dataFolderPath = this.rootFolderPath + File.separator + "data";
      this.settingsFolderPath = this.rootFolderPath + File.separator + "settings";
      this.logFolderPath = this.rootFolderPath + File.separator + "logs";
      this.backupFolderPath = this.rootFolderPath + File.separator + "backup";
      if (!FileMgmt.checkOrCreateFolders(this.rootFolderPath, this.rootFolderPath + File.separator + "logs", this.dataFolderPath, this.dataFolderPath + File.separator + "plot-block-data") || !FileMgmt.checkOrCreateFiles(this.dataFolderPath + File.separator + "regen.txt", this.dataFolderPath + File.separator + "snapshot_queue.txt")) {
         TownyMessaging.sendErrorMsg("Could not create flatfile default files and folders.");
      }

      this.task = plugin.getScheduler().runAsyncRepeating(() -> {
         synchronized(this.queryQueue) {
            while(!this.queryQueue.isEmpty()) {
               Runnable operation = (Runnable)this.queryQueue.poll();
               operation.run();
            }

         }
      }, 5L, 5L);
   }

   public void finishTasks() {
      if (this.task != null) {
         this.task.cancel();
      }

      while(!this.queryQueue.isEmpty()) {
         Runnable operation = (Runnable)this.queryQueue.poll();
         operation.run();
      }

   }

   public boolean backup() throws IOException {
      if (!TownySettings.getSaveDatabase().equalsIgnoreCase("flatfile") && !TownySettings.disableMySQLBackupWarning()) {
         this.plugin.getLogger().info("***** Warning *****");
         this.plugin.getLogger().info("***** Only Snapshots & Regen files in plugins/Towny/data/ will be backed up!");
         this.plugin.getLogger().info("***** This does not include your residents/towns/nations.");
         this.plugin.getLogger().info("***** Make sure you have scheduled a backup in MySQL too!!!");
         this.plugin.getLogger().info("***** If you already have backups or accept the risk, this message can be disabled in the database config.");
      }

      String backupType = TownySettings.getFlatFileBackupType();
      String var10000 = this.backupFolderPath;
      String newBackupFolder = var10000 + File.separator + BACKUP_DATE_FORMAT.format(System.currentTimeMillis());
      FileMgmt.checkOrCreateFolders(this.rootFolderPath, this.rootFolderPath + File.separator + "backup");
      String var3 = backupType.toLowerCase(Locale.ROOT);
      byte var4 = -1;
      switch(var3.hashCode()) {
      case -1268966290:
         if (var3.equals("folder")) {
            var4 = 0;
         }
         break;
      case -880960548:
         if (var3.equals("tar.gz")) {
            var4 = 2;
         }
         break;
      case 114597:
         if (var3.equals("tar")) {
            var4 = 3;
         }
         break;
      case 120609:
         if (var3.equals("zip")) {
            var4 = 1;
         }
      }

      boolean var5;
      switch(var4) {
      case 0:
         FileMgmt.checkOrCreateFolder(newBackupFolder);
         FileMgmt.copyDirectory(new File(this.dataFolderPath), new File(newBackupFolder));
         FileMgmt.copyDirectory(new File(this.logFolderPath), new File(newBackupFolder));
         FileMgmt.copyDirectory(new File(this.settingsFolderPath), new File(newBackupFolder));
         var5 = true;
         break;
      case 1:
         FileMgmt.zipDirectories(new File(newBackupFolder + ".zip"), new File(this.dataFolderPath), new File(this.logFolderPath), new File(this.settingsFolderPath));
         var5 = true;
         break;
      case 2:
      case 3:
         FileMgmt.tar(new File(newBackupFolder.concat(".tar.gz")), new File(this.dataFolderPath), new File(this.logFolderPath), new File(this.settingsFolderPath));
         var5 = true;
         break;
      default:
         var5 = false;
      }

      return var5;
   }

   @NotNull
   public Resident newResident(String name) throws AlreadyRegisteredException, NotRegisteredException {
      return this.newResident(name, (UUID)null);
   }

   @NotNull
   public Resident newResident(String name, UUID uuid) throws AlreadyRegisteredException, NotRegisteredException {
      String filteredName;
      try {
         filteredName = NameValidation.checkAndFilterPlayerName(name);
      } catch (InvalidNameException var5) {
         throw new NotRegisteredException(var5.getMessage());
      }

      if (this.universe.hasResident(name)) {
         throw new AlreadyRegisteredException("A resident with the name " + filteredName + " is already in use.");
      } else {
         Resident resident = new Resident(filteredName);
         if (uuid != null) {
            resident.setUUID(uuid);
         }

         this.universe.registerResident(resident);
         return resident;
      }
   }

   public void newNation(String name) throws AlreadyRegisteredException, NotRegisteredException {
      this.newNation(name, (UUID)null);
   }

   public void newNation(String name, @Nullable UUID uuid) throws AlreadyRegisteredException, NotRegisteredException {
      String filteredName;
      try {
         filteredName = NameValidation.checkAndFilterNationNameOrThrow(name);
      } catch (InvalidNameException var5) {
         throw new NotRegisteredException(var5.getMessage());
      }

      if (this.universe.hasNation(filteredName)) {
         throw new AlreadyRegisteredException("The nation " + filteredName + " is already in use.");
      } else {
         Nation nation = new Nation(filteredName);
         if (uuid != null) {
            nation.setUUID(uuid);
         }

         this.universe.registerNation(nation);
      }
   }

   public void newWorld(String name) throws AlreadyRegisteredException {
      if (this.universe.getWorldMap().containsKey(name.toLowerCase(Locale.ROOT))) {
         throw new AlreadyRegisteredException("The world " + name + " is already in use.");
      } else {
         this.universe.getWorldMap().put(name.toLowerCase(Locale.ROOT), new TownyWorld(name));
      }
   }

   public void removeResident(Resident resident) {
      Iterator var2 = this.universe.getTowns().iterator();

      while(var2.hasNext()) {
         Town town = (Town)var2.next();
         if (town.exists()) {
            boolean save = false;
            if (town.hasOutlaw(resident)) {
               town.removeOutlaw(resident);
               save = true;
            }

            if (town.hasTrustedResident(resident)) {
               town.removeTrustedResident(resident);
               save = true;
            }

            if (save) {
               town.save();
            }
         }
      }

      var2 = this.universe.getGroups().iterator();

      while(var2.hasNext()) {
         PlotGroup group = (PlotGroup)var2.next();
         if (group.hasTrustedResident(resident)) {
            group.removeTrustedResident(resident);
            group.save();
         }
      }

      var2 = this.universe.getTownBlocks().values().iterator();

      TownBlock townBlock;
      while(var2.hasNext()) {
         townBlock = (TownBlock)var2.next();
         if (townBlock.hasTrustedResident(resident)) {
            townBlock.removeTrustedResident(resident);
            townBlock.save();
         }
      }

      var2 = (new ArrayList(resident.getTownBlocks())).iterator();

      while(var2.hasNext()) {
         townBlock = (TownBlock)var2.next();
         townBlock.setResident((Resident)null, false);
         resident.removeTownBlock(townBlock);
         if (townBlock.getType() != TownBlockType.EMBASSY) {
            townBlock.setPlotPrice(townBlock.getTownOrNull().getPlotPrice());
         }

         townBlock.setType(townBlock.getType());
         townBlock.save();
      }

      List<Resident> toSave = new ArrayList();
      Iterator var9 = this.universe.getResidents().iterator();

      Resident toCheck;
      while(var9.hasNext()) {
         toCheck = (Resident)var9.next();
         TownyMessaging.sendDebugMsg("Checking friends of: " + toCheck.getName());
         if (toCheck.hasFriend(resident)) {
            TownyMessaging.sendDebugMsg("       - Removing Friend: " + resident.getName());
            toCheck.removeFriend(resident);
            toSave.add(toCheck);
         }
      }

      var9 = toSave.iterator();

      while(var9.hasNext()) {
         toCheck = (Resident)var9.next();
         this.saveResident(toCheck);
      }

      if (resident.hasTown() && resident.getTownOrNull() != null) {
         resident.removeTown();
      }

      if (resident.hasUUID() && !resident.isNPC()) {
         this.saveHibernatedResident(resident.getUUID(), resident.getRegistered());
      }

      this.deleteResident(resident);

      try {
         this.universe.unregisterResident(resident);
      } catch (NotRegisteredException var5) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred while unregistering resident " + resident.getName(), var5);
      }

      if (TownySettings.isDeleteEcoAccount() && TownyEconomyHandler.isActive()) {
         resident.getAccount().removeAccount();
      }

      this.plugin.deleteCache(resident);
      BukkitTools.fireEvent(new DeletePlayerEvent(resident));
   }

   public void removeTownBlock(TownBlock townBlock) {
      Town town = townBlock.getTownOrNull();
      if (town == null) {
         this.plugin.getLogger().severe(String.format("The TownBlock at (%s, %d, %d) is not registered to a town.", townBlock.getWorld().getName(), townBlock.getX(), townBlock.getZ()));
      }

      TownPreUnclaimEvent event = new TownPreUnclaimEvent(town, townBlock);
      if (BukkitTools.isEventCancelled(event)) {
         if (!event.getCancelMessage().isEmpty()) {
            this.plugin.getLogger().warning(event.getCancelMessage());
         }

      } else {
         if (townBlock.isJail() && townBlock.getJail() != null) {
            this.removeJail(townBlock.getJail());
         }

         if (TownySettings.getTownUnclaimCoolDownTime() > 0) {
            CooldownTimerTask.addCooldownTimer(townBlock.getWorldCoord().toString(), CooldownTimerTask.CooldownType.TOWNBLOCK_UNCLAIM);
         }

         this.universe.removeTownBlock(townBlock);
         this.deleteTownBlock(townBlock);
         if (townBlock.getWorld().isDeletingEntitiesOnUnclaim()) {
            WorldCoordEntityRemover.addToQueue(townBlock.getWorldCoord());
         }

         if (townBlock.getWorld().isUsingPlotManagementDelete()) {
            WorldCoordMaterialRemover.addToQueue(townBlock.getWorldCoord());
         }

         if (townBlock.getWorld().isUsingPlotManagementRevert()) {
            TownyRegenAPI.addToRegenQueueList(townBlock.getWorldCoord(), true);
         }

         BukkitTools.fireEvent(new TownUnclaimEvent(town, townBlock.getWorldCoord(), false));
      }
   }

   public void removeTownBlocks(Town town) {
      Iterator var2 = (new ArrayList(town.getTownBlocks())).iterator();

      while(var2.hasNext()) {
         TownBlock townBlock = (TownBlock)var2.next();
         this.removeTownBlock(townBlock);
      }

   }

   public boolean removeTown(@NotNull Town town, @NotNull DeleteTownEvent.Cause cause, @Nullable CommandSender sender, boolean delayFullRemoval) {
      if (delayFullRemoval) {
         TownPreRuinedEvent tpre = new TownPreRuinedEvent(town, cause, sender);
         if (!BukkitTools.isEventCancelled(tpre)) {
            TownRuinUtil.putTownIntoRuinedState(town);
            return false;
         }

         if (sender != null && !tpre.getCancelMessage().isEmpty()) {
            TownyMessaging.sendErrorMsg(tpre.getCancelMessage());
         }
      }

      PreDeleteTownEvent preEvent = new PreDeleteTownEvent(town, cause, sender);
      if (!cause.ignoresPreEvent() && BukkitTools.isEventCancelled(preEvent)) {
         if (sender != null && !preEvent.getCancelMessage().isEmpty()) {
            TownyMessaging.sendErrorMsg((Object)sender, (String)preEvent.getCancelMessage());
         }

         return false;
      } else {
         Resident mayor = town.getMayor();
         TownyWorld townyWorld = town.getHomeblockWorld();
         if (town.hasSpawn()) {
            try {
               this.universe.removeSpawnPoint(town.getSpawn());
            } catch (TownyException var13) {
            }
         }

         this.removeTownBlocks(town);
         List<Resident> toSave = new ArrayList(town.getResidents());
         if (town.hasNation()) {
            town.removeNation();
         }

         if (TownyEconomyHandler.isActive()) {
            town.getAccount().removeAccount();
         }

         Iterator var9 = toSave.iterator();

         while(var9.hasNext()) {
            Resident resident = (Resident)var9.next();
            resident.clearModes(false);
            resident.removeTown(true);
         }

         (new ArrayList(this.universe.getJailedResidentMap())).stream().filter((residentx) -> {
            return residentx.hasJailTown(town.getName());
         }).forEach((residentx) -> {
            JailUtil.unJailResident(residentx, UnJailReason.JAIL_DELETED);
         });
         if (townyWorld != null) {
            try {
               townyWorld.removeTown(town);
            } catch (NotRegisteredException var12) {
            }

            this.saveWorld(townyWorld);
         }

         try {
            this.universe.unregisterTown(town);
         } catch (NotRegisteredException var11) {
            TownyMessaging.sendErrorMsg(var11.getMessage());
         }

         this.plugin.resetCache();
         this.deleteTown(town);
         BukkitTools.fireEvent(new DeleteTownEvent(town, mayor, cause, sender));
         TownyMessaging.sendGlobalMessage(Translatable.of("msg_del_town2", town.getName()));
         return true;
      }
   }

   public boolean removeNation(@NotNull Nation nation, @NotNull DeleteNationEvent.Cause cause, @Nullable CommandSender sender) {
      PreDeleteNationEvent preEvent = new PreDeleteNationEvent(nation, cause, sender);
      if (sender != null) {
         preEvent.setCancelMessage(Translatable.of("msg_err_you_cannot_delete_this_nation").forLocale(sender));
      }

      if (!cause.ignoresPreEvent() && BukkitTools.isEventCancelled(preEvent)) {
         if (sender != null && !preEvent.getCancelMessage().isEmpty()) {
            TownyMessaging.sendErrorMsg(preEvent.getCancelMessage());
         }

         return false;
      } else {
         Resident king = null;
         if (nation.hasKing()) {
            king = nation.getKing();
         }

         if (nation.hasSpawn()) {
            try {
               this.universe.removeSpawnPoint(nation.getSpawn());
            } catch (TownyException var14) {
            }
         }

         List<Nation> toSaveNation = new ArrayList();
         Iterator var7 = (new ArrayList(this.universe.getNations())).iterator();

         while(true) {
            Nation toCheck;
            do {
               if (!var7.hasNext()) {
                  var7 = toSaveNation.iterator();

                  while(var7.hasNext()) {
                     toCheck = (Nation)var7.next();
                     this.saveNation(toCheck);
                  }

                  var7 = (new ArrayList(this.universe.getNations())).iterator();

                  while(var7.hasNext()) {
                     toCheck = (Nation)var7.next();
                     Iterator var9 = (new ArrayList(toCheck.getSentAllyInvites())).iterator();

                     while(var9.hasNext()) {
                        Invite invite = (Invite)var9.next();
                        if (invite.getReceiver().getName().equalsIgnoreCase(nation.getName())) {
                           toCheck.deleteSentAllyInvite(invite);
                           InviteHandler.removeInvite(invite);
                        }
                     }
                  }

                  var7 = (new ArrayList(nation.getSentAllyInvites())).iterator();

                  while(var7.hasNext()) {
                     Invite invite = (Invite)var7.next();
                     nation.deleteSentAllyInvite(invite);
                     InviteHandler.removeInvite(invite);
                  }

                  if (TownyEconomyHandler.isActive()) {
                     nation.getAccount().removeAccount();
                  }

                  this.deleteNation(nation);
                  List<Town> toSave = new ArrayList(nation.getTowns());
                  nation.clear();

                  try {
                     this.universe.unregisterNation(nation);
                  } catch (NotRegisteredException var13) {
                  }

                  Iterator var17 = toSave.iterator();

                  while(true) {
                     Town town;
                     do {
                        if (!var17.hasNext()) {
                           this.plugin.resetCache();
                           BukkitTools.fireEvent(new DeleteNationEvent(nation, king, cause, sender));
                           return true;
                        }

                        town = (Town)var17.next();
                     } while(!town.exists());

                     Iterator var19 = town.getResidents().iterator();

                     while(var19.hasNext()) {
                        Resident res = (Resident)var19.next();
                        res.updatePermsForNationRemoval();
                        res.save();
                     }

                     try {
                        town.setNation((Nation)null);
                     } catch (AlreadyRegisteredException var12) {
                     }

                     town.save();
                     BukkitTools.fireEvent(new NationRemoveTownEvent(town, nation));
                  }
               }

               toCheck = (Nation)var7.next();
            } while(!toCheck.hasAlly(nation) && !toCheck.hasEnemy(nation));

            if (toCheck.hasAlly(nation)) {
               toCheck.removeAlly(nation);
            } else {
               toCheck.removeEnemy(nation);
            }

            toSaveNation.add(toCheck);
         }
      }
   }

   public void removeWorld(TownyWorld world) throws UnsupportedOperationException {
      this.deleteWorld(world);
      throw new UnsupportedOperationException();
   }

   public void removeJail(Jail jail) {
      (new ArrayList(this.universe.getJailedResidentMap())).stream().filter((resident) -> {
         return resident.getJail().getUUID().equals(jail.getUUID());
      }).forEach((resident) -> {
         JailUtil.unJailResident(resident, UnJailReason.JAIL_DELETED);
      });
      if (jail.hasCells()) {
         jail.removeAllCells();
      }

      if (jail.getTown() != null) {
         jail.getTown().removeJail(jail);
      }

      this.universe.unregisterJail(jail);
      this.deleteJail(jail);
   }

   public void removePlotGroup(PlotGroup group) {
      this.universe.unregisterGroup(group.getUUID());
      this.deletePlotGroup(group);
   }

   public void removeDistrict(District district) {
      this.universe.unregisterDistrict(district.getUUID());
      this.deleteDistrict(district);
   }

   public void renameTown(Town town, String newName) throws AlreadyRegisteredException, NotRegisteredException {
      this.lock.lock();

      String oldName;
      try {
         String filteredName;
         try {
            filteredName = NameValidation.checkAndFilterTownNameOrThrow(newName);
         } catch (InvalidNameException var21) {
            throw new NotRegisteredException(var21.getMessage());
         }

         if (this.universe.hasTown(filteredName)) {
            throw new AlreadyRegisteredException("The town " + filteredName + " is already in use.");
         }

         List<Resident> toSave = new ArrayList(town.getResidents());
         boolean isCapital = false;
         Nation nation = null;
         double townBalance = 0.0D;
         oldName = town.getName();
         if (TownyEconomyHandler.isActive()) {
            try {
               townBalance = town.getAccount().getHoldingBalance();
               town.getAccount().withdraw(townBalance, "Rename Town - Transfer from old account");
            } catch (Exception var20) {
               TownyMessaging.sendErrorMsg("The bank balance for the town " + oldName + " could not be received from the economy plugin and will not be able to be converted.");
            }
         }

         UUID oldUUID = town.getUUID();
         long oldregistration = town.getRegistered();
         if (town.hasNation()) {
            nation = town.getNationOrNull();
            isCapital = town.isCapital();
         }

         TownyWorld world = town.getHomeblockWorld();
         if (world.hasTown(town)) {
            world.removeTown(town);
         }

         this.deleteTown(town);
         this.universe.unregisterTown(town);
         town.setName(filteredName);
         this.universe.registerTown(town);
         world.addTown(town);
         if (isCapital) {
            nation.setCapital(town);
         }

         town.setUUID(oldUUID);
         town.setRegistered(oldregistration);
         if (TownyEconomyHandler.isActive()) {
            BankAccount var10000 = town.getAccount();
            String var10001 = TownySettings.getTownAccountPrefix();
            var10000.setName(var10001 + town.getName());
            town.getAccount().setBalance(townBalance, "Rename Town - Transfer to new account");
         }

         Iterator var14 = toSave.iterator();

         while(var14.hasNext()) {
            Resident resident = (Resident)var14.next();
            this.saveResident(resident);
         }

         town.saveTownBlocks();
         if (town.hasPlotGroups()) {
            var14 = town.getPlotGroups().iterator();

            while(var14.hasNext()) {
               PlotGroup pg = (PlotGroup)var14.next();
               pg.setTown(town);
               this.savePlotGroup(pg);
            }
         }

         this.saveTown(town);
         this.saveWorld(town.getHomeblockWorld());
         if (nation != null) {
            this.saveNation(nation);
         }
      } finally {
         this.lock.unlock();
      }

      BukkitTools.fireEvent(new RenameTownEvent(oldName, town));
   }

   public void renameNation(Nation nation, String newName) throws AlreadyRegisteredException, NotRegisteredException {
      this.lock.lock();

      String oldName;
      try {
         String filteredName;
         try {
            filteredName = NameValidation.checkAndFilterNationNameOrThrow(newName);
         } catch (InvalidNameException var15) {
            throw new NotRegisteredException(var15.getMessage());
         }

         if (this.universe.hasNation(filteredName)) {
            throw new AlreadyRegisteredException("The nation " + filteredName + " is already in use.");
         }

         List<Town> toSave = new ArrayList(nation.getTowns());
         double nationBalance = 0.0D;
         if (TownyEconomyHandler.isActive()) {
            try {
               nationBalance = nation.getAccount().getHoldingBalance();
               nation.getAccount().setBalance(0.0D, "Rename Nation - Transfer from old account");
            } catch (Exception var14) {
               TownyMessaging.sendErrorMsg("The bank balance for the nation " + nation.getName() + ", could not be received from the economy plugin and will not be able to be converted.");
            }
         }

         this.deleteNation(nation);
         oldName = nation.getName();
         this.universe.unregisterNation(nation);
         nation.setName(filteredName);
         this.universe.registerNation(nation);
         if (TownyEconomyHandler.isActive()) {
            BankAccount var10000 = nation.getAccount();
            String var10001 = TownySettings.getNationAccountPrefix();
            var10000.setName(var10001 + nation.getName());
            nation.getAccount().setBalance(nationBalance, "Rename Nation - Transfer to new account");
         }

         Iterator var8 = toSave.iterator();

         while(var8.hasNext()) {
            Town town = (Town)var8.next();
            this.saveTown(town);
         }

         this.saveNation(nation);
         Nation oldNation = new Nation(oldName);
         List<Nation> toSaveNations = new ArrayList();
         this.universe.getNations().stream().filter((n) -> {
            return n.hasAlly(oldNation) || n.hasEnemy(oldNation);
         }).forEach((n) -> {
            if (n.hasAlly(oldNation)) {
               n.removeAlly(oldNation);
               n.addAlly(nation);
            } else {
               n.removeEnemy(oldNation);
               n.addEnemy(nation);
            }

            toSaveNations.add(n);
         });
         toSaveNations.forEach(Nation::save);
      } finally {
         this.lock.unlock();
      }

      BukkitTools.fireEvent(new RenameNationEvent(oldName, nation));
   }

   public void renameGroup(PlotGroup group, String newName) throws AlreadyRegisteredException {
      group.setName(newName);
      this.savePlotGroup(group);
   }

   public void renameDistrict(District district, String newName) throws AlreadyRegisteredException {
      district.setName(newName);
      this.saveDistrict(district);
   }

   public void renamePlayer(Resident resident, String newName) throws AlreadyRegisteredException, NotRegisteredException {
      this.lock.lock();
      String oldName = resident.getName();

      try {
         double balance = 0.0D;
         if (TownyEconomyHandler.isActive() && TownyEconomyHandler.getVersion().startsWith("iConomy 5")) {
            balance = resident.getAccount().getHoldingBalance();
            resident.getAccount().removeAccount();
         }

         if (TownyEconomyHandler.isActive() && resident.getAccountOrNull() != null) {
            resident.getAccount().setName(newName);
         }

         this.universe.unregisterResident(resident);
         resident.setName(newName);
         this.universe.registerResident(resident);
         if (TownyEconomyHandler.isActive() && TownyEconomyHandler.getVersion().startsWith("iConomy 5")) {
            resident.getAccount().setName(resident.getName());
            resident.getAccount().setBalance(balance, "Rename Player - Transfer to new account");
         }

         this.saveResident(resident);
         Iterator var6 = resident.getTownBlocks().iterator();

         while(var6.hasNext()) {
            TownBlock tb = (TownBlock)var6.next();
            this.saveTownBlock(tb);
         }

         if (resident.isMayor()) {
            this.saveTown(resident.getTown());
         }

         Resident oldResident = new Resident(oldName);
         Set<Resident> residentsToSave = new HashSet();
         Iterator var8 = (new ArrayList(this.universe.getResidents())).iterator();

         while(var8.hasNext()) {
            Resident toCheck = (Resident)var8.next();
            if (toCheck.hasFriend(oldResident)) {
               toCheck.removeFriend(oldResident);
               toCheck.addFriend(resident);
               residentsToSave.add(toCheck);
            }
         }

         residentsToSave.forEach((res) -> {
            res.save();
         });
         Set<Town> townsToSave = new HashSet();
         Iterator var17 = (new ArrayList(this.universe.getTowns())).iterator();

         while(var17.hasNext()) {
            Town toCheckTown = (Town)var17.next();
            if (toCheckTown.hasOutlaw(oldResident)) {
               toCheckTown.removeOutlaw(oldResident);
               toCheckTown.addOutlaw(resident);
               townsToSave.add(toCheckTown);
            }

            if (toCheckTown.hasTrustedResident(oldResident)) {
               toCheckTown.removeTrustedResident(oldResident);
               toCheckTown.addTrustedResident(resident);
               townsToSave.add(toCheckTown);
            }
         }

         townsToSave.forEach((town) -> {
            town.save();
         });
         this.deleteResident(oldResident);
      } finally {
         this.lock.unlock();
      }

      BukkitTools.fireEvent(new RenameResidentEvent(oldName, resident));
   }

   public boolean savePlotData(PlotBlockData plotChunk) {
      String path = this.getPlotFilename(plotChunk);
      this.queryQueue.add(() -> {
         String var10002 = this.dataFolderPath;
         File file = new File(var10002 + File.separator + "plot-block-data" + File.separator + plotChunk.getWorldName());
         FileMgmt.savePlotData(plotChunk, file, path);
      });
      return true;
   }

   public PlotBlockData loadPlotData(String worldName, int x, int z) {
      TownyWorld world = this.universe.getWorld(worldName);
      return world == null ? null : this.loadPlotData(new TownBlock(x, z, world));
   }

   public PlotBlockData loadPlotData(TownBlock townBlock) {
      PlotBlockData plotBlockData = null;

      try {
         plotBlockData = new PlotBlockData(townBlock);
      } catch (NullPointerException var11) {
         TownyMessaging.sendErrorMsg("Unable to load plotblockdata for townblock: " + townBlock.getWorldCoord().toString() + ". Skipping regeneration for this townBlock.");
         return null;
      }

      String fileName = this.getPlotFilename(townBlock);
      if (this.isFile(fileName)) {
         try {
            ZipFile zipFile = new ZipFile(fileName);

            PlotBlockData var6;
            try {
               InputStream stream = zipFile.getInputStream((ZipEntry)zipFile.entries().nextElement());
               var6 = this.loadDataStream(plotBlockData, stream);
            } catch (Throwable var8) {
               try {
                  zipFile.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }

               throw var8;
            }

            zipFile.close();
            return var6;
         } catch (IOException var9) {
            this.plugin.getLogger().log(Level.WARNING, "An exception occurred while loading plot block data from file " + fileName, var9);
            return null;
         }
      } else if (this.isFile(this.getLegacyPlotFilename(townBlock))) {
         try {
            return this.loadDataStream(plotBlockData, new FileInputStream(this.getLegacyPlotFilename(townBlock)));
         } catch (FileNotFoundException var10) {
            this.plugin.getLogger().log(Level.WARNING, "Could not find file for legacy plot block data file for townblock " + townBlock, var10);
            return null;
         }
      } else {
         return null;
      }
   }

   private PlotBlockData loadDataStream(PlotBlockData plotBlockData, InputStream stream) {
      int version = false;
      ArrayList blockArr = new ArrayList();

      try {
         DataInputStream fin = new DataInputStream(stream);

         label64: {
            Object var9;
            label63: {
               try {
                  fin.mark(3);
                  byte[] key = new byte[3];
                  fin.read(key, 0, 3);
                  String test = new String(key);
                  if (TownyFlatFileSource.elements.fromString(test) != TownyFlatFileSource.elements.VER) {
                     var9 = null;
                     break label63;
                  }

                  int version = fin.read();
                  if (version >= 4) {
                     plotBlockData.setVersion(version);
                     plotBlockData.setHeight(fin.readInt());
                     plotBlockData.setMinHeight(version == 4 ? 0 : fin.readInt());

                     while(true) {
                        String value;
                        if ((value = fin.readUTF()) == null) {
                           break label64;
                        }

                        blockArr.add(value);
                     }
                  }

                  var9 = null;
               } catch (Throwable var11) {
                  try {
                     fin.close();
                  } catch (Throwable var10) {
                     var11.addSuppressed(var10);
                  }

                  throw var11;
               }

               fin.close();
               return (PlotBlockData)var9;
            }

            fin.close();
            return (PlotBlockData)var9;
         }

         fin.close();
      } catch (EOFException var12) {
      } catch (IOException var13) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred while loading plot block data stream", var13);
      }

      plotBlockData.setBlockList(blockArr);
      plotBlockData.resetBlockListRestored();
      return plotBlockData;
   }

   public void deletePlotData(PlotBlockData plotChunk) {
      File file = new File(this.getPlotFilename(plotChunk));
      this.queryQueue.add(new DeleteFileTask(file, true));
   }

   public boolean hasPlotData(TownBlock townBlock) {
      return this.isFile(this.getPlotFilename(townBlock));
   }

   private String getPlotFilename(PlotBlockData plotChunk) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "plot-block-data" + File.separator + plotChunk.getWorldName() + File.separator + plotChunk.getX() + "_" + plotChunk.getZ() + "_" + plotChunk.getSize() + ".zip";
   }

   private String getPlotFilename(TownBlock townBlock) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "plot-block-data" + File.separator + townBlock.getWorld().getName() + File.separator + townBlock.getX() + "_" + townBlock.getZ() + "_" + TownySettings.getTownBlockSize() + ".zip";
   }

   public String getLegacyPlotFilename(TownBlock townBlock) {
      String var10000 = this.dataFolderPath;
      return var10000 + File.separator + "plot-block-data" + File.separator + townBlock.getWorld().getName() + File.separator + townBlock.getX() + "_" + townBlock.getZ() + "_" + TownySettings.getTownBlockSize() + ".data";
   }

   private boolean isFile(String fileName) {
      File file = new File(fileName);
      return file.exists() && file.isFile();
   }

   public boolean loadRegenList() {
      TownyMessaging.sendDebugMsg("Loading Regen List");
      String line = null;

      try {
         BufferedReader fin = new BufferedReader(new InputStreamReader(new FileInputStream(this.dataFolderPath + File.separator + "regen.txt"), StandardCharsets.UTF_8));

         boolean var9;
         try {
            while((line = fin.readLine()) != null) {
               if (!line.equals("")) {
                  String[] split = line.split(",");
                  WorldCoord wc = new WorldCoord(split[0], Integer.parseInt(split[1]), Integer.parseInt(split[2]));
                  TownyRegenAPI.addToRegenQueueList(wc, false);
               }
            }

            var9 = true;
         } catch (Throwable var7) {
            try {
               fin.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         fin.close();
         return var9;
      } catch (Exception var8) {
         this.plugin.getLogger().log(Level.WARNING, "Error Loading Regen List at " + line + ", in towny\\data\\regen.txt", var8);
         return false;
      }
   }

   protected final String serializeMetadata(TownyObject obj) {
      return DataFieldIO.serializeCDFs(obj.getMetadata());
   }

   public boolean saveRegenList() {
      this.queryQueue.add(() -> {
         File file = new File(this.dataFolderPath + File.separator + "regen.txt");
         Collection<String> lines = (Collection)TownyRegenAPI.getRegenQueueList().stream().map((wc) -> {
            String var10000 = wc.getWorldName();
            return var10000 + "," + wc.getX() + "," + wc.getZ();
         }).collect(Collectors.toList());
         FileMgmt.listToFile(lines, file.getPath());
      });
      return true;
   }

   public void deleteFile(String fileName) {
      File file = new File(fileName);
      this.queryQueue.add(new DeleteFileTask(file, true));
   }

   public void mergeNation(Nation succumbingNation, Nation prevailingNation) {
      if (TownyEconomyHandler.isActive()) {
         succumbingNation.getAccount().payTo(succumbingNation.getAccount().getHoldingBalance(), prevailingNation, "Nation merge bank accounts.");
      }

      this.lock.lock();
      List<Town> towns = new ArrayList(succumbingNation.getTowns());

      Town town;
      for(Iterator var4 = towns.iterator(); var4.hasNext(); this.saveTown(town)) {
         town = (Town)var4.next();
         town.removeNation();

         try {
            town.setNation(prevailingNation);
         } catch (AlreadyRegisteredException var7) {
         }
      }

      this.lock.unlock();
   }

   public void mergeTown(Town mergeInto, Town mergeFrom) {
      if (TownyEconomyHandler.isActive() && mergeFrom.getAccount().getHoldingBalance() > 0.0D) {
         mergeFrom.getAccount().payTo(mergeFrom.getAccount().getHoldingBalance(), mergeInto, Translation.of("msg_town_merge_transaction_reason"));
      }

      this.lock.lock();
      boolean isSameNation = mergeInto.hasNation() && mergeInto.getNationOrNull().hasTown(mergeFrom);
      String mayorName = mergeFrom.getMayor().getName();
      List<Jail> jails = (List)this.universe.getJailUUIDMap().values().stream().filter((jailx) -> {
         return jailx.getTown().equals(mergeFrom);
      }).collect(Collectors.toList());
      List<Location> outposts = new ArrayList(mergeFrom.getAllOutpostSpawns());
      mergeInto.addPurchasedBlocks(mergeFrom.getPurchasedBlocks());
      int mergeFromBonus = mergeFrom.getBonusBlocks();
      int newTownBonus = TownySettings.getNewTownBonusBlocks();
      if (newTownBonus > 0 && mergeFromBonus >= newTownBonus) {
         mergeFromBonus -= newTownBonus;
      }

      mergeInto.addBonusBlocks(mergeFromBonus);
      Iterator var9 = mergeFrom.getTownBlocks().iterator();

      while(var9.hasNext()) {
         TownBlock tb = (TownBlock)var9.next();
         tb.setTown(mergeInto);
         tb.save();
      }

      List<Resident> residents = new ArrayList(mergeFrom.getResidents());
      Iterator var18 = residents.iterator();

      Resident resident;
      while(var18.hasNext()) {
         resident = (Resident)var18.next();

         try {
            if (mergeInto.hasOutlaw(resident)) {
               resident.removeTown();
            } else {
               List<String> nationRanks = new ArrayList(resident.getNationRanks());
               resident.removeTown();
               resident.setTown(mergeInto);
               if (isSameNation) {
                  Iterator var13 = nationRanks.iterator();

                  while(var13.hasNext()) {
                     String rank = (String)var13.next();
                     resident.addNationRank(rank);
                  }
               }

               resident.save();
            }
         } catch (TownyException var16) {
         }
      }

      var18 = mergeFrom.getOutlaws().iterator();

      while(var18.hasNext()) {
         resident = (Resident)var18.next();
         if (!mergeInto.hasOutlaw(resident) && !mergeInto.hasResident(resident)) {
            try {
               mergeInto.addOutlaw(resident);
            } catch (AlreadyRegisteredException var15) {
            }
         }
      }

      Jail jail;
      for(var18 = jails.iterator(); var18.hasNext(); jail.setTown(mergeInto)) {
         jail = (Jail)var18.next();
         TownBlock jailPlot = jail.getTownBlock();
         if (jailPlot.getType() != TownBlockType.JAIL) {
            jailPlot.setType(TownBlockType.JAIL);
         }
      }

      var18 = outposts.iterator();

      while(var18.hasNext()) {
         Location outpost = (Location)var18.next();
         mergeInto.addOutpostSpawn(outpost);
      }

      this.lock.unlock();
      this.removeTown(mergeFrom, DeleteTownEvent.Cause.MERGED, (CommandSender)null, false);
      mergeInto.save();
      TownyMessaging.sendGlobalMessage(Translatable.of("msg_town_merge_success", mergeFrom.getName(), mayorName, mergeInto.getName()));
   }

   public List<UUID> toUUIDList(Collection<Resident> residents) {
      return (List)residents.stream().filter(Resident::hasUUID).map(Resident::getUUID).collect(Collectors.toList());
   }

   public UUID[] toUUIDArray(String[] uuidArray) {
      UUID[] uuids = new UUID[uuidArray.length];

      for(int i = 0; i < uuidArray.length; ++i) {
         try {
            uuids[i] = UUID.fromString(uuidArray[i]);
         } catch (IllegalArgumentException var5) {
         }
      }

      return uuids;
   }

   public String generateReplacementName(boolean town) {
      Random r = new Random();
      String replacementName = "replacementname" + r.nextInt(99) + "1";

      try {
         replacementName = this.getNextName(town);
      } catch (TownyException var5) {
      }

      return replacementName;
   }

   private String getNextName(boolean town) throws TownyException {
      String name = town ? "Town" : "Nation";
      int i = 0;

      do {
         ++i;
         String newName = name + i;
         if (town) {
            if (!this.universe.hasTown(newName)) {
               return newName;
            }
         } else if (!this.universe.hasNation(newName)) {
            return newName;
         }
      } while(i <= 100000);

      throw new TownyException("Too many replacement names.");
   }
}
