package com.palmergames.bukkit.towny.db;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.util.FileMgmt;
import java.util.List;

public class FlatFileSaveTask implements Runnable {
   private final List<String> list;
   private final String path;

   public FlatFileSaveTask(List<String> list, String path) {
      this.list = list;
      this.path = path;
   }

   public void run() {
      try {
         FileMgmt.listToFile(this.list, this.path);
      } catch (NullPointerException var2) {
         TownyMessaging.sendErrorMsg("Null Error saving to file - " + this.path);
      }

   }
}
