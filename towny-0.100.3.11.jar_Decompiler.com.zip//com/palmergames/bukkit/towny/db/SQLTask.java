package com.palmergames.bukkit.towny.db;

import java.util.List;
import java.util.Map;
import org.jetbrains.annotations.ApiStatus.Internal;

@Internal
public class SQLTask implements Runnable {
   private final TownySQLSource source;
   public final boolean update;
   public final String tb_name;
   public final Map<String, ?> args;
   public final List<String> keys;

   public SQLTask(TownySQLSource source, String tb_name, Map<String, ?> args) {
      this(source, false, tb_name, args, (List)null);
   }

   public SQLTask(TownySQLSource source, String tb_name, Map<String, ?> args, List<String> keys) {
      this(source, true, tb_name, args, keys);
   }

   private SQLTask(TownySQLSource source, boolean update, String tb_name, Map<String, ?> args, List<String> keys) {
      this.source = source;
      this.update = update;
      this.tb_name = tb_name;
      this.args = args;
      this.keys = keys;
   }

   public void run() {
      if (this.update) {
         this.source.queueUpdateDB(this.tb_name, this.args, this.keys);
      } else {
         this.source.queueDeleteDB(this.tb_name, this.args);
      }

   }
}
