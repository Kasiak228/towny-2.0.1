package com.palmergames.bukkit.towny.db;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.DeleteNationEvent;
import com.palmergames.bukkit.towny.event.DeleteTownEvent;
import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.object.District;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.regen.PlotBlockData;
import java.io.IOException;
import java.util.Iterator;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class TownyDataSource {
   final Lock lock = new ReentrantLock();
   protected final Towny plugin;
   protected final TownyUniverse universe;

   TownyDataSource(Towny plugin, TownyUniverse universe) {
      this.plugin = plugin;
      this.universe = universe;
   }

   public abstract boolean backup() throws IOException;

   public boolean loadAll() {
      return this.loadWorldList() && this.loadNationList() && this.loadTownList() && this.loadPlotGroupList() && this.loadDistrictList() && this.loadJailList() && this.loadResidentList() && this.loadTownBlockList() && this.loadWorlds() && this.loadResidents() && this.loadTowns() && this.loadNations() && this.loadTownBlocks() && this.loadPlotGroups() && this.loadDistricts() && this.loadJails() && this.loadRegenList() && this.loadCooldowns();
   }

   public boolean saveAll() {
      return this.saveWorlds() && this.saveNations() && this.saveTowns() && this.saveResidents() && this.savePlotGroups() && this.saveDistricts() && this.saveTownBlocks() && this.saveJails() && this.saveRegenList() && this.saveCooldowns();
   }

   public boolean saveAllWorlds() {
      return this.saveWorlds();
   }

   public boolean saveQueues() {
      return this.saveRegenList();
   }

   public abstract void finishTasks();

   public abstract boolean loadTownBlockList();

   public abstract boolean loadResidentList();

   public abstract boolean loadTownList();

   public abstract boolean loadNationList();

   public abstract boolean loadWorldList();

   public abstract boolean loadRegenList();

   public abstract boolean loadTownBlocks();

   public abstract boolean loadJailList();

   public abstract boolean loadResident(Resident var1);

   public abstract boolean loadTown(Town var1);

   public abstract boolean loadNation(Nation var1);

   public abstract boolean loadWorld(TownyWorld var1);

   public abstract boolean loadJail(Jail var1);

   public abstract boolean loadPlotGroupList();

   public abstract boolean loadPlotGroup(PlotGroup var1);

   public abstract boolean loadDistrictList();

   public abstract boolean loadDistrict(District var1);

   public abstract boolean saveRegenList();

   public abstract boolean saveResident(Resident var1);

   public abstract boolean saveHibernatedResident(UUID var1, long var2);

   public abstract boolean saveTown(Town var1);

   public abstract boolean savePlotGroup(PlotGroup var1);

   public abstract boolean saveDistrict(District var1);

   public abstract boolean saveJail(Jail var1);

   public abstract boolean saveNation(Nation var1);

   public abstract boolean saveWorld(TownyWorld var1);

   public abstract boolean saveTownBlock(TownBlock var1);

   public abstract boolean savePlotData(PlotBlockData var1);

   public abstract PlotBlockData loadPlotData(String var1, int var2, int var3);

   public abstract PlotBlockData loadPlotData(TownBlock var1);

   public abstract boolean hasPlotData(TownBlock var1);

   public abstract void deletePlotData(PlotBlockData var1);

   public abstract void deleteResident(Resident var1);

   public abstract void deleteHibernatedResident(UUID var1);

   public abstract void deleteTown(Town var1);

   public abstract void deleteNation(Nation var1);

   public abstract void deleteWorld(TownyWorld var1);

   public abstract void deleteTownBlock(TownBlock var1);

   public abstract void deleteFile(String var1);

   public abstract void deletePlotGroup(PlotGroup var1);

   public abstract void deleteDistrict(District var1);

   public abstract void deleteJail(Jail var1);

   public abstract CompletableFuture<Optional<Long>> getHibernatedResidentRegistered(UUID var1);

   public boolean cleanup() {
      return true;
   }

   public boolean loadResidents() {
      TownyMessaging.sendDebugMsg("Loading Residents");
      Iterator var1 = this.universe.getResidents().iterator();

      Resident resident;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         resident = (Resident)var1.next();
      } while(this.loadResident(resident));

      this.plugin.getLogger().severe("Loading Error: Could not read resident data '" + resident.getName() + "'.");
      return false;
   }

   public boolean loadTowns() {
      TownyMessaging.sendDebugMsg("Loading Towns");
      Iterator var1 = this.universe.getTowns().iterator();

      Town town;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         town = (Town)var1.next();
      } while(this.loadTown(town));

      this.plugin.getLogger().severe("Loading Error: Could not read town data '" + town.getName() + "'.");
      return false;
   }

   public boolean loadNations() {
      TownyMessaging.sendDebugMsg("Loading Nations");
      Iterator var1 = this.universe.getNations().iterator();

      Nation nation;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         nation = (Nation)var1.next();
      } while(this.loadNation(nation));

      this.plugin.getLogger().severe("Loading Error: Could not read nation data '" + nation.getName() + "'.");
      return false;
   }

   public boolean loadWorlds() {
      TownyMessaging.sendDebugMsg("Loading Worlds");
      Iterator var1 = this.universe.getTownyWorlds().iterator();

      TownyWorld world;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         world = (TownyWorld)var1.next();
      } while(this.loadWorld(world));

      this.plugin.getLogger().severe("Loading Error: Could not read world data '" + world.getName() + "'.");
      return false;
   }

   public boolean loadJails() {
      TownyMessaging.sendDebugMsg("Loading Jails");
      Iterator var1 = this.universe.getJails().iterator();

      Jail jail;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         jail = (Jail)var1.next();
      } while(this.loadJail(jail));

      this.plugin.getLogger().severe("Loading Error: Could not read jail data '" + jail.getUUID() + "'.");
      return false;
   }

   public boolean loadPlotGroups() {
      TownyMessaging.sendDebugMsg("Loading PlotGroups");
      Iterator var1 = this.universe.getGroups().iterator();

      PlotGroup group;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         group = (PlotGroup)var1.next();
      } while(this.loadPlotGroup(group));

      this.plugin.getLogger().severe("Loading Error: Could not read PlotGroup data: '" + group.getUUID() + "'.");
      return false;
   }

   public boolean loadDistricts() {
      TownyMessaging.sendDebugMsg("Loading Districts");
      Iterator var1 = this.universe.getDistricts().iterator();

      District district;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         district = (District)var1.next();
      } while(this.loadDistrict(district));

      this.plugin.getLogger().severe("Loading Error: Could not read District data: '" + district.getUUID() + "'.");
      return false;
   }

   public abstract boolean loadCooldowns();

   public boolean saveResidents() {
      TownyMessaging.sendDebugMsg("Saving Residents");
      Iterator var1 = this.universe.getResidents().iterator();

      while(var1.hasNext()) {
         Resident resident = (Resident)var1.next();
         this.saveResident(resident);
      }

      return true;
   }

   public boolean savePlotGroups() {
      TownyMessaging.sendDebugMsg("Saving PlotGroups");
      Iterator var1 = this.universe.getGroups().iterator();

      while(var1.hasNext()) {
         PlotGroup plotGroup = (PlotGroup)var1.next();
         if (plotGroup.hasTownBlocks()) {
            this.savePlotGroup(plotGroup);
         } else {
            this.deletePlotGroup(plotGroup);
         }
      }

      return true;
   }

   public boolean saveDistricts() {
      TownyMessaging.sendDebugMsg("Saving Districts");
      Iterator var1 = this.universe.getDistricts().iterator();

      while(var1.hasNext()) {
         District district = (District)var1.next();
         if (district.hasTownBlocks()) {
            this.saveDistrict(district);
         } else {
            this.deleteDistrict(district);
         }
      }

      return true;
   }

   public boolean saveJails() {
      TownyMessaging.sendDebugMsg("Saving Jails");
      Iterator var1 = this.universe.getJails().iterator();

      while(var1.hasNext()) {
         Jail jail = (Jail)var1.next();
         this.saveJail(jail);
      }

      return true;
   }

   public boolean saveTowns() {
      TownyMessaging.sendDebugMsg("Saving Towns");
      Iterator var1 = this.universe.getTowns().iterator();

      while(var1.hasNext()) {
         Town town = (Town)var1.next();
         this.saveTown(town);
      }

      return true;
   }

   public boolean saveNations() {
      TownyMessaging.sendDebugMsg("Saving Nations");
      Iterator var1 = this.universe.getNations().iterator();

      while(var1.hasNext()) {
         Nation nation = (Nation)var1.next();
         this.saveNation(nation);
      }

      return true;
   }

   public boolean saveWorlds() {
      TownyMessaging.sendDebugMsg("Saving Worlds");
      Iterator var1 = this.universe.getTownyWorlds().iterator();

      while(var1.hasNext()) {
         TownyWorld world = (TownyWorld)var1.next();
         this.saveWorld(world);
      }

      return true;
   }

   public boolean saveTownBlocks() {
      TownyMessaging.sendDebugMsg("Saving Townblocks");
      Iterator var1 = this.universe.getTowns().iterator();

      while(var1.hasNext()) {
         Town town = (Town)var1.next();
         Iterator var3 = town.getTownBlocks().iterator();

         while(var3.hasNext()) {
            TownBlock townBlock = (TownBlock)var3.next();
            this.saveTownBlock(townBlock);
         }
      }

      return true;
   }

   public abstract boolean saveCooldowns();

   public abstract void removeResident(Resident var1);

   public abstract void removeTownBlock(TownBlock var1);

   public abstract void removeTownBlocks(Town var1);

   public boolean removeNation(@NotNull Nation nation, @NotNull DeleteNationEvent.Cause cause) {
      return this.removeNation(nation, cause, (CommandSender)null);
   }

   public abstract boolean removeNation(@NotNull Nation var1, @NotNull DeleteNationEvent.Cause var2, @Nullable CommandSender var3);

   @NotNull
   public abstract Resident newResident(String var1) throws AlreadyRegisteredException, NotRegisteredException;

   @NotNull
   public abstract Resident newResident(String var1, UUID var2) throws AlreadyRegisteredException, NotRegisteredException;

   public abstract void newNation(String var1) throws AlreadyRegisteredException, NotRegisteredException;

   public abstract void newNation(String var1, UUID var2) throws AlreadyRegisteredException, NotRegisteredException;

   public abstract void newWorld(String var1) throws AlreadyRegisteredException;

   public boolean removeTown(Town town, @NotNull DeleteTownEvent.Cause cause) {
      return this.removeTown(town, cause, (CommandSender)null);
   }

   public boolean removeTown(@NotNull Town town, @NotNull DeleteTownEvent.Cause cause, @Nullable CommandSender sender) {
      return this.removeTown(town, cause, sender, TownySettings.getTownRuinsEnabled() && !town.isRuined());
   }

   public abstract boolean removeTown(@NotNull Town var1, @NotNull DeleteTownEvent.Cause var2, @Nullable CommandSender var3, boolean var4);

   public abstract void removeWorld(TownyWorld var1) throws UnsupportedOperationException;

   public abstract void removeJail(Jail var1);

   public abstract void removePlotGroup(PlotGroup var1);

   public abstract void removeDistrict(District var1);

   public abstract void renameTown(Town var1, String var2) throws AlreadyRegisteredException, NotRegisteredException;

   public abstract void renameNation(Nation var1, String var2) throws AlreadyRegisteredException, NotRegisteredException;

   public abstract void mergeNation(Nation var1, Nation var2);

   public abstract void mergeTown(Town var1, Town var2);

   public abstract void renamePlayer(Resident var1, String var2) throws AlreadyRegisteredException, NotRegisteredException;

   public abstract void renameGroup(PlotGroup var1, String var2) throws AlreadyRegisteredException;

   public abstract void renameDistrict(District var1, String var2) throws AlreadyRegisteredException;

   /** @deprecated */
   @Deprecated
   public void removeTown(Town town) {
      this.removeTown(town, DeleteTownEvent.Cause.UNKNOWN);
   }

   /** @deprecated */
   @Deprecated
   public void removeNation(Nation nation) {
      this.removeNation(nation, DeleteNationEvent.Cause.UNKNOWN, (CommandSender)null);
   }
}
