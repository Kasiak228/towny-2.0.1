package com.palmergames.bukkit.towny.utils;

import com.palmergames.adventure.text.Component;
import com.palmergames.adventure.text.event.ClickEvent;
import com.palmergames.bukkit.towny.TownyFormatter;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translator;
import com.palmergames.bukkit.towny.object.statusscreens.StatusScreen;
import com.palmergames.bukkit.util.Colors;
import com.palmergames.util.StringMgmt;
import java.util.Collection;
import java.util.List;

public class NationUtil {
   public static void addNationComponenents(Town town, StatusScreen screen, Translator translator) {
      Nation nation = town.getNationOrNull();
      if (nation != null) {
         List<String> towns = TownyFormatter.getFormattedNames((Collection)nation.getTowns());
         if (towns.size() > 10) {
            TownyFormatter.shortenOverLengthList(towns, 11, translator);
         }

         Component hover = buildNationComponentHover(town, translator, nation, towns);
         String var10002 = translator.of("status_town_nation");
         String var10003 = nation.getName();
         screen.addComponentOf("nation", TownyFormatter.colourKeyValue(var10002, var10003 + TownyFormatter.formatPopulationBrackets(nation.getTowns().size())), hover.asHoverEvent(), ClickEvent.runCommand("/towny:nation " + nation.getName()));
      }
   }

   private static Component buildNationComponentHover(Town town, Translator translator, Nation nation, List<String> towns) {
      Component hover = TownyComponents.miniMessage(Colors.translateColorCodes(String.format(TownySettings.getPAPIFormattingNation(), nation.getFormattedName()))).append((Component)Component.newline()).append(TownyComponents.miniMessage(getTownJoinedNationDate(town, translator))).append((Component)Component.newline()).append(TownyComponents.miniMessage(TownyFormatter.colourKeyValue(translator.of("status_nation_king"), nation.getCapital().getMayor().getFormattedName()))).append((Component)Component.newline()).append(TownyComponents.miniMessage(TownyFormatter.colourKeyValue(translator.of("town_plu"), StringMgmt.join((Collection)towns, ", "))));
      int nationZoneSize = town.getNationZoneSize();
      if (nationZoneSize > 0) {
         hover = hover.append(Component.newline().append(TownyComponents.miniMessage(TownyFormatter.colourKeyValue(translator.of("status_nation_zone_size"), town.isNationZoneEnabled() ? String.valueOf(nationZoneSize) : translator.of("status_off_bad")))));
      }

      hover = hover.append((Component)Component.newline()).append(translator.component("status_hover_click_for_more"));
      return hover;
   }

   private static String getTownJoinedNationDate(Town town, Translator translator) {
      return TownyFormatter.colourKeyValue(translator.of("status_joined_nation"), town.getJoinedNationAt() > 0L ? TownyFormatter.lastOnlineFormatIncludeYear.format(town.getJoinedNationAt()) : translator.of("status_unknown"));
   }

   public static boolean hasReachedMaximumAllies(Nation nation) {
      return TownySettings.getMaxNationAllies() >= 0 && nation.getAllies().size() >= TownySettings.getMaxNationAllies();
   }

   public static boolean hasReachedMaximumResidents(Nation nation) {
      int maxResidentsPerNation = TownySettings.getMaxResidentsPerNation();
      return maxResidentsPerNation > 0 && nation.getResidents().size() >= maxResidentsPerNation;
   }

   public static boolean canAddTownsResidentCount(Nation nation, int additionalResidents) {
      if (hasReachedMaximumResidents(nation)) {
         return false;
      } else {
         int maxResidentPerNation = TownySettings.getMaxResidentsPerNation();
         return maxResidentPerNation == 0 || nation.getResidents().size() + additionalResidents <= maxResidentPerNation;
      }
   }

   public static boolean hasReachedMaximumTowns(Nation nation) {
      int maxTownsPerNation = TownySettings.getMaxTownsPerNation();
      return maxTownsPerNation > 0 && nation.getTowns().size() >= maxTownsPerNation;
   }
}
