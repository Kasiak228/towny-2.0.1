package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.TownySettings;
import java.util.ArrayList;
import java.util.List;

public class MapUtil {
   public static String generateRandomNationColourAsHexCode() {
      List<String> allowedColourCodes = new ArrayList(TownySettings.getNationColorsMap().values());
      int randomIndex = (int)(Math.random() * (double)allowedColourCodes.size());
      return (String)allowedColourCodes.get(randomIndex);
   }

   public static String generateRandomTownColourAsHexCode() {
      List<String> allowedColourCodes = new ArrayList(TownySettings.getTownColorsMap().values());
      int randomIndex = (int)(Math.random() * (double)allowedColourCodes.size());
      return (String)allowedColourCodes.get(randomIndex);
   }
}
