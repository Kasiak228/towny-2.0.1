package com.palmergames.bukkit.towny.utils;

import com.google.common.base.Preconditions;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.player.PlayerCacheGetTownBlockStatusEvent;
import com.palmergames.bukkit.towny.hooks.PluginIntegrations;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.PermissionData;
import com.palmergames.bukkit.towny.object.PlayerCache;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyPermission;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.permissions.PermissionNodes;
import com.palmergames.bukkit.util.BukkitTools;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;
import org.jetbrains.annotations.NotNull;

public class PlayerCacheUtil {
   static Towny plugin = null;

   public static void initialize(Towny plugin) {
      PlayerCacheUtil.plugin = plugin;
   }

   public static PlayerCache getCache(Player player) {
      return plugin.getCache(player);
   }

   public static boolean getCachePermission(Player player, Location location, Material material, TownyPermission.ActionType action) {
      WorldCoord worldCoord = WorldCoord.parseWorldCoord(location);

      String var10000;
      try {
         PlayerCache cache = plugin.getCache(player);
         cache.updateCoord(worldCoord);
         boolean result = cache.getCachePermission(material, action);
         var10000 = player.getName();
         TownyMessaging.sendDebugMsg("Cache permissions for " + var10000 + " using " + material.getKey() + ":" + action + " = " + result);
         return result;
      } catch (NullPointerException var9) {
         PlayerCache.TownBlockStatus status = cacheStatus(player, worldCoord, fetchTownBlockStatus(player, worldCoord));
         triggerCacheCreate(player, location, worldCoord, status, material, action);
         PlayerCache cache = plugin.getCache(player);
         cache.updateCoord(worldCoord);
         boolean result = cache.getCachePermission(material, action);
         var10000 = player.getName();
         TownyMessaging.sendDebugMsg("New Cache created for " + var10000 + " using " + material.getKey() + ":" + action + ":" + status.name() + " = " + result);
         return result;
      }
   }

   private static void triggerCacheCreate(Player player, Location location, WorldCoord worldCoord, PlayerCache.TownBlockStatus status, Material material, TownyPermission.ActionType action) {
      boolean permission = getPermission(player, status, worldCoord, material, action);
      PlayerCache cache = plugin.getCache(player);
      cache.updateCoord(worldCoord);
      switch(action) {
      case BUILD:
         cache.setBuildPermission(material, permission);
         break;
      case DESTROY:
         cache.setDestroyPermission(material, permission);
         break;
      case SWITCH:
         cache.setSwitchPermission(material, permission);
         break;
      case ITEM_USE:
         cache.setItemUsePermission(material, permission);
      }

      String var10000 = player.getName();
      TownyMessaging.sendDebugMsg(var10000 + " (" + worldCoord + ") Cached " + action.getCommonName() + ": " + permission);
   }

   public static PlayerCache.TownBlockStatus cacheStatus(Player player, WorldCoord worldCoord, PlayerCache.TownBlockStatus townBlockStatus) {
      PlayerCache cache = plugin.getCache(player);
      cache.updateCoord(worldCoord);
      cache.setStatus(townBlockStatus);
      TownyMessaging.sendDebugMsg(player.getName() + " (" + worldCoord + ") Cached Status: " + townBlockStatus);
      return townBlockStatus;
   }

   public static void cacheBlockErrMsg(Player player, String msg) {
      PlayerCache cache = plugin.getCache(player);
      cache.setBlockErrMsg(msg);
   }

   public static PlayerCache.TownBlockStatus fetchTownBlockStatus(Player player, WorldCoord worldCoord) {
      PlayerCache.TownBlockStatus status = getTownBlockStatus(player, worldCoord);
      PlayerCacheGetTownBlockStatusEvent event = new PlayerCacheGetTownBlockStatusEvent(player, worldCoord, status);
      BukkitTools.fireEvent(event);
      return event.getTownBlockStatus();
   }

   public static PlayerCache.TownBlockStatus getTownBlockStatus(Player player, WorldCoord worldCoord) {
      TownyWorld townyWorld = worldCoord.getTownyWorld();
      if (townyWorld != null && townyWorld.isUsingTowny()) {
         TownBlock townBlock = worldCoord.getTownBlockOrNull();
         Town town = townBlock != null ? townBlock.getTownOrNull() : null;
         if (townBlock != null && town != null) {
            Resident resident = TownyUniverse.getInstance().getResident(player.getUniqueId());
            if (resident == null) {
               if (PluginIntegrations.getInstance().isNPC(player)) {
                  return PlayerCache.TownBlockStatus.NOT_REGISTERED;
               }

               resident = TownyUniverse.getInstance().getResident(player.getName());
               if (resident == null) {
                  plugin.getLogger().warning("Failed to fetch resident: " + player.getName());
                  return PlayerCache.TownBlockStatus.NOT_REGISTERED;
               }
            }

            if (town.isMayor(resident)) {
               return PlayerCache.TownBlockStatus.TOWN_OWNER;
            } else if (!town.hasTrustedResident(resident) || townBlock.hasResident() && !TownySettings.doTrustedPlayersGetPermsOnPersonallyOwnedLand()) {
               if (townBlock.hasTrustedResident(resident) && !townBlock.hasResident(resident)) {
                  return PlayerCache.TownBlockStatus.PLOT_TRUSTED;
               } else {
                  Resident owner = townBlock.getResidentOrNull();
                  if (owner != null) {
                     if (resident == owner) {
                        return PlayerCache.TownBlockStatus.PLOT_OWNER;
                     } else if (owner.hasFriend(resident) && !CombatUtil.isEnemy(resident, owner)) {
                        return PlayerCache.TownBlockStatus.PLOT_FRIEND;
                     } else if (resident.hasTown() && CombatUtil.isSameTown(owner, resident)) {
                        return PlayerCache.TownBlockStatus.PLOT_TOWN;
                     } else {
                        return resident.hasTown() && CombatUtil.isAlly(owner, resident) ? PlayerCache.TownBlockStatus.PLOT_ALLY : PlayerCache.TownBlockStatus.OUTSIDER;
                     }
                  } else if (!resident.hasTown()) {
                     return PlayerCache.TownBlockStatus.OUTSIDER;
                  } else if (town.hasResident(resident)) {
                     return PlayerCache.TownBlockStatus.TOWN_RESIDENT;
                  } else if (CombatUtil.isSameNation(town, resident.getTownOrNull())) {
                     return PlayerCache.TownBlockStatus.TOWN_NATION;
                  } else if (CombatUtil.isAlly(town, resident.getTownOrNull())) {
                     return PlayerCache.TownBlockStatus.TOWN_ALLY;
                  } else {
                     return CombatUtil.isEnemy(resident.getTownOrNull(), town) ? PlayerCache.TownBlockStatus.ENEMY : PlayerCache.TownBlockStatus.OUTSIDER;
                  }
               }
            } else {
               return PlayerCache.TownBlockStatus.TOWN_TRUSTED;
            }
         } else {
            return TownySettings.getNationZonesEnabled() ? TownyAPI.getInstance().hasNationZone(worldCoord) : PlayerCache.TownBlockStatus.UNCLAIMED_ZONE;
         }
      } else {
         return PlayerCache.TownBlockStatus.OFF_WORLD;
      }
   }

   private static boolean getPermission(Player player, PlayerCache.TownBlockStatus status, WorldCoord pos, Material material, TownyPermission.ActionType action) {
      TownyUniverse townyUniverse = TownyUniverse.getInstance();
      if (townyUniverse.getPermissionSource().isTownyAdmin((Permissible)player)) {
         return true;
      } else {
         Town targetTown = pos.getTownOrNull();
         if (targetTown != null && TownySettings.isTownBankruptcyEnabled() && action == TownyPermission.ActionType.BUILD && targetTown.isBankrupt() && !targetTown.isRuined()) {
            cacheBlockErrMsg(player, Translatable.of("msg_err_bankrupt_town_cannot_build").forLocale((CommandSender)player));
            return false;
         } else if (status != PlayerCache.TownBlockStatus.OFF_WORLD && status != PlayerCache.TownBlockStatus.PLOT_OWNER && status != PlayerCache.TownBlockStatus.TOWN_OWNER) {
            Resident res = townyUniverse.getResident(player.getUniqueId());
            if (res == null) {
               cacheBlockErrMsg(player, Translatable.of("msg_err_not_registered").forLocale((CommandSender)player));
               return false;
            } else if (status == PlayerCache.TownBlockStatus.NOT_REGISTERED) {
               cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error").forLocale((CommandSender)player));
               return false;
            } else {
               if (TownyAPI.getInstance().isWilderness(pos)) {
                  boolean hasWildOverride = townyUniverse.getPermissionSource().hasWildOverride(pos.getTownyWorld(), player, material, action);
                  if (status == PlayerCache.TownBlockStatus.UNCLAIMED_ZONE) {
                     if (hasWildOverride) {
                        return true;
                     }

                     cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_wild", Translatable.of(action.toString())).forLocale((CommandSender)player));
                     return false;
                  }

                  if (TownySettings.getNationZonesEnabled() && status == PlayerCache.TownBlockStatus.NATION_ZONE) {
                     if (res.hasPermissionNode(PermissionNodes.TOWNY_ADMIN_NATION_ZONE.getNode())) {
                        return true;
                     }

                     if (!hasWildOverride) {
                        cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_wild", Translatable.of(action.toString())).forLocale((CommandSender)player));
                        return false;
                     }

                     Town nearestTown = pos.getTownyWorld().getClosestTownWithNationFromCoord(pos.getCoord(), (Town)null);
                     Nation nearestNation = nearestTown.getNationOrNull();
                     if (nearestNation.hasResident(res)) {
                        if (TownySettings.getNationZonesSkipConqueredTowns() && res.getTownOrNull().isConquered() && !nearestTown.hasResident(res)) {
                           cacheBlockErrMsg(player, Translatable.of("nation_zone_conquered_status_denies_use").forLocale(res));
                           return false;
                        }

                        if (TownySettings.getNationZonesProtectsConqueredTowns() && nearestTown.isConquered() && !nearestTown.hasResident(res)) {
                           cacheBlockErrMsg(player, Translatable.of("nation_zone_conquered_status_denies_use").forLocale(res));
                           return false;
                        }

                        return true;
                     }

                     cacheBlockErrMsg(player, Translatable.of("nation_zone_this_area_under_protection_of", pos.getTownyWorld().getFormattedUnclaimedZoneName(), nearestNation.getName()).forLocale((CommandSender)player));
                     return false;
                  }
               }

               TownBlock townBlock = pos.getTownBlockOrNull();
               if (townyUniverse.getPermissionSource().hasAllTownOverride(player, material, action)) {
                  return true;
               } else {
                  if (targetTown.equals(TownyAPI.getInstance().getResidentTownOrNull(res))) {
                     if (townyUniverse.getPermissionSource().hasOwnTownOverride(player, material, action)) {
                        return true;
                     }

                     if (!townBlock.hasResident() && townyUniverse.getPermissionSource().hasTownOwnedOverride(player, material, action)) {
                        return true;
                     }
                  }

                  if (townBlock.getPermissionOverrides().containsKey(res) && ((PermissionData)townBlock.getPermissionOverrides().get(res)).getPermissionTypes()[action.getIndex()] != PermissionGUIUtil.SetPermissionType.UNSET) {
                     PermissionGUIUtil.SetPermissionType type = ((PermissionData)townBlock.getPermissionOverrides().get(res)).getPermissionTypes()[action.getIndex()];
                     if (type == PermissionGUIUtil.SetPermissionType.NEGATED) {
                        cacheBlockErrMsg(player, Translatable.of("msg_cache_block_err", Translatable.of(action.toString())).forLocale((CommandSender)player));
                     }

                     return type.equals(PermissionGUIUtil.SetPermissionType.SET);
                  } else if (status != PlayerCache.TownBlockStatus.PLOT_TRUSTED && status != PlayerCache.TownBlockStatus.TOWN_TRUSTED) {
                     if (status == PlayerCache.TownBlockStatus.PLOT_FRIEND) {
                        if (townBlock.getPermissions().getResidentPerm(action) && isAllowedMaterial(townBlock, material, action)) {
                           return true;
                        } else {
                           cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_plot", Translatable.of("msg_cache_block_error_plot_friends"), Translatable.of(action.toString())).forLocale((CommandSender)player));
                           return false;
                        }
                     } else if (status == PlayerCache.TownBlockStatus.PLOT_TOWN) {
                        if (townBlock.getPermissions().getNationPerm(action) && isAllowedMaterial(townBlock, material, action)) {
                           return true;
                        } else {
                           cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_plot", Translatable.of("msg_cache_block_error_plot_town_members"), Translatable.of(action.toString())).forLocale((CommandSender)player));
                           return false;
                        }
                     } else if (status == PlayerCache.TownBlockStatus.TOWN_RESIDENT) {
                        if (townBlock.getPermissions().getResidentPerm(action) && isAllowedMaterial(townBlock, material, action)) {
                           return true;
                        } else {
                           cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_town_resident", Translatable.of(action.toString())).forLocale((CommandSender)player));
                           return false;
                        }
                     } else if (status == PlayerCache.TownBlockStatus.TOWN_NATION) {
                        if (townBlock.getPermissions().getNationPerm(action) && isAllowedMaterial(townBlock, material, action)) {
                           return true;
                        } else {
                           cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_town_nation", Translatable.of(action.toString())).forLocale((CommandSender)player));
                           return false;
                        }
                     } else if (status != PlayerCache.TownBlockStatus.PLOT_ALLY && status != PlayerCache.TownBlockStatus.TOWN_ALLY) {
                        if (status != PlayerCache.TownBlockStatus.OUTSIDER && status != PlayerCache.TownBlockStatus.ENEMY) {
                           if (status == PlayerCache.TownBlockStatus.WARZONE) {
                              return true;
                           } else {
                              TownyMessaging.sendErrorMsg((Object)player, (String)("Error updating " + action.toString() + " permission."));
                              return false;
                           }
                        } else if (townBlock.getPermissions().getOutsiderPerm(action) && isAllowedMaterial(townBlock, material, action)) {
                           return true;
                        } else {
                           if (townBlock.hasResident()) {
                              cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_plot", Translatable.of("msg_cache_block_error_plot_outsiders"), Translatable.of(action.toString())).forLocale((CommandSender)player));
                           } else {
                              cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_town_outsider", Translatable.of(action.toString())).forLocale((CommandSender)player));
                           }

                           return false;
                        }
                     } else if (townBlock.getPermissions().getAllyPerm(action) && isAllowedMaterial(townBlock, material, action)) {
                        return true;
                     } else {
                        if (status == PlayerCache.TownBlockStatus.PLOT_ALLY) {
                           cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_plot", Translatable.of("msg_cache_block_error_plot_allies"), Translatable.of(action.toString())).forLocale((CommandSender)player));
                        } else {
                           cacheBlockErrMsg(player, Translatable.of("msg_cache_block_error_town_allies", Translatable.of(action.toString())).forLocale((CommandSender)player));
                        }

                        return false;
                     }
                  } else {
                     return true;
                  }
               }
            }
         } else {
            return true;
         }
      }
   }

   private static boolean isAllowedMaterial(TownBlock townBlock, Material material, TownyPermission.ActionType action) {
      return (action == TownyPermission.ActionType.BUILD || action == TownyPermission.ActionType.DESTROY) && !townBlock.getData().getAllowedBlocks().isEmpty() ? townBlock.getData().getAllowedBlocks().contains(material) : true;
   }

   public static boolean isOwnerCache(@NotNull PlayerCache cache) {
      Preconditions.checkNotNull(cache, "Cache cannot be null.");

      PlayerCache.TownBlockStatus status;
      try {
         status = cache.getStatus();
      } catch (NullPointerException var3) {
         return false;
      }

      return status.equals(PlayerCache.TownBlockStatus.ADMIN) || status.equals(PlayerCache.TownBlockStatus.PLOT_OWNER) || status.equals(PlayerCache.TownBlockStatus.TOWN_OWNER);
   }
}
