package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.util.EntityLists;
import com.palmergames.util.JavaUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class EntityTypeUtil {
   private static int attempted = 0;
   private static final Map<EntityType, Material> ENTITY_TYPE_MATERIAL_MAP = (Map)JavaUtil.make(() -> {
      Map<EntityType, Material> map = new HashMap();
      register(map, "axolotl", "axolotl_bucket");
      register(map, "cod", "cod");
      register(map, "salmon", "salmon");
      register(map, "pufferfish", "pufferfish");
      register(map, "tropical_fish", "tropical_fish");
      register(map, "tadpole", "tadpole_bucket");
      register(map, "parrot", "parrot_spawn_egg");
      register(map, "item_frame", "item_frame");
      register(map, "glow_item_frame", "glow_item_frame");
      register(map, "painting", "painting");
      register(map, "armor_stand", "armor_stand");
      register(map, "leash_knot", "lead");
      register(map, "end_crystal", "end_crystal");
      register(map, "minecart", "minecart");
      register(map, "spawner_minecart", "minecart");
      register(map, "chest_minecart", "chest_minecart");
      register(map, "furnace_minecart", "furnace_minecart");
      register(map, "command_block_minecart", "command_block_minecart");
      register(map, "hopper_minecart", "hopper_minecart");
      register(map, "tnt_minecart", "tnt_minecart");
      register(map, "boat", "oak_boat");
      register(map, "chest_boat", "oak_chest_boat");
      register(map, "cow", "cow_spawn_egg");
      register(map, "goat", "goat_spawn_egg");
      register(map, "mooshroom", "mooshroom_spawn_egg");
      int var10000 = attempted;
      TownyMessaging.sendDebugMsg("[EntityTypeUtil] Attempted: " + var10000 + " | Registered: " + map.size());
      return map;
   });

   public static boolean isInstanceOfAny(List<Class<?>> classes, Object obj) {
      Iterator var2 = classes.iterator();

      Class c;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         c = (Class)var2.next();
      } while(!c.isInstance(obj));

      return true;
   }

   public static boolean isProtectedEntity(Entity entity) {
      return isInstanceOfAny(TownySettings.getProtectedEntityTypes(), entity);
   }

   public static List<Class<?>> parseLivingEntityClassNames(List<String> mobClassNames, String errorPrefix) {
      List<Class<?>> livingEntityClasses = new ArrayList();
      Iterator var3 = mobClassNames.iterator();

      while(var3.hasNext()) {
         String mobClassName = (String)var3.next();
         if (!mobClassName.isEmpty()) {
            try {
               Class<?> c = Class.forName("org.bukkit.entity." + mobClassName);
               livingEntityClasses.add(c);
            } catch (ClassNotFoundException var6) {
               TownyMessaging.sendErrorMsg(String.format("%s%s is not an acceptable class.", errorPrefix, mobClassName));
            } catch (Exception var7) {
               TownyMessaging.sendErrorMsg(String.format("%s%s is not an acceptable living entity.", errorPrefix, mobClassName));
            }
         }
      }

      return livingEntityClasses;
   }

   @Nullable
   public static Material parseEntityToMaterial(EntityType entityType) {
      Material lookup = (Material)ENTITY_TYPE_MATERIAL_MAP.get(entityType);
      return lookup != null ? lookup : (Material)Registry.MATERIAL.get(entityType.getKey());
   }

   @NotNull
   public static Material parseEntityToMaterial(EntityType entityType, @NotNull Material defaultValue) {
      Material material = parseEntityToMaterial(entityType);
      return material == null ? defaultValue : material;
   }

   public static boolean isExplosive(EntityType entityType) {
      return EntityLists.EXPLOSIVE.contains(entityType);
   }

   public static boolean isPVPExplosive(EntityType entityType) {
      return EntityLists.PVP_EXPLOSIVE.contains(entityType);
   }

   public static boolean isPVMExplosive(EntityType entityType) {
      return EntityLists.PVE_EXPLOSIVE.contains(entityType);
   }

   private static void register(Map<EntityType, Material> map, String name, String mat) {
      ++attempted;
      EntityType type = (EntityType)Registry.ENTITY_TYPE.get(NamespacedKey.minecraft(name));
      Material material = (Material)Registry.MATERIAL.get(NamespacedKey.minecraft(mat));
      if (type != null && material != null) {
         map.put(type, material);
      } else {
         TownyMessaging.sendDebugMsg("[EntityTypeUtil] Could not map " + name + " to " + mat);
      }
   }
}
