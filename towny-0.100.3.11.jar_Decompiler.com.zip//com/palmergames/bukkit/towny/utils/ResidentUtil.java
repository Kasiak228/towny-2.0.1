package com.palmergames.bukkit.towny.utils;

import com.palmergames.adventure.text.Component;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.teleport.OutlawTeleportEvent;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.ResidentList;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownBlockTypeCache;
import com.palmergames.bukkit.towny.object.TownBlockTypeHandler;
import com.palmergames.bukkit.towny.object.TownyInventory;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.gui.SelectionGUI;
import com.palmergames.bukkit.towny.object.metadata.BooleanDataField;
import com.palmergames.bukkit.towny.permissions.PermissionNodes;
import com.palmergames.bukkit.towny.tasks.CooldownTimerTask;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.TimeMgmt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Level;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ResidentUtil {
   private static BooleanDataField borderMeta = new BooleanDataField("bordertitles");

   public static List<Resident> getOnlineResidentsViewable(Player viewer, ResidentList residentList) {
      return (List)residentList.getResidents().stream().filter((res) -> {
         return viewer != null ? res.isOnline() && BukkitTools.playerCanSeePlayer(viewer, res.getPlayer()) : res.isOnline();
      }).collect(Collectors.toList());
   }

   public static List<Resident> getValidatedResidents(CommandSender sender, List<String> names) {
      List<Resident> residents = new ArrayList();
      Iterator var3 = names.iterator();

      while(var3.hasNext()) {
         String name = (String)var3.next();
         List<Player> matches = BukkitTools.matchPlayer(name);
         if (matches.size() > 1) {
            Stream var10001 = matches.stream().map(Player::getName);
            TownyMessaging.sendErrorMsg((Object)sender, (String)("Multiple players selected: " + (String)var10001.collect(Collectors.joining(", "))));
         } else {
            String targetName = !matches.isEmpty() ? ((Player)matches.get(0)).getName() : name;
            Resident target = TownyUniverse.getInstance().getResident(targetName);
            if (target != null) {
               residents.add(target);
            } else {
               TownyMessaging.sendErrorMsg(sender, Translatable.of("msg_err_not_registered_1", targetName));
            }
         }
      }

      return residents;
   }

   public static List<Resident> getValidatedResidentsOfTown(CommandSender sender, Town town, String[] names) {
      List<Resident> residents = new ArrayList();
      String[] var4 = names;
      int var5 = names.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String name = var4[var6];
         if (town.hasResident(name)) {
            residents.add(TownyAPI.getInstance().getResident(name));
         } else {
            TownyMessaging.sendErrorMsg(sender, Translatable.of("msg_err_not_same_town", name));
         }
      }

      return residents;
   }

   public static void openGUIInventory(Resident resident, List<String> list, String name) {
      ArrayList<ItemStack> items = new ArrayList();
      Iterator var4 = list.iterator();

      while(var4.hasNext()) {
         String item = (String)var4.next();
         Material mat = Material.getMaterial(item);
         if (mat != null) {
            items.add(new ItemStack(mat));
         }
      }

      createTownyGUI(resident, items, name);
   }

   public static void openGUIInventory(Resident resident, Collection<Material> set, String name) {
      ArrayList<ItemStack> items = new ArrayList();
      Iterator var4 = set.iterator();

      while(var4.hasNext()) {
         Material material = (Material)var4.next();
         items.add(new ItemStack(material));
      }

      createTownyGUI(resident, items, name);
   }

   public static void openSelectionGUI(Resident resident, SelectionGUI.SelectionType selectionType) {
      String inventoryName = Translatable.of("gui_title_select_plot_type").forLocale(resident);
      Inventory page = getBlankPage(inventoryName);
      ArrayList<Inventory> pages = new ArrayList();

      ItemStack item;
      for(Iterator var5 = TownBlockTypeHandler.getTypes().values().iterator(); var5.hasNext(); page.addItem(new ItemStack[]{item})) {
         TownBlockType townBlockType = (TownBlockType)var5.next();
         item = new ItemStack(Material.GRASS_BLOCK);
         ItemMeta meta = item.getItemMeta();
         meta.setDisplayName("§6" + townBlockType.getFormattedName());
         item.setItemMeta(meta);
         if (page.firstEmpty() == 46) {
            pages.add(page);
            page = getBlankPage(inventoryName);
         }
      }

      pages.add(page);
      resident.setGUIPageNum(0);
      resident.setGUIPages(pages);
      new SelectionGUI(resident, (Inventory)pages.get(0), inventoryName, selectionType);
   }

   private static void createTownyGUI(Resident resident, ArrayList<ItemStack> items, String name) {
      Inventory page = getBlankPage(name);
      ArrayList<Inventory> pages = new ArrayList();

      ItemStack item;
      for(Iterator var5 = items.iterator(); var5.hasNext(); page.addItem(new ItemStack[]{item})) {
         item = (ItemStack)var5.next();
         if (page.firstEmpty() == 46) {
            pages.add(page);
            page = getBlankPage(name);
         }
      }

      pages.add(page);
      resident.setGUIPages(pages);
      resident.setGUIPageNum(0);
      new TownyInventory(resident, (Inventory)pages.get(0), name);
   }

   public static Inventory getBlankPage(String name) {
      Inventory page = Bukkit.createInventory((InventoryHolder)null, 54, name);
      ItemStack nextpage = new ItemStack(Material.ARROW);
      ItemMeta meta = nextpage.getItemMeta();
      meta.setDisplayName("§6Next");
      nextpage.setItemMeta(meta);
      ItemStack prevpage = new ItemStack(Material.ARROW);
      meta = prevpage.getItemMeta();
      meta.setDisplayName("§6Back");
      prevpage.setItemMeta(meta);
      page.setItem(53, nextpage);
      page.setItem(45, prevpage);
      return page;
   }

   public static Resident createAndGetNPCResident() {
      Resident npc = null;

      try {
         String name = nextNpcName();
         UUID npcUUID = UUID.randomUUID();
         TownyUniverse.getInstance().getDataSource().newResident(name, npcUUID);
         npc = TownyUniverse.getInstance().getResident(npcUUID);
         npc.setRegistered(System.currentTimeMillis());
         npc.setLastOnline(0L);
         npc.setNPC(true);
         npc.save();
      } catch (TownyException var3) {
         Towny.getPlugin().getLogger().log(Level.WARNING, "exception occurred while creating new npc resident", var3);
      }

      return npc;
   }

   public static String nextNpcName() throws TownyException {
      int i = 0;

      do {
         String var10000 = TownySettings.getNPCPrefix();
         ++i;
         String name = var10000 + i;
         if (!TownyUniverse.getInstance().hasResident(name)) {
            return name;
         }
      } while(i <= 100000);

      throw new TownyException(Translatable.of("msg_err_too_many_npc"));
   }

   public static void reduceResidentCountToFitTownMaxPop(Town town) {
      if (TownySettings.getMaxResidentsPerTown() != 0) {
         int max = TownySettings.getMaxResidentsForTown(town);
         if (town.getNumResidents() > max) {
            int i = 1;
            List<Resident> toRemove = new ArrayList(town.getNumResidents() - max);

            for(Iterator var4 = town.getResidents().iterator(); var4.hasNext(); ++i) {
               Resident res = (Resident)var4.next();
               if (i > max) {
                  toRemove.add(res);
               }
            }

            if (!toRemove.isEmpty()) {
               toRemove.stream().forEach((resx) -> {
                  resx.removeTown();
               });
            }

         }
      }
   }

   public static void outlawEnteredTown(Resident outlaw, Town town, Location location) {
      OutlawTeleportEvent outlawEvent = new OutlawTeleportEvent(outlaw, town, location);
      if (!BukkitTools.isEventCancelled(outlawEvent)) {
         boolean hasBypassNode = outlaw.hasPermissionNode(PermissionNodes.TOWNY_ADMIN_OUTLAW_TELEPORT_BYPASS.getNode()) && !outlaw.hasMode("adminbypass");
         if (TownySettings.doTownsGetWarnedOnOutlaw() && !hasBypassNode && !CooldownTimerTask.hasCooldown(outlaw.getName(), CooldownTimerTask.CooldownType.OUTLAW_WARNING)) {
            if (TownySettings.getOutlawWarningMessageCooldown() > 0) {
               CooldownTimerTask.addCooldownTimer(outlaw.getName(), CooldownTimerTask.CooldownType.OUTLAW_WARNING);
            }

            TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_outlaw_town_notify", outlaw.getFormattedName()));
         }

         if (!TownySettings.canOutlawsEnterTowns() && !hasBypassNode) {
            if (TownySettings.getOutlawTeleportWarmup() > 0) {
               TownyMessaging.sendMsg(outlaw, Translatable.of("msg_outlaw_kick_cooldown", town, TimeMgmt.formatCountdownTime((long)TownySettings.getOutlawTeleportWarmup())));
            }

            Towny.getPlugin().getScheduler().runLater(() -> {
               Player player = outlaw.getPlayer();
               if (player != null) {
                  Town currTown = TownyAPI.getInstance().getTown(player.getLocation());
                  if (currTown != null && currTown == town) {
                     SpawnUtil.outlawTeleport(town, outlaw);
                  }
               }
            }, (long)TownySettings.getOutlawTeleportWarmup() * 20L);
         } else {
            TownyMessaging.sendMsg(outlaw, Translatable.of("msg_you_are_an_outlaw_in_this_town", town));
            if (town.getTownBlockTypeCache().getNumTownBlocks(TownBlockType.JAIL, TownBlockTypeCache.CacheType.ALL) < 1) {
               return;
            }

            Translatable bailMsg = null;
            if (TownySettings.isAllowingBail() && TownyEconomyHandler.isActive()) {
               double bail = TownySettings.getBailAmount();
               if (outlaw.isMayor()) {
                  bail = outlaw.isKing() ? TownySettings.getBailAmountKing() : TownySettings.getBailAmountMayor();
               }

               bailMsg = Translatable.of("msg_you_are_an_outlaw_in_this_town_bail_amount", TownyEconomyHandler.getFormattedBalance(bail));
            }

            Translatable timeMsg = Translatable.of("msg_you_are_an_outlaw_in_this_town_jail_time", TownySettings.getJailedOutlawJailHours());
            if (bailMsg != null) {
               timeMsg.append((Component)Component.space()).append(bailMsg);
            }

            TownyMessaging.sendMsg(outlaw, timeMsg);
         }

      }
   }

   public static void toggleResidentBorderTitles(Resident resident, Optional<Boolean> choice) {
      boolean borderTitleActive = (Boolean)choice.orElse(!resident.isSeeingBorderTitles());
      MetaDataUtil.setBoolean(resident, borderMeta, borderTitleActive, true);
      TownyMessaging.sendMsg(resident, Translatable.of("msg_border_titles_toggled", borderTitleActive ? Translatable.of("enabled") : Translatable.of("disabled")));
   }
}
