package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.object.Nameable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class NameUtil {
   public static <T extends Nameable> List<String> getNames(Collection<T> objs) {
      ArrayList<String> names = new ArrayList();
      Iterator var2 = objs.iterator();

      while(var2.hasNext()) {
         Nameable obj = (Nameable)var2.next();
         if (obj.getName() != null) {
            names.add(obj.getName());
         }
      }

      return names;
   }

   public static List<String> filterByStart(List<String> list, String startingWith) {
      return list != null && startingWith != null ? (List)list.stream().filter((name) -> {
         return name.toLowerCase(Locale.ROOT).startsWith(startingWith.toLowerCase(Locale.ROOT));
      }).collect(Collectors.toList()) : Collections.emptyList();
   }

   public static String getTagFromName(String name) {
      return name.substring(0, Math.min(name.length(), TownySettings.getMaxTagLength())).replace("_", "").replace("-", "");
   }
}
