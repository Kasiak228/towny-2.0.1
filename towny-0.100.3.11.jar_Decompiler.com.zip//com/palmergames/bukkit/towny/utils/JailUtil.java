package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.resident.ResidentJailEvent;
import com.palmergames.bukkit.towny.event.resident.ResidentPreJailEvent;
import com.palmergames.bukkit.towny.event.resident.ResidentUnjailEvent;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.Position;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translator;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.jail.JailReason;
import com.palmergames.bukkit.towny.object.jail.UnJailReason;
import com.palmergames.bukkit.util.BookFactory;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class JailUtil {
   private static List<Resident> queuedJailedResidents = new ArrayList();

   public static void jailResident(Resident resident, Jail jail, int cell, int hours, JailReason reason, CommandSender jailer) {
      if (TownySettings.isAllowingBail() && TownyEconomyHandler.isActive()) {
         double bail = TownySettings.getBailAmount();
         if (resident.isMayor()) {
            bail = resident.isKing() ? TownySettings.getBailAmountKing() : TownySettings.getBailAmountMayor();
         }

         jailResidentWithBail(resident, jail, cell, hours, bail, reason, jailer);
      } else {
         jailResidentWithBail(resident, jail, cell, hours, 0.0D, reason, jailer);
      }

   }

   public static void jailResidentWithBail(Resident resident, Jail jail, int cell, int hours, double bail, JailReason reason, CommandSender jailer) {
      String senderName = jailer instanceof Player ? jailer.getName() : "Admin";
      ResidentPreJailEvent event = new ResidentPreJailEvent(resident, jail, cell, hours, bail, reason);
      if (BukkitTools.isEventCancelled(event)) {
         TownyMessaging.sendErrorMsg((Object)jailer, (String)event.getCancelMessage());
      } else {
         Player jailedPlayer = resident.getPlayer();
         if (jailedPlayer == null) {
            TownyMessaging.sendErrorMsg(jailer, Translatable.of("msg_player_is_not_online", resident.getName()));
         } else {
            if (TownySettings.isJailBookEnabled()) {
               sendJailedBookToResident(jailedPlayer, reason, hours, bail);
            }

            switch(reason) {
            case MAYOR:
               if (TownySettings.doesJailingPreventLoggingOut()) {
                  addJailedPlayerToLogOutMap(resident);
               }
            case OUTLAW_DEATH:
            case PRISONER_OF_WAR:
            default:
               String jailName = jail.hasName() ? jail.getName() : Translatable.of("jail_sing").toString();
               if (TownySettings.isAllowingBail() && bail > 0.0D && TownyEconomyHandler.isActive()) {
                  TownyMessaging.sendPrefixedTownMessage(jail.getTown(), Translatable.of("msg_player_has_been_sent_to_jail_into_cell_number_x_for_x_hours_by_x_for_x_bail", resident.getName(), jailName, cell, hours, bail, senderName));
               } else {
                  TownyMessaging.sendPrefixedTownMessage(jail.getTown(), Translatable.of("msg_player_has_been_sent_to_jail_into_cell_number_x_for_x_hours_by_x", resident.getName(), jailName, cell, hours, senderName));
               }

               resident.setJail(jail);
               resident.setJailCell(Math.max(0, cell - 1));
               resident.setJailHours(hours);
               resident.setJailBailCost(bail);
               resident.save();
               TownyUniverse.getInstance().getJailedResidentMap().add(resident);
               Translator translator = Translator.locale((CommandSender)jailedPlayer);
               TownyMessaging.sendMsg((CommandSender)jailedPlayer, (String)translator.of("msg_you've_been_jailed_for_x_hours", hours));
               if (TownySettings.isAllowingBail() && bail > 0.0D && TownyEconomyHandler.isActive()) {
                  TownyMessaging.sendMsg((CommandSender)jailedPlayer, (String)translator.of("msg_you_have_been_jailed_your_bail_is_x", bail));
               }

               TownyMessaging.sendTitleMessageToResident(resident, translator.of("msg_you_have_been_jailed"), translator.of("msg_run_to_the_wilderness_or_wait_for_a_jailbreak"));
               teleportToJail(resident);
               ResidentJailEvent var10000 = new ResidentJailEvent;
               Player var10004;
               if (jailer instanceof Player) {
                  Player player = (Player)jailer;
                  var10004 = player;
               } else {
                  var10004 = null;
               }

               var10000.<init>(resident, reason, var10004);
               BukkitTools.fireEvent(var10000);
            }
         }
      }
   }

   public static void unJailResident(Resident resident, UnJailReason reason) {
      Jail jail = resident.getJail();
      String jailName = jail.hasName() ? jail.getName() : ", cell unknown.";
      Town town = null;
      switch(reason) {
      case ESCAPE:
         town = resident.getTownOrNull();
         if (town != null) {
            TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_player_escaped_jail_into_wilderness", resident.getName(), jail.getWildName()));
         } else {
            TownyMessaging.sendMsg(resident, Translatable.of("msg_you_have_been_freed_from_jail"));
         }

         if (town != null && !town.getUUID().equals(jail.getTown().getUUID())) {
            TownyMessaging.sendPrefixedTownMessage(jail.getTown(), Translatable.of("msg_player_escaped_jail_into_wilderness", resident.getName(), jail.getWildName()));
         }

         unJailResident(resident);
         break;
      case LEFT_TOWN:
         town = resident.getTownOrNull();
         TownyMessaging.sendMsg(resident, Translatable.of("msg_you_have_been_freed_from_jail"));
         TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_player_escaped_jail_by_leaving_town", resident.getName()));
         unJailResident(resident);
         break;
      case BAIL:
         unjailAndTeleportAwayFromJail(resident);
         TownyMessaging.sendMsg(resident, Translatable.of("msg_you_have_paid_bail"));
         TownyMessaging.sendPrefixedTownMessage(jail.getTown(), Translatable.of("msg_has_paid_bail", resident.getName()));
         break;
      case SENTENCE_SERVED:
         unjailAndTeleportAwayFromJail(resident);
         TownyMessaging.sendMsg(resident, Translatable.of("msg_you_have_served_your_sentence_and_are_free"));
         TownyMessaging.sendPrefixedTownMessage(jail.getTown(), Translatable.of("msg_x_has_served_their_sentence_and_is_free", resident.getName()));
         break;
      case OUT_OF_SPACE:
         unjailAndTeleportAwayFromJail(resident);
         TownyMessaging.sendMsg(resident, Translatable.of("msg_you_were_released_as_town_ran_out_of_slots"));
         TownyMessaging.sendPrefixedTownMessage(jail.getTown(), Translatable.of("msg_x_has_been_released_as_jail_slots_ran_out", resident.getName()));
         break;
      case INSUFFICIENT_FUNDS:
         unjailAndTeleportAwayFromJail(resident);
         TownyMessaging.sendMsg(resident, Translatable.of("msg_you_were_released_as_town_ran_out_of_upkeep_funds"));
         TownyMessaging.sendPrefixedTownMessage(jail.getTown(), Translatable.of("msg_x_has_been_released_ran_out_of_upkeep_funds", resident.getName()));
         break;
      case PARDONED:
      case JAIL_DELETED:
      case ADMIN:
         unjailAndTeleportAwayFromJail(resident);
         TownyMessaging.sendMsg(resident, Translatable.of("msg_you_have_been_freed_from_jail"));
         TownyMessaging.sendPrefixedTownMessage(jail.getTown(), Translatable.of("msg_x_has_been_freed_from_x", resident.getName(), jailName));
         break;
      case JAILBREAK:
         TownyMessaging.sendMsg(resident, Translatable.of("msg_you_have_been_freed_via_jailbreak"));
         unJailResident(resident);
      }

      BukkitTools.fireEvent(new ResidentUnjailEvent(resident, reason));
   }

   public static void unJailResident(Resident resident) {
      TownyUniverse.getInstance().getJailedResidentMap().remove(resident);
      resident.setJailCell(0);
      resident.setJailHours(0);
      resident.setJail((Jail)null);
      resident.setJailBailCost(0.0D);
      resident.save();
   }

   private static void sendJailedBookToResident(Player player, JailReason reason, int hours, double cost) {
      Translator translator = Translator.locale((CommandSender)player);
      String pages = getJailBookPages(player, reason, hours, cost, translator);
      ItemStack jailBook = new ItemStack(BookFactory.makeBook(translator.of("msg_jailed_title"), translator.of("msg_jailed_author"), pages));
      Towny.getPlugin().getScheduler().runLater((Entity)player, (Runnable)(() -> {
         player.getInventory().addItem(new ItemStack[]{jailBook});
      }), 1L);
   }

   private static String getJailBookPages(Player player, JailReason reason, int hours, double cost, Translator translator) {
      String pages = translator.of("msg_jailed_handbook_1", translator.of(reason.getCause()));
      pages = pages + translator.of("msg_jailed_handbook_2") + "\n\n";
      pages = pages + translator.of("msg_jailed_handbook_3", hours) + "\n\n";
      pages = pages + (TownySettings.JailDeniesTownLeave() ? translator.of("msg_jailed_handbook_4_cant") : translator.of("msg_jailed_handbook_4_can") + "\n");
      if (TownySettings.isAllowingBail() && TownyEconomyHandler.isActive()) {
         pages = pages + translator.of("msg_jailed_handbook_bail_1");
         if (reason == JailReason.PRISONER_OF_WAR) {
            Resident resident = TownyUniverse.getInstance().getResident(player.getUniqueId());
            if (resident.isMayor()) {
               cost = resident.isKing() ? TownySettings.getBailAmountKing() : TownySettings.getBailAmountMayor();
            }
         }

         pages = pages + translator.of("msg_jailed_handbook_bail_2", TownyEconomyHandler.getFormattedBalance(cost)) + "\n\n";
      }

      pages = pages + translator.of("msg_jailed_handbook_5");
      pages = pages + translator.of("msg_jailed_handbook_6");
      if (TownySettings.JailAllowsTeleportItems()) {
         pages = pages + translator.of("msg_jailed_teleport");
      }

      pages = pages + "\n\n";
      if (reason.equals(JailReason.PRISONER_OF_WAR)) {
         pages = pages + translator.of("msg_jailed_war_prisoner");
      }

      return pages;
   }

   public static void createJailPlot(TownBlock townBlock, Town town, Location location) throws TownyException {
      UUID uuid = UUID.randomUUID();
      List<Position> jailSpawns = new ArrayList(1);
      jailSpawns.add(Position.ofLocation(location));
      Jail jail = new Jail(uuid, town, townBlock, jailSpawns);
      TownyUniverse.getInstance().registerJail(jail);
      jail.save();
      town.addJail(jail);
      townBlock.setJail(jail);
   }

   private static void unjailAndTeleportAwayFromJail(Resident resident) {
      if (resident.isOnline()) {
         if (!TownySettings.doesUnjailingTeleportPlayer()) {
            unJailResident(resident);
         } else {
            long delay = Math.max(0L, (long)TownySettings.getTeleportWarmupTime() * 20L - 10L);
            Towny.getPlugin().getScheduler().runLater((Entity)resident.getPlayer(), (Runnable)(() -> {
               unJailResident(resident);
            }), delay);
            SpawnUtil.jailAwayTeleport(resident);
         }
      }
   }

   private static void teleportToJail(Resident resident) {
      TownyMessaging.sendMsg(resident, Translatable.of("msg_you_are_being_sent_to_jail"));
      SpawnUtil.jailTeleport(resident);
   }

   private static void addJailedPlayerToLogOutMap(Resident resident) {
      queuedJailedResidents.add(resident);
      TownyMessaging.sendMsg(resident, Translatable.of("msg_do_not_log_out_while_waiting_to_be_teleported"));
      Towny.getPlugin().getScheduler().runLater(() -> {
         queuedJailedResidents.remove(resident);
      }, (long)TownySettings.getTeleportWarmupTime() * 20L);
   }

   public static boolean isQueuedToBeJailed(Resident resident) {
      return queuedJailedResidents.contains(resident);
   }

   public static void maxJailedUnjail(Town town) {
      Stream<Resident> jailedResidents = town.getJailedResidents().stream();
      Resident unjailedresident = TownySettings.getMaxJailedNewJailBehavior() == 1 ? (Resident)jailedResidents.min(Comparator.comparingInt(Resident::getJailHours)).get() : (Resident)jailedResidents.min(Comparator.comparingDouble(Resident::getJailBailCost)).get();
      unJailResident(unjailedresident, UnJailReason.OUT_OF_SPACE);
   }
}
