package com.palmergames.bukkit.towny.utils;

import com.palmergames.adventure.bossbar.BossBar;
import com.palmergames.adventure.text.Component;
import com.palmergames.bukkit.config.ConfigNodes;
import com.palmergames.bukkit.towny.ChunkNotification;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.ChunkNotificationEvent;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.scheduling.ScheduledTask;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ChunkNotificationUtil {
   private static final Map<UUID, ScheduledTask> playerActionTasks = new HashMap();
   private static final Map<UUID, BossBar> playerBossBarMap = new HashMap();

   public static void showChunkNotification(Player player, Resident resident, WorldCoord to, WorldCoord from) {
      String msg = null;

      try {
         ChunkNotification chunkNotifier = new ChunkNotification(from, to);
         msg = chunkNotifier.getNotificationString(resident);
      } catch (NullPointerException var6) {
         Logger var10000 = Towny.getPlugin().getLogger();
         Level var10001 = Level.WARNING;
         String var10002 = System.lineSeparator();
         var10000.log(var10001, "ChunkNotifier generated an NPE, this is harmless but if you'd like to report it the following information will be useful: " + var10002 + "  Player: " + player.getName() + "  To: " + to.getWorldName() + "," + to.getX() + "," + to.getZ() + "  From: " + from.getWorldName() + "," + from.getX() + "," + from.getZ(), var6);
      }

      if (msg != null) {
         ChunkNotificationEvent cne = new ChunkNotificationEvent(player, msg, to, from);
         BukkitTools.fireEvent(cne);
         msg = cne.getMessage();
         if (!cne.isCancelled() && msg != null && !msg.isEmpty()) {
            sendChunkNoticiation(player, msg);
         }
      }
   }

   public static void cancelChunkNotificationTasks() {
      playerActionTasks.values().forEach(ScheduledTask::cancel);
   }

   private static void sendChunkNoticiation(Player player, String msg) {
      String var2 = TownySettings.getNotificationsAppearAs().toLowerCase(Locale.ROOT);
      byte var3 = -1;
      switch(var2.hashCode()) {
      case 3052376:
         if (var2.equals("chat")) {
            var3 = 1;
         }
         break;
      case 3387192:
         if (var2.equals("none")) {
            var3 = 2;
         }
         break;
      case 68611462:
         if (var2.equals("bossbar")) {
            var3 = 0;
         }
      }

      switch(var3) {
      case 0:
         sendBossBarChunkNotification(player, TownyComponents.miniMessage(msg));
         break;
      case 1:
         TownyMessaging.sendMessage((Object)player, (String)msg);
      case 2:
         break;
      default:
         sendActionBarChunkNotification(player, TownyComponents.miniMessage(msg));
      }

   }

   private static void sendActionBarChunkNotification(Player player, Component msgComponent) {
      int seconds = TownySettings.getInt(ConfigNodes.NOTIFICATION_DURATION);
      if (seconds > 3) {
         if (playerActionTasks.get(player.getUniqueId()) != null) {
            removePlayerActionTasks(player);
         }

         AtomicInteger remainingSeconds = new AtomicInteger(seconds);
         ScheduledTask task = Towny.getPlugin().getScheduler().runAsyncRepeating(() -> {
            TownyMessaging.sendActionBarMessageToPlayer(player, msgComponent);
            remainingSeconds.getAndDecrement();
            if (remainingSeconds.get() == 0 && playerActionTasks.containsKey(player.getUniqueId())) {
               removePlayerActionTasks(player);
            }

         }, 0L, 20L);
         playerActionTasks.put(player.getUniqueId(), task);
      } else {
         TownyMessaging.sendActionBarMessageToPlayer(player, msgComponent);
      }

   }

   private static void sendBossBarChunkNotification(Player player, Component message) {
      int ticks = TownySettings.getInt(ConfigNodes.NOTIFICATION_DURATION) * 20;
      if (playerBossBarMap.containsKey(player.getUniqueId())) {
         removePlayerActionTasks(player);
         removePlayerBossBar(player);
      }

      BossBar.Color color = (BossBar.Color)BossBar.Color.NAMES.valueOr(TownySettings.getBossBarNotificationColor().toLowerCase(Locale.ROOT), BossBar.Color.WHITE);
      BossBar.Overlay overlay = (BossBar.Overlay)BossBar.Overlay.NAMES.valueOr(TownySettings.getBossBarNotificationOverlay().toLowerCase(Locale.ROOT), BossBar.Overlay.PROGRESS);
      BossBar bossBar = BossBar.bossBar(message, TownySettings.getBossBarNotificationProgress(), color, overlay);
      TownyMessaging.sendBossBarMessageToPlayer(player, bossBar);
      ScheduledTask task = Towny.getPlugin().getScheduler().runAsyncLater(() -> {
         playerActionTasks.remove(player.getUniqueId());
         removePlayerBossBar(player);
      }, (long)ticks);
      playerBossBarMap.put(player.getUniqueId(), bossBar);
      playerActionTasks.put(player.getUniqueId(), task);
   }

   private static void removePlayerActionTasks(Player player) {
      ScheduledTask task = (ScheduledTask)playerActionTasks.remove(player.getUniqueId());
      if (task != null) {
         task.cancel();
      }

   }

   private static void removePlayerBossBar(Player player) {
      BossBar bar = (BossBar)playerBossBarMap.remove(player.getUniqueId());
      if (bar != null) {
         Towny.getAdventure().player(player).hideBossBar(bar);
      }

   }

   public static void cancelPlayerTasks(@NotNull Player player) {
      removePlayerActionTasks(player);
      removePlayerBossBar(player);
   }
}
