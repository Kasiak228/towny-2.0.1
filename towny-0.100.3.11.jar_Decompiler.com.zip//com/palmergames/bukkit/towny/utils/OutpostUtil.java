package com.palmergames.bukkit.towny.utils;

import com.palmergames.adventure.text.event.ClickEvent;
import com.palmergames.adventure.text.event.HoverEvent;
import com.palmergames.bukkit.towny.TownyFormatter;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.Coord;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translator;
import com.palmergames.bukkit.towny.object.statusscreens.StatusScreen;

public class OutpostUtil {
   public static boolean OutpostTests(Town town, Resident resident, TownyWorld world, Coord key, boolean isAdmin, boolean isPlotSetOutpost) throws TownyException {
      if (TownySettings.isOutpostsLimitedByLevels() && town.getMaxOutpostSpawn() >= town.getOutpostLimit()) {
         throw new TownyException(Translatable.of("msg_err_not_enough_outposts_free_to_claim", town.getMaxOutpostSpawn(), town.getOutpostLimit()));
      } else if (!TownySettings.isOutpostsLimitedByLevels() && TownySettings.getAmountOfResidentsForOutpost() != 0 && town.getResidents().size() < TownySettings.getAmountOfResidentsForOutpost()) {
         throw new TownyException(Translatable.of("msg_err_not_enough_residents"));
      } else {
         int maxOutposts = TownySettings.getMaxResidentOutposts(resident);
         if (!isAdmin && maxOutposts != -1 && maxOutposts <= town.getAllOutpostSpawns().size()) {
            throw new TownyException(Translatable.of("msg_max_outposts_own", maxOutposts));
         } else if (world.getMinDistanceFromOtherTownsHomeBlocks(key) < TownySettings.getMinDistanceFromTownHomeblocks()) {
            throw new TownyException(Translatable.of("msg_too_close2", Translatable.of("homeblock")));
         } else {
            int maxDistance = TownySettings.getMaxDistanceForOutpostsFromTown();
            int distance;
            if (maxDistance > 0) {
               if (!world.getName().equalsIgnoreCase(town.getHomeblockWorld().getName())) {
                  throw new TownyException(Translatable.of("msg_err_you_can_only_claim_outposts_in_your_homeblocks_world"));
               }

               distance = world.getMinDistanceFromOtherPlotsOwnedByTown(key, town);
               if (distance > maxDistance) {
                  throw new TownyException(Translatable.of("msg_err_not_close_enough_to_your_town_nearest_plot", distance, maxDistance));
               }
            }

            distance = world.getMinDistanceFromOtherTownsPlots(key, isPlotSetOutpost ? town : null);
            if (distance >= TownySettings.getMinDistanceFromTownPlotblocks() && distance >= TownySettings.getMinDistanceForOutpostsFromPlot()) {
               return true;
            } else {
               throw new TownyException(Translatable.of("msg_too_close2", Translatable.of("townblock")));
            }
         }
      }
   }

   public static void addOutpostComponent(Town town, StatusScreen screen, Translator translator) {
      String outpostLine = "";
      if (TownySettings.isOutpostsLimitedByLevels()) {
         outpostLine = TownyFormatter.colourKeyValue(translator.of("status_town_outposts"), translator.of("status_fractions", town.getMaxOutpostSpawn(), town.getOutpostLimit()));
         if (town.hasNation()) {
            int nationBonus = town.getNationOrNull().getNationLevel().nationBonusOutpostLimit();
            if (nationBonus > 0) {
               outpostLine = outpostLine + TownyFormatter.colourBracketElement(translator.of("status_town_size_nationbonus"), String.valueOf(nationBonus));
            }
         }
      } else if (town.hasOutpostSpawn()) {
         outpostLine = TownyFormatter.colourKeyValue(translator.of("status_town_outposts"), String.valueOf(town.getMaxOutpostSpawn()));
      }

      screen.addComponentOf("outposts", outpostLine, HoverEvent.showText(translator.component("status_hover_click_for_more")), ClickEvent.runCommand("/towny:town outpost list"));
   }
}
