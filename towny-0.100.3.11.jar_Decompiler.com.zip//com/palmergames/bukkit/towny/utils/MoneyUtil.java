package com.palmergames.bukkit.towny.utils;

import com.palmergames.adventure.text.Component;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyFormatter;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.economy.NationPreTransactionEvent;
import com.palmergames.bukkit.towny.event.economy.NationTransactionEvent;
import com.palmergames.bukkit.towny.event.economy.TownPreTransactionEvent;
import com.palmergames.bukkit.towny.event.economy.TownTransactionEvent;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.EconomyHandler;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownBlockTypeCache;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translator;
import com.palmergames.bukkit.towny.object.economy.transaction.Transaction;
import com.palmergames.bukkit.towny.object.statusscreens.StatusScreen;
import com.palmergames.bukkit.util.BukkitTools;
import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Iterator;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class MoneyUtil {
   public static double getTownDebtCap(Town town, double upkeep) {
      return TownySettings.isDebtCapAFixedNumberOfDays() ? upkeep * (double)TownySettings.getDebtCapFixedDays() : getEstimatedValueOfTown(town);
   }

   public static double getEstimatedValueOfTown(Town town) {
      return TownySettings.getNewTownPrice() + (double)(town.getTownBlocks().size() - 1) * TownySettings.getClaimPrice() + (double)town.getAllOutpostSpawns().size() * (TownySettings.getOutpostCost() - TownySettings.getClaimPrice());
   }

   public static void townWithdraw(Player player, Resident resident, Town town, int amount) {
      try {
         commonTests(amount, resident, town, player.getLocation(), false, true);
         Transaction transaction = Transaction.withdraw((double)amount).paidBy((EconomyHandler)town).paidTo((EconomyHandler)resident).build();
         BukkitTools.ifCancelledThenThrow(new TownPreTransactionEvent(town, transaction));
         town.withdrawFromBank(resident, amount);
         TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_xx_withdrew_xx", resident.getName(), amount, Translatable.of("town_sing")));
         BukkitTools.fireEvent(new TownTransactionEvent(town, transaction));
      } catch (TownyException var5) {
         TownyMessaging.sendErrorMsg((Object)player, (String)var5.getMessage(player));
      }

   }

   public static void townDeposit(Player player, Resident resident, Town town, Nation nation, int amount) {
      try {
         commonTests(amount, resident, town, player.getLocation(), false, false);
         Transaction transaction = Transaction.deposit((double)amount).paidBy((EconomyHandler)resident).paidTo((EconomyHandler)town).build();
         BukkitTools.ifCancelledThenThrow(new TownPreTransactionEvent(town, transaction));
         if (nation == null) {
            town.depositToBank(resident, amount);
            TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_xx_deposited_xx", resident.getName(), amount, Translatable.of("town_sing")));
         } else {
            resident.getAccount().payTo((double)amount, (EconomyHandler)town, "Town Deposit from Nation member");
            TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_xx_deposited_xx", resident.getName(), amount, Translatable.literal(town.getName() + " ").append(Translatable.of("town_sing"))));
         }

         BukkitTools.fireEvent(new TownTransactionEvent(town, transaction));
      } catch (TownyException var6) {
         TownyMessaging.sendErrorMsg((Object)player, (String)var6.getMessage(player));
      }

   }

   public static void nationWithdraw(Player player, Resident resident, Nation nation, int amount) {
      try {
         commonTests(amount, resident, nation.getCapital(), player.getLocation(), true, true);
         Transaction transaction = Transaction.withdraw((double)amount).paidBy((EconomyHandler)nation).paidTo((EconomyHandler)resident).build();
         BukkitTools.ifCancelledThenThrow(new NationPreTransactionEvent(nation, transaction));
         nation.withdrawFromBank(resident, amount);
         TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_xx_withdrew_xx", resident.getName(), amount, Translatable.of("nation_sing")));
         BukkitTools.fireEvent(new NationTransactionEvent(nation, transaction));
      } catch (TownyException var5) {
         TownyMessaging.sendErrorMsg((Object)player, (String)var5.getMessage(player));
      }

   }

   public static void nationDeposit(Player player, Resident resident, Nation nation, int amount) {
      try {
         commonTests(amount, resident, nation.getCapital(), player.getLocation(), true, false);
         Transaction transaction = Transaction.deposit((double)amount).paidBy((EconomyHandler)resident).paidTo((EconomyHandler)nation).build();
         BukkitTools.ifCancelledThenThrow(new NationPreTransactionEvent(nation, transaction));
         nation.depositToBank(resident, amount);
         TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_xx_deposited_xx", resident.getName(), amount, Translatable.of("nation_sing")));
         BukkitTools.fireEvent(new NationTransactionEvent(nation, transaction));
      } catch (TownyException var5) {
         TownyMessaging.sendErrorMsg((Object)player, (String)var5.getMessage(player));
      }

   }

   private static void commonTests(int amount, Resident resident, Town town, Location loc, boolean nation, boolean withdraw) throws TownyException {
      Nation townNation = nation ? town.getNationOrNull() : null;
      if (!TownyEconomyHandler.isActive()) {
         throw new TownyException(Translatable.of("msg_err_no_economy"));
      } else if (amount < 0) {
         throw new TownyException(Translatable.of("msg_err_negative_money"));
      } else if (!withdraw && !resident.getAccount().canPayFromHoldings((double)amount)) {
         throw new TownyException(Translatable.of("msg_insuf_funds"));
      } else if (!nation && town.isRuined()) {
         throw new TownyException(Translatable.of("msg_err_cannot_use_command_because_town_ruined"));
      } else if (!withdraw || (!nation || TownySettings.getNationBankAllowWithdrawls()) && (nation || TownySettings.getTownBankAllowWithdrawls())) {
         if (!withdraw && (!nation && TownySettings.getTownBankCap(town) > 0.0D || nation && TownySettings.getNationBankCap(townNation) > 0.0D)) {
            double bankcap = 0.0D;
            double balance = 0.0D;
            if (!nation && town.getBankCap() > 0.0D) {
               bankcap = town.getBankCap();
               balance = town.getAccount().getHoldingBalance();
            } else if (nation && townNation.getBankCap() > 0.0D) {
               bankcap = townNation.getBankCap();
               balance = townNation.getAccount().getHoldingBalance();
            }

            if (bankcap > 0.0D && (double)amount + balance > bankcap) {
               throw new TownyException(Translatable.of("msg_err_deposit_capped", bankcap));
            }
         }

         if (TownySettings.isBankActionLimitedToBankPlots()) {
            testBankPlotRules(town, loc);
         }

         if (TownySettings.isBankActionDisallowedOutsideTown() && isNotInOwnTown(town, loc)) {
            if (nation) {
               throw new TownyException(Translatable.of("msg_err_unable_to_use_bank_outside_nation_capital"));
            } else {
               throw new TownyException(Translatable.of("msg_err_unable_to_use_bank_outside_your_town"));
            }
         } else {
            int minAmount = false;
            int minAmount;
            if (withdraw) {
               minAmount = nation ? TownySettings.getNationMinWithdraw() : TownySettings.getTownMinWithdraw();
            } else {
               minAmount = nation ? TownySettings.getNationMinDeposit() : TownySettings.getTownMinDeposit();
            }

            if (amount < minAmount) {
               throw new TownyException(Translatable.of("msg_err_must_be_greater_than_or_equal_to", formatMoney((double)minAmount)));
            }
         }
      } else {
         throw new TownyException(Translatable.of("msg_err_withdraw_disabled"));
      }
   }

   private static void testBankPlotRules(Town town, Location loc) throws TownyException {
      if (isNotInOwnTown(town, loc)) {
         throw new TownyException(Translatable.of("msg_err_unable_to_command_outside_of_town"));
      } else {
         TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
         if (!tb.getType().equals(TownBlockType.BANK)) {
            if (TownySettings.doHomeblocksNoLongerWorkWhenATownHasBankPlots() && town.getTownBlockTypeCache().getNumTownBlocks(TownBlockType.BANK, TownBlockTypeCache.CacheType.ALL) > 0) {
               throw new TownyException(Translatable.of("msg_err_unable_to_use_bank_outside_bank_plot_no_homeblock"));
            } else if (!tb.isHomeBlock()) {
               throw new TownyException(Translatable.of("msg_err_unable_to_use_bank_outside_bank_plot"));
            }
         }
      }
   }

   private static boolean isNotInOwnTown(Town town, Location loc) {
      return TownyAPI.getInstance().isWilderness(loc) || !town.equals(TownyAPI.getInstance().getTown(loc));
   }

   public static void checkLegacyDebtAccounts() {
      File f = new File(TownyUniverse.getInstance().getRootFolder(), "debtAccountsConverted.txt");
      if (!f.exists()) {
         Towny.getPlugin().getScheduler().runAsyncLater(() -> {
            TownyEconomyHandler.economyExecutor().execute(MoneyUtil::convertLegacyDebtAccounts);
         }, 600L);
      }

   }

   private static void convertLegacyDebtAccounts() {
      Iterator var0 = TownyUniverse.getInstance().getTowns().iterator();

      while(var0.hasNext()) {
         Town town = (Town)var0.next();
         String name = "[DEBT]-" + town.getName();
         if (TownyEconomyHandler.hasAccount(name)) {
            town.setDebtBalance(TownyEconomyHandler.getBalance(name, town.getAccount().getBukkitWorld()));
            town.save();
            TownyEconomyHandler.setBalance(name, 0.0D, town.getAccount().getBukkitWorld());
         }
      }

      Towny.getPlugin().saveResource("debtAccountsConverted.txt", false);
   }

   public static double getMoneyAboveZeroOrThrow(String input) throws TownyException {
      double amount;
      try {
         amount = Double.parseDouble(input);
      } catch (NumberFormatException var4) {
         throw new TownyException(Translatable.of("msg_error_must_be_num"));
      }

      if (amount < 0.0D) {
         throw new TownyException(Translatable.of("msg_err_negative_money"));
      } else {
         return amount;
      }
   }

   public static double returnPurchasedBlocksCost(int alreadyPurchased, int toPurchase, Town town) {
      int n;
      if (alreadyPurchased + toPurchase > TownySettings.getMaxPurchasedBlocks(town)) {
         n = TownySettings.getMaxPurchasedBlocks(town) - alreadyPurchased;
      } else {
         n = toPurchase;
      }

      if (n == 0) {
         return (double)n;
      } else {
         double increaseValue = TownySettings.getPurchasedBonusBlocksIncreaseValue();
         double baseCost = TownySettings.getPurchasedBonusBlocksCost();
         double maxPrice = TownySettings.getPurchasedBonusBlocksMaxPrice();
         boolean hasMaxPrice = maxPrice >= 0.0D;
         double blockCost;
         if (increaseValue == 1.0D) {
            blockCost = hasMaxPrice ? Math.min(baseCost, maxPrice) : baseCost;
            return (double)Math.round(blockCost * (double)n);
         } else {
            blockCost = baseCost * Math.pow(increaseValue, (double)alreadyPurchased);
            if (hasMaxPrice) {
               if (blockCost >= maxPrice) {
                  return (double)Math.round(maxPrice * (double)n);
               }

               int increases = (int)Math.ceil((Math.log(maxPrice) - Math.log(blockCost)) / Math.log(increaseValue));
               if (increases < n) {
                  double cost = blockCost * (1.0D - Math.pow(increaseValue, (double)increases)) / (1.0D - increaseValue) + (double)(n - increases) * maxPrice;
                  return (double)Math.round(cost);
               }
            }

            double cost = blockCost * (1.0D - Math.pow(increaseValue, (double)n)) / (1.0D - increaseValue);
            return (double)Math.round(cost);
         }
      }
   }

   public static void addTownMoneyComponents(Town town, Translator translator, StatusScreen screen) {
      screen.addComponentOf("moneynewline", (Component)Component.newline());
      screen.addComponentOf("bankString", TownyFormatter.colourKeyValue(translator.of("status_bank"), town.getAccount().getHoldingFormattedBalance()));
      String var10002;
      if (town.isBankrupt()) {
         if (town.getAccount().getDebtCap() == 0.0D) {
            town.getAccount().setDebtCap(getTownDebtCap(town, TownySettings.getTownUpkeepCost(town)));
         }

         var10002 = translator.of("status_bank_bankrupt");
         screen.addComponentOf("bankrupt", var10002 + " " + TownyFormatter.colourKeyValue(translator.of("status_debtcap"), "-" + formatMoney(town.getAccount().getDebtCap())));
      }

      if (TownySettings.isTaxingDaily()) {
         if (town.hasUpkeep()) {
            var10002 = translator.of("status_splitter");
            screen.addComponentOf("upkeep", var10002 + TownyFormatter.colourKey(translator.of("status_bank_town2")) + " " + TownyFormatter.colourKeyImportant(formatMoney(BigDecimal.valueOf(TownySettings.getTownUpkeepCost(town)).setScale(2, RoundingMode.HALF_UP).doubleValue())));
         }

         if (TownySettings.getUpkeepPenalty() > 0.0D && town.isOverClaimed()) {
            var10002 = translator.of("status_splitter");
            screen.addComponentOf("upkeepPenalty", var10002 + TownyFormatter.colourKey(translator.of("status_bank_town_penalty_upkeep")) + " " + TownyFormatter.colourKeyImportant(formatMoney(TownySettings.getTownPenaltyUpkeepCost(town))));
         }

         if (town.isNeutral()) {
            double neutralCost = TownySettings.getTownNeutralityCost(town);
            if (neutralCost > 0.0D) {
               var10002 = translator.of("status_splitter");
               String var10003 = translator.of("status_neutrality_cost");
               screen.addComponentOf("neutralityCost", var10002 + TownyFormatter.colourKey(var10003 + " " + TownyFormatter.colourKeyImportant(formatMoney(neutralCost))));
            }
         }

         var10002 = translator.of("status_splitter");
         screen.addComponentOf("towntax", var10002 + TownyFormatter.colourKey(translator.of("status_bank_town3")) + " " + TownyFormatter.colourKeyImportant(town.isTaxPercentage() ? town.getTaxes() + "%" : formatMoney(town.getTaxes())));
      }
   }

   public static void addNationMoneyComponentsToScreen(Nation nation, Translator translator, StatusScreen screen) {
      screen.addComponentOf("moneynewline", (Component)Component.newline());
      screen.addComponentOf("bankString", TownyFormatter.colourKeyValue(translator.of("status_bank"), nation.getAccount().getHoldingFormattedBalance()));
      if (TownySettings.isTaxingDaily()) {
         String var10002;
         String var10003;
         if (TownySettings.getNationUpkeepCost(nation) > 0.0D) {
            var10002 = translator.of("status_splitter");
            var10003 = translator.of("status_bank_town2");
            screen.addComponentOf("nationupkeep", var10002 + TownyFormatter.colourKey(var10003 + " " + TownyFormatter.colourKeyImportant(formatMoney(TownySettings.getNationUpkeepCost(nation)))));
         }

         if (nation.isNeutral()) {
            double neutralCost = TownySettings.getNationNeutralityCost(nation);
            if (neutralCost > 0.0D) {
               var10002 = translator.of("status_splitter");
               var10003 = translator.of("status_neutrality_cost");
               screen.addComponentOf("neutralityCost", var10002 + TownyFormatter.colourKey(var10003 + " " + TownyFormatter.colourKeyImportant(formatMoney(neutralCost))));
            }
         }

         var10002 = translator.of("status_splitter");
         screen.addComponentOf("nationtax", var10002 + TownyFormatter.colourKey(translator.of("status_nation_tax")) + " " + TownyFormatter.colourKeyImportant(nation.isTaxPercentage() ? nation.getTaxes() + "%" : formatMoney(nation.getTaxes())));
         var10002 = translator.of("status_splitter");
         screen.addComponentOf("nationConqueredTax", var10002 + TownyFormatter.colourKey(translator.of("status_nation_conquered_tax")) + " " + TownyFormatter.colourKeyImportant(formatMoney(nation.getConqueredTax())));
      }
   }

   private static String formatMoney(double money) {
      return TownyEconomyHandler.getFormattedBalance(money);
   }
}
