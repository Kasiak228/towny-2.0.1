package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.damage.TownBlockPVPTestEvent;
import com.palmergames.bukkit.towny.event.damage.TownyDispenserDamageEntityEvent;
import com.palmergames.bukkit.towny.event.damage.TownyFriendlyFireTestEvent;
import com.palmergames.bukkit.towny.event.damage.TownyPlayerDamagePlayerEvent;
import com.palmergames.bukkit.towny.event.damage.WildernessPVPTestEvent;
import com.palmergames.bukkit.towny.event.executors.TownyActionEventExecutor;
import com.palmergames.bukkit.towny.hooks.PluginIntegrations;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownyPermission;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.EntityLists;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.entity.AnimalTamer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LightningStrike;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Wolf;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.permissions.Permissible;
import org.bukkit.projectiles.BlockProjectileSource;
import org.bukkit.projectiles.ProjectileSource;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;

public class CombatUtil {
   @Nullable
   private static final MethodHandle GET_LIGHTNING_CAUSING_ENTITY;

   public static boolean preventDamageCall(Entity attacker, Entity defender, DamageCause cause) {
      TownyWorld world = TownyAPI.getInstance().getTownyWorld(defender.getWorld());
      if (world != null && world.isUsingTowny()) {
         Player a = null;
         Player b = null;
         Entity directSource = attacker;
         if (attacker instanceof Projectile) {
            Projectile projectile = (Projectile)attacker;
            ProjectileSource source = projectile.getShooter();
            if (source instanceof Entity) {
               Entity entity = (Entity)source;
               directSource = entity;
            } else if (source instanceof BlockProjectileSource) {
               BlockProjectileSource blockProjectileSource = (BlockProjectileSource)source;
               if (preventDispenserDamage(blockProjectileSource.getBlock(), defender, cause)) {
                  return true;
               }
            }
         } else if (attacker instanceof LightningStrike) {
            LightningStrike lightning = (LightningStrike)attacker;
            Entity causingEntity = getLightningCausingEntity(lightning);
            if (causingEntity != null) {
               directSource = causingEntity;
            }
         }

         Player player;
         if (directSource instanceof Player) {
            player = (Player)directSource;
            a = player;
         }

         if (defender instanceof Player) {
            player = (Player)defender;
            b = player;
         }

         return a == b && a != null && b != null ? false : preventDamageCall(world, attacker, defender, a, b, cause);
      } else {
         return false;
      }
   }

   private static boolean preventDamageCall(TownyWorld world, Entity attackingEntity, Entity defendingEntity, Player attackingPlayer, Player defendingPlayer, DamageCause cause) {
      Projectile projectileAttacker = null;
      if (attackingEntity instanceof Projectile) {
         Projectile projectile = (Projectile)attackingEntity;
         projectileAttacker = projectile;
         ProjectileSource var9 = projectile.getShooter();
         if (var9 instanceof Entity) {
            Entity entity = (Entity)var9;
            attackingEntity = entity;
         }
      }

      TownBlock defenderTB = TownyAPI.getInstance().getTownBlock(defendingEntity.getLocation());
      TownBlock attackerTB = TownyAPI.getInstance().getTownBlock(attackingEntity.getLocation());
      Wolf wolf;
      if (attackingPlayer != null && isNotNPC(attackingPlayer)) {
         if (defendingPlayer != null && isNotNPC(defendingPlayer)) {
            boolean cancelled = false;
            if (!isArenaPlot(attackerTB, defenderTB) && !isTownyAdminBypassingPVP(attackingPlayer)) {
               cancelled = preventFriendlyFire(attackingPlayer, defendingPlayer, world) || preventPvP(world, attackerTB) || preventPvP(world, defenderTB) || preventJailedPVP(defendingPlayer, attackingPlayer);
            }

            TownyPlayerDamagePlayerEvent event = new TownyPlayerDamagePlayerEvent(defendingPlayer.getLocation(), defendingPlayer, cause, defenderTB, cancelled, attackingPlayer);
            if (BukkitTools.isEventCancelled(event) && event.getMessage() != null) {
               TownyMessaging.sendErrorMsg((Object)attackingPlayer, (String)event.getMessage());
            }

            return event.isCancelled();
         }

         if (defenderTB != null) {
            if (defendingEntity instanceof Wolf) {
               wolf = (Wolf)defendingEntity;
               if (isOwner(wolf, attackingPlayer) || isTargetingPlayer(wolf, attackingPlayer)) {
                  return false;
               }

               if (EntityTypeUtil.isProtectedEntity(defendingEntity)) {
                  return !defenderTB.getPermissions().pvp && !TownyActionEventExecutor.canDestroy(attackingPlayer, wolf.getLocation(), Material.STONE);
               }
            }

            if (defenderTB.getType() == TownBlockType.FARM && TownySettings.getFarmAnimals().contains(defendingEntity.getType().toString())) {
               return !TownyActionEventExecutor.canDestroy(attackingPlayer, defendingEntity.getLocation(), Material.WHEAT);
            }

            if (EntityTypeUtil.isProtectedEntity(defendingEntity)) {
               return !TownyActionEventExecutor.canDestroy(attackingPlayer, defendingEntity.getLocation(), Material.DIRT);
            }
         }

         if (defenderTB == null && defendingEntity instanceof Wolf) {
            wolf = (Wolf)defendingEntity;
            if (wolf.isTamed() && !isOwner(wolf, attackingPlayer)) {
               return preventPvP(world, attackerTB) || preventPvP(world, defenderTB);
            }
         }

         if (EntityLists.DESTROY_PROTECTED.contains(defendingEntity)) {
            Material material = EntityTypeUtil.parseEntityToMaterial(defendingEntity.getType());
            if (material != null) {
               return !TownyActionEventExecutor.canDestroy(attackingPlayer, defendingEntity.getLocation(), material);
            }
         }
      } else if (defendingPlayer == null) {
         if (defenderTB == null) {
            return false;
         }

         if (!TownySettings.areProtectedEntitiesProtectedAgainstMobs()) {
            return false;
         }

         if (projectileAttacker != null && EntityTypeUtil.isInstanceOfAny(TownySettings.getProtectedEntityTypes(), defendingEntity)) {
            return true;
         }

         if (attackingEntity instanceof Wolf) {
            wolf = (Wolf)attackingEntity;
            if (EntityTypeUtil.isInstanceOfAny(TownySettings.getProtectedEntityTypes(), defendingEntity)) {
               if (isATamedWolfWithAOnlinePlayer(wolf)) {
                  Player owner = BukkitTools.getPlayerExact(wolf.getOwner().getName());
                  return !PlayerCacheUtil.getCachePermission(owner, defendingEntity.getLocation(), Material.AIR, TownyPermission.ActionType.DESTROY);
               }

               wolf.setAngry(false);
               return true;
            }
         }

         if (attackingEntity.getType().getKey().equals(NamespacedKey.minecraft("axolotl")) && EntityTypeUtil.isInstanceOfAny(TownySettings.getProtectedEntityTypes(), defendingEntity)) {
            return true;
         }
      } else {
         if (attackingEntity instanceof Wolf) {
            wolf = (Wolf)attackingEntity;
            if (preventPvP(world, attackerTB) || preventPvP(world, defenderTB)) {
               wolf.setAngry(false);
               return true;
            }
         }

         if (attackingEntity instanceof LightningStrike && world.hasTridentStrike(attackingEntity.getUniqueId()) && preventPvP(world, defenderTB)) {
            return true;
         }
      }

      return false;
   }

   private static boolean preventJailedPVP(Player defendingPlayer, Player attackingPlayer) {
      if (TownySettings.doJailPlotsPreventPVP()) {
         Resident defendingResident = TownyAPI.getInstance().getResident(defendingPlayer.getUniqueId());
         Resident attackingResident = TownyAPI.getInstance().getResident(attackingPlayer.getUniqueId());
         TownBlock defTB = TownyAPI.getInstance().getTownBlock(defendingPlayer);
         TownBlock atkTB = TownyAPI.getInstance().getTownBlock(attackingPlayer);
         if (defendingResident == null || attackingResident == null) {
            return false;
         }

         if (defendingResident.isJailed() && defTB != null && defTB.isJail() || attackingResident.isJailed() && atkTB != null && atkTB.isJail()) {
            return true;
         }
      }

      return false;
   }

   public static boolean preventPvP(TownyWorld world, TownBlock townBlock) {
      if (townBlock != null) {
         TownBlockPVPTestEvent event = new TownBlockPVPTestEvent(townBlock, isPvP(townBlock));
         BukkitTools.fireEvent(event);
         return !event.isPvp();
      } else {
         WildernessPVPTestEvent event = new WildernessPVPTestEvent(world, isWorldPvP(world));
         BukkitTools.fireEvent(event);
         return !event.isPvp();
      }
   }

   private static boolean isPvP(@NotNull TownBlock townBlock) {
      if (townBlock.getTownOrNull().isAdminDisabledPVP()) {
         return false;
      } else if (!townBlock.getPermissions().pvp && !townBlock.getTownOrNull().isPVP() && !townBlock.getWorld().isForcePVP()) {
         return false;
      } else {
         return !townBlock.isHomeBlock() || !townBlock.getWorld().isForcePVP() || !TownySettings.isForcePvpNotAffectingHomeblocks();
      }
   }

   public static boolean isWorldPvP(TownyWorld world) {
      return world.isForcePVP() || world.isPVP();
   }

   public static boolean preventFriendlyFire(Player attacker, Player defender, TownyWorld world) {
      if (attacker == defender) {
         return false;
      } else if (attacker != null && defender != null && !world.isFriendlyFireEnabled() && isAlly(attacker.getName(), defender.getName())) {
         if (isArenaPlot(attacker, defender)) {
            return false;
         } else {
            TownyFriendlyFireTestEvent event = new TownyFriendlyFireTestEvent(attacker, defender, world);
            BukkitTools.fireEvent(event);
            if (!event.isPVP() && !event.getCancelledMessage().isEmpty()) {
               TownyMessaging.sendErrorMsg((Object)attacker, (String)event.getCancelledMessage());
            }

            return !event.isPVP();
         }
      } else {
         return false;
      }
   }

   public static boolean isArenaPlot(Player attacker, Player defender) {
      TownBlock attackerTB = TownyAPI.getInstance().getTownBlock(attacker);
      TownBlock defenderTB = TownyAPI.getInstance().getTownBlock(defender);
      return isArenaPlot(attackerTB, defenderTB);
   }

   public static boolean isArenaPlot(TownBlock attackerTB, TownBlock defenderTB) {
      return defenderTB != null && attackerTB != null && defenderTB.getType() == TownBlockType.ARENA && attackerTB.getType() == TownBlockType.ARENA;
   }

   public static boolean isAlly(String attackingResident, String defendingResident) {
      TownyUniverse townyUniverse = TownyUniverse.getInstance();
      Resident residentA = townyUniverse.getResident(attackingResident);
      Resident residentB = townyUniverse.getResident(defendingResident);
      return residentA != null && residentB != null && residentA.hasTown() && residentB.hasTown() ? isAlly(residentA.getTownOrNull(), residentB.getTownOrNull()) : false;
   }

   public static boolean isAlly(Resident a, Resident b) {
      return a != null && b != null && a.hasTown() && b.hasTown() ? isAlly(a.getTownOrNull(), b.getTownOrNull()) : false;
   }

   public static boolean isAlly(Town a, Town b) {
      if (isSameTown(a, b)) {
         return true;
      } else if (a.hasAlly(b)) {
         return true;
      } else if (isSameNation(a, b)) {
         return true;
      } else {
         return a.hasNation() && b.hasNation() && a.getNationOrNull().hasAlly(b.getNationOrNull());
      }
   }

   public static boolean isSameNation(Town a, Town b) {
      if (isSameTown(a, b)) {
         return true;
      } else {
         return a.hasNation() && b.hasNation() && a.getNationOrNull().hasTown(b);
      }
   }

   public static boolean isSameTown(Town a, Town b) {
      return a != null && b != null ? a.getUUID().equals(b.getUUID()) : false;
   }

   public static boolean isSameNation(Resident a, Resident b) {
      return a.hasTown() && b.hasTown() ? isSameNation(a.getTownOrNull(), b.getTownOrNull()) : false;
   }

   public static boolean isSameTown(Resident a, Resident b) {
      return a.hasTown() && b.hasTown() ? isSameTown(a.getTownOrNull(), b.getTownOrNull()) : false;
   }

   public static boolean areAllAllies(List<Nation> possibleAllies) {
      if (possibleAllies.size() <= 1) {
         return true;
      } else {
         for(int i = 0; i < possibleAllies.size() - 1; ++i) {
            if (!((Nation)possibleAllies.get(i)).hasAlly((Nation)possibleAllies.get(i + 1))) {
               return false;
            }
         }

         return true;
      }
   }

   public static boolean areAllFriends(List<Resident> possibleFriends) {
      if (possibleFriends.size() <= 1) {
         return true;
      } else {
         for(int i = 0; i < possibleFriends.size() - 1; ++i) {
            if (!((Resident)possibleFriends.get(i)).hasFriend((Resident)possibleFriends.get(i + 1))) {
               return false;
            }
         }

         return true;
      }
   }

   public static boolean isEnemy(String a, String b) {
      Resident residentA = TownyUniverse.getInstance().getResident(a);
      Resident residentB = TownyUniverse.getInstance().getResident(b);
      if (residentA != null && residentB != null && residentA.hasTown() && residentB.hasTown()) {
         return isEnemy(residentA.getTownOrNull(), residentB.getTownOrNull());
      } else {
         return false;
      }
   }

   public static boolean isEnemy(Resident a, Resident b) {
      return a != null && b != null && a.hasTown() && b.hasTown() ? isEnemy(a.getTownOrNull(), b.getTownOrNull()) : false;
   }

   public static boolean isEnemy(Town a, Town b) {
      if (a.hasEnemy(b)) {
         return true;
      } else if (a.hasNation() && b.hasNation()) {
         if (!isSameTown(a, b) && !isSameNation(a, b)) {
            return a.getNationOrNull().hasEnemy(b.getNationOrNull());
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean isEnemyTownBlock(Player player, WorldCoord worldCoord) {
      Resident resident = TownyUniverse.getInstance().getResident(player.getUniqueId());
      return resident != null && resident.hasTown() && worldCoord.hasTownBlock() ? isEnemy(worldCoord.getTownOrNull(), resident.getTownOrNull()) : false;
   }

   private static boolean isOwner(Wolf wolf, Player attackingPlayer) {
      AnimalTamer var3 = wolf.getOwner();
      boolean var10000;
      if (var3 instanceof HumanEntity) {
         HumanEntity owner = (HumanEntity)var3;
         if (owner.getUniqueId().equals(attackingPlayer.getUniqueId())) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private static boolean isTargetingPlayer(Wolf wolf, Player attackingPlayer) {
      return wolf.isAngry() && wolf.getTarget() != null && wolf.getTarget().equals(attackingPlayer);
   }

   private static boolean isATamedWolfWithAOnlinePlayer(Wolf wolf) {
      AnimalTamer var2 = wolf.getOwner();
      boolean var10000;
      if (var2 instanceof HumanEntity) {
         HumanEntity owner = (HumanEntity)var2;
         if (Bukkit.getPlayer(owner.getUniqueId()) != null) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   public static boolean preventDispenserDamage(Block dispenser, Entity entity, DamageCause cause) {
      TownBlock dispenserTB = WorldCoord.parseWorldCoord(dispenser).getTownBlockOrNull();
      TownBlock defenderTB = WorldCoord.parseWorldCoord(entity).getTownBlockOrNull();
      TownyWorld world = TownyAPI.getInstance().getTownyWorld(dispenser.getWorld());
      if (world != null && world.isUsingTowny()) {
         boolean preventDamage = false;
         if (!isArenaPlot(dispenserTB, defenderTB)) {
            preventDamage = preventPvP(world, dispenserTB) || preventPvP(world, defenderTB);
         }

         return BukkitTools.isEventCancelled(new TownyDispenserDamageEntityEvent(entity.getLocation(), entity, cause, defenderTB, preventDamage, dispenser));
      } else {
         return false;
      }
   }

   private static boolean isNotNPC(Entity entity) {
      return !PluginIntegrations.getInstance().isNPC(entity);
   }

   @Internal
   @Nullable
   public static Entity getLightningCausingEntity(@NotNull LightningStrike lightning) {
      if (GET_LIGHTNING_CAUSING_ENTITY == null) {
         return null;
      } else {
         try {
            return GET_LIGHTNING_CAUSING_ENTITY.invokeExact(lightning);
         } catch (Throwable var2) {
            return null;
         }
      }
   }

   private static boolean isTownyAdminBypassingPVP(Player attackingPlayer) {
      return TownySettings.isPVPAlwaysAllowedForAdmins() && TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((Permissible)attackingPlayer);
   }

   static {
      MethodHandle temp = null;

      try {
         temp = MethodHandles.publicLookup().unreflect(LightningStrike.class.getMethod("getCausingEntity"));
      } catch (Throwable var2) {
      }

      GET_LIGHTNING_CAUSING_ENTITY = temp;
   }
}
