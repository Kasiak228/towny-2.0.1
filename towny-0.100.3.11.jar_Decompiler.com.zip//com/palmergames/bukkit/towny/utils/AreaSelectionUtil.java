package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockOwner;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.util.BiomeUtil;
import com.palmergames.util.MathUtil;
import com.palmergames.util.StringMgmt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AreaSelectionUtil {
   private static final int MAX_RECT_RADIUS = 15;
   private static final int MAX_CIRC_RADIUS = 18;
   private static final int MAX_SIZE = 1009;

   public static List<WorldCoord> selectWorldCoordArea(TownBlockOwner owner, WorldCoord pos, String[] args) throws TownyException {
      return selectWorldCoordArea(owner, pos, args, false);
   }

   public static List<WorldCoord> selectWorldCoordArea(TownBlockOwner owner, WorldCoord pos, String[] args, boolean claim) throws TownyException {
      List<WorldCoord> out = new ArrayList();
      if (args.length == 0) {
         ((List)out).add(pos);
      } else {
         int maxSelectionSize = claim ? getSelectionSize(args, owner) : 1009;
         if (args.length > 1) {
            if (args[0].equalsIgnoreCase("rect")) {
               out = selectWorldCoordAreaRect(maxSelectionSize, pos, StringMgmt.remFirstArg(args), claim);
            } else if (args[0].equalsIgnoreCase("circle")) {
               out = selectWorldCoordAreaCircle(maxSelectionSize, pos, StringMgmt.remFirstArg(args), claim);
            } else {
               if (args.length != 3 || !args[1].startsWith("x") || !args[2].startsWith("z")) {
                  throw new TownyException(Translatable.of("msg_err_invalid_property", StringMgmt.join((Object[])args, " ")));
               }

               ((List)out).add(new WorldCoord(args[0], Integer.parseInt(args[1].replace("x", "")), Integer.parseInt(args[2].replace("z", ""))));
            }
         } else if (args[0].equalsIgnoreCase("auto")) {
            out = selectWorldCoordAreaRect(maxSelectionSize, pos, args, claim);
         } else {
            try {
               Integer.parseInt(args[0]);
               out = selectWorldCoordAreaRect(maxSelectionSize, pos, args, claim);
            } catch (NumberFormatException var7) {
               throw new TownyException(Translatable.of("msg_err_invalid_property", args[0]));
            }
         }
      }

      return (List)out;
   }

   private static int getSelectionSize(String[] args, TownBlockOwner owner) {
      return (args.length != 1 || !args[0].equalsIgnoreCase("auto")) && (args.length != 2 || !args[1].equalsIgnoreCase("auto")) ? 1009 : getAvailableClaimsFrom(owner);
   }

   private static int getAvailableClaimsFrom(TownBlockOwner owner) {
      if (owner instanceof Town) {
         Town town = (Town)owner;
         return town.hasUnlimitedClaims() ? 1009 : town.availableTownBlocks();
      } else if (owner instanceof Resident) {
         Resident resident = (Resident)owner;
         return TownySettings.getMaxResidentPlots(resident) - resident.getTownBlocks().size();
      } else {
         return 0;
      }
   }

   private static List<WorldCoord> selectWorldCoordAreaRect(int maxSelectionSize, WorldCoord pos, String[] args, boolean claim) throws TownyException {
      List<WorldCoord> out = new ArrayList();
      if (args.length <= 0) {
         throw new TownyException(Translatable.of("msg_err_invalid_radius"));
      } else {
         int r = 15;
         int needed;
         int x;
         if (args[0].equalsIgnoreCase("auto")) {
            if (TownySettings.getMaxClaimRadiusValue() > 0) {
               r = Math.min(r, TownySettings.getMaxClaimRadiusValue());
            }
         } else {
            try {
               r = Integer.parseInt(args[0]);
            } catch (NumberFormatException var13) {
               throw new TownyException(Translatable.of("msg_err_invalid_radius"));
            }

            if (TownySettings.getMaxClaimRadiusValue() > 0 && r > TownySettings.getMaxClaimRadiusValue()) {
               throw new TownyException(Translatable.of("msg_err_invalid_radius_number", TownySettings.getMaxClaimRadiusValue()));
            }

            needed = pos.isWilderness() ? 1 : 0;

            for(x = 1; x <= r && needed < maxSelectionSize; ++x) {
               needed += x * 8;
            }

            r = x - 1;
            maxSelectionSize = needed + 1;
         }

         needed = (r * 2 + 1) / 2;
         x = 0;
         int z = 0;
         int dx = 0;
         int dz = -1;

         for(int i = 0; i <= maxSelectionSize; ++i) {
            if (-needed <= x && x <= needed && -needed <= z && z <= needed) {
               out.add(pos.add(x, z));
            }

            if (x == z || x < 0 && x == -z || x > 0 && x == 1 - z) {
               int swap = dx;
               dx = -dz;
               dz = swap;
            }

            x += dx;
            z += dz;
         }

         if (claim && !pos.isWilderness()) {
            out.remove(0);
         }

         return out;
      }
   }

   private static List<WorldCoord> selectWorldCoordAreaCircle(int maxSelectionSize, WorldCoord pos, String[] args, boolean claim) throws TownyException {
      List<WorldCoord> out = new ArrayList();
      if (args.length <= 0) {
         throw new TownyException(Translatable.of("msg_err_invalid_radius"));
      } else {
         int r = 18;
         int halfSideLength;
         if (args[0].equalsIgnoreCase("auto")) {
            if (maxSelectionSize > 0) {
               while((double)maxSelectionSize - Math.ceil(3.141592653589793D * (double)r * (double)r) >= 0.0D) {
                  ++r;
               }
            }

            if (TownySettings.getMaxClaimRadiusValue() > 0) {
               r = Math.min(r, TownySettings.getMaxClaimRadiusValue());
            }
         } else {
            try {
               r = Integer.parseInt(args[0]);
            } catch (NumberFormatException var13) {
               throw new TownyException(Translatable.of("msg_err_invalid_radius"));
            }

            if (r < 0) {
               throw new TownyException(Translatable.of("msg_err_invalid_radius"));
            }

            if (TownySettings.getMaxClaimRadiusValue() > 0 && r > TownySettings.getMaxClaimRadiusValue()) {
               throw new TownyException(Translatable.of("msg_err_invalid_radius_number", TownySettings.getMaxClaimRadiusValue()));
            }

            halfSideLength = 0;
            if (maxSelectionSize > 0) {
               while((double)maxSelectionSize - Math.ceil(3.141592653589793D * (double)halfSideLength * (double)halfSideLength) >= 0.0D) {
                  ++halfSideLength;
               }
            }

            --halfSideLength;
            r = Math.min(r, halfSideLength);
         }

         halfSideLength = (r * 2 + 1) / 2;
         int x = 0;
         int z = 0;
         int dx = 0;
         int dz = -1;

         for(int i = 0; i <= maxSelectionSize; ++i) {
            if (-halfSideLength <= x && x <= halfSideLength && -halfSideLength <= z && z <= halfSideLength && MathUtil.distanceSquared((double)x, (double)z) <= MathUtil.sqr((double)r) && out.size() <= maxSelectionSize) {
               out.add(pos.add(x, z));
            }

            if (x == z || x < 0 && x == -z || x > 0 && x == 1 - z) {
               int swap = dx;
               dx = -dz;
               dz = swap;
            }

            x += dx;
            z += dz;
         }

         if (claim && !pos.isWilderness()) {
            out.remove(0);
         }

         return out;
      }
   }

   public static List<WorldCoord> filterInvalidProximityTownBlocks(List<WorldCoord> selection, Town town) {
      List<WorldCoord> out = new ArrayList();
      Iterator var3 = selection.iterator();

      while(var3.hasNext()) {
         WorldCoord worldCoord = (WorldCoord)var3.next();
         if (worldCoord.getTownyWorld().getMinDistanceFromOtherTownsPlots(worldCoord, town) >= TownySettings.getMinDistanceFromTownPlotblocks()) {
            out.add(worldCoord);
         } else {
            TownyMessaging.sendDebugMsg("AreaSelectionUtil:filterInvalidProximity - Coord: " + worldCoord + " too close to another town.");
         }
      }

      return out;
   }

   public static List<WorldCoord> filterInvalidProximityToHomeblock(List<WorldCoord> selection, Town town) {
      List<WorldCoord> out = new ArrayList();
      Iterator var3 = selection.iterator();

      while(var3.hasNext()) {
         WorldCoord worldCoord = (WorldCoord)var3.next();
         if (!isTooCloseToHomeBlock(worldCoord, town)) {
            out.add(worldCoord);
         } else {
            TownyMessaging.sendDebugMsg("AreaSelectionUtil:filterInvalidProximity - Coord: " + worldCoord + " too close to another town's homeblock.");
         }
      }

      return out;
   }

   public static boolean isTooCloseToHomeBlock(WorldCoord wc, Town town) {
      return wc.getTownyWorld().getMinDistanceFromOtherTownsHomeBlocks(wc, town) < TownySettings.getMinDistanceFromTownHomeblocks();
   }

   public static List<WorldCoord> filterOutTownOwnedBlocks(List<WorldCoord> selection) {
      return (List)selection.stream().filter(WorldCoord::isWilderness).collect(Collectors.toList());
   }

   public static List<WorldCoord> filterOutWildernessBlocks(List<WorldCoord> selection) {
      return (List)selection.stream().filter(WorldCoord::hasTownBlock).collect(Collectors.toList());
   }

   public static List<WorldCoord> filterOwnedBlocks(TownBlockOwner owner, List<WorldCoord> selection) {
      return (List)filterOutWildernessBlocks(selection).stream().filter((wc) -> {
         return wc.getTownBlockOrNull().isOwner(owner);
      }).collect(Collectors.toList());
   }

   public static List<WorldCoord> filterUnownedBlocks(TownBlockOwner owner, List<WorldCoord> selection) {
      return (List)filterOutWildernessBlocks(selection).stream().filter((wc) -> {
         return !wc.getTownBlockOrNull().isOwner(owner);
      }).collect(Collectors.toList());
   }

   public static boolean filterHomeBlock(Town town, List<WorldCoord> selection) {
      if (!town.hasHomeBlock()) {
         return false;
      } else {
         WorldCoord homeCoord = town.getHomeBlockOrNull().getWorldCoord();
         return selection.removeIf((worldCoord) -> {
            return worldCoord.equals(homeCoord);
         });
      }
   }

   public static List<WorldCoord> filterPlotsByGroup(PlotGroup group, List<WorldCoord> selection) {
      return (List)filterOutWildernessBlocks(selection).stream().map(WorldCoord::getTownBlockOrNull).filter(TownBlock::hasPlotObjectGroup).filter((tb) -> {
         return group.hasTownBlock(tb);
      }).map(TownBlock::getWorldCoord).collect(Collectors.toList());
   }

   public static HashSet<PlotGroup> getPlotGroupsFromSelection(List<WorldCoord> selection) {
      HashSet<PlotGroup> seenGroups = new HashSet();
      Iterator var2 = selection.iterator();

      while(var2.hasNext()) {
         WorldCoord coord = (WorldCoord)var2.next();
         if (coord.hasTownBlock() && coord.getTownBlockOrNull().hasPlotObjectGroup()) {
            seenGroups.add(coord.getTownBlockOrNull().getPlotObjectGroup());
         }
      }

      return seenGroups;
   }

   public static List<WorldCoord> filterPlotsForSale(Resident resident, List<WorldCoord> selection) {
      List<WorldCoord> out = new ArrayList();
      Iterator var3 = selection.iterator();

      while(var3.hasNext()) {
         WorldCoord worldCoord = (WorldCoord)var3.next();
         TownBlock townBlock = worldCoord.getTownBlockOrNull();
         if (townBlock != null && residentCanBuyTownBlock(resident, townBlock)) {
            if (townBlock.hasPlotObjectGroup()) {
               out.clear();
               out.add(worldCoord);
               return out;
            }

            out.add(worldCoord);
         }
      }

      return out;
   }

   public static List<WorldCoord> filterPlotsForSale(List<WorldCoord> selection) {
      List<WorldCoord> out = new ArrayList();
      Iterator var2 = selection.iterator();

      while(var2.hasNext()) {
         WorldCoord worldCoord = (WorldCoord)var2.next();
         TownBlock townBlock = worldCoord.getTownBlockOrNull();
         if (townBlock != null && townBlockIsForSale(townBlock)) {
            if (townBlock.hasPlotObjectGroup()) {
               out.clear();
               out.add(worldCoord);
               return out;
            }

            out.add(worldCoord);
         }
      }

      return out;
   }

   private static boolean residentCanBuyTownBlock(Resident resident, TownBlock townBlock) {
      try {
         townBlock.testTownMembershipAgePreventsThisClaimOrThrow(resident);
      } catch (TownyException var3) {
         if (resident.isOnline()) {
            TownyMessaging.sendErrorMsg((Object)resident.getPlayer(), (String)var3.getMessage(resident.getPlayer()));
         }

         return false;
      }

      Town town = townBlock.getTownOrNull();
      return town != null && townBlockIsForSale(townBlock) && (town.hasResident(resident) || townBlock.getType().equals(TownBlockType.EMBASSY));
   }

   private static boolean townBlockIsForSale(TownBlock townBlock) {
      return townBlock.isForSale() || townBlock.hasPlotObjectGroup() && townBlock.getPlotObjectGroup().getPrice() != -1.0D;
   }

   public static List<WorldCoord> filterPlotsNotForSale(List<WorldCoord> selection) {
      return (List)selection.stream().filter((wc) -> {
         return wc.hasTownBlock() && wc.getTownBlockOrNull().isForSale();
      }).collect(Collectors.toList());
   }

   public static List<WorldCoord> filterOutResidentBlocks(Resident resident, List<WorldCoord> selection) {
      return (List)selection.stream().filter((wc) -> {
         return wc.hasTownBlock() && !wc.getTownBlockOrNull().hasResident() || !wc.getTownBlockOrNull().hasResident(resident);
      }).collect(Collectors.toList());
   }

   public static List<WorldCoord> filterOutUnwantedBiomeWorldCoords(Player player, List<WorldCoord> selection) {
      if (!TownySettings.isUnwantedBiomeClaimingEnabled()) {
         return selection;
      } else {
         Predicate<WorldCoord> biomeThresholdTest = (wc) -> {
            return BiomeUtil.getWorldCoordUnwantedBiomePercent(wc) < TownySettings.getUnwantedBiomeThreshold();
         };
         return filterOutByBiome(player, selection, biomeThresholdTest, "msg_err_cannot_claim_the_following_worldcoords_because_of_unwanted_biome");
      }
   }

   public static List<WorldCoord> filterOutOceanBiomeWorldCoords(Player player, List<WorldCoord> selection) {
      if (!TownySettings.isOceanClaimingBlocked()) {
         return selection;
      } else {
         Predicate<WorldCoord> biomeThresholdTest = (wc) -> {
            return BiomeUtil.getWorldCoordOceanBiomePercent(wc) < TownySettings.getOceanBlockThreshold();
         };
         return filterOutByBiome(player, selection, biomeThresholdTest, "msg_err_cannot_claim_the_following_worldcoords_because_of_ocean_biome");
      }
   }

   public static List<WorldCoord> filterOutByBiome(Player player, List<WorldCoord> selection, Predicate<WorldCoord> biomeThresholdTest, String errorMsg) {
      Map<Boolean, List<WorldCoord>> worldCoords = (Map)selection.stream().collect(Collectors.partitioningBy(biomeThresholdTest));
      if (!((List)worldCoords.get(false)).isEmpty()) {
         TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of(errorMsg, prettyWorldCoordList((List)worldCoords.get(false))));
      }

      return (List)worldCoords.get(true);
   }

   private static String prettyWorldCoordList(List<WorldCoord> worldCoords) {
      return StringMgmt.join((Collection)worldCoords.stream().map((wc) -> {
         return String.format("(%s)", wc.getCoord().toString());
      }).collect(Collectors.toList()), ", ");
   }

   public static int getAreaSelectPivot(String[] args) {
      for(int i = 0; i < args.length; ++i) {
         if (args[i].equalsIgnoreCase("within")) {
            return i;
         }
      }

      return -1;
   }

   public static boolean isOnEdgeOfOwnership(TownBlockOwner owner, WorldCoord worldCoord) {
      return worldCoord.getCardinallyAdjacentWorldCoords(false).stream().filter((wc) -> {
         return !wc.hasTownBlock() || !wc.getTownBlockOrNull().isOwner(owner);
      }).findAny().isPresent();
   }
}
