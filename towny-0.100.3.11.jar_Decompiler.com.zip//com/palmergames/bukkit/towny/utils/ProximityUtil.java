package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.Coord;
import com.palmergames.bukkit.towny.object.District;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockOwner;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.util.MathUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.jetbrains.annotations.Nullable;

public class ProximityUtil {
   public static void allowTownHomeBlockOrThrow(TownyWorld world, Coord key, @Nullable Town town, boolean newTown) throws TownyException {
      if (world.hasTowns()) {
         int distanceToNextNearestHomeblock;
         if (newTown && (TownySettings.getMinDistanceFromTownPlotblocks() > 0 || TownySettings.getNewTownMinDistanceFromTownPlots() > 0)) {
            distanceToNextNearestHomeblock = TownySettings.getNewTownMinDistanceFromTownPlots();
            if (distanceToNextNearestHomeblock <= 0) {
               distanceToNextNearestHomeblock = TownySettings.getMinDistanceFromTownPlotblocks();
            }

            if (world.getMinDistanceFromOtherTownsPlots(key) < distanceToNextNearestHomeblock) {
               throw new TownyException(Translatable.of("msg_too_close2", Translatable.of("townblock")));
            }
         }

         if (TownySettings.getMinDistanceFromTownHomeblocks() > 0 || TownySettings.getMaxDistanceBetweenHomeblocks() > 0 || TownySettings.getMinDistanceBetweenHomeblocks() > 0 || newTown && TownySettings.getNewTownMinDistanceFromTownHomeblocks() > 0) {
            distanceToNextNearestHomeblock = world.getMinDistanceFromOtherTownsHomeBlocks(key, town);
            int minDistance = newTown ? TownySettings.getNewTownMinDistanceFromTownHomeblocks() : 0;
            if (minDistance <= 0) {
               minDistance = TownySettings.getMinDistanceFromTownHomeblocks();
            }

            if (distanceToNextNearestHomeblock < minDistance || distanceToNextNearestHomeblock < TownySettings.getMinDistanceBetweenHomeblocks()) {
               throw new TownyException(Translatable.of("msg_too_close2", Translatable.of("homeblock")));
            }

            if (TownySettings.getMaxDistanceBetweenHomeblocks() > 0 && distanceToNextNearestHomeblock > TownySettings.getMaxDistanceBetweenHomeblocks()) {
               throw new TownyException(Translatable.of("msg_too_far"));
            }
         }

      }
   }

   public static void allowTownClaimOrThrow(TownyWorld world, WorldCoord townBlockToClaim, @Nullable Town town, boolean outpost) throws TownyException {
      allowTownClaimOrThrow(world, townBlockToClaim, town, outpost, false);
   }

   public static void allowTownClaimOrThrow(TownyWorld world, WorldCoord townBlockToClaim, @Nullable Town town, boolean outpost, boolean trade) throws TownyException {
      if (!town.hasUnlimitedClaims() && town.availableTownBlocks() <= 0) {
         throw new TownyException(Translatable.of("msg_err_not_enough_blocks"));
      } else if (!trade && !townBlockToClaim.isWilderness()) {
         throw new TownyException(Translatable.of("msg_already_claimed", townBlockToClaim.getTownOrNull()));
      } else if (AreaSelectionUtil.isTooCloseToHomeBlock(townBlockToClaim, town)) {
         throw new TownyException(Translatable.of("msg_too_close2", Translatable.of("homeblock")));
      } else if (world.getMinDistanceFromOtherTownsPlots(townBlockToClaim, town) < TownySettings.getMinDistanceFromTownPlotblocks()) {
         throw new TownyException(Translatable.of("msg_too_close2", Translatable.of("townblock")));
      } else {
         testAdjacentClaimsRulesOrThrow(townBlockToClaim, town, outpost);
         if (!outpost && !isEdgeBlock(town, townBlockToClaim) && !town.getTownBlocks().isEmpty()) {
            throw new TownyException(Translatable.of("msg_err_not_attached_edge"));
         }
      }
   }

   public static void testAdjacentClaimsRulesOrThrow(WorldCoord townBlockToClaim, Town town, boolean outpost) throws TownyException {
      int minAdjacentBlocks = TownySettings.getMinAdjacentBlocks();
      testAdjacentClaimsRulesOrThrow(townBlockToClaim, town, outpost, minAdjacentBlocks);
   }

   public static void testAdjacentClaimsRulesOrThrow(WorldCoord townBlockToClaim, Town town, boolean outpost, int minAdjacentBlocks) throws TownyException {
      if (!outpost && minAdjacentBlocks > 0 && townHasClaimedEnoughLandToBeRestrictedByAdjacentClaims(town, minAdjacentBlocks)) {
         int numAdjacent = numAdjacentTownOwnedTownBlocks(town, townBlockToClaim);
         if (numAdjacent < minAdjacentBlocks && numAdjacentOutposts(town, townBlockToClaim) == 0) {
            throw new TownyException(Translatable.of("msg_min_adjacent_blocks", minAdjacentBlocks, numAdjacent));
         }
      }

   }

   private static boolean townHasClaimedEnoughLandToBeRestrictedByAdjacentClaims(Town town, int minAdjacentBlocks) {
      if (minAdjacentBlocks == 3 && town.getTownBlocks().size() < 5) {
         return false;
      } else {
         return town.getTownBlocks().size() > minAdjacentBlocks;
      }
   }

   private static int numAdjacentTownOwnedTownBlocks(Town town, WorldCoord worldCoord) {
      return (int)worldCoord.getCardinallyAdjacentWorldCoords(true).stream().filter((wc) -> {
         return wc.hasTown(town);
      }).count();
   }

   private static int numAdjacentOutposts(Town town, WorldCoord worldCoord) {
      return (int)worldCoord.getCardinallyAdjacentWorldCoords(true).stream().filter((wc) -> {
         return wc.hasTown(town);
      }).map(WorldCoord::getTownBlockOrNull).filter(Objects::nonNull).filter(TownBlock::isOutpost).count();
   }

   private static boolean isEdgeBlock(TownBlockOwner owner, WorldCoord worldCoord) {
      Iterator var2 = worldCoord.getCardinallyAdjacentWorldCoords().iterator();

      WorldCoord wc;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         wc = (WorldCoord)var2.next();
      } while(wc.isWilderness() || !wc.getTownBlockOrNull().isOwner(owner));

      return true;
   }

   public static void allowTownUnclaimOrThrow(TownyWorld world, WorldCoord townBlockToUnclaim, @Nullable Town town) throws TownyException {
      if (townBlockToUnclaim.isWilderness()) {
         throw new TownyException(Translatable.of("msg_err_empty_area_selection"));
      } else if (!townBlockToUnclaim.getTownBlockOrNull().getTownOrNull().equals(town)) {
         throw new TownyException(Translatable.of("msg_not_own_area"));
      } else if (townBlockToUnclaim.getTownBlock().isHomeBlock()) {
         throw new TownyException(Translatable.of("msg_err_cannot_unclaim_homeblock"));
      } else {
         testAdjacentUnclaimsRulesOrThrow(townBlockToUnclaim, town);
      }
   }

   public static void testAdjacentUnclaimsRulesOrThrow(WorldCoord townBlockToUnclaim, Town town) throws TownyException {
      int minAdjacentBlocks = TownySettings.getMinAdjacentBlocks();
      testAdjacentUnclaimsRulesOrThrow(townBlockToUnclaim, town, minAdjacentBlocks);
   }

   public static void testAdjacentUnclaimsRulesOrThrow(WorldCoord townBlockToUnclaim, Town town, int minAdjacentBlocks) throws TownyException {
      if (minAdjacentBlocks > 0 && townHasClaimedEnoughLandToBeRestrictedByAdjacentClaims(town, minAdjacentBlocks)) {
         Iterator var4 = townBlockToUnclaim.getCardinallyAdjacentWorldCoords(true).iterator();

         while(var4.hasNext()) {
            WorldCoord wc = (WorldCoord)var4.next();
            if (!wc.isWilderness() && wc.hasTown(town)) {
               int numAdjacent = numAdjacentTownOwnedTownBlocks(town, wc);
               if (numAdjacent - 1 < minAdjacentBlocks && numAdjacentOutposts(town, wc) == 0) {
                  throw new TownyException(Translatable.of("msg_err_cannot_unclaim_not_enough_adjacent_claims", wc.getX(), wc.getZ(), numAdjacent));
               }
            }
         }
      }

   }

   public static void testAdjacentAddDistrictRulesOrThrow(WorldCoord townBlockToClaim, Town town, District district, int minAdjacentBlocks) throws TownyException {
      if (minAdjacentBlocks > 0 && townHasClaimedEnoughLandToBeRestrictedByAdjacentClaims(town, minAdjacentBlocks)) {
         int numAdjacent = numAdjacentDistrictTownBlocks(town, district, townBlockToClaim);
         if (numAdjacent < minAdjacentBlocks) {
            throw new TownyException(Translatable.of("msg_min_adjacent_blocks", minAdjacentBlocks, numAdjacent));
         }
      }

   }

   public static void testAdjacentRemoveDistrictRulesOrThrow(WorldCoord townBlockToUnclaim, Town town, District district, int minAdjacentBlocks) throws TownyException {
      if (minAdjacentBlocks > 0 && townHasClaimedEnoughLandToBeRestrictedByAdjacentClaims(town, minAdjacentBlocks)) {
         Iterator var5 = townBlockToUnclaim.getCardinallyAdjacentWorldCoords(true).iterator();

         while(var5.hasNext()) {
            WorldCoord wc = (WorldCoord)var5.next();
            if (!wc.isWilderness() && wc.hasTown(town) && wc.getTownBlock().hasDistrict() && wc.getTownBlock().getDistrict().getName().equals(district.getName())) {
               int numAdjacent = numAdjacentDistrictTownBlocks(town, district, wc);
               if (numAdjacent - 1 < minAdjacentBlocks) {
                  throw new TownyException(Translatable.of("msg_err_cannot_remove_from_district_not_enough_adjacent_claims", wc.getX(), wc.getZ(), numAdjacent));
               }
            }
         }
      }

   }

   private static int numAdjacentDistrictTownBlocks(Town town, District district, WorldCoord worldCoord) {
      return (int)worldCoord.getCardinallyAdjacentWorldCoords(true).stream().filter((wc) -> {
         return wc.hasTown(town) && wc.getTownBlockOrNull() != null;
      }).map((wc) -> {
         return wc.getTownBlockOrNull();
      }).filter((tb) -> {
         return tb.hasDistrict() && tb.getDistrict().equals(district);
      }).count();
   }

   public static void testTownProximityToNation(Town town, Nation nation) throws TownyException {
      if (!(TownySettings.getNationProximityToCapital() <= 0.0D)) {
         Town capital = nation.getCapital();
         if (capital.hasHomeBlock() && town.hasHomeBlock()) {
            WorldCoord capitalCoord = capital.getHomeBlockOrNull().getWorldCoord();
            WorldCoord townCoord = town.getHomeBlockOrNull().getWorldCoord();
            if (!capitalCoord.getWorldName().equalsIgnoreCase(townCoord.getWorldName())) {
               throw new TownyException(Translatable.of("msg_err_nation_homeblock_in_another_world"));
            } else if (isTownTooFarFromNation(town, capital, nation.getTowns())) {
               throw new TownyException(Translatable.of("msg_err_town_not_close_enough_to_nation", town.getName()));
            }
         } else {
            throw new TownyException(Translatable.of("msg_err_homeblock_has_not_been_set"));
         }
      }
   }

   public static List<Town> gatherOutOfRangeTowns(Nation nation) {
      return gatherOutOfRangeTowns(nation, nation.getCapital());
   }

   public static List<Town> gatherOutOfRangeTowns(Nation nation, Town capital) {
      List<Town> removedTowns = new ArrayList();
      if (TownySettings.getNationProximityToCapital() <= 0.0D) {
         return removedTowns;
      } else {
         TownBlock capitalHomeBlock = capital.getHomeBlockOrNull();
         if (capitalHomeBlock == null) {
            return removedTowns;
         } else {
            WorldCoord capitalCoord = capitalHomeBlock.getWorldCoord();
            List<Town> townsToCheck = nation.getTowns();

            for(List localRemovedTowns = townsToCheck; localRemovedTowns.size() > 0; townsToCheck = (List)nation.getTowns().stream().filter((t) -> {
               return !removedTowns.contains(t);
            }).collect(Collectors.toList())) {
               localRemovedTowns = getListOfOutOfRangeTownsFromList(townsToCheck, capital, capitalCoord);
               Iterator var7 = localRemovedTowns.iterator();

               while(var7.hasNext()) {
                  Town localTown = (Town)var7.next();
                  if (!removedTowns.contains(localTown)) {
                     removedTowns.add(localTown);
                  }
               }
            }

            return removedTowns;
         }
      }
   }

   private static List<Town> getListOfOutOfRangeTownsFromList(List<Town> towns, Town capital, WorldCoord capitalCoord) {
      List<Town> removedTowns = new ArrayList();
      Iterator var4 = towns.iterator();

      while(var4.hasNext()) {
         Town town = (Town)var4.next();
         if (!town.equals(capital) && isTownTooFarFromNation(town, capital, towns)) {
            removedTowns.add(town);
         }
      }

      return removedTowns;
   }

   public static void removeOutOfRangeTowns(Nation nation) {
      if (nation.hasCapital() && !(TownySettings.getNationProximityToCapital() <= 0.0D)) {
         List<Town> toRemove = gatherOutOfRangeTowns(nation);
         if (!toRemove.isEmpty()) {
            toRemove.stream().forEach((town) -> {
               TownyMessaging.sendPrefixedTownMessage(town, Translatable.of("msg_town_left_nation", nation.getName()));
               TownyMessaging.sendPrefixedNationMessage(nation, Translatable.of("msg_nation_town_left", town.getName()));
               town.removeNation();
               town.save();
            });
         }
      }
   }

   public static boolean isTownTooFarFromNation(Town town, Town newCapital, List<Town> towns) {
      return !closeEnoughToCapital(town, newCapital) && !closeEnoughToOtherNationTowns(town, newCapital, towns);
   }

   private static boolean closeEnoughToCapital(Town town, Town newCapital) {
      return closeEnoughToTown(town, newCapital, TownySettings.getNationProximityToCapital());
   }

   private static boolean closeEnoughToOtherNationTowns(Town town, Town newCapital, List<Town> towns) {
      double maxDistanceFromOtherTowns = TownySettings.getNationProximityToOtherNationTowns();
      double maxDistanceFromTheCapital = TownySettings.getNationProximityAbsoluteMaximum();
      if (maxDistanceFromOtherTowns <= 0.0D) {
         return false;
      } else {
         return maxDistanceFromTheCapital > 0.0D && !closeEnoughToTown(town, newCapital, maxDistanceFromTheCapital) ? false : towns.stream().filter((t) -> {
            return !t.equals(town) && !t.isCapital();
         }).anyMatch((t) -> {
            return closeEnoughToTown(town, t, maxDistanceFromOtherTowns);
         });
      }
   }

   private static boolean closeEnoughToTown(Town town1, Town town2, double maxAllowedDistance) {
      if (town1.hasHomeBlock() && town2.hasHomeBlock()) {
         WorldCoord town1Coord = town1.getHomeBlockOrNull().getWorldCoord();
         WorldCoord town2Coord = town2.getHomeBlockOrNull().getWorldCoord();
         if (!town1Coord.getWorldName().equals(town2Coord.getWorldName())) {
            return false;
         } else {
            return MathUtil.distance(town1Coord, town2Coord) <= maxAllowedDistance;
         }
      } else {
         return false;
      }
   }
}
