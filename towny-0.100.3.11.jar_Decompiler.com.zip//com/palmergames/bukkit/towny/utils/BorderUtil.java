package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.CellBorder;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyPermission;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Collectors;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;

public class BorderUtil {
   private static final int[][] DIRECTIONS = new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

   public static List<CellBorder> getOuterBorder(List<WorldCoord> worldCoords) {
      List<CellBorder> borderCoords = new ArrayList();
      Iterator var2 = worldCoords.iterator();

      while(var2.hasNext()) {
         WorldCoord worldCoord = (WorldCoord)var2.next();
         CellBorder border = new CellBorder(worldCoord, new boolean[]{!worldCoords.contains(worldCoord.add(-1, 0)), !worldCoords.contains(worldCoord.add(-1, -1)), !worldCoords.contains(worldCoord.add(0, -1)), !worldCoords.contains(worldCoord.add(1, -1)), !worldCoords.contains(worldCoord.add(1, 0)), !worldCoords.contains(worldCoord.add(1, 1)), !worldCoords.contains(worldCoord.add(0, 1)), !worldCoords.contains(worldCoord.add(-1, 1))});
         if (border.hasAnyBorder()) {
            borderCoords.add(border);
         }
      }

      return borderCoords;
   }

   public static List<CellBorder> getPlotBorder(List<WorldCoord> worldCoords) {
      List<CellBorder> borderCoords = new ArrayList();
      Iterator var2 = worldCoords.iterator();

      while(var2.hasNext()) {
         WorldCoord worldCoord = (WorldCoord)var2.next();
         CellBorder border = getPlotBorder(worldCoord);
         borderCoords.add(border);
      }

      return borderCoords;
   }

   public static CellBorder getPlotBorder(WorldCoord worldCoord) {
      return new CellBorder(worldCoord, new boolean[]{true, true, true, true, true, true, true, true});
   }

   public static List<BlockState> allowedBlocks(List<BlockState> blocks, Block originBlock) {
      return allowedBlocks(blocks, originBlock, (Player)null);
   }

   public static List<BlockState> allowedBlocks(List<BlockState> blocks, Block originBlock, Player player) {
      return (List)blocks.stream().filter((blockState) -> {
         return allowedMove(originBlock, blockState.getBlock(), player);
      }).collect(Collectors.toList());
   }

   public static List<BlockState> disallowedBlocks(List<BlockState> blocks, Block originBlock) {
      return disallowedBlocks(blocks, originBlock, (Player)null);
   }

   public static List<BlockState> disallowedBlocks(List<BlockState> blocks, Block originBlock, Player player) {
      return (List)blocks.stream().filter((blockState) -> {
         return !allowedMove(originBlock, blockState.getBlock(), player);
      }).collect(Collectors.toList());
   }

   public static boolean allowedMove(Block block, Block blockTo) {
      return allowedMove(block, blockTo, (Player)null);
   }

   public static boolean allowedMove(Block block, Block blockTo, @Nullable Player player) {
      if (player != null && PlayerCacheUtil.getCachePermission(player, blockTo.getLocation(), block.getType(), TownyPermission.ActionType.BUILD) && PlayerCacheUtil.getCachePermission(player, block.getLocation(), block.getType(), TownyPermission.ActionType.BUILD)) {
         return true;
      } else {
         WorldCoord from = WorldCoord.parseWorldCoord(block);
         WorldCoord to = WorldCoord.parseWorldCoord(blockTo);
         if (!from.equals(to) && !TownyAPI.getInstance().isWilderness(to)) {
            if (!from.hasTownBlock()) {
               return false;
            } else {
               TownBlock currentTownBlock = from.getTownBlockOrNull();
               TownBlock destinationTownBlock = to.getTownBlockOrNull();
               if (currentTownBlock.hasResident() != destinationTownBlock.hasResident()) {
                  return false;
               } else {
                  Resident resident = player != null ? TownyAPI.getInstance().getResident(player) : null;
                  if (resident != null && currentTownBlock.hasTrustedResident(resident) && !destinationTownBlock.hasTrustedResident(resident) && destinationTownBlock.getResidentOrNull() != resident) {
                     return false;
                  } else if (currentTownBlock.hasResident() && destinationTownBlock.hasResident() && currentTownBlock.getResidentOrNull() == destinationTownBlock.getResidentOrNull()) {
                     return true;
                  } else {
                     return currentTownBlock.getTownOrNull() == destinationTownBlock.getTownOrNull() && !currentTownBlock.hasResident() && !destinationTownBlock.hasResident();
                  }
               }
            }
         } else {
            return true;
         }
      }
   }

   @Internal
   @NotNull
   public static BorderUtil.FloodfillResult getFloodFillableCoords(@NotNull Town town, @NotNull WorldCoord origin) {
      TownyWorld originWorld = origin.getTownyWorld();
      if (originWorld == null) {
         return BorderUtil.FloodfillResult.fail((Translatable)null);
      } else if (origin.hasTownBlock()) {
         return BorderUtil.FloodfillResult.fail(Translatable.of("msg_err_floodfill_not_in_wild"));
      } else {
         Set<WorldCoord> coords = new HashSet(town.getTownBlockMap().keySet());
         coords.removeIf((coordx) -> {
            return !originWorld.equals(coordx.getTownyWorld());
         });
         if (coords.isEmpty()) {
            return BorderUtil.FloodfillResult.fail((Translatable)null);
         } else {
            int minX = origin.getX();
            int maxX = origin.getX();
            int minZ = origin.getZ();
            int maxZ = origin.getZ();

            WorldCoord coord;
            for(Iterator var8 = coords.iterator(); var8.hasNext(); maxZ = Math.max(maxZ, coord.getZ())) {
               coord = (WorldCoord)var8.next();
               minX = Math.min(minX, coord.getX());
               maxX = Math.max(maxX, coord.getX());
               minZ = Math.min(minZ, coord.getZ());
            }

            Set<WorldCoord> valid = new HashSet();
            Set<WorldCoord> visited = new HashSet();
            Queue<WorldCoord> queue = new LinkedList();
            queue.offer(origin);
            visited.add(origin);

            while(!queue.isEmpty()) {
               WorldCoord current = (WorldCoord)queue.poll();
               valid.add(current);
               int[][] var12 = DIRECTIONS;
               int var13 = var12.length;

               for(int var14 = 0; var14 < var13; ++var14) {
                  int[] direction = var12[var14];
                  int xOffset = direction[0];
                  int zOffset = direction[1];
                  WorldCoord candidate = current.add(xOffset, zOffset);
                  if (!coords.contains(candidate) && (candidate.getX() >= maxX || candidate.getX() <= minX || candidate.getZ() >= maxZ || candidate.getZ() <= minZ)) {
                     return BorderUtil.FloodfillResult.oob();
                  }

                  TownBlock townBlock = candidate.getTownBlockOrNull();
                  if (townBlock != null && townBlock.hasTown() && !town.equals(townBlock.getTownOrNull())) {
                     return BorderUtil.FloodfillResult.fail(Translatable.of("msg_err_floodfill_cannot_contain_towns"));
                  }

                  if (townBlock == null && !visited.contains(candidate) && !coords.contains(candidate)) {
                     queue.offer(candidate);
                     visited.add(candidate);
                  }
               }
            }

            return BorderUtil.FloodfillResult.success(valid);
         }
      }
   }

   public static record FloodfillResult(@NotNull BorderUtil.FloodfillResult.Type type, @Nullable Translatable feedback, @NotNull Collection<WorldCoord> coords) {
      public FloodfillResult(@NotNull BorderUtil.FloodfillResult.Type type, @Nullable Translatable feedback, @NotNull Collection<WorldCoord> coords) {
         this.type = type;
         this.feedback = feedback;
         this.coords = coords;
      }

      static BorderUtil.FloodfillResult fail(@Nullable Translatable feedback) {
         return new BorderUtil.FloodfillResult(BorderUtil.FloodfillResult.Type.FAIL, feedback, Collections.emptySet());
      }

      static BorderUtil.FloodfillResult oob() {
         return new BorderUtil.FloodfillResult(BorderUtil.FloodfillResult.Type.OUT_OF_BOUNDS, Translatable.of("msg_err_floodfill_out_of_bounds"), Collections.emptySet());
      }

      static BorderUtil.FloodfillResult success(Collection<WorldCoord> coords) {
         return new BorderUtil.FloodfillResult(BorderUtil.FloodfillResult.Type.SUCCESS, (Translatable)null, coords);
      }

      @NotNull
      public BorderUtil.FloodfillResult.Type type() {
         return this.type;
      }

      @Nullable
      public Translatable feedback() {
         return this.feedback;
      }

      @NotNull
      public Collection<WorldCoord> coords() {
         return this.coords;
      }

      public static enum Type {
         SUCCESS,
         FAIL,
         OUT_OF_BOUNDS;

         // $FF: synthetic method
         private static BorderUtil.FloodfillResult.Type[] $values() {
            return new BorderUtil.FloodfillResult.Type[]{SUCCESS, FAIL, OUT_OF_BOUNDS};
         }
      }
   }
}
