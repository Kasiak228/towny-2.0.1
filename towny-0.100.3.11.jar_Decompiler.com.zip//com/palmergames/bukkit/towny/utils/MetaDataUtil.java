package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.object.TownyObject;
import com.palmergames.bukkit.towny.object.metadata.BooleanDataField;
import com.palmergames.bukkit.towny.object.metadata.ByteDataField;
import com.palmergames.bukkit.towny.object.metadata.CustomDataField;
import com.palmergames.bukkit.towny.object.metadata.DecimalDataField;
import com.palmergames.bukkit.towny.object.metadata.IntegerDataField;
import com.palmergames.bukkit.towny.object.metadata.LocationDataField;
import com.palmergames.bukkit.towny.object.metadata.LongDataField;
import com.palmergames.bukkit.towny.object.metadata.StringDataField;
import org.bukkit.Location;
import org.jetbrains.annotations.Nullable;

public class MetaDataUtil {
   public static boolean hasMeta(TownyObject townyObject, String key) {
      return townyObject.hasMeta(key);
   }

   public static boolean hasMeta(TownyObject townyObject, StringDataField sdf) {
      return townyObject.hasMeta(sdf.getKey());
   }

   public static boolean hasMeta(TownyObject townyObject, BooleanDataField bdf) {
      return townyObject.hasMeta(bdf.getKey());
   }

   public static boolean hasMeta(TownyObject townyObject, LongDataField ldf) {
      return townyObject.hasMeta(ldf.getKey());
   }

   public static boolean hasMeta(TownyObject townyObject, IntegerDataField idf) {
      return townyObject.hasMeta(idf.getKey());
   }

   public static boolean hasMeta(TownyObject townyObject, DecimalDataField ddf) {
      return townyObject.hasMeta(ddf.getKey());
   }

   public static boolean hasMeta(TownyObject townyObject, ByteDataField bdf) {
      return townyObject.hasMeta(bdf.getKey());
   }

   public static boolean hasMeta(TownyObject townyObject, LocationDataField ldf) {
      return townyObject.hasMeta(ldf.getKey());
   }

   public static String getString(TownyObject townyObject, StringDataField sdf) {
      CustomDataField<?> cdf = townyObject.getMetadata(sdf.getKey());
      return cdf instanceof StringDataField ? (String)((StringDataField)cdf).getValue() : "";
   }

   public static boolean getBoolean(TownyObject townyObject, BooleanDataField bdf) {
      CustomDataField<?> cdf = townyObject.getMetadata(bdf.getKey());
      return cdf instanceof BooleanDataField ? (Boolean)((BooleanDataField)cdf).getValue() : false;
   }

   public static long getLong(TownyObject townyObject, LongDataField ldf) {
      CustomDataField<?> cdf = townyObject.getMetadata(ldf.getKey());
      return cdf instanceof LongDataField ? (Long)((LongDataField)cdf).getValue() : 0L;
   }

   public static int getInt(TownyObject townyObject, IntegerDataField idf) {
      CustomDataField<?> cdf = townyObject.getMetadata(idf.getKey());
      return cdf instanceof IntegerDataField ? (Integer)((IntegerDataField)cdf).getValue() : 0;
   }

   public static double getDouble(TownyObject townyObject, DecimalDataField ddf) {
      CustomDataField<?> cdf = townyObject.getMetadata(ddf.getKey());
      return cdf instanceof DecimalDataField ? (Double)((DecimalDataField)cdf).getValue() : 0.0D;
   }

   public static byte getByte(TownyObject townyObject, ByteDataField bdf) {
      CustomDataField<?> cdf = townyObject.getMetadata(bdf.getKey());
      return cdf instanceof ByteDataField ? (Byte)((ByteDataField)cdf).getValue() : 0;
   }

   @Nullable
   public static Location getLocation(TownyObject townyObject, LocationDataField ldf) {
      CustomDataField<?> cdf = townyObject.getMetadata(ldf.getKey());
      return cdf instanceof LocationDataField ? (Location)((LocationDataField)cdf).getValue() : null;
   }

   public static void addNewMeta(TownyObject townyObject, StringDataField sdf, boolean save) {
      townyObject.addMetaData(sdf, save);
   }

   public static void addNewMeta(TownyObject townyObject, BooleanDataField bdf, boolean save) {
      townyObject.addMetaData(bdf, save);
   }

   public static void addNewMeta(TownyObject townyObject, LongDataField ldf, boolean save) {
      townyObject.addMetaData(ldf, save);
   }

   public static void addNewMeta(TownyObject townyObject, IntegerDataField idf, boolean save) {
      townyObject.addMetaData(idf, save);
   }

   public static void addNewMeta(TownyObject townyObject, DecimalDataField ddf, boolean save) {
      townyObject.addMetaData(ddf, save);
   }

   public static void addNewMeta(TownyObject townyObject, ByteDataField bdf, boolean save) {
      townyObject.addMetaData(bdf, save);
   }

   public static void addNewMeta(TownyObject townyObject, LocationDataField ldf, boolean save) {
      townyObject.addMetaData(ldf, save);
   }

   public static void addNewStringMeta(TownyObject townyObject, String key, String value, boolean save) {
      addNewMeta(townyObject, new StringDataField(key, value), save);
   }

   public static void addNewBooleanMeta(TownyObject townyObject, String key, boolean value, boolean save) {
      addNewMeta(townyObject, new BooleanDataField(key, value), save);
   }

   public static void addNewLongMeta(TownyObject townyObject, String key, long value, boolean save) {
      addNewMeta(townyObject, new LongDataField(key, value), save);
   }

   public static void addNewIntegerMeta(TownyObject townyObject, String key, int value, boolean save) {
      addNewMeta(townyObject, new IntegerDataField(key, value), save);
   }

   public static void addNewDoubleMeta(TownyObject townyObject, String key, double value, boolean save) {
      addNewMeta(townyObject, new DecimalDataField(key, value), save);
   }

   public static void addNewByteMeta(TownyObject townyObject, String key, byte value, boolean save) {
      addNewMeta(townyObject, new ByteDataField(key, value), save);
   }

   public static void addNewLocationMeta(TownyObject townyObject, String key, Location value, boolean save) {
      addNewMeta(townyObject, new LocationDataField(key, value), save);
   }

   public static void setString(TownyObject townyObject, StringDataField sdf, String string, boolean save) {
      CustomDataField<?> cdf = townyObject.getMetadata(sdf.getKey());
      if (cdf == null) {
         addNewStringMeta(townyObject, sdf.getKey(), string, save);
      } else {
         if (cdf instanceof StringDataField) {
            StringDataField value = (StringDataField)cdf;
            value.setValue(string);
            if (save) {
               townyObject.save();
            }
         }

      }
   }

   public static void setBoolean(TownyObject townyObject, BooleanDataField bdf, boolean bool, boolean save) {
      CustomDataField<?> cdf = townyObject.getMetadata(bdf.getKey());
      if (cdf == null) {
         addNewBooleanMeta(townyObject, bdf.getKey(), bool, save);
      } else {
         if (cdf instanceof BooleanDataField) {
            BooleanDataField value = (BooleanDataField)cdf;
            value.setValue(bool);
            if (save) {
               townyObject.save();
            }
         }

      }
   }

   public static void setLong(TownyObject townyObject, LongDataField ldf, long num, boolean save) {
      CustomDataField<?> cdf = townyObject.getMetadata(ldf.getKey());
      if (cdf == null) {
         addNewLongMeta(townyObject, ldf.getKey(), num, save);
      } else {
         if (cdf instanceof LongDataField) {
            LongDataField value = (LongDataField)cdf;
            value.setValue(num);
            if (save) {
               townyObject.save();
            }
         }

      }
   }

   public static void setInt(TownyObject townyObject, IntegerDataField idf, int num, boolean save) {
      CustomDataField<?> cdf = townyObject.getMetadata(idf.getKey());
      if (cdf == null) {
         addNewIntegerMeta(townyObject, idf.getKey(), num, save);
      } else {
         if (cdf instanceof IntegerDataField) {
            IntegerDataField value = (IntegerDataField)cdf;
            value.setValue(num);
            if (save) {
               townyObject.save();
            }
         }

      }
   }

   public static void setDouble(TownyObject townyObject, DecimalDataField ddf, double num, boolean save) {
      CustomDataField<?> cdf = townyObject.getMetadata(ddf.getKey());
      if (cdf == null) {
         addNewDoubleMeta(townyObject, ddf.getKey(), num, save);
      } else {
         if (cdf instanceof DecimalDataField) {
            DecimalDataField value = (DecimalDataField)cdf;
            value.setValue(num);
            if (save) {
               townyObject.save();
            }
         }

      }
   }

   public static void setByte(TownyObject townyObject, ByteDataField bdf, byte num, boolean save) {
      CustomDataField<?> cdf = townyObject.getMetadata(bdf.getKey());
      if (cdf == null) {
         addNewByteMeta(townyObject, bdf.getKey(), num, save);
      } else {
         if (cdf instanceof ByteDataField) {
            ByteDataField value = (ByteDataField)cdf;
            value.setValue(num);
            if (save) {
               townyObject.save();
            }
         }

      }
   }

   public static void setLocation(TownyObject townyObject, LocationDataField ldf, Location loc, boolean save) {
      CustomDataField<?> cdf = townyObject.getMetadata(ldf.getKey());
      if (cdf == null) {
         addNewLocationMeta(townyObject, ldf.getKey(), loc, save);
      } else {
         if (cdf instanceof LocationDataField) {
            LocationDataField value = (LocationDataField)cdf;
            value.setValue(loc);
            if (save) {
               townyObject.save();
            }
         }

      }
   }
}
