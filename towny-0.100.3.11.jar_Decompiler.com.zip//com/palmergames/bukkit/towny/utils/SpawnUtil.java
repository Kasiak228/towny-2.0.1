package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyTimerHandler;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.confirmations.Confirmation;
import com.palmergames.bukkit.towny.event.NationSpawnEvent;
import com.palmergames.bukkit.towny.event.SpawnEvent;
import com.palmergames.bukkit.towny.event.TownSpawnEvent;
import com.palmergames.bukkit.towny.event.teleport.ResidentSpawnEvent;
import com.palmergames.bukkit.towny.event.teleport.SuccessfulTownyTeleportEvent;
import com.palmergames.bukkit.towny.event.teleport.UnjailedResidentTeleportEvent;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.SpawnInformation;
import com.palmergames.bukkit.towny.object.SpawnType;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyObject;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.economy.Account;
import com.palmergames.bukkit.towny.object.spawnlevel.NationSpawnLevel;
import com.palmergames.bukkit.towny.object.spawnlevel.TownSpawnLevel;
import com.palmergames.bukkit.towny.permissions.PermissionNodes;
import com.palmergames.bukkit.towny.tasks.CooldownTimerTask;
import com.palmergames.bukkit.towny.tasks.TeleportWarmupTimerTask;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.paperlib.PaperLib;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.permissions.Permissible;
import org.jetbrains.annotations.Nullable;

public class SpawnUtil {
   private static Towny plugin;

   public static void initialize(Towny plugin) {
      SpawnUtil.plugin = plugin;
   }

   public static void sendToTownySpawn(Player player, String[] split, TownyObject townyObject, String notAffordMSG, boolean outpost, boolean ignoreWarn, SpawnType spawnType) throws TownyException {
      Resident resident = TownyAPI.getInstance().getResidentOrThrow(player);
      Town var10000;
      switch(spawnType) {
      case RESIDENT:
         var10000 = resident.getTownOrNull();
         break;
      case TOWN:
         var10000 = (Town)townyObject;
         break;
      default:
         var10000 = null;
      }

      Town town = var10000;
      Nation nation = spawnType == SpawnType.NATION ? (Nation)townyObject : null;
      SpawnInformation spawnInfo = getSpawnInformation(player, split.length == 0, notAffordMSG, outpost, spawnType, resident, town, nation);
      getSpawnLoc(player, town, nation, spawnType, outpost, split).thenAccept((spawnLoc) -> {
         if (!spawnLoc.isWorldLoaded()) {
            TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_err_world_not_loaded"));
         } else {
            try {
               sendSpawnEvent(player, spawnType, spawnLoc, spawnInfo);
            } catch (TownyException var10) {
               TownyMessaging.sendErrorMsg((Object)player, (String)var10.getMessage(player));
               return;
            }

            if (spawnInfo.travelCost > 0.0D) {
               String paymentMsg = getPaymentMsg(spawnInfo.townSpawnLevel, spawnInfo.nationSpawnLevel, spawnType);
               Account payee = TownySettings.isTownSpawnPaidToTown() ? getPayee(town, nation, spawnType) : Account.SERVER_ACCOUNT;
               initiateCostedSpawn(player, resident, spawnLoc, spawnInfo.travelCost, (Account)payee, paymentMsg, ignoreWarn, spawnInfo.cooldown);
            } else {
               initiateSpawn(player, spawnLoc, spawnInfo.cooldown, 0.0D, (Account)null);
            }

         }
      });
   }

   private static SpawnInformation getSpawnInformation(Player player, boolean noCmdArgs, String notAffordMSG, boolean outpost, SpawnType spawnType, Resident resident, Town town, Nation nation) {
      boolean isTownyAdmin = isTownyAdmin(player);
      SpawnInformation spawnInformation = new SpawnInformation();

      try {
         testResidentAbility(resident);
         spawnInformation.townSpawnLevel = getTownSpawnLevel(player, noCmdArgs, spawnType, resident, town, outpost, isTownyAdmin);
         spawnInformation.nationSpawnLevel = getNationSpawnLevel(player, noCmdArgs, spawnType, resident, nation, isTownyAdmin);
         spawnInformation.cooldown = getCooldown(player, spawnInformation);
         if (!isTownyAdmin) {
            testDisallowedZones(player, resident, spawnType, TownySettings.getDisallowedTownSpawnZones());
         }

         spawnInformation.travelCost = getTravelCost(player, town, nation, spawnInformation.townSpawnLevel, spawnInformation.nationSpawnLevel, spawnType);
         if (spawnInformation.travelCost > 0.0D && !resident.getAccount().canPayFromHoldings(spawnInformation.travelCost)) {
            throw new TownyException(notAffordMSG);
         }
      } catch (TownyException var11) {
         spawnInformation.eventCancelled = true;
         spawnInformation.eventCancellationMessage = var11.getMessage();
      }

      return spawnInformation;
   }

   public static void outlawTeleport(Town town, Resident outlaw) {
      Player outlawedPlayer = outlaw.getPlayer();
      if (outlawedPlayer != null) {
         PaperLib.getBedSpawnLocationAsync(outlawedPlayer, true).thenAccept((bed) -> {
            Location spawnLocation = town.getWorld().getSpawnLocation();
            if (!TownySettings.getOutlawTeleportWorld().equals("")) {
               spawnLocation = ((World)Objects.requireNonNull(Bukkit.getWorld(TownySettings.getOutlawTeleportWorld()))).getSpawnLocation();
            }

            if (bed != null && TownyAPI.getInstance().getTown(bed) != town) {
               spawnLocation = bed;
            }

            if (outlaw.hasTown() && TownyAPI.getInstance().getTownSpawnLocation(outlawedPlayer) != null) {
               spawnLocation = TownyAPI.getInstance().getTownSpawnLocation(outlawedPlayer);
            }

            TownyMessaging.sendMsg(outlaw, Translatable.of("msg_outlaw_kicked", town));
            initiatePluginTeleport(outlaw, spawnLocation, true);
         });
      }
   }

   public static void jailAwayTeleport(Resident jailed) {
      getIdealLocation(jailed).thenAccept((loc) -> {
         UnjailedResidentTeleportEvent event = new UnjailedResidentTeleportEvent(jailed, loc);
         if (!BukkitTools.isEventCancelled(event)) {
            initiatePluginTeleport(jailed, event.getLocation(), false);
         }
      });
   }

   public static void jailTeleport(Resident jailed) {
      initiatePluginTeleport(jailed, jailed.getJailSpawn(), false);
   }

   private static void testResidentAbility(Resident resident) throws TownyException {
      if (CooldownTimerTask.hasCooldown(resident.getName(), "teleport")) {
         throw new TownyException(Translatable.of("msg_err_cannot_spawn_x_seconds_remaining", CooldownTimerTask.getCooldownRemaining(resident.getName(), "teleport")));
      } else if (resident.isJailed()) {
         throw new TownyException(Translatable.of("msg_cannot_spawn_while_jailed"));
      }
   }

   private static boolean isTownyAdmin(Player player) {
      return TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((Permissible)player) || hasPerm(player, PermissionNodes.TOWNY_SPAWN_ADMIN);
   }

   private static boolean playerHasFreeSpawn(Player player) {
      return hasPerm(player, PermissionNodes.TOWNY_COMMAND_TOWNYADMIN_TOWN_SPAWN_FREECHARGE) || hasPerm(player, PermissionNodes.TOWNY_SPAWN_ADMIN_NOCHARGE);
   }

   private static TownSpawnLevel getTownSpawnLevel(Player player, boolean noCmdArgs, SpawnType spawnType, Resident resident, Town town, boolean outpost, boolean isTownyAdmin) throws TownyException {
      TownSpawnLevel var10000;
      switch(spawnType) {
      case RESIDENT:
         var10000 = isTownyAdmin ? TownSpawnLevel.ADMIN : TownSpawnLevel.TOWN_RESIDENT;
         break;
      case TOWN:
         var10000 = isTownyAdmin ? TownSpawnLevel.ADMIN : getTownSpawnLevel(player, resident, town, outpost, noCmdArgs);
         break;
      default:
         var10000 = null;
      }

      return var10000;
   }

   private static TownSpawnLevel getTownSpawnLevel(Player player, Resident resident, Town town, boolean outpost, boolean noArg) throws TownyException {
      TownSpawnLevel townSpawnLevel = null;
      if (noArg && !outpost) {
         townSpawnLevel = TownSpawnLevel.TOWN_RESIDENT;
      } else {
         if (TownySettings.trustedResidentsGetToSpawnToTown() && (town.hasTrustedResident(resident) || resident.hasTown() && town.hasTrustedTown(resident.getTownOrNull()))) {
            townSpawnLevel = TownSpawnLevel.TOWN_RESIDENT;
         } else if (!resident.hasTown()) {
            townSpawnLevel = TownSpawnLevel.UNAFFILIATED;
         } else if (resident.getTownOrNull() == town) {
            townSpawnLevel = outpost ? TownSpawnLevel.TOWN_RESIDENT_OUTPOST : TownSpawnLevel.TOWN_RESIDENT;
         } else if (resident.hasNation() && town.hasNation()) {
            Nation playerNation = resident.getNationOrNull();
            Nation targetNation = town.getNationOrNull();
            if (playerNation == targetNation) {
               if (!town.isPublic() && TownySettings.isAllySpawningRequiringPublicStatus() && !resident.hasPermissionNode(PermissionNodes.TOWNY_SPAWN_NATION_BYPASS_PUBLIC.getNode())) {
                  throw new TownyException(Translatable.of("msg_err_ally_isnt_public", town));
               }

               townSpawnLevel = TownSpawnLevel.PART_OF_NATION;
            } else if (targetNation.hasEnemy(playerNation)) {
               if (!town.isNeutral() || !TownySettings.areEnemiesAllowedToSpawnToPeacefulTowns()) {
                  throw new TownyException(Translatable.of("msg_err_public_spawn_enemy"));
               }

               townSpawnLevel = TownSpawnLevel.TOWN_RESIDENT;
            } else if (targetNation.hasAlly(playerNation)) {
               if (!town.isPublic() && TownySettings.isAllySpawningRequiringPublicStatus() && !resident.hasPermissionNode(PermissionNodes.TOWNY_SPAWN_ALLY_BYPASS_PUBLIC.getNode())) {
                  throw new TownyException(Translatable.of("msg_err_ally_isnt_public", town));
               }

               townSpawnLevel = TownSpawnLevel.NATION_ALLY;
            } else {
               townSpawnLevel = TownSpawnLevel.UNAFFILIATED;
            }
         } else {
            townSpawnLevel = TownSpawnLevel.UNAFFILIATED;
         }

         if (townSpawnLevel == TownSpawnLevel.UNAFFILIATED && !town.isPublic()) {
            if (!TownySettings.isConfigAllowingPublicTownSpawnTravel()) {
               throw new TownyException(Translatable.of("msg_err_town_unaffiliated"));
            }

            throw new TownyException(Translatable.of("msg_err_not_public"));
         }
      }

      townSpawnLevel.checkIfAllowed(player, town);
      return townSpawnLevel;
   }

   private static NationSpawnLevel getNationSpawnLevel(Player player, boolean noCmdArgs, SpawnType spawnType, Resident resident, Nation nation, boolean isTownyAdmin) throws TownyException {
      return spawnType == SpawnType.NATION ? (isTownyAdmin ? NationSpawnLevel.ADMIN : getNationSpawnLevel(player, resident, nation, noCmdArgs)) : null;
   }

   private static NationSpawnLevel getNationSpawnLevel(Player player, Resident resident, Nation nation, boolean noArg) throws TownyException {
      NationSpawnLevel nationSpawnLevel = null;
      if (noArg) {
         nationSpawnLevel = NationSpawnLevel.PART_OF_NATION;
      } else {
         if (!resident.hasTown()) {
            nationSpawnLevel = NationSpawnLevel.UNAFFILIATED;
         } else if (resident.hasNation()) {
            Nation playerNation = resident.getNationOrNull();
            if (playerNation == nation) {
               nationSpawnLevel = NationSpawnLevel.PART_OF_NATION;
            } else {
               if (nation.hasEnemy(playerNation)) {
                  throw new TownyException(Translatable.of("msg_err_public_spawn_enemy"));
               }

               if (nation.hasAlly(playerNation)) {
                  nationSpawnLevel = NationSpawnLevel.NATION_ALLY;
               } else {
                  nationSpawnLevel = NationSpawnLevel.UNAFFILIATED;
               }
            }
         } else {
            nationSpawnLevel = NationSpawnLevel.UNAFFILIATED;
         }

         if (nationSpawnLevel == NationSpawnLevel.UNAFFILIATED && !nation.isPublic()) {
            if (!TownySettings.isConfigAllowingPublicNationSpawnTravel()) {
               throw new TownyException(Translatable.of("msg_err_nation_unaffiliated"));
            }

            throw new TownyException(Translatable.of("msg_err_nation_not_public"));
         }
      }

      nationSpawnLevel.checkIfAllowed(player, nation);
      return nationSpawnLevel;
   }

   private static int getCooldown(Player player, SpawnInformation spawnInformation) {
      return player.hasPermission(PermissionNodes.TOWNY_SPAWN_ADMIN_NOCOOLDOWN.getNode()) ? 0 : (spawnInformation.townSpawnLevel != null ? spawnInformation.townSpawnLevel.getCooldown() : spawnInformation.nationSpawnLevel.getCooldown());
   }

   private static CompletableFuture<Location> getSpawnLoc(Player player, Town town, Nation nation, SpawnType spawnType, boolean outpost, String[] split) throws TownyException {
      CompletableFuture var10000;
      switch(spawnType) {
      case RESIDENT:
         var10000 = TownySettings.getBedUse() ? PaperLib.getBedSpawnLocationAsync(player, true).thenApply((bedLoc) -> {
            if (bedLoc != null) {
               return bedLoc;
            } else {
               return town != null && town.hasSpawn() ? town.getSpawnOrNull() : player.getWorld().getSpawnLocation();
            }
         }) : (town != null && town.hasSpawn() ? CompletableFuture.completedFuture(town.getSpawnOrNull()) : CompletableFuture.completedFuture(player.getWorld().getSpawnLocation()));
         break;
      case TOWN:
         var10000 = outpost ? CompletableFuture.completedFuture(getOutpostSpawnLocation(town, split)) : CompletableFuture.completedFuture(town.getSpawn());
         break;
      case NATION:
         var10000 = CompletableFuture.completedFuture(nation.getSpawn());
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private static Location getOutpostSpawnLocation(Town town, String[] split) throws TownyException {
      if (!town.hasOutpostSpawn()) {
         throw new TownyException(Translatable.of("msg_err_outpost_spawn"));
      } else if (split.length == 0) {
         return town.getOutpostSpawn(1);
      } else {
         Integer index = null;
         String userInput = split[split.length - 1];

         try {
            if (!userInput.contains("name:")) {
               index = Integer.parseInt(userInput);
            } else {
               index = getOutpostIndexFromName(town, index, userInput.replace("name:", "").replace("_", " "));
            }
         } catch (NumberFormatException var5) {
            index = getOutpostIndexFromName(town, index, userInput.replace("_", " "));
         } catch (ArrayIndexOutOfBoundsException var6) {
            index = 1;
         }

         if (TownySettings.isOutpostLimitStoppingTeleports() && TownySettings.isOutpostsLimitedByLevels() && town.isOverOutpostLimit() && Math.max(1, index) > town.getOutpostLimit()) {
            throw new TownyException(Translatable.of("msg_err_over_outposts_limit", town.getMaxOutpostSpawn(), town.getOutpostLimit()));
         } else {
            return town.getOutpostSpawn(Math.max(1, index));
         }
      }
   }

   private static Integer getOutpostIndexFromName(Town town, Integer index, String userInput) {
      Iterator var3 = town.getAllOutpostSpawns().iterator();

      while(var3.hasNext()) {
         Location loc = (Location)var3.next();
         TownBlock tboutpost = TownyAPI.getInstance().getTownBlock(loc);
         if (tboutpost != null) {
            String name = !tboutpost.hasPlotObjectGroup() ? tboutpost.getName() : tboutpost.getPlotObjectGroup().getName();
            if (name.toLowerCase(Locale.ROOT).startsWith(userInput.toLowerCase(Locale.ROOT))) {
               index = 1 + town.getAllOutpostSpawns().indexOf(loc);
            }
         }
      }

      if (index == null) {
         index = 1;
      }

      return index;
   }

   private static void testDisallowedZones(Player player, Resident resident, SpawnType spawnType, List<String> disallowedZones) throws TownyException {
      if (!disallowedZones.isEmpty()) {
         Town townAtPlayerLoc = TownyAPI.getInstance().getTown(player.getLocation());
         if (townAtPlayerLoc == null && disallowedZones.contains("unclaimed")) {
            throw new TownyException(Translatable.of("msg_err_x_spawn_disallowed_from_x", spawnType.typeName(), Translatable.of("msg_the_wilderness")));
         }

         if (townAtPlayerLoc != null) {
            if (townAtPlayerLoc.hasOutlaw(player.getName()) && disallowedZones.contains("outlaw")) {
               throw new TownyException(Translatable.of("msg_err_x_spawn_disallowed_from_x", "RTP", Translatable.of("msg_a_town_you_are_outlawed_in")));
            }

            Nation townLocNation;
            if (resident.hasTown() && townAtPlayerLoc.hasNation()) {
               townLocNation = townAtPlayerLoc.getNationOrNull();
               if (townLocNation.hasSanctionedTown(resident.getTownOrNull())) {
                  throw new TownyException(Translatable.of("msg_err_cannot_nation_spawn_your_town_is_sanctioned", townLocNation.getName()));
               }
            }

            if (resident.hasNation() && townAtPlayerLoc.hasNation()) {
               if (CombatUtil.isEnemy(resident.getTownOrNull(), townAtPlayerLoc) && disallowedZones.contains("enemy")) {
                  throw new TownyException(Translatable.of("msg_err_x_spawn_disallowed_from_x", spawnType.typeName(), Translatable.of("msg_enemy_areas")));
               }

               townLocNation = townAtPlayerLoc.getNationOrNull();
               Nation resNation = resident.getNationOrNull();
               if (!townLocNation.hasAlly(resNation) && !townLocNation.hasEnemy(resNation) && disallowedZones.contains("neutral")) {
                  throw new TownyException(Translatable.of("msg_err_x_spawn_disallowed_from_x", spawnType.typeName(), Translatable.of("msg_neutral_towns")));
               }
            }
         }
      }

   }

   private static double getTravelCost(Player player, Town town, Nation nation, TownSpawnLevel townSpawnLevel, NationSpawnLevel nationSpawnLevel, SpawnType spawnType) {
      if (TownyEconomyHandler.isActive() && !playerHasFreeSpawn(player)) {
         if (!TownySettings.isPublicSpawnCostAffectedByTownSpawncost() && (isPublicSpawn(townSpawnLevel) || isPublicSpawn(nationSpawnLevel))) {
            return TownySettings.getSpawnTravelCost();
         } else {
            double var10000;
            switch(spawnType) {
            case RESIDENT:
               var10000 = town == null ? 0.0D : Math.min(townSpawnLevel.getCost(town), townSpawnLevel.getCost());
               break;
            case TOWN:
               var10000 = Math.min(townSpawnLevel.getCost(town), townSpawnLevel.getCost());
               break;
            case NATION:
               var10000 = Math.min(nationSpawnLevel.getCost(nation), nationSpawnLevel.getCost());
               break;
            default:
               throw new IncompatibleClassChangeError();
            }

            return var10000;
         }
      } else {
         return 0.0D;
      }
   }

   private static boolean isPublicSpawn(NationSpawnLevel nationSpawnLevel) {
      return NationSpawnLevel.UNAFFILIATED.equals(nationSpawnLevel);
   }

   private static boolean isPublicSpawn(TownSpawnLevel townSpawnLevel) {
      return TownSpawnLevel.UNAFFILIATED.equals(townSpawnLevel);
   }

   private static String getPaymentMsg(TownSpawnLevel townSpawnLevel, NationSpawnLevel nationSpawnLevel, SpawnType spawnType) {
      String var10000;
      switch(spawnType) {
      case RESIDENT:
         var10000 = String.format(spawnType.getTypeName() + " (%s)", townSpawnLevel);
         break;
      case TOWN:
         var10000 = String.format(spawnType.getTypeName() + " (%s)", townSpawnLevel);
         break;
      case NATION:
         var10000 = String.format(spawnType.getTypeName() + " (%s)", nationSpawnLevel);
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private static Account getPayee(Town town, Nation nation, SpawnType spawnType) {
      Object var10000;
      switch(spawnType) {
      case RESIDENT:
         var10000 = town == null ? Account.SERVER_ACCOUNT : town.getAccount();
         break;
      case TOWN:
         var10000 = town.getAccount();
         break;
      case NATION:
         var10000 = nation.getAccount();
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return (Account)var10000;
   }

   private static void sendSpawnEvent(Player player, SpawnType spawnType, Location spawnLoc, SpawnInformation spawnInformation) throws TownyException {
      BukkitTools.ifCancelledThenThrow(getSpawnEvent(player, spawnType, spawnLoc, spawnInformation));
   }

   private static SpawnEvent getSpawnEvent(Player player, SpawnType spawnType, Location spawnLoc, SpawnInformation spawnInfo) {
      Object var10000;
      switch(spawnType) {
      case RESIDENT:
         var10000 = new ResidentSpawnEvent(player, player.getLocation(), spawnLoc, spawnInfo.eventCancelled, spawnInfo.eventCancellationMessage);
         break;
      case TOWN:
         var10000 = new TownSpawnEvent(player, player.getLocation(), spawnLoc, spawnInfo.eventCancelled, spawnInfo.eventCancellationMessage);
         break;
      case NATION:
         var10000 = new NationSpawnEvent(player, player.getLocation(), spawnLoc, spawnInfo.eventCancelled, spawnInfo.eventCancellationMessage);
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return (SpawnEvent)var10000;
   }

   private static void initiateSpawn(Player player, Location spawnLoc, int cooldown, double cost, @Nullable Account refundAccount) {
      Resident resident = TownyAPI.getInstance().getResident(player);
      if (resident != null) {
         if (TownyTimerHandler.isTeleportWarmupRunning() && !hasPerm(player, PermissionNodes.TOWNY_SPAWN_ADMIN_NOWARMUP)) {
            TownyMessaging.sendMsg((CommandSender)player, (Translatable)Translatable.of("msg_town_spawn_warmup", TownySettings.getTeleportWarmupTime()));
            TeleportWarmupTimerTask.requestTeleport(resident, spawnLoc, cooldown, refundAccount, cost);
         } else {
            if (player.getVehicle() != null) {
               player.getVehicle().eject();
            }

            PaperLib.teleportAsync(player, spawnLoc, TeleportCause.COMMAND);
            BukkitTools.fireEvent(new SuccessfulTownyTeleportEvent(resident, spawnLoc, cost));
            if (cooldown > 0 && !hasPerm(player, PermissionNodes.TOWNY_SPAWN_ADMIN_NOCOOLDOWN)) {
               CooldownTimerTask.addCooldownTimer(player.getName(), "teleport", cooldown);
            }
         }

      }
   }

   private static void initiateCostedSpawn(Player player, Resident resident, Location spawnLoc, double travelCost, Account payee, String paymentMsg, boolean ignoreWarn, int cooldown) {
      if (!ignoreWarn && TownySettings.isSpawnWarnConfirmationUsed()) {
         Confirmation.runOnAccept(() -> {
            payAndThenSpawn(player, resident, spawnLoc, travelCost, payee, paymentMsg, cooldown);
         }).setTitle(Translatable.of("msg_spawn_warn", TownyEconomyHandler.getFormattedBalance(travelCost))).sendTo(player);
      } else {
         payAndThenSpawn(player, resident, spawnLoc, travelCost, payee, paymentMsg, cooldown);
      }

   }

   private static void payAndThenSpawn(Player player, Resident resident, Location spawnLoc, double travelCost, Account payee, String paymentMsg, int cooldown) {
      if (resident.getAccount().payTo(travelCost, payee, paymentMsg)) {
         TownyMessaging.sendMsg((CommandSender)player, (Translatable)Translatable.of("msg_cost_spawn", TownyEconomyHandler.getFormattedBalance(travelCost)));
         initiateSpawn(player, spawnLoc, cooldown, travelCost, payee);
      }

   }

   private static CompletableFuture<Location> getIdealLocation(Resident resident) {
      Town town = resident.getTownOrNull();
      Location loc = resident.getPlayer().getWorld().getSpawnLocation();
      if (town != null && town.hasSpawn()) {
         loc = town.getSpawnOrNull();
      }

      return PaperLib.getBedSpawnLocationAsync(resident.getPlayer(), true).thenApply((bed) -> {
         return bed == null ? loc : bed;
      });
   }

   private static void initiatePluginTeleport(Resident resident, Location loc, boolean ignoreWarmup) {
      Player player = resident.getPlayer();
      if (player != null) {
         plugin.getScheduler().runLater((Entity)player, (Runnable)(() -> {
            PaperLib.teleportAsync(resident.getPlayer(), loc, TeleportCause.PLUGIN);
         }), ignoreWarmup ? 0L : (long)TownySettings.getTeleportWarmupTime() * 20L);
      }
   }

   private static void initiatePluginTeleport(Resident resident, CompletableFuture<Location> loc, boolean ignoreWarmup) {
      loc.thenAccept((location) -> {
         initiatePluginTeleport(resident, location, ignoreWarmup);
      });
   }

   private static boolean hasPerm(Player player, PermissionNodes node) {
      return TownyUniverse.getInstance().getPermissionSource().testPermission((Permissible)player, node.getNode());
   }
}
