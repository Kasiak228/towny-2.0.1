package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyFormatter;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.conversation.ResidentConversation;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.PermissionData;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyPermission;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.object.gui.EditGUI;
import com.palmergames.bukkit.towny.object.gui.PermissionGUI;
import com.palmergames.bukkit.towny.permissions.PermissionNodes;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.Colors;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.inventory.meta.BookMeta.Generation;
import org.bukkit.permissions.Permissible;
import org.jetbrains.annotations.NotNull;

public class PermissionGUIUtil {
   private static final PermissionGUIUtil.SetPermissionType[] defaultTypes;
   private static final int[] woolSlots;

   public static void openPermissionGUI(@NotNull Resident resident, @NotNull TownBlock townBlock) {
      boolean canEdit = true;

      try {
         TownyAPI.getInstance().testPlotOwnerOrThrow(resident, townBlock);
      } catch (TownyException var10) {
         canEdit = false;
      }

      Inventory page = ResidentUtil.getBlankPage(Translatable.of("permission_gui_header").forLocale(resident));
      ArrayList<Inventory> pages = new ArrayList();

      ItemStack skull;
      for(Iterator var5 = townBlock.getPermissionOverrides().entrySet().iterator(); var5.hasNext(); page.addItem(new ItemStack[]{skull})) {
         Entry<Resident, PermissionData> entry = (Entry)var5.next();
         skull = new ItemStack(Material.PLAYER_HEAD);
         SkullMeta meta = (SkullMeta)skull.getItemMeta();
         if (!((Resident)entry.getKey()).hasUUID()) {
            meta.setOwningPlayer(BukkitTools.getOfflinePlayer(((Resident)entry.getKey()).getName()));
         } else {
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(((Resident)entry.getKey()).getUUID()));
         }

         meta.setDisplayName("§6" + ((Resident)entry.getKey()).getName());
         List<String> lore = new ArrayList();
         String var10001 = ((PermissionData)entry.getValue()).getPermissionTypes()[TownyPermission.ActionType.BUILD.getIndex()].getColor();
         lore.add(var10001 + "Build§8  | " + ((PermissionData)entry.getValue()).getPermissionTypes()[TownyPermission.ActionType.DESTROY.getIndex()].getColor() + "Destroy");
         var10001 = ((PermissionData)entry.getValue()).getPermissionTypes()[TownyPermission.ActionType.SWITCH.getIndex()].getColor();
         lore.add(var10001 + "Switch§8 | " + ((PermissionData)entry.getValue()).getPermissionTypes()[TownyPermission.ActionType.ITEM_USE.getIndex()].getColor() + "Item");
         if (canEdit) {
            if (((PermissionData)entry.getValue()).getLastChangedAt() > 0L && !((PermissionData)entry.getValue()).getLastChangedBy().equals("")) {
               lore.add(Translatable.of("msg_last_edited", TownyFormatter.lastOnlineFormat.format(((PermissionData)entry.getValue()).getLastChangedAt()), ((PermissionData)entry.getValue()).getLastChangedBy()).forLocale(resident));
            }

            lore.add(Translatable.of("msg_click_to_edit").forLocale(resident));
         }

         meta.setLore(lore);
         skull.setItemMeta(meta);
         if (page.firstEmpty() == 46) {
            pages.add(page);
            page = ResidentUtil.getBlankPage(Translatable.of("permission_gui_header").forLocale(resident));
         }
      }

      if (canEdit) {
         ItemStack addButton = new ItemStack(Material.NAME_TAG);
         ItemMeta addButtonMeta = addButton.getItemMeta();
         addButtonMeta.setDisplayName("§6Add Player");
         addButton.setItemMeta(addButtonMeta);
         page.setItem(46, addButton);
      }

      page.setItem(52, createTutorialBook());
      pages.add(page);
      resident.setGUIPages(pages);
      resident.setGUIPageNum(0);
      new PermissionGUI(resident, (Inventory)pages.get(0), Translatable.of("permission_gui_header").forLocale(resident), townBlock, canEdit);
   }

   public static void openPermissionEditorGUI(@NotNull Resident resident, @NotNull TownBlock townBlock, @NotNull ItemStack clickedItem) {
      Inventory inventory = Bukkit.createInventory((InventoryHolder)null, 54, Translatable.of("permission_gui_header").forLocale(resident));
      SkullMeta meta = (SkullMeta)clickedItem.getItemMeta();
      Resident skullOwner = TownyAPI.getInstance().getResident(Colors.strip(meta.getDisplayName()));
      clickedItem.setItemMeta(meta);
      inventory.setItem(4, clickedItem);
      PermissionGUIUtil.SetPermissionType[] setPermissionTypes = ((PermissionData)townBlock.getPermissionOverrides().get(skullOwner)).getPermissionTypes();
      TownyPermission.ActionType[] var7 = TownyPermission.ActionType.values();
      int var8 = var7.length;

      ItemStack deleteButton;
      for(int var9 = 0; var9 < var8; ++var9) {
         TownyPermission.ActionType actionType = var7[var9];
         deleteButton = new ItemStack(setPermissionTypes[actionType.getIndex()].getWoolColour());
         ItemMeta woolMeta = deleteButton.getItemMeta();
         String var10001 = setPermissionTypes[actionType.getIndex()].getColor();
         woolMeta.setDisplayName(var10001 + ChatColor.BOLD + actionType.getCommonName());
         deleteButton.setItemMeta(woolMeta);
         inventory.setItem(woolSlots[actionType.getIndex()], deleteButton);
      }

      ItemStack saveButton = new ItemStack(Material.LIME_WOOL);
      ItemMeta saveButtonMeta = saveButton.getItemMeta();
      saveButtonMeta.setDisplayName("§a" + ChatColor.BOLD + "Save");
      saveButton.setItemMeta(saveButtonMeta);
      ItemStack backButton = new ItemStack(Material.RED_WOOL);
      ItemMeta backButtonMeta = saveButton.getItemMeta();
      backButtonMeta.setDisplayName("§4" + ChatColor.BOLD + "Back");
      backButton.setItemMeta(backButtonMeta);
      deleteButton = new ItemStack(Material.RED_WOOL);
      backButtonMeta.setDisplayName("§4" + ChatColor.BOLD + "Delete");
      deleteButton.setItemMeta(backButtonMeta);
      inventory.setItem(48, saveButton);
      inventory.setItem(50, backButton);
      inventory.setItem(53, deleteButton);
      new EditGUI(resident, inventory, Translatable.of("permission_gui_header").forLocale(resident), townBlock, skullOwner);
   }

   public static PermissionGUIUtil.SetPermissionType[] getDefaultTypes() {
      return defaultTypes;
   }

   public static int[] getWoolSlots() {
      return woolSlots;
   }

   public static ItemStack createTutorialBook() {
      ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
      BookMeta meta = (BookMeta)book.getItemMeta();
      List<String> pages = new ArrayList();
      pages.add("    §lPlot Perm GUI§r\n\nUsing the GUI, you can give or remove permissions from individual players in your plots.\n\n§l  Getting Started§r\n\nTo start, you will need to add players to the GUI. You can do this using /plot perm add.");
      pages.add("After a player has been added, you can now start editing their permissions.\n\n§l    Permissions§r\n\nAfter you've clicked on a player head, you will be able to edit their permissions.§a Green§0 means that this player has this permission.");
      pages.add("§cRed§0 means that this player does not have this permission.\n\n§7Gray§0 means that normal plot permissions apply.\n\nWhen starting out, all permissions will be gray. Note that denying permissions will not work for plot owners or mayors.");
      meta.setTitle("GUI Tutorial");
      meta.setGeneration(Generation.ORIGINAL);
      meta.setPages(pages);
      meta.setAuthor("Warriorrr");
      book.setItemMeta(meta);
      return book;
   }

   public static void handleConversation(Player player) {
      TownBlock startingTownBlock = WorldCoord.parseWorldCoord((Entity)player).getTownBlockOrNull();
      if (startingTownBlock == null) {
         TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_not_claimed_1"));
      } else {
         (new ResidentConversation(player)).runOnResponse((res) -> {
            if (!TownyUniverse.getInstance().getPermissionSource().testPermission((Permissible)player, PermissionNodes.TOWNY_COMMAND_PLOT_PERM_ADD.getNode())) {
               TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_err_command_disable"));
            } else {
               Resident resident = (Resident)res;
               if (startingTownBlock.hasPlotObjectGroup()) {
                  PlotGroup group = startingTownBlock.getPlotObjectGroup();
                  if (group.getPermissionOverrides().containsKey(resident)) {
                     TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_overrides_already_set", resident.getName(), Translatable.of("plotgroup_sing")));
                     return;
                  }

                  group.putPermissionOverride(resident, new PermissionData(getDefaultTypes(), player.getName()));
               } else {
                  if (startingTownBlock.getPermissionOverrides().containsKey(resident)) {
                     TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_overrides_already_set", resident.getName(), Translatable.of("townblock")));
                     return;
                  }

                  startingTownBlock.getPermissionOverrides().put(resident, new PermissionData(getDefaultTypes(), player.getName()));
                  startingTownBlock.save();
               }

               TownyMessaging.sendMsg((CommandSender)player, (Translatable)Translatable.of("msg_overrides_added", resident.getName()));
               openPermissionGUI(TownyAPI.getInstance().getResident(player), startingTownBlock);
            }
         });
      }
   }

   static {
      defaultTypes = new PermissionGUIUtil.SetPermissionType[]{PermissionGUIUtil.SetPermissionType.UNSET, PermissionGUIUtil.SetPermissionType.UNSET, PermissionGUIUtil.SetPermissionType.UNSET, PermissionGUIUtil.SetPermissionType.UNSET};
      woolSlots = new int[]{21, 23, 30, 32};
   }

   public static enum SetPermissionType {
      UNSET("§8", Material.GRAY_WOOL),
      SET("§2", Material.LIME_WOOL),
      NEGATED("§4", Material.RED_WOOL);

      private String color;
      private Material woolColour;

      private SetPermissionType(String color, Material woolColour) {
         this.color = color;
         this.woolColour = woolColour;
      }

      public String getColor() {
         return this.color;
      }

      public Material getWoolColour() {
         return this.woolColour;
      }

      // $FF: synthetic method
      private static PermissionGUIUtil.SetPermissionType[] $values() {
         return new PermissionGUIUtil.SetPermissionType[]{UNSET, SET, NEGATED};
      }
   }
}
