package com.palmergames.bukkit.towny.utils;

import com.palmergames.bukkit.towny.object.ChangelogResult;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.jetbrains.annotations.NotNull;

public class ChangelogReader {
   private final String lastVersion;
   private final InputStream changelogStream;
   private final int limit;

   private ChangelogReader(String lastVersion, InputStream inputStream, int limit) {
      this.lastVersion = lastVersion;
      this.changelogStream = inputStream;
      this.limit = limit;
   }

   @NotNull
   public ChangelogResult read() throws IOException {
      List<String> out = new ArrayList();
      int linesRead = 0;
      int nextVersionIndex = 0;
      BufferedReader reader = new BufferedReader(new InputStreamReader(this.changelogStream, StandardCharsets.UTF_8));

      ChangelogResult var8;
      label81: {
         try {
            boolean lastVersionFound = false;
            boolean nextVersionFound = false;

            while(true) {
               String line;
               while((line = reader.readLine()) != null) {
                  ++linesRead;
                  if (!lastVersionFound && line.startsWith(this.lastVersion)) {
                     lastVersionFound = true;
                  } else if (lastVersionFound && !nextVersionFound && !line.startsWith("-")) {
                     nextVersionFound = true;
                     nextVersionIndex = linesRead;
                  } else if (nextVersionFound && (this.limit < 0 || out.size() < this.limit)) {
                     out.add(line);
                  }
               }

               if (!lastVersionFound) {
                  var8 = new ChangelogResult(Collections.emptyList(), false, false, -1, linesRead);
                  break label81;
               }
               break;
            }
         } catch (Throwable var10) {
            try {
               reader.close();
            } catch (Throwable var9) {
               var10.addSuppressed(var9);
            }

            throw var10;
         }

         reader.close();
         return new ChangelogResult(out, true, this.limit >= 0 && linesRead >= this.limit, nextVersionIndex, linesRead);
      }

      reader.close();
      return var8;
   }

   public static ChangelogReader reader(@NotNull String lastVersion, @NotNull InputStream changelogStream) {
      return reader(lastVersion, changelogStream, -1);
   }

   public static ChangelogReader reader(@NotNull String lastVersion, @NotNull InputStream changelogStream, int limit) {
      return new ChangelogReader(lastVersion, changelogStream, limit);
   }
}
