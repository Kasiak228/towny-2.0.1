package com.palmergames.bukkit.towny.regen;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.actions.TownyExplodingBlocksEvent;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.regen.block.BlockLocation;
import com.palmergames.bukkit.towny.tasks.ProtectionRegenTask;
import com.palmergames.bukkit.util.ItemLists;
import com.palmergames.util.JavaUtil;
import java.lang.invoke.MethodHandle;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.Chunk;
import org.bukkit.ChunkSnapshot;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Bisected.Half;
import org.bukkit.block.data.type.Door;
import org.bukkit.block.data.type.PistonHead;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TownyRegenAPI {
   private static final Set<WorldCoord> regenWorldCoordList = ConcurrentHashMap.newKeySet();
   private static final Map<String, PlotBlockData> plotChunks = new ConcurrentHashMap();
   private static final Map<BlockLocation, ProtectionRegenTask> protectionRegenTasks = new ConcurrentHashMap();
   private static final Set<Block> protectionPlaceholders = new HashSet();
   private static final MethodHandle GET_CHUNK_SNAPSHOT;

   public static void turnOffRevertOnUnclaimForWorld(TownyWorld world) {
      removeRegenQueueListOfWorld(world);
      removePlotChunksForWorld(world);
   }

   public static void finishPlotBlockData(PlotBlockData plotChunk) {
      String var10000 = plotChunk.getWorldName();
      TownyMessaging.sendDebugMsg("Revert on unclaim complete for " + var10000 + " " + plotChunk.getX() + "," + plotChunk.getZ());
      removeFromRegenQueueList(plotChunk.getWorldCoord());
      removeFromActiveRegeneration(plotChunk);
      deletePlotChunkSnapshot(plotChunk);
      plotChunk.getWorldCoord().unloadChunks();
   }

   public static Collection<WorldCoord> getRegenQueueList() {
      return regenWorldCoordList;
   }

   public static boolean regenQueueHasAvailable() {
      return !regenWorldCoordList.isEmpty();
   }

   private static void removeRegenQueueListOfWorld(@NotNull TownyWorld world) {
      if (regenWorldCoordList.removeIf((wc) -> {
         return world.equals(wc.getTownyWorld());
      })) {
         TownyUniverse.getInstance().getDataSource().saveRegenList();
      }

   }

   public static void removeFromRegenQueueList(WorldCoord wc) {
      if (regenWorldCoordList.remove(wc)) {
         TownyUniverse.getInstance().getDataSource().saveRegenList();
      }

   }

   public static void addToRegenQueueList(WorldCoord wc, boolean save) {
      if (regenWorldCoordList.add(wc) && save) {
         TownyUniverse.getInstance().getDataSource().saveRegenList();
      }

   }

   public static void getWorldCoordFromQueueForRegeneration() {
      Iterator var0 = getRegenQueueList().iterator();

      while(var0.hasNext()) {
         WorldCoord wc = (WorldCoord)var0.next();
         if (getPlotChunks().size() >= 20) {
            break;
         }

         if (!hasActiveRegeneration(wc)) {
            PlotBlockData plotData = getPlotChunkSnapshot(new TownBlock(wc.getX(), wc.getZ(), wc.getTownyWorld()));
            if (plotData != null) {
               plotData.getWorldCoord().loadChunks();
               addToActiveRegeneration(plotData);
               String var10000 = plotData.getWorldName();
               TownyMessaging.sendDebugMsg("Revert on unclaim beginning for " + var10000 + " " + plotData.getX() + "," + plotData.getZ());
            } else {
               removeFromRegenQueueList(wc);
            }
         }
      }

   }

   public static Map<String, PlotBlockData> getPlotChunks() {
      return plotChunks;
   }

   public static Collection<PlotBlockData> getActivePlotBlockDatas() {
      return plotChunks.values();
   }

   public static boolean hasActiveRegenerations() {
      return !plotChunks.isEmpty();
   }

   public static boolean hasActiveRegeneration(WorldCoord wc) {
      return plotChunks.containsKey(getPlotKey(wc));
   }

   private static void removePlotChunksForWorld(TownyWorld world) {
      plotChunks.values().removeIf((data) -> {
         return data.getWorldName().equals(world.getName());
      });
   }

   public static void removeFromActiveRegeneration(PlotBlockData plotChunk) {
      plotChunks.remove(getPlotKey(plotChunk));
   }

   public static void addToActiveRegeneration(PlotBlockData plotChunk) {
      plotChunks.putIfAbsent(getPlotKey(plotChunk), plotChunk);
   }

   public static void addPlotChunkSnapshot(PlotBlockData plotChunk) {
      TownyUniverse townyUniverse = TownyUniverse.getInstance();
      TownBlock townBlock = plotChunk.getWorldCoord().getTownBlockOrNull();
      if (townBlock == null || !townyUniverse.getDataSource().hasPlotData(townBlock)) {
         townyUniverse.getDataSource().savePlotData(plotChunk);
      }

   }

   private static void deletePlotChunkSnapshot(PlotBlockData plotChunk) {
      TownyUniverse.getInstance().getDataSource().deletePlotData(plotChunk);
   }

   public static PlotBlockData getPlotChunkSnapshot(TownBlock townBlock) {
      return TownyUniverse.getInstance().getDataSource().loadPlotData(townBlock);
   }

   @Nullable
   public static PlotBlockData getPlotChunk(TownBlock townBlock) {
      return (PlotBlockData)plotChunks.get(getPlotKey(townBlock));
   }

   private static String getPlotKey(PlotBlockData plotChunk) {
      String var10000 = plotChunk.getWorldName();
      return "[" + var10000 + "|" + plotChunk.getX() + "|" + plotChunk.getZ() + "]";
   }

   public static String getPlotKey(TownBlock townBlock) {
      String var10000 = townBlock.getWorld().getName();
      return "[" + var10000 + "|" + townBlock.getX() + "|" + townBlock.getZ() + "]";
   }

   public static String getPlotKey(WorldCoord wc) {
      String var10000 = wc.getWorldName();
      return "[" + var10000 + "|" + wc.getX() + "|" + wc.getZ() + "]";
   }

   public static boolean beginProtectionRegenTask(Block block, int count, TownyWorld world, Event event) {
      if (!hasProtectionRegenTask(new BlockLocation(block.getLocation()))) {
         if (block.getType() == Material.PISTON_HEAD) {
            PistonHead blockData = (PistonHead)block.getBlockData();
            block = block.getRelative(blockData.getFacing().getOppositeFace());
         }

         ProtectionRegenTask task = new ProtectionRegenTask(Towny.getPlugin(), block);
         task.setTask(Towny.getPlugin().getScheduler().runLater((Location)block.getLocation(), (Runnable)task, (world.getPlotManagementWildRevertDelay() + (long)count) * 20L));
         addProtectionRegenTask(task);
         if (event instanceof TownyExplodingBlocksEvent) {
            event = ((TownyExplodingBlocksEvent)event).getBukkitExplodeEvent();
         }

         if (event instanceof EntityExplodeEvent) {
            ((EntityExplodeEvent)event).setYield(0.0F);
         } else if (event instanceof BlockExplodeEvent) {
            ((BlockExplodeEvent)event).setYield(0.0F);
         }

         handlePeskyBlocks(block);
         return true;
      } else {
         return false;
      }
   }

   private static void handlePeskyBlocks(Block block) {
      if (ItemLists.EXPLODABLE_ATTACHABLES.contains(block.getType())) {
         BlockData var2 = block.getBlockData();
         if (var2 instanceof Door) {
            Door door = (Door)var2;
            if (door.getHalf().equals(Half.TOP)) {
               block.getRelative(BlockFace.DOWN).setType(Material.AIR);
               block.setType(Material.AIR);
            }
         } else {
            block.setType(Material.AIR);
         }
      }

   }

   public static boolean hasProtectionRegenTask(BlockLocation blockLocation) {
      return protectionRegenTasks.containsKey(blockLocation);
   }

   public static ProtectionRegenTask GetProtectionRegenTask(BlockLocation blockLocation) {
      return (ProtectionRegenTask)protectionRegenTasks.get(blockLocation);
   }

   public static void addProtectionRegenTask(ProtectionRegenTask task) {
      protectionRegenTasks.put(task.getBlockLocation(), task);
   }

   public static void removeProtectionRegenTask(ProtectionRegenTask task) {
      protectionRegenTasks.remove(task.getBlockLocation());
      if (protectionRegenTasks.isEmpty()) {
         protectionPlaceholders.clear();
      }

   }

   public static void cancelProtectionRegenTasks() {
      boolean replaceProtections = true;

      try {
         if (Class.forName("org.spigotmc.WatchdogThread").isInstance(Thread.currentThread())) {
            Towny.getPlugin().getLogger().severe("Detected a watchdog crash, ongoing protection revert tasks will not be finished.");
            replaceProtections = false;
         }
      } catch (Throwable var3) {
      }

      Iterator var1 = protectionRegenTasks.values().iterator();

      while(var1.hasNext()) {
         ProtectionRegenTask task = (ProtectionRegenTask)var1.next();
         task.getTask().cancel();
         if (replaceProtections) {
            task.replaceProtections();
         }
      }

      protectionRegenTasks.clear();
      protectionPlaceholders.clear();
   }

   public static boolean isPlaceholder(Block block) {
      return protectionPlaceholders.contains(block);
   }

   public static void addPlaceholder(Block block) {
      protectionPlaceholders.add(block);
   }

   public static void removePlaceholder(Block block) {
      protectionPlaceholders.remove(block);
   }

   public static void handleNewSnapshot(@NotNull TownBlock townBlock) {
      createPlotSnapshot(townBlock).thenAcceptAsync((data) -> {
         if (!data.getBlockList().isEmpty()) {
            addPlotChunkSnapshot(data);
         }
      }).exceptionally((e) -> {
         if (e.getCause() != null) {
            e = e.getCause();
         }

         Towny.getPlugin().getLogger().log(Level.WARNING, "An exception occurred while creating a plot snapshot for " + townBlock.getWorldCoord().toString(), e);
         return null;
      });
   }

   public static CompletableFuture<PlotBlockData> createPlotSnapshot(@NotNull TownBlock townBlock) {
      List<ChunkSnapshot> snapshots = new ArrayList();
      Collection<CompletableFuture<Chunk>> futures = townBlock.getWorldCoord().getChunks();
      futures.forEach((future) -> {
         future.thenAccept((chunk) -> {
            try {
               if (GET_CHUNK_SNAPSHOT != null) {
                  snapshots.add(GET_CHUNK_SNAPSHOT.invoke(chunk, false, false, false, false));
               } else {
                  snapshots.add(chunk.getChunkSnapshot(false, false, false));
               }
            } catch (Throwable var3) {
               snapshots.add(chunk.getChunkSnapshot(false, false, false));
            }

         });
      });
      return CompletableFuture.allOf((CompletableFuture[])futures.toArray(new CompletableFuture[0])).thenApplyAsync((v) -> {
         PlotBlockData data = new PlotBlockData(townBlock);
         data.initialize(snapshots);
         return data;
      });
   }

   static {
      GET_CHUNK_SNAPSHOT = JavaUtil.getMethodHandle(Chunk.class, "getChunkSnapshot", Boolean.TYPE, Boolean.TYPE, Boolean.TYPE, Boolean.TYPE);
   }
}
