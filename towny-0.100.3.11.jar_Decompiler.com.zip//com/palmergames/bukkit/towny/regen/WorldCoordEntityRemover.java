package com.palmergames.bukkit.towny.regen;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.WorldCoord;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.jetbrains.annotations.Nullable;

public class WorldCoordEntityRemover {
   private static final List<WorldCoord> worldCoordQueue = new ArrayList();
   private static final List<WorldCoord> activeQueue = new ArrayList();

   public static boolean hasQueue() {
      return !worldCoordQueue.isEmpty();
   }

   public static boolean isQueued(WorldCoord worldCoord) {
      return worldCoordQueue.contains(worldCoord);
   }

   public static int getQueueSize() {
      return worldCoordQueue.size();
   }

   public static void addToQueue(WorldCoord worldCoord) {
      if (!worldCoordQueue.contains(worldCoord)) {
         worldCoordQueue.add(worldCoord);
      }

   }

   @Nullable
   public static WorldCoord getWorldCoordFromQueue() {
      if (!worldCoordQueue.isEmpty()) {
         Iterator var0 = worldCoordQueue.iterator();

         while(var0.hasNext()) {
            WorldCoord wc = (WorldCoord)var0.next();
            if (!isActiveQueue(wc)) {
               return wc;
            }
         }
      }

      return null;
   }

   public static boolean isActiveQueue(WorldCoord worldCoord) {
      return activeQueue.contains(worldCoord);
   }

   public static int getActiveQueueSize() {
      return activeQueue.size();
   }

   public static void addToActiveQueue(WorldCoord worldCoord) {
      if (!activeQueue.contains(worldCoord)) {
         activeQueue.add(worldCoord);
      }

   }

   public static void doDeleteTownBlockEntities(WorldCoord worldCoord) {
      TownyWorld world = worldCoord.getTownyWorld();
      if (world != null && world.isUsingTowny() && world.isDeletingEntitiesOnUnclaim()) {
         addToActiveQueue(worldCoord);
         Towny.getPlugin().getScheduler().run(worldCoord.getLowerMostCornerLocation(), () -> {
            try {
               World bukkitWorld = world.getBukkitWorld();
               if (bukkitWorld == null) {
                  return;
               }

               Iterator var3 = bukkitWorld.getNearbyEntities(worldCoord.getBoundingBox()).iterator();

               while(var3.hasNext()) {
                  Entity entity = (Entity)var3.next();
                  if (world.getUnclaimDeleteEntityTypes().contains(entity.getType())) {
                     entity.remove();
                  }
               }
            } finally {
               worldCoordQueue.remove(worldCoord);
               activeQueue.remove(worldCoord);
            }

         });
      } else {
         worldCoordQueue.remove(worldCoord);
      }
   }
}
