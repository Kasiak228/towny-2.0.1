package com.palmergames.bukkit.towny.huds;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyAsciiMap;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.asciimap.WildernessMapEvent;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.object.map.TownyMapData;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.Colors;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class MapHUD {
   private static final ChatColor WHITE;
   private static final ChatColor GOLD;
   private static final ChatColor GREEN;
   private static final ChatColor DARK_GREEN;
   private static final String HUD_OBJECTIVE = "MAP_HUD_OBJ";
   private static final String TEAM_MAP_PREFIX = "mapTeam";
   private static final String TEAM_OWNER = "ownerTeam";
   private static final String TEAM_TOWN = "townTeam";
   private static int lineWidth;
   private static int lineHeight;
   private static int halfLineWidth;
   private static int halfLineHeight;

   public static String mapHudTestKey() {
      return "mapTeam1";
   }

   public static void toggleOn(Player player) {
      Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
      Objective objective = BukkitTools.objective(board, "MAP_HUD_OBJ", "maphud");
      objective.setDisplaySlot(DisplaySlot.SIDEBAR);
      int score = lineHeight + 2;
      ChatColor[] colors = ChatColor.values();

      for(int i = 0; i < lineHeight; ++i) {
         board.registerNewTeam("mapTeam" + i).addEntry(colors[i].toString());
         objective.getScore(colors[i].toString()).setScore(score);
         --score;
      }

      String townEntry = DARK_GREEN + Translatable.of("town_sing").forLocale((CommandSender)player) + ": ";
      String ownerEntry = DARK_GREEN + Translatable.of("owner_status").forLocale((CommandSender)player) + ": ";
      board.registerNewTeam("townTeam").addEntry(townEntry);
      objective.getScore(townEntry).setScore(2);
      board.registerNewTeam("ownerTeam").addEntry(ownerEntry);
      objective.getScore(ownerEntry).setScore(1);
      player.setScoreboard(board);
      updateMap(player);
   }

   public static void updateMap(Player player) {
      updateMap(player, WorldCoord.parseWorldCoord((Entity)player));
   }

   public static void updateMap(Player player, WorldCoord wc) {
      Scoreboard board = player.getScoreboard();
      if (board == null) {
         toggleOn(player);
      } else if (board.getObjective("MAP_HUD_OBJ") != null && wc.getTownyWorld() != null && wc.getTownyWorld().isUsingTowny()) {
         int wcX = wc.getX();
         int wcZ = wc.getZ();
         String boardTitle = String.format("%sTowny Map %s(%s, %s)", GOLD, WHITE, wcX, wcZ);
         board.getObjective("MAP_HUD_OBJ").setDisplayName(boardTitle);
         String[][] map = new String[lineWidth][lineHeight];
         fillMapArray(wcX, wcZ, TownyAPI.getInstance().getResident(player.getName()), player.getWorld(), map);
         writeMapToBoard(board, map);
         TownBlock tb = wc.getTownBlockOrNull();
         Team var10000 = board.getTeam("townTeam");
         ChatColor var10001 = GREEN;
         var10000.setSuffix(var10001 + (tb != null && tb.hasTown() ? tb.getTownOrNull().getName() : Translatable.of("status_no_town").forLocale((CommandSender)player)));
         var10000 = board.getTeam("ownerTeam");
         var10001 = GREEN;
         var10000.setSuffix(var10001 + (tb != null && tb.hasResident() ? tb.getResidentOrNull().getName() : Translatable.of("status_no_town").forLocale((CommandSender)player)));
      } else {
         HUDManager.toggleOff(player);
      }
   }

   private static void fillMapArray(int wcX, int wcZ, Resident resident, World bukkitWorld, String[][] map) {
      int y = 0;

      for(int tby = wcX + (lineWidth - halfLineWidth - 1); tby >= wcX - halfLineWidth; --tby) {
         int x = 0;

         for(int tbx = wcZ - halfLineHeight; tbx <= wcZ + (lineHeight - halfLineHeight - 1); ++tbx) {
            WorldCoord worldCoord = new WorldCoord(bukkitWorld, tby, tbx);
            if (worldCoord.hasTownBlock()) {
               mapTownBlock(resident, map, x, y, worldCoord.getTownBlockOrNull());
            } else {
               mapWilderness(map, x, y, worldCoord);
            }

            ++x;
         }

         ++y;
      }

   }

   private static void mapTownBlock(Resident resident, String[][] map, int x, int y, TownBlock townBlock) {
      map[y][x] = getTownBlockColour(resident, x, y, townBlock);
      if (isForSale(townBlock)) {
         map[y][x] = map[y][x] + TownyAsciiMap.forSaleSymbol;
      } else if (townBlock.isHomeBlock()) {
         map[y][x] = map[y][x] + TownyAsciiMap.homeSymbol;
      } else if (townBlock.isOutpost()) {
         map[y][x] = map[y][x] + TownyAsciiMap.outpostSymbol;
      } else {
         map[y][x] = map[y][x] + townBlock.getType().getAsciiMapKey();
      }

   }

   private static String getTownBlockColour(Resident resident, int x, int y, TownBlock townBlock) {
      if (playerLocatedAtThisCoord(x, y)) {
         return "§6";
      } else if (townBlock.hasResident(resident)) {
         return "§e";
      } else if (townBlock.getData().hasColour()) {
         return Colors.getLegacyFromNamedTextColor(townBlock.getData().getColour());
      } else {
         return resident.hasTown() ? getTownBlockColour(resident, townBlock.getTownOrNull()) : "§f";
      }
   }

   private static String getTownBlockColour(Resident resident, Town townAtTownBlock) {
      if (townAtTownBlock.hasResident(resident)) {
         return "§a";
      } else if (!resident.hasNation()) {
         return "§f";
      } else {
         Nation resNation = resident.getNationOrNull();
         if (resNation.hasTown(townAtTownBlock)) {
            return "§2";
         } else if (!townAtTownBlock.hasNation()) {
            return "§f";
         } else {
            Nation townBlockNation = townAtTownBlock.getNationOrNull();
            if (resNation.hasAlly(townBlockNation)) {
               return "§2";
            } else {
               return resNation.hasEnemy(townBlockNation) ? "§4" : "§f";
            }
         }
      }
   }

   private static boolean playerLocatedAtThisCoord(int x, int y) {
      return x == halfLineHeight && y == halfLineWidth;
   }

   private static boolean isForSale(TownBlock townBlock) {
      return townBlock.getPlotPrice() != -1.0D || townBlock.hasPlotObjectGroup() && townBlock.getPlotObjectGroup().getPrice() != -1.0D;
   }

   private static void mapWilderness(String[][] map, int x, int y, WorldCoord worldCoord) {
      map[y][x] = playerLocatedAtThisCoord(x, y) ? "§6" : "§8";
      TownyMapData data = (TownyMapData)getWildernessMapDataMap().get(worldCoord);
      String symbol;
      if (data != null && !data.isOld()) {
         TownyMapData mapData = (TownyMapData)getWildernessMapDataMap().get(worldCoord);
         symbol = mapData.getSymbol();
      } else {
         WildernessMapEvent wildMapEvent = new WildernessMapEvent(worldCoord);
         BukkitTools.fireEvent(wildMapEvent);
         symbol = wildMapEvent.getMapSymbol();
         getWildernessMapDataMap().put(worldCoord, new TownyMapData(worldCoord, symbol, wildMapEvent.getHoverText(), wildMapEvent.getClickCommand()));
         Towny.getPlugin().getScheduler().runAsyncLater(() -> {
            getWildernessMapDataMap().computeIfPresent(worldCoord, (key, cachedData) -> {
               return cachedData.isOld() ? null : cachedData;
            });
         }, 700L);
      }

      map[y][x] = map[y][x] + symbol;
   }

   private static Map<WorldCoord, TownyMapData> getWildernessMapDataMap() {
      return TownyUniverse.getInstance().getWildernessMapDataMap();
   }

   private static void writeMapToBoard(Scoreboard board, String[][] map) {
      for(int my = 0; my < lineHeight; ++my) {
         String line = "";

         for(int mx = lineWidth - 1; mx >= 0; --mx) {
            line = line + map[mx][my];
         }

         board.getTeam("mapTeam" + my).setSuffix(line);
      }

   }

   static {
      WHITE = ChatColor.WHITE;
      GOLD = ChatColor.GOLD;
      GREEN = ChatColor.GREEN;
      DARK_GREEN = ChatColor.DARK_GREEN;
      lineWidth = 19;
      lineHeight = 10;
      halfLineWidth = lineWidth / 2;
      halfLineHeight = lineHeight / 2;
   }
}
