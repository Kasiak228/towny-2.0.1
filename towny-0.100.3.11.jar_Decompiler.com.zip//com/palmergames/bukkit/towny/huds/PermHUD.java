package com.palmergames.bukkit.towny.huds;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockOwner;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownyPermission;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translator;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.utils.CombatUtil;
import com.palmergames.bukkit.util.BukkitTools;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class PermHUD {
   private static final ChatColor DARK_RED;
   private static final ChatColor WHITE;
   private static final ChatColor GRAY;
   private static final ChatColor YELLOW;
   private static final ChatColor DARK_GREEN;
   private static final ChatColor GOLD;
   private static final ChatColor BOLD;
   private static final ChatColor UNDERLINE;
   private static final String HUD_OBJECTIVE = "PERM_HUD_OBJ";
   private static final String TEAM_PERMS_TITLE = "permsTitle";
   private static final String TEAM_DISTRICT_NAME = "districtName";
   private static final String TEAM_PLOT_NAME = "plot_name";
   private static final String TEAM_PLOT_COST = "plot_cost";
   private static final String TEAM_BUILD = "build";
   private static final String TEAM_DESTROY = "destroy";
   private static final String TEAM_SWITCH = "switching";
   private static final String TEAM_ITEMUSE = "item";
   private static final String TEAM_PLOT_TYPE = "plotType";
   private static final String TEAM_PVP = "pvp";
   private static final String TEAM_EXPLOSIONS = "explosions";
   private static final String TEAM_FIRESPREAD = "firespread";
   private static final String TEAM_MOBSPAWNING = "mobspawn";
   private static final String TEAM_TITLE = "keyTitle";
   private static final String TEAM_RESIDENT = "keyResident";
   private static final String TEAM_FRIEND = "keyFriend";
   private static final String TEAM_ALLY = "keyAlly";

   public static void updatePerms(Player p) {
      updatePerms(p, WorldCoord.parseWorldCoord((Entity)p));
   }

   public static String permHudTestKey() {
      return "plot_name";
   }

   public static void updatePerms(Player p, WorldCoord worldCoord) {
      Translator translator = Translator.locale((CommandSender)p);
      Scoreboard board = p.getScoreboard();
      if (board == null) {
         toggleOn(p);
      } else if (board.getObjective("PERM_HUD_OBJ") == null) {
         HUDManager.toggleOff(p);
      } else if (worldCoord.isWilderness()) {
         clearPerms(p);
      } else {
         TownBlock townBlock = worldCoord.getTownBlockOrNull();
         TownBlockOwner owner = townBlock.getTownBlockOwner();
         boolean plotGroup = townBlock.hasPlotObjectGroup();
         ChatColor var10000 = GOLD;
         String title = var10000 + owner.getName() + (townBlock.hasResident() ? " (" + townBlock.getTownOrNull().getName() + ")" : "");
         String districtName = townBlock.hasDistrict() ? townBlock.getDistrict().getFormattedName() : "";
         String type = townBlock.getType().equals(TownBlockType.RESIDENTIAL) ? " " : townBlock.getType().getName();
         String plotName = plotGroup && !townBlock.getPlotObjectGroup().getName().isEmpty() ? townBlock.getPlotObjectGroup().getName() : (!townBlock.getName().isEmpty() ? townBlock.getName() : "");
         String var23;
         if (plotName.isEmpty()) {
            var23 = " ";
         } else {
            var10000 = DARK_GREEN;
            var23 = HUDManager.check(var10000 + translator.of(plotGroup ? "msg_perm_hud_plotgroup_name" : "msg_perm_hud_plot_name") + WHITE + plotName);
         }

         plotName = var23;
         String forSale = getPlotPrice(translator, townBlock, plotGroup);
         TownyPermission tp = townBlock.getPermissions();
         boolean residentOwned = owner instanceof Resident;
         String build = getPermLine(tp, TownyPermission.ActionType.BUILD, residentOwned);
         String destroy = getPermLine(tp, TownyPermission.ActionType.DESTROY, residentOwned);
         String switching = getPermLine(tp, TownyPermission.ActionType.SWITCH, residentOwned);
         String item = getPermLine(tp, TownyPermission.ActionType.ITEM_USE, residentOwned);
         TownyWorld world = townBlock.getWorld();
         String pvp = getTranslatedOnOrOff(!CombatUtil.preventPvP(world, townBlock), translator);
         String explosions = getTranslatedOnOrOff(world.isForceExpl() || tp.explosion, translator);
         String firespread = getTranslatedOnOrOff(world.isForceFire() || tp.fire, translator);
         String mobspawn = getTranslatedOnOrOff(world.isForceTownMobs() || tp.mobs || townBlock.getTownOrNull().isAdminEnabledMobs(), translator);
         board.getObjective("PERM_HUD_OBJ").setDisplayName(HUDManager.check(title));
         board.getTeam("districtName").setSuffix(districtName);
         board.getTeam("plot_name").setSuffix(plotName);
         board.getTeam("plotType").setSuffix(type);
         board.getTeam("plot_cost").setSuffix(forSale);
         board.getTeam("build").setSuffix(build);
         board.getTeam("destroy").setSuffix(destroy);
         board.getTeam("switching").setSuffix(switching);
         board.getTeam("item").setSuffix(item);
         board.getTeam("pvp").setSuffix(pvp);
         board.getTeam("explosions").setSuffix(explosions);
         board.getTeam("firespread").setSuffix(firespread);
         board.getTeam("mobspawn").setSuffix(mobspawn);
      }
   }

   private static String getPlotPrice(Translator translator, TownBlock townBlock, boolean plotGroup) {
      String forSale = translator.of("msg_perm_hud_no");
      if (TownyEconomyHandler.isActive()) {
         forSale = plotGroup && townBlock.getPlotObjectGroup().getPrice() > -1.0D ? prettyMoney(townBlock.getPlotObjectGroup().getPrice()) : (townBlock.isForSale() ? prettyMoney(townBlock.getPlotPrice()) : forSale);
      } else {
         forSale = (!plotGroup || !(townBlock.getPlotObjectGroup().getPrice() > -1.0D)) && (plotGroup || !townBlock.isForSale()) ? forSale : translator.of("msg_perm_hud_yes");
      }

      return forSale;
   }

   private static String getPermLine(TownyPermission tp, TownyPermission.ActionType actionType, boolean residentOwned) {
      String v = residentOwned ? "f" : "r";
      String u = residentOwned ? "t" : "n";
      String var10000 = tp.getResidentPerm(actionType) ? v : "-";
      return var10000 + (tp.getNationPerm(actionType) ? u : "-") + (tp.getAllyPerm(actionType) ? "a" : "-") + (tp.getOutsiderPerm(actionType) ? "o" : "-");
   }

   private static String getTranslatedOnOrOff(boolean test, Translator translator) {
      return test ? translator.of("status_on") : translator.of("status_off");
   }

   private static void clearPerms(Player p) {
      Scoreboard board = p.getScoreboard();

      try {
         board.getObjective("PERM_HUD_OBJ").setDisplayName(HUDManager.check(getFormattedWildernessName(p.getWorld())));
         board.getTeam("districtName").setSuffix(" ");
         board.getTeam("plot_name").setSuffix(" ");
         board.getTeam("plotType").setSuffix(" ");
         board.getTeam("plot_cost").setSuffix(" ");
         board.getTeam("build").setSuffix(" ");
         board.getTeam("destroy").setSuffix(" ");
         board.getTeam("switching").setSuffix(" ");
         board.getTeam("item").setSuffix(" ");
         board.getTeam("pvp").setSuffix(" ");
         board.getTeam("explosions").setSuffix(" ");
         board.getTeam("firespread").setSuffix(" ");
         board.getTeam("mobspawn").setSuffix(" ");
      } catch (NullPointerException var3) {
         toggleOn(p);
      }

   }

   private static String getFormattedWildernessName(World w) {
      StringBuilder wildernessName = (new StringBuilder()).append(DARK_RED).append(BOLD);
      if (TownyAPI.getInstance().isTownyWorld(w)) {
         wildernessName.append(TownyAPI.getInstance().getTownyWorld(w).getFormattedUnclaimedZoneName());
      } else {
         wildernessName.append("Unknown");
      }

      return wildernessName.toString();
   }

   public static void toggleOn(Player p) {
      Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
      initializeScoreboard(Translator.locale((CommandSender)p), board);
      p.setScoreboard(board);
      updatePerms(p);
   }

   private static void initializeScoreboard(Translator translator, Scoreboard board) {
      String PERM_HUD_TITLE = GOLD.makeConcatWithConstants<invokedynamic>(GOLD);
      String districtName_entry = "";
      String plotName_entry = "";
      ChatColor var10000 = DARK_GREEN;
      String keyPlotType_entry = var10000 + translator.of("msg_perm_hud_plot_type");
      var10000 = DARK_GREEN;
      String forSale_entry = var10000 + translator.of("msg_perm_hud_plot_for_sale") + GRAY;
      var10000 = YELLOW;
      String permsTitle_entry = var10000 + UNDERLINE + translator.of("msg_perm_hud_title");
      var10000 = DARK_GREEN;
      String build_entry = var10000 + translator.of("msg_perm_hud_build") + GRAY;
      var10000 = DARK_GREEN;
      String destroy_entry = var10000 + translator.of("msg_perm_hud_destroy") + GRAY;
      var10000 = DARK_GREEN;
      String switching_entry = var10000 + translator.of("msg_perm_hud_switch") + GRAY;
      var10000 = DARK_GREEN;
      String item_entry = var10000 + translator.of("msg_perm_hud_item_use") + GRAY;
      var10000 = DARK_GREEN;
      String pvp_entry = var10000 + translator.of("msg_perm_hud_pvp") + " ";
      var10000 = DARK_GREEN;
      String explosions_entry = var10000 + translator.of("msg_perm_hud_explosions") + " ";
      var10000 = DARK_GREEN;
      String firespread_entry = var10000 + translator.of("msg_perm_hud_firespread") + " ";
      var10000 = DARK_GREEN;
      String mobspawn_entry = var10000 + translator.of("msg_perm_hud_mobspawns") + " ";
      var10000 = YELLOW;
      String keyTitle_entry = var10000 + UNDERLINE + translator.of("msg_perm_hud_key");
      var10000 = DARK_GREEN;
      String keyResident_entry = var10000 + BOLD + "f" + WHITE + " - " + GRAY + translator.of("msg_perm_hud_friend") + DARK_GREEN + " " + BOLD + "r" + WHITE + " - " + GRAY + translator.of("msg_perm_hud_resident");
      var10000 = DARK_GREEN;
      String keyNation_entry = var10000 + BOLD + "t" + WHITE + " - " + GRAY + translator.of("msg_perm_hud_town") + DARK_GREEN + " " + BOLD + "n" + WHITE + " - " + GRAY + translator.of("msg_perm_hud_nation");
      var10000 = DARK_GREEN;
      String keyAlly_entry = var10000 + BOLD + "a" + WHITE + " - " + GRAY + translator.of("msg_perm_hud_ally") + DARK_GREEN + " " + BOLD + "o" + WHITE + " - " + GRAY + translator.of("msg_perm_hud_outsider");
      Objective obj = BukkitTools.objective(board, "PERM_HUD_OBJ", PERM_HUD_TITLE);
      obj.setDisplaySlot(DisplaySlot.SIDEBAR);
      obj.setDisplayName(PERM_HUD_TITLE);
      Team districtName = board.registerNewTeam("districtName");
      Team plotName = board.registerNewTeam("plot_name");
      Team keyPlotType = board.registerNewTeam("plotType");
      Team forSaleTitle = board.registerNewTeam("plot_cost");
      Team permsTitle = board.registerNewTeam("permsTitle");
      Team build = board.registerNewTeam("build");
      Team destroy = board.registerNewTeam("destroy");
      Team switching = board.registerNewTeam("switching");
      Team item = board.registerNewTeam("item");
      Team pvp = board.registerNewTeam("pvp");
      Team explosions = board.registerNewTeam("explosions");
      Team firespread = board.registerNewTeam("firespread");
      Team mobspawn = board.registerNewTeam("mobspawn");
      Team keyTitle = board.registerNewTeam("keyTitle");
      Team keyResident = board.registerNewTeam("keyResident");
      Team keyFriend = board.registerNewTeam("keyFriend");
      Team keyAlly = board.registerNewTeam("keyAlly");
      districtName.addEntry(districtName_entry);
      plotName.addEntry(plotName_entry);
      keyPlotType.addEntry(keyPlotType_entry);
      forSaleTitle.addEntry(forSale_entry);
      permsTitle.addEntry(permsTitle_entry);
      build.addEntry(build_entry);
      destroy.addEntry(destroy_entry);
      switching.addEntry(switching_entry);
      item.addEntry(item_entry);
      pvp.addEntry(pvp_entry);
      explosions.addEntry(explosions_entry);
      firespread.addEntry(firespread_entry);
      mobspawn.addEntry(mobspawn_entry);
      keyTitle.addEntry(keyTitle_entry);
      keyResident.addEntry(keyResident_entry);
      keyFriend.addEntry(keyNation_entry);
      keyAlly.addEntry(keyAlly_entry);
      obj.getScore(districtName_entry).setScore(17);
      obj.getScore(plotName_entry).setScore(16);
      obj.getScore(keyPlotType_entry).setScore(15);
      obj.getScore(forSale_entry).setScore(14);
      obj.getScore(permsTitle_entry).setScore(13);
      obj.getScore(build_entry).setScore(12);
      obj.getScore(destroy_entry).setScore(11);
      obj.getScore(switching_entry).setScore(10);
      obj.getScore(item_entry).setScore(9);
      obj.getScore(pvp_entry).setScore(8);
      obj.getScore(explosions_entry).setScore(7);
      obj.getScore(firespread_entry).setScore(6);
      obj.getScore(mobspawn_entry).setScore(5);
      obj.getScore(keyTitle_entry).setScore(4);
      obj.getScore(keyResident_entry).setScore(3);
      obj.getScore(keyNation_entry).setScore(2);
      obj.getScore(keyAlly_entry).setScore(1);
   }

   private static String prettyMoney(double price) {
      return TownyEconomyHandler.getFormattedBalance(price);
   }

   static {
      DARK_RED = ChatColor.DARK_RED;
      WHITE = ChatColor.WHITE;
      GRAY = ChatColor.GRAY;
      YELLOW = ChatColor.YELLOW;
      DARK_GREEN = ChatColor.DARK_GREEN;
      GOLD = ChatColor.GOLD;
      BOLD = ChatColor.BOLD;
      UNDERLINE = ChatColor.UNDERLINE;
   }
}
