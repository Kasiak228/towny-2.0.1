package com.palmergames.bukkit.towny;

import com.palmergames.adventure.platform.bukkit.BukkitAudiences;
import com.palmergames.bukkit.config.CommentedConfiguration;
import com.palmergames.bukkit.config.ConfigNodes;
import com.palmergames.bukkit.config.migration.ConfigMigrator;
import com.palmergames.bukkit.metrics.bukkit.Metrics;
import com.palmergames.bukkit.metrics.charts.SimplePie;
import com.palmergames.bukkit.towny.command.InviteCommand;
import com.palmergames.bukkit.towny.command.NationCommand;
import com.palmergames.bukkit.towny.command.PlotCommand;
import com.palmergames.bukkit.towny.command.ResidentCommand;
import com.palmergames.bukkit.towny.command.TownCommand;
import com.palmergames.bukkit.towny.command.TownyAdminCommand;
import com.palmergames.bukkit.towny.command.TownyCommand;
import com.palmergames.bukkit.towny.command.TownyWorldCommand;
import com.palmergames.bukkit.towny.command.commandobjects.AcceptCommand;
import com.palmergames.bukkit.towny.command.commandobjects.CancelCommand;
import com.palmergames.bukkit.towny.command.commandobjects.ConfirmCommand;
import com.palmergames.bukkit.towny.command.commandobjects.DenyCommand;
import com.palmergames.bukkit.towny.db.DatabaseConfig;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.exceptions.initialization.TownyInitException;
import com.palmergames.bukkit.towny.hooks.PluginIntegrations;
import com.palmergames.bukkit.towny.huds.HUDManager;
import com.palmergames.bukkit.towny.invites.InviteHandler;
import com.palmergames.bukkit.towny.listeners.TownyBlockListener;
import com.palmergames.bukkit.towny.listeners.TownyCustomListener;
import com.palmergames.bukkit.towny.listeners.TownyEntityListener;
import com.palmergames.bukkit.towny.listeners.TownyEntityMonitorListener;
import com.palmergames.bukkit.towny.listeners.TownyInventoryListener;
import com.palmergames.bukkit.towny.listeners.TownyLoginListener;
import com.palmergames.bukkit.towny.listeners.TownyPaperEvents;
import com.palmergames.bukkit.towny.listeners.TownyPlayerListener;
import com.palmergames.bukkit.towny.listeners.TownyServerListener;
import com.palmergames.bukkit.towny.listeners.TownyVehicleListener;
import com.palmergames.bukkit.towny.listeners.TownyWorldListener;
import com.palmergames.bukkit.towny.object.ChangelogResult;
import com.palmergames.bukkit.towny.object.PlayerCache;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownBlockTypeHandler;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.object.metadata.MetadataLoader;
import com.palmergames.bukkit.towny.permissions.TownyPerms;
import com.palmergames.bukkit.towny.regen.TownyRegenAPI;
import com.palmergames.bukkit.towny.scheduling.TaskScheduler;
import com.palmergames.bukkit.towny.scheduling.impl.BukkitTaskScheduler;
import com.palmergames.bukkit.towny.scheduling.impl.FoliaTaskScheduler;
import com.palmergames.bukkit.towny.scheduling.impl.PaperTaskScheduler;
import com.palmergames.bukkit.towny.tasks.OnPlayerLogin;
import com.palmergames.bukkit.towny.utils.ChangelogReader;
import com.palmergames.bukkit.towny.utils.ChunkNotificationUtil;
import com.palmergames.bukkit.towny.utils.MinecraftVersion;
import com.palmergames.bukkit.towny.utils.PlayerCacheUtil;
import com.palmergames.bukkit.towny.utils.SpawnUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.Version;
import com.palmergames.paperlib.PaperLib;
import com.palmergames.util.FileMgmt;
import com.palmergames.util.JavaUtil;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.ApiStatus.Internal;

public class Towny extends JavaPlugin {
   private static Towny plugin;
   private final String version = this.getDescription().getVersion();
   private TownyUniverse townyUniverse;
   private final boolean isFolia = JavaUtil.classExists("io.papermc.paper.threadedregions.RegionizedServer");
   private final TaskScheduler scheduler;
   private static BukkitAudiences adventure;
   private final Map<UUID, PlayerCache> playerCache = Collections.synchronizedMap(new HashMap());
   private final Set<TownyInitException.TownyError> errors = new HashSet();

   public Towny() {
      plugin = this;
      this.scheduler = (TaskScheduler)(this.isFolia() ? new FoliaTaskScheduler(this) : (this.expandedSchedulingAvailable() ? new PaperTaskScheduler(this) : new BukkitTaskScheduler(this)));
   }

   public void onEnable() {
      Bukkit.getLogger().info("====================      Towny      ========================");
      this.townyUniverse = TownyUniverse.getInstance();
      BukkitTools.initialize(this);
      TownyTimerHandler.initialize(this);
      TownyEconomyHandler.initialize(this);
      TownyFormatter.initialize();
      PlayerCacheUtil.initialize(this);
      TownyPerms.initialize(this);
      InviteHandler.initialize(this);
      SpawnUtil.initialize(this);

      try {
         this.loadFoundation(false);
         this.cycleTimers();
         this.resetCache();
         if (isMinecraftVersionStillSupported()) {
            TownyUpdateChecker.checkForUpdates(this);
         }
      } catch (TownyInitException var3) {
         this.addError(var3.getError());
         this.getLogger().log(Level.SEVERE, var3.getMessage(), var3);
      }

      adventure = BukkitAudiences.create(this);
      PluginIntegrations.getInstance().checkForPlugins(this);
      this.registerSpecialCommands();
      this.registerCommands();
      this.addMetricsCharts();
      if (!this.isError()) {
         if (TownySettings.isTownyUpdating(this.getVersion())) {
            this.printChangelogToConsole();
            this.townyUniverse.getDataSource().saveAll();
            this.townyUniverse.getDataSource().cleanup();
         }

         if (!TownySettings.getLastRunVersion().equals(this.getVersion())) {
            TownySettings.setLastRunVersion(this.getVersion());
         }
      }

      if (!this.isError(TownyInitException.TownyError.MAIN_CONFIG) && !this.isError(TownyInitException.TownyError.PERMISSIONS)) {
         TownyPerms.registerPermissionNodes();
      }

      this.registerEvents();
      Bukkit.getLogger().info("=============================================================");
      if (this.isError()) {
         plugin.getLogger().warning("[WARNING] - ***** SAFE MODE ***** " + this.version);
      } else {
         plugin.getLogger().info("Version: " + this.version + " - Plugin Enabled");
      }

      Bukkit.getLogger().info("=============================================================");
      if (!this.isError()) {
         Iterator var1 = BukkitTools.getOnlinePlayers().iterator();

         while(var1.hasNext()) {
            Player player = (Player)var1.next();
            if (player != null) {
               if (player.getName().contains(" ")) {
                  player.kickPlayer("Invalid name!");
                  return;
               }

               this.scheduler.run((Runnable)(new OnPlayerLogin(this, player)));
            }
         }
      }

   }

   public void loadFoundation(boolean reload) {
      this.handleLegacyConfigs();
      this.loadDatabaseConfig(reload);
      this.loadConfig(reload);
      this.loadLocalization(reload);
      this.loadPermissions(reload);
      PluginIntegrations.getInstance().unloadPAPIExpansion(reload);
      TownBlockTypeHandler.initialize();
      TownyLogger.initialize();
      this.townyUniverse.clearAllObjects();
      this.townyUniverse.loadAndSaveDatabase(TownySettings.getLoadDatabase(), TownySettings.getSaveDatabase());
      MetadataLoader.getInstance().scheduleDeserialization();
      if (!TownySettings.getLastRunVersion().equals(this.getVersion())) {
         ConfigMigrator migrator = new ConfigMigrator(TownySettings.getConfig(), "config-migration.json", false);
         migrator.migrate();
      }

      this.loadTownAndNationLevels();
      PluginIntegrations.getInstance().loadPAPIExpansion(reload);
      this.townyUniverse.performCleanupAndBackup();
   }

   public void loadConfig(boolean reload) {
      TownySettings.loadConfig(this.getDataFolder().toPath().resolve("settings").resolve("config.yml"), this.getVersion());
      if (reload) {
         if (this.removeError(TownyInitException.TownyError.MAIN_CONFIG) && TownySettings.isUsingEconomy() && !TownyEconomyHandler.isActive()) {
            PluginIntegrations.getInstance().setupAndPrintEconomy(TownySettings.isUsingEconomy());
         }

         TownyMessaging.sendMsg(Translatable.of("msg_reloaded_config"));
      }

   }

   public void loadLocalization(boolean reload) {
      Translation.loadTranslationRegistry();
      if (reload) {
         this.removeError(TownyInitException.TownyError.LOCALIZATION);
         TownyMessaging.sendMsg(Translatable.of("msg_reloaded_lang"));
      }

   }

   private void loadDatabaseConfig(boolean reload) {
      if (!this.checkForLegacyDatabaseConfig()) {
         throw new TownyInitException("Unable to migrate old database settings to Towny\\data\\settings\\database.yml", TownyInitException.TownyError.DATABASE_CONFIG);
      } else {
         DatabaseConfig.loadDatabaseConfig(this.getDataFolder().toPath().resolve("settings").resolve("database.yml"));
         if (reload) {
            this.removeError(TownyInitException.TownyError.DATABASE_CONFIG);
         }

      }
   }

   public void loadPermissions(boolean reload) {
      TownyPerms.loadPerms(this.getDataFolder().toPath().resolve("settings").resolve("townyperms.yml"));
      if (reload) {
         this.removeError(TownyInitException.TownyError.PERMISSIONS);
         TownyPerms.updateOnlinePerms();
      }

   }

   private void loadTownAndNationLevels() throws TownyInitException {
      try {
         TownySettings.loadTownLevelConfig();
      } catch (TownyException var3) {
         throw new TownyInitException("Failed to load town level config", TownyInitException.TownyError.MAIN_CONFIG, var3);
      }

      try {
         TownySettings.loadNationLevelConfig();
      } catch (TownyException var2) {
         throw new TownyInitException("Failed to load nation level config", TownyInitException.TownyError.MAIN_CONFIG, var2);
      }
   }

   private void handleLegacyConfigs() {
      Path configPath = getPlugin().getDataFolder().toPath().resolve("settings").resolve("config.yml");
      if (Files.exists(configPath, new LinkOption[0])) {
         CommentedConfiguration config = new CommentedConfiguration(configPath);
         if (config.load() && !config.getString(ConfigNodes.LAST_RUN_VERSION.getRoot(), "0.0.0.0").equals(this.getVersion())) {
            TownBlockTypeHandler.Migrator.checkForLegacyOptions(config);
            ConfigMigrator earlyMigrator = new ConfigMigrator(config, "config-migration.json", true);
            earlyMigrator.migrate();
         }
      }
   }

   private boolean checkForLegacyDatabaseConfig() {
      Path configYMLPath = this.getDataFolder().toPath().resolve("settings").resolve("config.yml");
      if (!Files.exists(configYMLPath, new LinkOption[0])) {
         return true;
      } else {
         CommentedConfiguration config = new CommentedConfiguration(configYMLPath);
         if (!config.load()) {
            return false;
         } else {
            if (config.contains("plugin.database.database_load")) {
               String dbload = config.getString("plugin.database.database_load");
               String dbsave = config.getString("plugin.database.database_save");
               String hostname = config.getString("plugin.database.sql.hostname");
               String port = config.getString("plugin.database.sql.port");
               String dbname = config.getString("plugin.database.sql.dbname");
               String tableprefix = config.getString("plugin.database.sql.table_prefix");
               String username = config.getString("plugin.database.sql.username");
               String password = config.getString("plugin.database.sql.password");
               String flags = config.getString("plugin.database.sql.flags");
               String max_pool = config.getString("plugin.database.sql.pooling.max_pool_size");
               String max_lifetime = config.getString("plugin.database.sql.pooling.max_lifetime");
               String connection_timeout = config.getString("plugin.database.sql.pooling.connection_timeout");
               Path databaseYMLPath = this.getDataFolder().toPath().resolve("settings").resolve("database.yml");
               if (!FileMgmt.checkOrCreateFile(databaseYMLPath.toString())) {
                  this.getLogger().severe("Unable to migrate old database settings to towny\\data\\settings\\database.yml");
                  return false;
               }

               CommentedConfiguration databaseConfig = new CommentedConfiguration(databaseYMLPath);
               databaseConfig.set("database.database_load", dbload);
               databaseConfig.set("database.database_save", dbsave);
               databaseConfig.set("database.sql.hostname", hostname);
               databaseConfig.set("database.sql.port", port);
               databaseConfig.set("database.sql.dbname", dbname);
               databaseConfig.set("database.sql.table_prefix", tableprefix);
               databaseConfig.set("database.sql.username", username);
               databaseConfig.set("database.sql.password", password);
               databaseConfig.set("database.sql.flags", flags);
               databaseConfig.set("database.sql.pooling.max_pool_size", max_pool);
               databaseConfig.set("database.sql.pooling.max_lifetime", max_lifetime);
               databaseConfig.set("database.sql.pooling.connection_timeout", connection_timeout);
               databaseConfig.save();
               this.getLogger().info("Database settings migrated to towny\\data\\settings\\database.yml");
            }

            return true;
         }
      }
   }

   public void onDisable() {
      Bukkit.getLogger().info("==============================================================");
      TownyUniverse townyUniverse = TownyUniverse.getInstance();
      if (townyUniverse.getDataSource() != null && !this.isError(TownyInitException.TownyError.DATABASE)) {
         townyUniverse.getDataSource().saveQueues();
         townyUniverse.getDataSource().saveCooldowns();
         plugin.getLogger().info("Finishing File IO Tasks...");
         townyUniverse.getDataSource().finishTasks();
      }

      this.toggleTimersOff();
      TownyRegenAPI.cancelProtectionRegenTasks();
      ChunkNotificationUtil.cancelChunkNotificationTasks();
      this.playerCache.clear();
      plugin.getLogger().info("Finishing Universe Tasks...");
      townyUniverse.finishTasks();
      if (adventure != null) {
         adventure.close();
         adventure = null;
      }

      PluginIntegrations.getInstance().disable3rdPartyPluginIntegrations();
      this.townyUniverse = null;
      TaskScheduler var3 = this.scheduler;
      if (var3 instanceof FoliaTaskScheduler) {
         FoliaTaskScheduler foliaScheduler = (FoliaTaskScheduler)var3;
         foliaScheduler.cancelTasks();
      }

      plugin.getLogger().info("Version: " + this.version + " - Plugin Disabled");
      Bukkit.getLogger().info("=============================================================");
   }

   private void cycleTimers() {
      this.toggleTimersOff();
      TownyTimerHandler.toggleTownyRepeatingTimer(true);
      TownyTimerHandler.toggleDailyTimer(true);
      TownyTimerHandler.toggleHourlyTimer(true);
      TownyTimerHandler.toggleShortTimer(true);
      TownyTimerHandler.toggleMobRemoval(true);
      TownyTimerHandler.toggleHealthRegen(TownySettings.hasHealthRegen());
      TownyTimerHandler.toggleTeleportWarmup(TownySettings.getTeleportWarmupTime() > 0);
      TownyTimerHandler.toggleCooldownTimer(true);
      TownyTimerHandler.toggleDrawSmokeTask(true);
      TownyTimerHandler.toggleDrawSpointsTask(TownySettings.getVisualizedSpawnPointsEnabled());
   }

   private void toggleTimersOff() {
      TownyTimerHandler.toggleTownyRepeatingTimer(false);
      TownyTimerHandler.toggleDailyTimer(false);
      TownyTimerHandler.toggleHourlyTimer(false);
      TownyTimerHandler.toggleShortTimer(false);
      TownyTimerHandler.toggleMobRemoval(false);
      TownyTimerHandler.toggleHealthRegen(false);
      TownyTimerHandler.toggleTeleportWarmup(false);
      TownyTimerHandler.toggleCooldownTimer(false);
      TownyTimerHandler.toggleDrawSmokeTask(false);
      TownyTimerHandler.toggleDrawSpointsTask(false);
   }

   private void registerEvents() {
      PluginManager pluginManager = this.getServer().getPluginManager();
      pluginManager.registerEvents(new HUDManager(this), this);
      pluginManager.registerEvents(new TownyEntityMonitorListener(this), this);
      pluginManager.registerEvents(new TownyVehicleListener(this), this);
      pluginManager.registerEvents(new TownyServerListener(this), this);
      pluginManager.registerEvents(new TownyCustomListener(this), this);
      pluginManager.registerEvents(new TownyWorldListener(this), this);
      pluginManager.registerEvents(new TownyLoginListener(), this);
      pluginManager.registerEvents(new TownyPlayerListener(this), this);
      pluginManager.registerEvents(new TownyBlockListener(this), this);
      pluginManager.registerEvents(new TownyEntityListener(this), this);
      pluginManager.registerEvents(new TownyInventoryListener(this), this);
      (new TownyPaperEvents(this)).register();
   }

   private void printChangelogToConsole() {
      try {
         InputStream is = JavaUtil.readResource("/ChangeLog.txt");

         label70: {
            try {
               String lastVersion = Version.fromString(TownySettings.getLastRunVersion()).toString();
               ChangelogReader reader = ChangelogReader.reader(lastVersion, is, 100);
               ChangelogResult result = reader.read();
               if (result.successful()) {
                  plugin.getLogger().info("------------------------------------");
                  plugin.getLogger().info("ChangeLog since v" + lastVersion + ":");
                  Iterator var5 = result.lines().iterator();

                  while(var5.hasNext()) {
                     String line = (String)var5.next();
                     if (!line.trim().replaceAll("\t", "").isEmpty()) {
                        Bukkit.getConsoleSender().sendMessage(line.trim().startsWith("-") ? line : "§e" + line);
                     }
                  }

                  if (result.limitReached()) {
                     plugin.getLogger().info("<snip>");
                     Logger var10000 = plugin.getLogger();
                     int var10001 = result.totalSize();
                     int var10002 = result.nextVersionIndex();
                     var10000.info("Changelog continues for another " + (var10001 - (var10002 + 99)) + " lines.");
                     plugin.getLogger().info("To read the full changelog since " + lastVersion + ", go to https://github.com/TownyAdvanced/Towny/blob/master/Towny/src/main/resources/ChangeLog.txt#L" + (result.nextVersionIndex() + 1));
                  }

                  plugin.getLogger().info("------------------------------------");
                  break label70;
               }

               plugin.getLogger().warning("Could not find starting index for the changelog.");
            } catch (Throwable var8) {
               if (is != null) {
                  try {
                     is.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (is != null) {
               is.close();
            }

            return;
         }

         if (is != null) {
            is.close();
         }
      } catch (IOException var9) {
         plugin.getLogger().log(Level.WARNING, "Could not read ChangeLog.txt", var9);
      }

   }

   public String getVersion() {
      return this.version;
   }

   public boolean isError() {
      return !this.errors.isEmpty();
   }

   @Internal
   public boolean isError(@NotNull TownyInitException.TownyError error) {
      return this.errors.contains(error);
   }

   @Internal
   public void addError(@NotNull TownyInitException.TownyError error) {
      this.errors.add(error);
   }

   @Internal
   public boolean removeError(@NotNull TownyInitException.TownyError error) {
      return this.errors.remove(error);
   }

   @Internal
   @NotNull
   public Collection<TownyInitException.TownyError> getErrors() {
      return this.errors;
   }

   public boolean hasCache(Player player) {
      return this.playerCache.containsKey(player.getUniqueId());
   }

   private PlayerCache newCache(Player player) {
      TownyWorld world = TownyAPI.getInstance().getTownyWorld(player.getWorld());
      if (world == null) {
         TownyMessaging.sendErrorMsg((Object)player, (String)("Could not create permission cache for unregistered world (" + player.getWorld().getName() + ")."));
         return null;
      } else {
         return new PlayerCache(player);
      }
   }

   public void deleteCache(Resident resident) {
      Player player = resident.getPlayer();
      if (player != null) {
         this.deleteCache(player);
      }

   }

   public void deleteCache(Player player) {
      this.deleteCache(player.getUniqueId());
   }

   public void deleteCache(UUID uuid) {
      this.playerCache.remove(uuid);
   }

   public PlayerCache getCache(Player player) {
      return (PlayerCache)this.playerCache.computeIfAbsent(player.getUniqueId(), (k) -> {
         return this.newCache(player);
      });
   }

   public PlayerCache getCacheOrNull(@NotNull UUID uuid) {
      return (PlayerCache)this.playerCache.get(uuid);
   }

   public void resetCache() {
      Iterator var1 = BukkitTools.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player player = (Player)var1.next();
         if (player != null) {
            this.getCache(player).resetAndUpdate(WorldCoord.parseWorldCoord((Entity)player));
         }
      }

   }

   public void updateCache(WorldCoord worldCoord) {
      Iterator var2 = BukkitTools.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         if (player != null && WorldCoord.parseWorldCoord((Entity)player).equals(worldCoord)) {
            this.getCache(player).resetAndUpdate(worldCoord);
         }
      }

   }

   public void updateCache() {
      WorldCoord worldCoord = null;
      Iterator var2 = BukkitTools.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         if (player != null) {
            worldCoord = WorldCoord.parseWorldCoord((Entity)player);
            PlayerCache cache = this.getCache(player);
            if (cache.getLastTownBlock() != worldCoord) {
               cache.resetAndUpdate(worldCoord);
            }
         }
      }

   }

   public void updateCache(Player player) {
      WorldCoord worldCoord = WorldCoord.parseWorldCoord((Entity)player);
      PlayerCache cache = this.getCache(player);
      if (!cache.getLastTownBlock().equals(worldCoord)) {
         cache.resetAndUpdate(worldCoord);
      }

   }

   public void resetCache(Player player) {
      this.getCache(player).resetAndUpdate(WorldCoord.parseWorldCoord((Entity)player));
   }

   public void setPlayerMode(Player player, String[] modes, boolean notify) {
      if (player != null) {
         Resident resident = TownyUniverse.getInstance().getResident(player.getName());
         if (resident != null) {
            resident.setModes(modes, notify);
         }

      }
   }

   public void removePlayerMode(Player player) {
      Resident resident = TownyUniverse.getInstance().getResident(player.getName());
      if (resident != null) {
         resident.clearModes();
      }

   }

   public void removePlayerModes(Player player) {
      Resident resident = TownyUniverse.getInstance().getResident(player.getName());
      if (resident != null) {
         resident.resetModes(new String[0], true);
      }

   }

   public List<String> getPlayerMode(Player player) {
      return this.getPlayerMode(player.getName());
   }

   public List<String> getPlayerMode(String name) {
      Resident resident = TownyUniverse.getInstance().getResident(name);
      return resident != null ? resident.getModes() : null;
   }

   public boolean hasPlayerMode(Player player, String mode) {
      return this.hasPlayerMode(player.getUniqueId(), mode);
   }

   public boolean hasPlayerMode(UUID uuid, String mode) {
      Resident resident = TownyUniverse.getInstance().getResident(uuid);
      return resident != null && resident.hasMode(mode);
   }

   public boolean hasPlayerMode(String name, String mode) {
      Resident resident = TownyUniverse.getInstance().getResident(name);
      return resident != null && resident.hasMode(mode);
   }

   public String getConfigPath() {
      String var10000 = this.getDataFolder().getPath();
      return var10000 + File.separator + "settings" + File.separator + "config.yml";
   }

   public Object getSetting(String root) {
      return TownySettings.getProperty(root);
   }

   @NotNull
   public static Towny getPlugin() {
      return plugin;
   }

   public static BukkitAudiences getAdventure() {
      return adventure;
   }

   private void registerSpecialCommands() {
      List<Command> commands = new ArrayList(4);
      commands.add(new AcceptCommand(this, TownySettings.getAcceptCommand()));
      commands.add(new DenyCommand(this, TownySettings.getDenyCommand()));
      commands.add(new ConfirmCommand(this, TownySettings.getConfirmCommand()));
      commands.add(new CancelCommand(this, TownySettings.getCancelCommand()));

      try {
         BukkitTools.getCommandMap().registerAll("towny", commands);
      } catch (ReflectiveOperationException var3) {
         throw new TownyInitException("An issue has occurred while registering custom commands.", TownyInitException.TownyError.OTHER, var3);
      }
   }

   private void registerCommands() {
      this.getCommand("townyadmin").setExecutor(new TownyAdminCommand(this));
      this.getCommand("townyworld").setExecutor(new TownyWorldCommand(this));
      this.getCommand("resident").setExecutor(new ResidentCommand(this));
      this.getCommand("towny").setExecutor(new TownyCommand(this));
      CommandExecutor townCommandExecutor = new TownCommand(this);
      this.getCommand("town").setExecutor(townCommandExecutor);
      this.getCommand("t").setTabCompleter((TabCompleter)townCommandExecutor);
      this.getCommand("nation").setExecutor(new NationCommand(this));
      this.getCommand("plot").setExecutor(new PlotCommand(this));
      this.getCommand("invite").setExecutor(new InviteCommand(this));
   }

   private void addMetricsCharts() {
      Metrics metrics = new Metrics(this, 2244);
      metrics.addCustomChart(new SimplePie("language", () -> {
         return TownySettings.getString(ConfigNodes.LANGUAGE);
      }));
      metrics.addCustomChart(new SimplePie("server_type", () -> {
         if (this.isFolia) {
            return "Folia";
         } else if (PaperLib.isPaper()) {
            return "Paper";
         } else if (PaperLib.isSpigot()) {
            return "Spigot";
         } else {
            return this.getServer().getName().equalsIgnoreCase("craftbukkit") ? "CraftBukkit" : "Unknown";
         }
      }));
      metrics.addCustomChart(new SimplePie("nation_zones_enabled", () -> {
         return TownySettings.getNationZonesEnabled() ? "true" : "false";
      }));
      metrics.addCustomChart(new SimplePie("database_type", () -> {
         return TownySettings.getSaveDatabase().toLowerCase(Locale.ROOT);
      }));
      metrics.addCustomChart(new SimplePie("town_block_size", () -> {
         return String.valueOf(TownySettings.getTownBlockSize());
      }));
      metrics.addCustomChart(new SimplePie("closed_economy_enabled", () -> {
         return String.valueOf(TownySettings.isEcoClosedEconomyEnabled());
      }));
   }

   public static boolean isTownyVersionSupported(String version) {
      return Version.fromString(getPlugin().getVersion()).isNewerThanOrEquals(Version.fromString(version));
   }

   public static boolean isMinecraftVersionStillSupported() {
      return MinecraftVersion.CURRENT_VERSION.isNewerThanOrEquals(MinecraftVersion.OLDEST_VERSION_SUPPORTED);
   }

   @Internal
   public boolean isFolia() {
      return this.isFolia;
   }

   private boolean expandedSchedulingAvailable() {
      return JavaUtil.classExists("io.papermc.paper.threadedregions.scheduler.FoliaAsyncScheduler");
   }

   @NotNull
   public TaskScheduler getScheduler() {
      return this.scheduler;
   }

   /** @deprecated */
   @Deprecated
   public World getServerWorld(String name) throws NotRegisteredException {
      World world = BukkitTools.getWorld(name);
      if (world == null) {
         throw new NotRegisteredException(String.format("A world called '$%s' has not been registered.", name));
      } else {
         return world;
      }
   }
}
