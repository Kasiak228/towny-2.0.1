package com.palmergames.bukkit.towny.object;

import java.util.UUID;

public interface Identifiable {
   UUID getUUID();

   void setUUID(UUID var1);
}
