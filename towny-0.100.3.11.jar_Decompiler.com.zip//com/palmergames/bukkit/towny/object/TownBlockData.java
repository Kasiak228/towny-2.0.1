package com.palmergames.bukkit.towny.object;

import com.palmergames.adventure.text.format.NamedTextColor;
import com.palmergames.bukkit.towny.TownyAsciiMap;
import com.palmergames.bukkit.towny.TownySettings;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.Material;
import org.jetbrains.annotations.Nullable;

public class TownBlockData {
   private String mapKey = "+";
   private NamedTextColor colour = null;
   private double cost = 0.0D;
   private double tax = 0.0D;
   private final Set<Material> itemUseIds = new HashSet();
   private final Set<Material> switchIds = new HashSet();
   private final Set<Material> allowedBlocks = new HashSet();

   public String getMapKey() {
      return this.mapKey;
   }

   public void setMapKey(String mapKey) {
      this.mapKey = TownyAsciiMap.parseSymbol(mapKey);
   }

   public boolean hasColour() {
      return this.colour != null;
   }

   @Nullable
   public NamedTextColor getColour() {
      return this.colour;
   }

   public void setColour(NamedTextColor colour) {
      this.colour = colour;
   }

   public double getCost() {
      return this.cost;
   }

   public void setCost(double cost) {
      this.cost = cost;
   }

   public Set<Material> getItemUseIds() {
      return this.itemUseIds.isEmpty() ? TownySettings.getItemUseMaterials() : this.itemUseIds;
   }

   public Set<Material> getSwitchIds() {
      return this.switchIds.isEmpty() ? TownySettings.getSwitchMaterials() : this.switchIds;
   }

   public Set<Material> getAllowedBlocks() {
      return this.allowedBlocks;
   }

   public void setItemUseIds(Collection<Material> itemUseIds) {
      this.itemUseIds.clear();
      this.itemUseIds.addAll(itemUseIds);
   }

   public void setSwitchIds(Collection<Material> switchIds) {
      this.switchIds.clear();
      this.switchIds.addAll(switchIds);
   }

   public void setAllowedBlocks(Collection<Material> allowedBlocks) {
      this.allowedBlocks.clear();
      this.allowedBlocks.addAll(allowedBlocks);
   }

   public void setTax(double tax) {
      this.tax = tax;
   }

   public double getTax(Town town) {
      return this.tax == 0.0D ? town.getPlotTax() : this.tax;
   }
}
