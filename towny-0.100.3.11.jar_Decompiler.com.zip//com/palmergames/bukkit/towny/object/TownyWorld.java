package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.metadata.CustomDataField;
import com.palmergames.util.MathUtil;
import com.palmergames.util.StringMgmt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;

public class TownyWorld extends TownyObject {
   private UUID uuid;
   private final HashMap<String, Town> towns = new HashMap();
   private boolean isDeletingEntitiesOnUnclaim = TownySettings.isDeletingEntitiesOnUnclaim();
   private Set<EntityType> unclaimDeleteEntityTypes = null;
   private boolean isUsingPlotManagementDelete = TownySettings.isUsingPlotManagementDelete();
   private Set<Material> plotManagementDeleteIds = null;
   private boolean isUsingPlotManagementMayorDelete = TownySettings.isUsingPlotManagementMayorDelete();
   private Set<Material> plotManagementMayorDelete = null;
   private boolean isUsingPlotManagementRevert = TownySettings.isUsingPlotManagementRevert();
   private Set<Material> plotManagementIgnoreIds = null;
   private Set<Material> revertOnUnclaimWhitelistMaterials = null;
   private boolean isUsingPlotManagementWildEntityRevert = TownySettings.isUsingPlotManagementWildEntityRegen();
   private long plotManagementWildRevertDelay = TownySettings.getPlotManagementWildRegenDelay();
   private Set<EntityType> entityExplosionProtection = null;
   private Set<Material> plotManagementWildRevertBlockWhitelist = null;
   private Set<Material> wildRevertMaterialsToNotOverwrite = null;
   private boolean isUsingPlotManagementWildBlockRevert = TownySettings.isUsingPlotManagementWildBlockRegen();
   private Set<Material> blockExplosionProtection = null;
   private Set<Material> unclaimedZoneIgnoreBlockMaterials = null;
   private Boolean unclaimedZoneBuild = null;
   private Boolean unclaimedZoneDestroy = null;
   private Boolean unclaimedZoneSwitch = null;
   private Boolean unclaimedZoneItemUse = null;
   private String unclaimedZoneName = null;
   private boolean isUsingTowny = TownySettings.isUsingTowny();
   private boolean isClaimable = TownySettings.isNewWorldClaimable();
   private boolean isWarAllowed = TownySettings.isWarAllowed();
   private boolean isPVP = TownySettings.isPvP();
   private boolean isForcePVP = TownySettings.isForcingPvP();
   private boolean isFriendlyFire = TownySettings.isFriendlyFireEnabled();
   private boolean isFire = TownySettings.isFire();
   private boolean isForceFire = TownySettings.isForcingFire();
   private boolean hasWorldMobs = TownySettings.isWorldMonstersOn();
   private boolean hasWildernessMonsters = TownySettings.isWildernessMonstersOn();
   private boolean isForceTownMobs = TownySettings.isForcingMonsters();
   private boolean isExplosion = TownySettings.isExplosions();
   private boolean isForceExpl = TownySettings.isForcingExplosions();
   private boolean isEndermanProtect = TownySettings.getEndermanProtect();
   private boolean isDisableCreatureTrample = TownySettings.isCreatureTramplingCropsDisabled();
   public Map<Location, Material> bedMap = new HashMap();
   public final List<UUID> tridentStrikeList = new ArrayList(0);

   public TownyWorld(String name) {
      super(name);
   }

   public TownyWorld(String name, UUID uuid) {
      super(name);
      this.uuid = uuid;
   }

   public boolean equals(Object other) {
      if (other == this) {
         return true;
      } else if (other instanceof TownyWorld) {
         TownyWorld otherTownyWorld = (TownyWorld)other;
         return this.getName().equals(otherTownyWorld.getName());
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.getUUID(), this.getName()});
   }

   public UUID getUUID() {
      return this.uuid;
   }

   @Internal
   public void setUUID(UUID uuid) {
      this.uuid = uuid;
   }

   @Nullable
   public World getBukkitWorld() {
      World world = this.uuid != null ? Bukkit.getWorld(this.uuid) : Bukkit.getWorld(this.getName());
      if (world == null) {
         world = Bukkit.getWorld(this.getName());
      }

      return world;
   }

   public HashMap<String, Town> getTowns() {
      return this.towns;
   }

   public boolean hasTowns() {
      return !this.towns.isEmpty();
   }

   public boolean hasTown(String name) {
      return this.towns.containsKey(name);
   }

   public boolean hasTown(Town town) {
      return this.hasTown(town.getName());
   }

   public void addTown(Town town) {
      if (!this.hasTown(town)) {
         this.towns.put(town.getName(), town);
      }

   }

   public TownBlock getTownBlock(Coord coord) throws NotRegisteredException {
      if (!this.hasTownBlock(coord)) {
         throw new NotRegisteredException();
      } else {
         return TownyUniverse.getInstance().getTownBlock(new WorldCoord(this.getName(), this.getUUID(), coord));
      }
   }

   public boolean hasTownBlock(Coord key) {
      return TownyUniverse.getInstance().hasTownBlock(new WorldCoord(this.getName(), this.getUUID(), key));
   }

   public TownBlock getTownBlock(int x, int z) throws NotRegisteredException {
      return this.getTownBlock(new Coord(x, z));
   }

   public List<TownBlock> getTownBlocks(Town town) {
      List<TownBlock> out = new ArrayList();
      Iterator var3 = town.getTownBlocks().iterator();

      while(var3.hasNext()) {
         TownBlock townBlock = (TownBlock)var3.next();
         if (townBlock.getWorld() == this) {
            out.add(townBlock);
         }
      }

      return out;
   }

   public Collection<TownBlock> getTownBlocks() {
      List<TownBlock> townBlocks = new ArrayList();
      Iterator var2 = TownyUniverse.getInstance().getTownBlocks().values().iterator();

      while(var2.hasNext()) {
         TownBlock townBlock = (TownBlock)var2.next();
         if (townBlock.getWorld() == this) {
            townBlocks.add(townBlock);
         }
      }

      return townBlocks;
   }

   public void removeTown(Town town) throws NotRegisteredException {
      if (!this.hasTown(town)) {
         throw new NotRegisteredException();
      } else {
         this.towns.remove(town.getName());
      }
   }

   public List<String> getTreeString(int depth) {
      List<String> out = new ArrayList();
      String var10001 = this.getTreeDepth(depth);
      out.add(var10001 + "World (" + this.getName() + ")");
      var10001 = this.getTreeDepth(depth + 1);
      out.add(var10001 + "TownBlocks (" + this.getTownBlocks().size() + "): ");
      return out;
   }

   public void setWarAllowed(boolean isWarAllowed) {
      this.isWarAllowed = isWarAllowed;
   }

   public boolean isWarAllowed() {
      return this.isWarAllowed;
   }

   public void setPVP(boolean isPVP) {
      this.isPVP = isPVP;
   }

   public boolean isPVP() {
      return this.isPVP;
   }

   public void setForcePVP(boolean isPVP) {
      this.isForcePVP = isPVP;
   }

   public boolean isForcePVP() {
      return this.isForcePVP;
   }

   public void setExpl(boolean isExpl) {
      this.isExplosion = isExpl;
   }

   public boolean isExpl() {
      return this.isExplosion;
   }

   public void setForceExpl(boolean isExpl) {
      this.isForceExpl = isExpl;
   }

   public boolean isForceExpl() {
      return this.isForceExpl;
   }

   public void setFire(boolean isFire) {
      this.isFire = isFire;
   }

   public boolean isFire() {
      return this.isFire;
   }

   public void setForceFire(boolean isFire) {
      this.isForceFire = isFire;
   }

   public boolean isForceFire() {
      return this.isForceFire;
   }

   public void setDisableCreatureTrample(boolean isDisableCreatureTrample) {
      this.isDisableCreatureTrample = isDisableCreatureTrample;
   }

   public boolean isDisableCreatureTrample() {
      return this.isDisableCreatureTrample;
   }

   public void setWorldMobs(boolean hasMobs) {
      this.hasWorldMobs = hasMobs;
   }

   public boolean hasWorldMobs() {
      return this.hasWorldMobs;
   }

   public void setWildernessMobs(boolean hasMonsters) {
      this.hasWildernessMonsters = hasMonsters;
   }

   public boolean hasWildernessMobs() {
      return this.hasWildernessMonsters;
   }

   public void setForceTownMobs(boolean setMobs) {
      this.isForceTownMobs = setMobs;
   }

   public boolean isForceTownMobs() {
      return this.isForceTownMobs;
   }

   public void setEndermanProtect(boolean setEnder) {
      this.isEndermanProtect = setEnder;
   }

   public boolean isEndermanProtect() {
      return this.isEndermanProtect;
   }

   public void setClaimable(boolean isClaimable) {
      this.isClaimable = isClaimable;
   }

   public boolean isClaimable() {
      return !this.isUsingTowny() ? false : this.isClaimable;
   }

   public void setUsingDefault() {
      this.setUnclaimedZoneBuild((Boolean)null);
      this.setUnclaimedZoneDestroy((Boolean)null);
      this.setUnclaimedZoneSwitch((Boolean)null);
      this.setUnclaimedZoneItemUse((Boolean)null);
      this.setUnclaimedZoneIgnore((List)null);
      this.setUnclaimedZoneName((String)null);
      this.setUsingTowny(TownySettings.isUsingTowny());
      this.setClaimable(TownySettings.isNewWorldClaimable());
      this.setWarAllowed(TownySettings.isWarAllowed());
      this.setPVP(TownySettings.isPvP());
      this.setForcePVP(TownySettings.isForcingPvP());
      this.setFriendlyFire(TownySettings.isFriendlyFireEnabled());
      this.setFire(TownySettings.isFire());
      this.setForceFire(TownySettings.isForcingFire());
      this.setWorldMobs(TownySettings.isWorldMonstersOn());
      this.setWildernessMobs(TownySettings.isWildernessMonstersOn());
      this.setForceTownMobs(TownySettings.isForcingMonsters());
      this.setExpl(TownySettings.isExplosions());
      this.setForceExpl(TownySettings.isForcingExplosions());
      this.setEndermanProtect(TownySettings.getEndermanProtect());
      this.setDisableCreatureTrample(TownySettings.isCreatureTramplingCropsDisabled());
      this.unclaimDeleteEntityTypes = null;
      this.setDeletingEntitiesOnUnclaim(TownySettings.isDeletingEntitiesOnUnclaim());
      this.setUsingPlotManagementDelete(TownySettings.isUsingPlotManagementDelete());
      this.plotManagementDeleteIds = null;
      this.setUsingPlotManagementMayorDelete(TownySettings.isUsingPlotManagementMayorDelete());
      this.plotManagementMayorDelete = null;
      this.setUsingPlotManagementRevert(TownySettings.isUsingPlotManagementRevert());
      this.plotManagementIgnoreIds = null;
      this.revertOnUnclaimWhitelistMaterials = null;
      this.setUsingPlotManagementWildEntityRevert(TownySettings.isUsingPlotManagementWildEntityRegen());
      this.entityExplosionProtection = null;
      this.setUsingPlotManagementWildBlockRevert(TownySettings.isUsingPlotManagementWildBlockRegen());
      this.blockExplosionProtection = null;
      this.plotManagementWildRevertBlockWhitelist = null;
      this.wildRevertMaterialsToNotOverwrite = null;
      this.entityExplosionProtection = null;
   }

   public void setUsingPlotManagementDelete(boolean using) {
      this.isUsingPlotManagementDelete = using;
   }

   public boolean isUsingPlotManagementDelete() {
      return this.isUsingPlotManagementDelete;
   }

   public void setDeletingEntitiesOnUnclaim(boolean using) {
      this.isDeletingEntitiesOnUnclaim = using;
   }

   public boolean isDeletingEntitiesOnUnclaim() {
      return this.isDeletingEntitiesOnUnclaim;
   }

   public Collection<EntityType> getUnclaimDeleteEntityTypes() {
      if (this.unclaimDeleteEntityTypes == null) {
         this.setUnclaimDeleteEntityTypes(TownySettings.getUnclaimDeleteEntityTypes());
      }

      return this.unclaimDeleteEntityTypes;
   }

   public void setUnclaimDeleteEntityTypes(List<String> entityTypes) {
      this.unclaimDeleteEntityTypes = TownySettings.toEntityTypeSet(entityTypes);
   }

   public void setUsingPlotManagementMayorDelete(boolean using) {
      this.isUsingPlotManagementMayorDelete = using;
   }

   public boolean isUsingPlotManagementMayorDelete() {
      return this.isUsingPlotManagementMayorDelete;
   }

   public void setUsingPlotManagementRevert(boolean using) {
      this.isUsingPlotManagementRevert = using;
   }

   public boolean isUsingPlotManagementRevert() {
      return this.isUsingPlotManagementRevert;
   }

   public Collection<Material> getPlotManagementDeleteIds() {
      return (Collection)(this.plotManagementDeleteIds == null ? TownySettings.getPlotManagementDeleteIds() : this.plotManagementDeleteIds);
   }

   public boolean isPlotManagementDeleteIds(Material material) {
      return this.getPlotManagementDeleteIds().contains(material);
   }

   public void setPlotManagementDeleteIds(List<String> plotManagementDeleteIds) {
      this.plotManagementDeleteIds = new HashSet(TownySettings.toMaterialSet(plotManagementDeleteIds));
   }

   public Collection<Material> getPlotManagementMayorDelete() {
      return (Collection)(this.plotManagementMayorDelete == null ? TownySettings.getPlotManagementMayorDelete() : this.plotManagementMayorDelete);
   }

   public boolean isPlotManagementMayorDelete(Material material) {
      return this.getPlotManagementMayorDelete().contains(material);
   }

   public void setPlotManagementMayorDelete(List<String> plotManagementMayorDelete) {
      this.plotManagementMayorDelete = new HashSet(TownySettings.toMaterialSet(plotManagementMayorDelete));
   }

   public boolean isUnclaimedBlockAllowedToRevert(Material mat) {
      if (!this.getRevertOnUnclaimWhitelistMaterials().isEmpty()) {
         return this.isRevertOnUnclaimWhitelistMaterial(mat);
      } else {
         return !this.isPlotManagementIgnoreIds(mat);
      }
   }

   public Collection<Material> getPlotManagementIgnoreIds() {
      return (Collection)(this.plotManagementIgnoreIds == null ? TownySettings.getPlotManagementIgnoreIds() : this.plotManagementIgnoreIds);
   }

   public boolean isPlotManagementIgnoreIds(Material mat) {
      return this.getPlotManagementIgnoreIds().contains(mat);
   }

   public void setPlotManagementIgnoreIds(List<String> plotManagementIgnoreIds) {
      this.plotManagementIgnoreIds = new HashSet(TownySettings.toMaterialSet(plotManagementIgnoreIds));
   }

   public Collection<Material> getRevertOnUnclaimWhitelistMaterials() {
      return (Collection)(this.revertOnUnclaimWhitelistMaterials == null ? TownySettings.getRevertOnUnclaimWhitelistMaterials() : this.revertOnUnclaimWhitelistMaterials);
   }

   public void setRevertOnUnclaimWhitelistMaterials(List<String> revertOnUnclaimWhitelistMaterials) {
      this.revertOnUnclaimWhitelistMaterials = new HashSet(TownySettings.toMaterialSet(revertOnUnclaimWhitelistMaterials));
   }

   public boolean isRevertOnUnclaimWhitelistMaterial(Material mat) {
      return this.getRevertOnUnclaimWhitelistMaterials().contains(mat);
   }

   public boolean isUsingPlotManagementWildEntityRevert() {
      return this.isUsingPlotManagementWildEntityRevert;
   }

   public boolean isUsingPlotManagementWildBlockRevert() {
      return this.isUsingPlotManagementWildBlockRevert;
   }

   public void setUsingPlotManagementWildEntityRevert(boolean isUsingPlotManagementWildEntityRevert) {
      this.isUsingPlotManagementWildEntityRevert = isUsingPlotManagementWildEntityRevert;
   }

   public void setUsingPlotManagementWildBlockRevert(boolean isUsingPlotManagementWildBlockRevert) {
      this.isUsingPlotManagementWildBlockRevert = isUsingPlotManagementWildBlockRevert;
   }

   public long getPlotManagementWildRevertDelay() {
      return this.plotManagementWildRevertDelay;
   }

   public void setPlotManagementWildRevertDelay(long plotManagementWildRevertDelay) {
      this.plotManagementWildRevertDelay = plotManagementWildRevertDelay;
   }

   public void setPlotManagementWildRevertEntities(List<String> entities) {
      this.entityExplosionProtection = new HashSet();
      this.entityExplosionProtection.addAll(TownySettings.toEntityTypeSet(entities));
   }

   public Collection<EntityType> getPlotManagementWildRevertEntities() {
      if (this.entityExplosionProtection == null) {
         this.setPlotManagementWildRevertEntities(TownySettings.getWildExplosionProtectionEntities());
      }

      return this.entityExplosionProtection;
   }

   public boolean isProtectingExplosionEntity(Entity entity) {
      if (this.entityExplosionProtection == null) {
         this.setPlotManagementWildRevertEntities(TownySettings.getWildExplosionProtectionEntities());
      }

      return this.entityExplosionProtection.contains(entity.getType());
   }

   public void setPlotManagementWildRevertBlockWhitelist(List<String> mats) {
      this.plotManagementWildRevertBlockWhitelist = new HashSet();
      this.plotManagementWildRevertBlockWhitelist.addAll(TownySettings.toMaterialSet(mats));
   }

   public Collection<Material> getPlotManagementWildRevertBlockWhitelist() {
      if (this.plotManagementWildRevertBlockWhitelist == null) {
         this.setPlotManagementWildRevertBlockWhitelist(TownySettings.getWildExplosionRevertBlockWhitelist());
      }

      return this.plotManagementWildRevertBlockWhitelist;
   }

   public boolean isPlotManagementWildRevertWhitelistedBlock(Material mat) {
      if (this.plotManagementWildRevertBlockWhitelist == null) {
         this.setPlotManagementWildRevertBlockWhitelist(TownySettings.getWildExplosionRevertBlockWhitelist());
      }

      return this.plotManagementWildRevertBlockWhitelist.isEmpty() || this.plotManagementWildRevertBlockWhitelist.contains(mat);
   }

   public boolean isExplodedBlockAllowedToRevert(Material mat) {
      if (this.getPlotManagementWildRevertBlockWhitelist().isEmpty()) {
         return !this.isPlotManagementIgnoreIds(mat);
      } else {
         return this.isPlotManagementWildRevertWhitelistedBlock(mat);
      }
   }

   public void setWildRevertMaterialsToNotOverwrite(List<String> mats) {
      this.wildRevertMaterialsToNotOverwrite = new HashSet();
      this.wildRevertMaterialsToNotOverwrite.addAll(TownySettings.toMaterialSet(mats));
   }

   public Collection<Material> getWildRevertMaterialsToNotOverwrite() {
      if (this.wildRevertMaterialsToNotOverwrite == null) {
         this.setWildRevertMaterialsToNotOverwrite(TownySettings.getWildExplosionRevertMaterialsToNotOverwrite());
      }

      return this.wildRevertMaterialsToNotOverwrite;
   }

   public boolean isMaterialNotAllowedToBeOverwrittenByWildRevert(Material mat) {
      if (this.wildRevertMaterialsToNotOverwrite == null) {
         this.setWildRevertMaterialsToNotOverwrite(TownySettings.getWildExplosionRevertMaterialsToNotOverwrite());
      }

      return this.wildRevertMaterialsToNotOverwrite.contains(mat);
   }

   /** @deprecated */
   @Deprecated
   public boolean isBlockAllowedToRevert(Material mat) {
      return this.isExplodedBlockAllowedToRevert(mat);
   }

   public void setPlotManagementWildRevertMaterials(List<String> mats) {
      this.blockExplosionProtection = new HashSet(TownySettings.toMaterialSet(mats));
   }

   public Collection<Material> getPlotManagementWildRevertBlocks() {
      if (this.blockExplosionProtection == null) {
         this.setPlotManagementWildRevertMaterials(TownySettings.getWildExplosionProtectionBlocks());
      }

      return this.blockExplosionProtection;
   }

   public boolean isProtectingExplosionBlock(Material material) {
      if (this.blockExplosionProtection == null) {
         this.setPlotManagementWildRevertMaterials(TownySettings.getWildExplosionProtectionBlocks());
      }

      return this.blockExplosionProtection.contains(material);
   }

   public void setUnclaimedZoneIgnore(List<String> unclaimedZoneIgnoreIds) {
      if (unclaimedZoneIgnoreIds == null) {
         this.unclaimedZoneIgnoreBlockMaterials = new HashSet(TownySettings.getUnclaimedZoneIgnoreMaterials());
      } else {
         this.unclaimedZoneIgnoreBlockMaterials = new HashSet(TownySettings.toMaterialSet(unclaimedZoneIgnoreIds));
      }

   }

   public Collection<Material> getUnclaimedZoneIgnoreMaterials() {
      return (Collection)(this.unclaimedZoneIgnoreBlockMaterials == null ? TownySettings.getUnclaimedZoneIgnoreMaterials() : this.unclaimedZoneIgnoreBlockMaterials);
   }

   public boolean isUnclaimedZoneIgnoreMaterial(Material mat) {
      return this.getUnclaimedZoneIgnoreMaterials().contains(mat);
   }

   public boolean getUnclaimedZonePerm(TownyPermission.ActionType type) {
      switch(type) {
      case BUILD:
         return this.getUnclaimedZoneBuild();
      case DESTROY:
         return this.getUnclaimedZoneDestroy();
      case SWITCH:
         return this.getUnclaimedZoneSwitch();
      case ITEM_USE:
         return this.getUnclaimedZoneItemUse();
      default:
         throw new UnsupportedOperationException();
      }
   }

   public Boolean getUnclaimedZoneBuild() {
      return this.unclaimedZoneBuild == null ? TownySettings.getUnclaimedZoneBuildRights() : this.unclaimedZoneBuild;
   }

   public void setUnclaimedZoneBuild(Boolean unclaimedZoneBuild) {
      this.unclaimedZoneBuild = unclaimedZoneBuild;
   }

   public Boolean getUnclaimedZoneDestroy() {
      return this.unclaimedZoneDestroy == null ? TownySettings.getUnclaimedZoneDestroyRights() : this.unclaimedZoneDestroy;
   }

   public void setUnclaimedZoneDestroy(Boolean unclaimedZoneDestroy) {
      this.unclaimedZoneDestroy = unclaimedZoneDestroy;
   }

   public Boolean getUnclaimedZoneSwitch() {
      return this.unclaimedZoneSwitch == null ? TownySettings.getUnclaimedZoneSwitchRights() : this.unclaimedZoneSwitch;
   }

   public void setUnclaimedZoneSwitch(Boolean unclaimedZoneSwitch) {
      this.unclaimedZoneSwitch = unclaimedZoneSwitch;
   }

   public String getUnclaimedZoneName() {
      return this.unclaimedZoneName == null ? TownySettings.getUnclaimedZoneName() : this.unclaimedZoneName;
   }

   public String getFormattedUnclaimedZoneName() {
      return StringMgmt.remUnderscore(this.getUnclaimedZoneName());
   }

   public void setUnclaimedZoneName(String unclaimedZoneName) {
      this.unclaimedZoneName = unclaimedZoneName;
   }

   public void setUsingTowny(boolean isUsingTowny) {
      this.isUsingTowny = isUsingTowny;
   }

   public boolean isUsingTowny() {
      return this.isUsingTowny;
   }

   public void setUnclaimedZoneItemUse(Boolean unclaimedZoneItemUse) {
      this.unclaimedZoneItemUse = unclaimedZoneItemUse;
   }

   public Boolean getUnclaimedZoneItemUse() {
      return this.unclaimedZoneItemUse == null ? TownySettings.getUnclaimedZoneItemUseRights() : this.unclaimedZoneItemUse;
   }

   /** @deprecated */
   @Deprecated
   public int getMinDistanceFromOtherTowns(Coord key) {
      return this.getMinDistanceFromOtherTownsHomeBlocks(key);
   }

   public int getMinDistanceFromOtherTownsHomeBlocks(Coord key) {
      return this.getMinDistanceFromOtherTownsHomeBlocks(key, (Town)null);
   }

   /** @deprecated */
   @Deprecated
   public int getMinDistanceFromOtherTowns(Coord key, Town homeTown) {
      return this.getMinDistanceFromOtherTownsHomeBlocks(key, homeTown);
   }

   public int getMinDistanceFromOtherTownsHomeBlocks(Coord key, Town homeTown) {
      double minSqr = -1.0D;
      int keyX = key.getX();
      int keyZ = key.getZ();
      Iterator var7 = this.getTowns().values().iterator();

      while(var7.hasNext()) {
         Town town = (Town)var7.next();

         try {
            Coord townCoord = town.getHomeBlock().getCoord();
            if ((homeTown == null || !homeTown.getUUID().equals(town.getUUID()) && (!TownySettings.isMinDistanceIgnoringTownsInSameNation() || !homeTown.hasNation() || !town.hasNation() || !town.getNationOrNull().equals(homeTown.getNationOrNull())) && (!TownySettings.isMinDistanceIgnoringTownsInAlliedNation() || !homeTown.isAlliedWith(town))) && town.getHomeblockWorld().equals(this)) {
               double distSqr = MathUtil.distanceSquared((double)townCoord.getX() - (double)keyX, (double)townCoord.getZ() - (double)keyZ);
               if (minSqr == -1.0D || distSqr < minSqr) {
                  minSqr = distSqr;
               }
            }
         } catch (TownyException var12) {
         }
      }

      return minSqr == -1.0D ? Integer.MAX_VALUE : (int)Math.ceil(Math.sqrt(minSqr));
   }

   public int getMinDistanceFromOtherTownsPlots(Coord key) {
      return this.getMinDistanceFromOtherTownsPlots(key, (Town)null);
   }

   public int getMinDistanceFromOtherTownsPlots(Coord key, Town homeTown) {
      int keyX = key.getX();
      int keyZ = key.getZ();
      double minSqr = -1.0D;
      Iterator var7 = this.getTowns().values().iterator();

      label71:
      while(true) {
         Town town;
         do {
            if (!var7.hasNext()) {
               return minSqr == -1.0D ? Integer.MAX_VALUE : (int)Math.ceil(Math.sqrt(minSqr));
            }

            town = (Town)var7.next();
         } while(homeTown != null && (homeTown.getUUID().equals(town.getUUID()) || TownySettings.isMinDistanceIgnoringTownsInSameNation() && homeTown.hasNation() && town.hasNation() && town.getNationOrNull().equals(homeTown.getNationOrNull()) || TownySettings.isMinDistanceIgnoringTownsInAlliedNation() && homeTown.isAlliedWith(town)));

         Iterator var9 = town.getTownBlocks().iterator();

         while(true) {
            double distSqr;
            do {
               int tbX;
               int tbZ;
               do {
                  TownBlock b;
                  do {
                     if (!var9.hasNext()) {
                        continue label71;
                     }

                     b = (TownBlock)var9.next();
                  } while(!b.getWorld().equals(this));

                  tbX = b.getX();
                  tbZ = b.getZ();
               } while(keyX == tbX && keyZ == tbZ);

               distSqr = MathUtil.distanceSquared((double)tbX - (double)keyX, (double)tbZ - (double)keyZ);
            } while(minSqr != -1.0D && !(distSqr < minSqr));

            minSqr = distSqr;
         }
      }
   }

   public int getMinDistanceFromOtherPlotsOwnedByTown(Coord key, Town town) {
      int keyX = key.getX();
      int keyZ = key.getZ();
      double minSqr = -1.0D;
      Iterator var7 = town.getTownBlocks().iterator();

      while(true) {
         double distSqr;
         do {
            int tbX;
            int tbZ;
            do {
               TownBlock b;
               do {
                  if (!var7.hasNext()) {
                     return minSqr == -1.0D ? Integer.MAX_VALUE : (int)Math.ceil(Math.sqrt(minSqr));
                  }

                  b = (TownBlock)var7.next();
               } while(!b.getWorld().equals(this));

               tbX = b.getX();
               tbZ = b.getZ();
            } while(keyX == tbX && keyZ == tbZ);

            distSqr = MathUtil.distanceSquared((double)tbX - (double)keyX, (double)tbZ - (double)keyZ);
         } while(minSqr != -1.0D && !(distSqr < minSqr));

         minSqr = distSqr;
      }
   }

   public Town getClosestTownWithNationFromCoord(Coord key, Town nearestTown) {
      int keyX = key.getX();
      int keyZ = key.getZ();
      double minSqr = -1.0D;
      Iterator var7 = this.getTowns().values().iterator();

      label39:
      while(true) {
         Town town;
         do {
            if (!var7.hasNext()) {
               return nearestTown;
            }

            town = (Town)var7.next();
         } while(!town.hasNation());

         Iterator var9 = town.getTownBlocks().iterator();

         while(true) {
            double distSqr;
            do {
               TownBlock b;
               do {
                  if (!var9.hasNext()) {
                     continue label39;
                  }

                  b = (TownBlock)var9.next();
               } while(!b.getWorld().equals(this));

               int tbX = b.getX();
               int tbZ = b.getZ();
               distSqr = MathUtil.distanceSquared((double)tbX - (double)keyX, (double)tbZ - (double)keyZ);
            } while(minSqr != -1.0D && !(distSqr < minSqr));

            minSqr = distSqr;
            nearestTown = town;
         }
      }
   }

   @Nullable
   public TownBlock getClosestTownblockWithNationFromCoord(Coord key) {
      int keyX = key.getX();
      int keyZ = key.getZ();
      double minSqr = -1.0D;
      TownBlock tb = null;
      Iterator var7 = this.getTowns().values().iterator();

      label39:
      while(true) {
         Town town;
         do {
            if (!var7.hasNext()) {
               return tb;
            }

            town = (Town)var7.next();
         } while(!town.hasNation());

         Iterator var9 = town.getTownBlocks().iterator();

         while(true) {
            TownBlock b;
            double distSqr;
            do {
               do {
                  if (!var9.hasNext()) {
                     continue label39;
                  }

                  b = (TownBlock)var9.next();
               } while(!b.getWorld().equals(this));

               int tbX = b.getX();
               int tbZ = b.getZ();
               distSqr = MathUtil.distanceSquared((double)tbX - (double)keyX, (double)tbZ - (double)keyZ);
            } while(minSqr != -1.0D && !(distSqr < minSqr));

            minSqr = distSqr;
            tb = b;
         }
      }
   }

   public void addMetaData(@NotNull CustomDataField<?> md) {
      this.addMetaData(md, true);
   }

   public void removeMetaData(@NotNull CustomDataField<?> md) {
      this.removeMetaData(md, true);
   }

   @Internal
   public boolean hasBedExplosionAtBlock(Location location) {
      return this.bedMap.containsKey(location);
   }

   @Nullable
   @Internal
   public Material getBedExplosionMaterial(Location location) {
      return this.hasBedExplosionAtBlock(location) ? (Material)this.bedMap.get(location) : null;
   }

   @Internal
   public void addBedExplosionAtBlock(Location location, Material material) {
      this.bedMap.put(location, material);
   }

   @Internal
   public void removeBedExplosionAtBlock(Location location) {
      if (this.hasBedExplosionAtBlock(location)) {
         this.bedMap.remove(location);
      }

   }

   @Internal
   public boolean hasTridentStrike(UUID uuid) {
      return this.tridentStrikeList.contains(uuid);
   }

   @Internal
   public void addTridentStrike(UUID uuid) {
      this.tridentStrikeList.add(uuid);
   }

   @Internal
   public void removeTridentStrike(UUID uuid) {
      this.tridentStrikeList.remove(uuid);
   }

   public void setFriendlyFire(boolean parseBoolean) {
      this.isFriendlyFire = parseBoolean;
   }

   public boolean isFriendlyFireEnabled() {
      return this.isFriendlyFire;
   }

   public void save() {
      TownyUniverse.getInstance().getDataSource().saveWorld(this);
   }

   @Internal
   public boolean exists() {
      return TownyUniverse.getInstance().hasTownyWorld(this.getName());
   }
}
