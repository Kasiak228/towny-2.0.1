package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.Towny;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;

public class TeleportWarmupParticle {
   private static final List<TeleportWarmupParticle.RingCoord> RING_PATTERN = createRingOffsets();
   public static final int RING_POINT_COUNT = 12;
   public static final int RING_DELAY_TICKS = 2;
   public final Location loc;

   public TeleportWarmupParticle(Location loc) {
      this.loc = loc;
      this.drawParticle();
   }

   private void drawParticle() {
      World world = this.loc.getWorld();
      if (world != null) {
         int i = 0;

         for(Iterator var3 = RING_PATTERN.iterator(); var3.hasNext(); ++i) {
            TeleportWarmupParticle.RingCoord ringPosition = (TeleportWarmupParticle.RingCoord)var3.next();
            Location point = this.loc.clone().add(ringPosition.x(), 0.0D, ringPosition.z());
            Towny.getPlugin().getScheduler().runAsyncLater(() -> {
               try {
                  world.spawnParticle(Particle.CRIT_MAGIC, point, 1, 0.0D, 0.0D, 0.0D, 0.0D);
               } catch (Exception var3) {
               }

            }, (long)i * 2L);
         }

      }
   }

   private static List<TeleportWarmupParticle.RingCoord> createRingOffsets() {
      ArrayList<TeleportWarmupParticle.RingCoord> ring = new ArrayList();
      double radius = 0.45D;
      double angleIncrement = 0.5235987755982988D;

      for(int i = 0; i < 12; ++i) {
         double angle = (double)i * 0.5235987755982988D;
         double x = 0.45D * Math.sin(angle);
         double y = 0.45D * Math.cos(angle);
         ring.add(TeleportWarmupParticle.RingCoord.offset(x, y));
      }

      return ring;
   }

   private static record RingCoord(double x, double z) {
      private RingCoord(double x, double z) {
         this.x = x;
         this.z = z;
      }

      private static TeleportWarmupParticle.RingCoord offset(double a, double b) {
         return new TeleportWarmupParticle.RingCoord(a, b);
      }

      public double x() {
         return this.x;
      }

      public double z() {
         return this.z;
      }
   }
}
