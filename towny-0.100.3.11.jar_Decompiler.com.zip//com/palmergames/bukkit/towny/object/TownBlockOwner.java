package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import java.util.Collection;

public interface TownBlockOwner extends Permissible, Nameable {
   Collection<TownBlock> getTownBlocks();

   boolean hasTownBlock(TownBlock var1);

   void addTownBlock(TownBlock var1) throws AlreadyRegisteredException;

   void removeTownBlock(TownBlock var1) throws NotRegisteredException;
}
