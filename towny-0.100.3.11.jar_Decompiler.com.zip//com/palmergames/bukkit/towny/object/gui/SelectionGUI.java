package com.palmergames.bukkit.towny.object.gui;

import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownyInventory;
import org.bukkit.inventory.Inventory;

public class SelectionGUI extends TownyInventory {
   private final SelectionGUI.SelectionType type;

   public SelectionGUI(Resident res, Inventory inv, String name, SelectionGUI.SelectionType type) {
      super(res, inv, name);
      this.type = type;
   }

   public SelectionGUI.SelectionType getType() {
      return this.type;
   }

   public static enum SelectionType {
      SWITCHES,
      ALLOWEDBLOCKS,
      ITEMUSE;

      // $FF: synthetic method
      private static SelectionGUI.SelectionType[] $values() {
         return new SelectionGUI.SelectionType[]{SWITCHES, ALLOWEDBLOCKS, ITEMUSE};
      }
   }
}
