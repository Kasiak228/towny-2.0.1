package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.object.economy.Account;
import org.bukkit.World;

public class EconomyAccount extends Account {
   private World world;

   protected EconomyAccount(Resident resident, String name, World world) {
      super(resident, name);
      this.world = world;
   }

   protected synchronized boolean addMoney(double amount) {
      return TownyEconomyHandler.add(this, amount, this.world);
   }

   protected synchronized boolean subtractMoney(double amount) {
      return TownyEconomyHandler.subtract(this, amount, this.world);
   }

   public World getWorld() {
      return this.world;
   }
}
