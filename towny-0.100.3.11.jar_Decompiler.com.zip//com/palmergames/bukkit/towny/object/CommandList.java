package com.palmergames.bukkit.towny.object;

import com.google.common.base.Preconditions;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.ApiStatus.Internal;

public class CommandList {
   private static final Pattern REMOVE_LEADING_SPACE = Pattern.compile("^[/ ]{1,2}");
   private static final Pattern MATCH_NAMESPACE = Pattern.compile("^(.+:)");
   final CommandList.CommandNode root = new CommandList.CommandNode("");

   public CommandList(Collection<String> commands) {
      Iterator var2 = commands.iterator();

      while(var2.hasNext()) {
         String command = (String)var2.next();
         this.addCommand(command);
      }

   }

   public void addCommand(@NotNull String command) {
      Preconditions.checkNotNull(command, "command");
      String normalized = normalizeCommand(command.toLowerCase(Locale.ROOT));
      if (!normalized.isEmpty()) {
         CommandList.CommandNode current = this.root;
         String[] var4 = normalized.split(" ");
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            String part = var4[var6];
            current = (CommandList.CommandNode)current.children.computeIfAbsent(part, (k) -> {
               return new CommandList.CommandNode(part);
            });
         }

         current.endOfWord = true;
      }
   }

   @Internal
   public static String normalizeCommand(String command) {
      command = REMOVE_LEADING_SPACE.matcher(command).replaceAll("");
      return MATCH_NAMESPACE.matcher(command).replaceAll("");
   }

   public boolean containsCommand(@NotNull String command) {
      Preconditions.checkNotNull(command, "command");
      String normalized = normalizeCommand(command.toLowerCase(Locale.ROOT));
      CommandList.CommandNode current = this.root;
      String[] var4 = normalized.split(" ");
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         String part = var4[var6];
         current = (CommandList.CommandNode)current.children.get(part);
         if (current == null) {
            break;
         }

         if (current.endOfWord) {
            return true;
         }
      }

      return false;
   }

   public static class CommandNode {
      final Map<String, CommandList.CommandNode> children = new HashMap();
      final String command;
      boolean endOfWord = false;

      public CommandNode(String command) {
         this.command = command;
      }
   }
}
