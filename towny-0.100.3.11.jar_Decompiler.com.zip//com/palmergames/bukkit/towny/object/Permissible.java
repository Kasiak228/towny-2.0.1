package com.palmergames.bukkit.towny.object;

public interface Permissible {
   void setPermissions(String var1);

   TownyPermission getPermissions();
}
