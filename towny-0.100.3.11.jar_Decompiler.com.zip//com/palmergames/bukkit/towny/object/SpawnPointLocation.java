package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.TownyAPI;
import org.bukkit.Location;

public class SpawnPointLocation extends Position {
   public SpawnPointLocation(Location loc) {
      super(TownyAPI.getInstance().getTownyWorld(loc.getWorld()), (double)loc.getBlockX(), (double)loc.getBlockY(), (double)loc.getBlockZ(), 0.0F, 0.0F);
   }

   private SpawnPointLocation(Position position) {
      super(position.world(), (double)position.blockX(), (double)position.blockY(), (double)position.blockZ(), 0.0F, 0.0F);
   }

   /** @deprecated */
   @Deprecated
   public String getWorld() {
      return this.world().getName();
   }

   public int getX() {
      return this.blockX();
   }

   public int getY() {
      return this.blockY();
   }

   public int getZ() {
      return this.blockZ();
   }

   public static SpawnPointLocation parseSpawnPointLocation(Location loc) {
      return parsePos(Position.ofLocation(loc));
   }

   public static SpawnPointLocation parsePos(Position position) {
      return new SpawnPointLocation(position);
   }

   public String toString() {
      String var10000 = this.world().getName();
      return var10000 + "," + this.blockX() + "," + this.blockY() + "," + this.blockZ();
   }

   public boolean equals(Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof SpawnPointLocation)) {
         return false;
      } else {
         SpawnPointLocation loc = (SpawnPointLocation)other;
         return this.world().equals(loc.world()) && this.blockX() == loc.blockX() && this.blockY() == loc.blockY() && this.blockZ() == loc.blockZ();
      }
   }
}
