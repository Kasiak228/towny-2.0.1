package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.util.DrawUtil;
import java.util.Arrays;
import java.util.function.Consumer;
import org.bukkit.Location;
import org.bukkit.World;

public class CellBorder extends WorldCoord {
   public boolean[] border;

   public CellBorder(WorldCoord worldCoord, boolean[] border) {
      super(worldCoord);
      this.border = border;
   }

   public void setBorderAt(CellBorder.Section s, boolean b) {
      this.border[s.ordinal()] = b;
   }

   public boolean hasBorderAt(CellBorder.Section s) {
      return this.border[s.ordinal()];
   }

   public boolean[] getBorder() {
      return this.border;
   }

   public boolean hasAnyBorder() {
      boolean[] var1 = this.border;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         boolean b = var1[var3];
         if (b) {
            return true;
         }
      }

      return false;
   }

   public int getBlockX() {
      return this.getX() * getCellSize();
   }

   public int getBlockZ() {
      return this.getZ() * getCellSize();
   }

   public void runBorderedOnSurface(int wallHeight, int cornerHeight, Consumer<Location> locationConsumer) {
      int x = this.getBlockX();
      int z = this.getBlockZ();
      int w = Coord.getCellSize() - 1;
      World world = this.getBukkitWorld();
      CellBorder.Section[] var8 = CellBorder.Section.values();
      int var9 = var8.length;

      for(int var10 = 0; var10 < var9; ++var10) {
         CellBorder.Section section = var8[var10];
         if (this.border[section.ordinal()] && (section.getType() == CellBorder.Section.Type.WALL && wallHeight > 0 || section.getType() == CellBorder.Section.Type.CORNER && cornerHeight > 0)) {
            switch(section) {
            case N:
               DrawUtil.runOnSurface(world, x, z, x, z + w, wallHeight, locationConsumer);
               break;
            case NE:
               DrawUtil.runOnSurface(world, x, z, x, z, cornerHeight, locationConsumer);
               break;
            case E:
               DrawUtil.runOnSurface(world, x, z, x + w, z, wallHeight, locationConsumer);
               break;
            case SE:
               DrawUtil.runOnSurface(world, x + w, z, x + w, z, cornerHeight, locationConsumer);
               break;
            case S:
               DrawUtil.runOnSurface(world, x + w, z, x + w, z + w, wallHeight, locationConsumer);
               break;
            case SW:
               DrawUtil.runOnSurface(world, x + w, z + w, x + w, z + w, cornerHeight, locationConsumer);
               break;
            case W:
               DrawUtil.runOnSurface(world, x, z + w, x + w, z + w, wallHeight, locationConsumer);
               break;
            case NW:
               DrawUtil.runOnSurface(world, x, z + w, x, z + w, cornerHeight, locationConsumer);
            }
         }
      }

   }

   public String toString() {
      String var10000 = super.toString();
      return var10000 + Arrays.toString(this.getBorder());
   }

   public static enum Section {
      N(CellBorder.Section.Type.WALL),
      NE(CellBorder.Section.Type.CORNER),
      E(CellBorder.Section.Type.WALL),
      SE(CellBorder.Section.Type.CORNER),
      S(CellBorder.Section.Type.WALL),
      SW(CellBorder.Section.Type.CORNER),
      W(CellBorder.Section.Type.WALL),
      NW(CellBorder.Section.Type.CORNER);

      private final CellBorder.Section.Type type;

      private Section(CellBorder.Section.Type type) {
         this.type = type;
      }

      public CellBorder.Section.Type getType() {
         return this.type;
      }

      public static int numParts() {
         return values().length;
      }

      // $FF: synthetic method
      private static CellBorder.Section[] $values() {
         return new CellBorder.Section[]{N, NE, E, SE, S, SW, W, NW};
      }

      public static enum Type {
         WALL,
         CORNER;

         // $FF: synthetic method
         private static CellBorder.Section.Type[] $values() {
            return new CellBorder.Section.Type[]{WALL, CORNER};
         }
      }
   }
}
