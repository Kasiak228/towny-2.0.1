package com.palmergames.bukkit.towny.object;

import java.util.Collection;

public interface ResidentList {
   Collection<Resident> getResidents();

   boolean hasResident(String var1);

   Collection<Resident> getOutlaws();
}
