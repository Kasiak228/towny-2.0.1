package com.palmergames.bukkit.towny.object;

import java.util.UUID;

public abstract class ObjectGroup extends TownyObject implements Identifiable {
   private UUID uuid;

   public ObjectGroup(UUID id, String name) {
      super(name);
      this.uuid = id;
   }

   public UUID getUUID() {
      return this.uuid;
   }

   public void setUUID(UUID id) {
      this.uuid = id;
   }

   public boolean equals(Object obj) {
      return obj instanceof ObjectGroup ? ((ObjectGroup)obj).uuid.equals(this.uuid) : false;
   }

   public String toString() {
      String var10000 = this.getName();
      return var10000 + "," + this.uuid;
   }

   public int hashCode() {
      return this.uuid.hashCode();
   }
}
