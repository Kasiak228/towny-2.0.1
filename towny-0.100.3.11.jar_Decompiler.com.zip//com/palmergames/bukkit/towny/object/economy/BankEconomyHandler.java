package com.palmergames.bukkit.towny.object.economy;

import com.palmergames.bukkit.towny.object.EconomyHandler;

public interface BankEconomyHandler extends EconomyHandler {
   double getBankCap();

   String getBankAccountPrefix();

   BankAccount getAccount();
}
