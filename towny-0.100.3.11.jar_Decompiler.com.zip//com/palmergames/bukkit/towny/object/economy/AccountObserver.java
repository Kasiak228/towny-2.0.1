package com.palmergames.bukkit.towny.object.economy;

public interface AccountObserver {
   void withdrew(Account var1, double var2, String var4);

   void deposited(Account var1, double var2, String var4);
}
