package com.palmergames.bukkit.towny.object.economy;

import java.util.List;

public interface AccountAuditor extends AccountObserver {
   List<String> getAuditHistory();

   List<BankTransaction> getTransactions();
}
