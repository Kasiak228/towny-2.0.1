package com.palmergames.bukkit.towny.object.economy;

import com.palmergames.bukkit.towny.object.EconomyHandler;
import org.bukkit.World;

public interface TownyServerAccountEconomyHandler extends EconomyHandler {
   Account getAccount();

   boolean addToServer(Account var1, double var2, World var4);

   boolean subtractFromServer(Account var1, double var2, World var4);
}
