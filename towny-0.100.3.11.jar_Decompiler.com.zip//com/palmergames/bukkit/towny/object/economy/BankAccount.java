package com.palmergames.bukkit.towny.object.economy;

import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.economy.TownEntersBankruptcyEvent;
import com.palmergames.bukkit.towny.object.Government;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.util.BukkitTools;
import org.bukkit.World;
import org.jetbrains.annotations.Nullable;

public class BankAccount extends Account {
   private double debtCap;
   private Government government;

   public BankAccount(String name, World world, Government government) {
      super(government, name, world);
      this.government = government;
   }

   public double getBalanceCap() {
      return this.government.getBankCap();
   }

   protected synchronized boolean subtractMoney(double amount) {
      if (this.isBankrupt()) {
         return this.addDebt(amount);
      } else if (!this.canPayFromHoldings(amount) && this.isAllowedToEnterBankruptcy()) {
         double newDebt = amount - this.getHoldingBalance();
         if (newDebt <= this.getDebtCap()) {
            boolean success = TownyEconomyHandler.setBalance(this.getName(), 0.0D, this.world);
            success &= this.addDebt(newDebt);
            if (success) {
               BukkitTools.fireEvent(new TownEntersBankruptcyEvent(this.getTown()));
            }

            return success;
         } else {
            return false;
         }
      } else {
         return TownyEconomyHandler.subtract(this, amount, this.world);
      }
   }

   protected synchronized boolean addMoney(double amount) {
      if (this.getBalanceCap() != 0.0D && this.getHoldingBalance() + amount > this.getBalanceCap()) {
         return false;
      } else {
         return this.isBankrupt() ? this.removeDebt(amount) : TownyEconomyHandler.add(this, amount, this.world);
      }
   }

   public synchronized boolean canPayFromHoldings(double amount) {
      if (this.isBankrupt()) {
         return this.getTownDebt() + amount <= this.getDebtCap();
      } else {
         return super.canPayFromHoldings(amount);
      }
   }

   public synchronized double getHoldingBalance(boolean setCache) {
      double balance = this.isBankrupt() ? this.getTownDebt() * -1.0D : TownyEconomyHandler.getBalance(this.getName(), this.getBukkitWorld());
      if (setCache) {
         this.cachedBalance.setBalance(balance);
      }

      return balance;
   }

   public String getHoldingFormattedBalance() {
      return this.isBankrupt() ? "-" + TownyEconomyHandler.getFormattedBalance(this.getTownDebt()) : TownyEconomyHandler.getFormattedBalance(this.getHoldingBalance());
   }

   private boolean isTownAccount() {
      return this.government instanceof Town;
   }

   @Nullable
   private Town getTown() {
      return this.isTownAccount() ? (Town)this.government : null;
   }

   public void removeAccount() {
      if (TownySettings.isDeletedObjectBalancePaidToOwner()) {
         Resident owner = this.getGovernmentOwner();
         if (owner != null && !owner.isNPC()) {
            double balance = this.getHoldingBalance();
            if (balance > 0.0D) {
               TownyMessaging.sendMsg(owner, Translatable.of("msg_recieved_refund_for_deleted_object", TownyEconomyHandler.getFormattedBalance(balance)));
               this.payTo(balance, owner, "Deleted " + (this.isTownAccount() ? "Town" : "Nation") + " bank balance refund.");
            }
         }
      }

      super.removeAccount();
   }

   @Nullable
   private Resident getGovernmentOwner() {
      Government var3 = this.government;
      Resident var10000;
      if (var3 instanceof Town) {
         Town town = (Town)var3;
         var10000 = town.getMayor();
      } else {
         var3 = this.government;
         if (var3 instanceof Nation) {
            Nation nation = (Nation)var3;
            if (nation.hasCapital()) {
               var10000 = nation.getKing();
               return var10000;
            }
         }

         var10000 = null;
      }

      return var10000;
   }

   public boolean isBankrupt() {
      Government var2 = this.government;
      boolean var10000;
      if (var2 instanceof Town) {
         Town town = (Town)var2;
         if (town.isBankrupt()) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private synchronized boolean addDebt(double amount) {
      if (this.isTownAccount() && TownySettings.isTownBankruptcyEnabled()) {
         double newDebtBalance = this.getTownDebt() + amount;
         if (newDebtBalance > this.getDebtCap()) {
            return false;
         } else {
            this.setTownDebt(newDebtBalance);
            return true;
         }
      } else {
         return false;
      }
   }

   private synchronized boolean removeDebt(double amount) {
      if (this.getTownDebt() < amount) {
         double netMoney = amount - this.getTownDebt();
         this.setTownDebt(0.0D);
         double bankBalance = TownyEconomyHandler.getBalance(this.getName(), this.getBukkitWorld());
         TownyEconomyHandler.setBalance(this.getName(), bankBalance + netMoney, this.world);
         return true;
      } else {
         this.setTownDebt(this.getTownDebt() - amount);
         return true;
      }
   }

   public synchronized double getDebtCap() {
      if (!this.isTownAccount()) {
         return Double.MAX_VALUE;
      } else if (TownySettings.isDebtCapDeterminedByTownLevel()) {
         return this.getTown().getTownLevel().debtCapModifier() * TownySettings.getDebtCapOverride();
      } else if (TownySettings.getDebtCapOverride() != 0.0D) {
         return TownySettings.getDebtCapOverride();
      } else {
         return TownySettings.getDebtCapMaximum() != 0.0D ? Math.min(this.debtCap, TownySettings.getDebtCapMaximum()) : this.debtCap;
      }
   }

   public void setDebtCap(double debtCap) {
      this.debtCap = debtCap;
   }

   private boolean isAllowedToEnterBankruptcy() {
      return TownySettings.isTownBankruptcyEnabled() && this.isTownAccount();
   }

   private double getTownDebt() {
      return this.getTown().getDebtBalance();
   }

   private void setTownDebt(double amount) {
      this.getTown().setDebtBalance(amount);
      this.getTown().save();
   }
}
