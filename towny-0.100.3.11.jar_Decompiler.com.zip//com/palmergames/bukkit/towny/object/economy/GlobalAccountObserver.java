package com.palmergames.bukkit.towny.object.economy;

import com.palmergames.bukkit.towny.TownyLogger;

public final class GlobalAccountObserver implements AccountObserver {
   public void withdrew(Account account, double amount, String reason) {
      TownyLogger.logMoneyTransaction((Account)account, amount, (Account)null, reason);
   }

   public void deposited(Account account, double amount, String reason) {
      TownyLogger.logMoneyTransaction((Account)account, amount, (Account)null, reason);
   }
}
