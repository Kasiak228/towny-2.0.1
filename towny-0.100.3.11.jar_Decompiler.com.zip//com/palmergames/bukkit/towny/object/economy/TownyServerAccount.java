package com.palmergames.bukkit.towny.object.economy;

import com.palmergames.bukkit.config.ConfigNodes;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.object.EconomyHandler;
import com.palmergames.bukkit.towny.object.economy.transaction.Transaction;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.UUID;
import org.bukkit.World;

public class TownyServerAccount extends Account implements TownyServerAccountEconomyHandler {
   private static final UUID uuid = UUID.fromString("a73f39b0-1b7c-4930-b4a3-ce101812d926");
   private static final String name;

   public TownyServerAccount() {
      super((EconomyHandler)null, name);
   }

   public TownyServerAccount(TownyServerAccountEconomyHandler economyHandler) {
      super(economyHandler, name);
   }

   public static UUID getUUID() {
      return uuid;
   }

   protected synchronized boolean addMoney(double amount) {
      return TownyEconomyHandler.add(this, amount, this.world);
   }

   protected synchronized boolean subtractMoney(double amount) {
      return TownyEconomyHandler.subtract(this, amount, this.world);
   }

   public boolean addToServer(Account account, double amount, World world) {
      boolean success = TownyEconomyHandler.add(this, amount, world);
      if (success) {
         BukkitTools.fireEvent(Transaction.add(amount).paidBy(account).paidToServer().asTownyTransactionEvent());
      }

      return success;
   }

   public boolean subtractFromServer(Account account, double amount, World world) {
      boolean success = TownyEconomyHandler.subtract(this, amount, world);
      if (success) {
         BukkitTools.fireEvent(Transaction.subtract(amount).paidByServer().paidTo(account).asTownyTransactionEvent());
      }

      return success;
   }

   public Account getAccount() {
      return this;
   }

   static {
      name = TownySettings.getString(ConfigNodes.ECO_CLOSED_ECONOMY_SERVER_ACCOUNT);
   }
}
