package com.palmergames.bukkit.towny.object.economy;

import com.palmergames.bukkit.towny.object.economy.transaction.TransactionType;
import java.text.SimpleDateFormat;

public class BankTransaction {
   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d ''yy '@' HH:mm:ss");
   private final TransactionType type;
   private final long time;
   private final Account account;
   private final double amount;
   private final double balance;
   private final String reason;

   public BankTransaction(TransactionType type, long time, Account account, double amount, double balance, String reason) {
      this.type = type;
      this.time = time;
      this.account = account;
      this.amount = amount;
      this.reason = reason;
      this.balance = balance;
   }

   public TransactionType getType() {
      return this.type;
   }

   public String getTime() {
      return dateFormat.format(this.time);
   }

   public long time() {
      return this.time;
   }

   public Account getAccount() {
      return this.account;
   }

   public double getBalance() {
      return this.balance;
   }

   public double getAmount() {
      return this.amount;
   }

   public String getReason() {
      return this.reason;
   }
}
