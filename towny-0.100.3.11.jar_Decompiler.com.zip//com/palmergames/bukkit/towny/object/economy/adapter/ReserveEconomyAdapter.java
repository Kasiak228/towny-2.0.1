package com.palmergames.bukkit.towny.object.economy.adapter;

import java.math.BigDecimal;
import net.tnemc.core.economy.EconomyAPI;
import org.bukkit.World;

public class ReserveEconomyAdapter implements EconomyAdapter {
   final EconomyAPI economy;

   public ReserveEconomyAdapter(EconomyAPI economy) {
      this.economy = economy;
   }

   public boolean add(String accountName, double amount, World world) {
      BigDecimal bd = BigDecimal.valueOf(amount);
      return this.economy.addHoldingsDetail(accountName, bd, world.getName()).success();
   }

   public boolean subtract(String accountName, double amount, World world) {
      BigDecimal bd = BigDecimal.valueOf(amount);
      return this.economy.removeHoldingsDetail(accountName, bd, world.getName()).success();
   }

   public boolean hasAccount(String accountName) {
      return this.economy.hasAccountDetail(accountName).success();
   }

   public double getBalance(String accountName, World world) {
      return this.economy.getHoldings(accountName, world.getName()).doubleValue();
   }

   public void newAccount(String accountName) {
      this.economy.createAccountDetail(accountName).success();
   }

   public void deleteAccount(String accountName) {
      this.economy.deleteAccountDetail(accountName);
   }

   public boolean setBalance(String accountName, double amount, World world) {
      BigDecimal bd = BigDecimal.valueOf(amount);
      return this.economy.setHoldingsDetail(accountName, bd, world.getName()).success();
   }

   public String getFormattedBalance(double balance) {
      BigDecimal bd = BigDecimal.valueOf(balance);
      return this.economy.format(bd);
   }
}
