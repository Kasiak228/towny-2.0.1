package com.palmergames.bukkit.towny.object.economy.adapter;

import org.bukkit.World;

public interface EconomyAdapter {
   boolean add(String var1, double var2, World var4);

   boolean subtract(String var1, double var2, World var4);

   boolean hasAccount(String var1);

   double getBalance(String var1, World var2);

   void newAccount(String var1);

   void deleteAccount(String var1);

   boolean setBalance(String var1, double var2, World var4);

   String getFormattedBalance(double var1);
}
