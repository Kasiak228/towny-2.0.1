package com.palmergames.bukkit.towny.object.economy.adapter;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.World;

public class VaultEconomyAdapter implements EconomyAdapter {
   private final Economy economy;

   public VaultEconomyAdapter(Economy economy) {
      this.economy = economy;
   }

   public boolean add(String accountName, double amount, World world) {
      return this.economy.depositPlayer(accountName, amount).type == ResponseType.SUCCESS;
   }

   public boolean subtract(String accountName, double amount, World world) {
      return this.economy.withdrawPlayer(accountName, amount).type == ResponseType.SUCCESS;
   }

   public boolean hasAccount(String accountName) {
      return this.economy.hasAccount(accountName);
   }

   public double getBalance(String accountName, World world) {
      return this.economy.getBalance(accountName);
   }

   public void newAccount(String accountName) {
      this.economy.createPlayerAccount(accountName);
   }

   public void deleteAccount(String accountName) {
      if (this.economy.hasAccount(accountName)) {
         this.economy.withdrawPlayer(accountName, this.economy.getBalance(accountName));
      }
   }

   public boolean setBalance(String accountName, double amount, World world) {
      double currentBalance = this.getBalance(accountName, world);
      double diff = Math.abs(amount - currentBalance);
      if (amount > currentBalance) {
         return this.add(accountName, diff, world);
      } else {
         return amount < currentBalance ? this.subtract(accountName, diff, world) : true;
      }
   }

   public String getFormattedBalance(double balance) {
      return this.economy.format(balance);
   }
}
