package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.TownySettings;
import java.util.Arrays;
import java.util.Locale;
import java.util.Objects;

public class TownyPermission {
   protected boolean[][] perms;
   public boolean pvp;
   public boolean fire;
   public boolean explosion;
   public boolean mobs;

   public TownyPermission() {
      this.perms = new boolean[TownyPermission.PermLevel.values.length][TownyPermission.ActionType.values.length];
      this.reset();
   }

   public void reset() {
      this.setAll(false);
   }

   public void change(TownyPermissionChange permChange) {
      this.change(permChange.getChangeAction(), permChange.getChangeValue(), permChange.getArgs());
   }

   public void change(TownyPermissionChange.Action permChange, boolean toValue, Object... args) {
      if (permChange == TownyPermissionChange.Action.SINGLE_PERM && args.length == 2) {
         this.perms[((TownyPermission.PermLevel)args[0]).getIndex()][((TownyPermission.ActionType)args[1]).getIndex()] = toValue;
      } else if (permChange == TownyPermissionChange.Action.PERM_LEVEL && args.length == 1) {
         Arrays.fill(this.perms[((TownyPermission.PermLevel)args[0]).getIndex()], toValue);
      } else if (permChange == TownyPermissionChange.Action.ACTION_TYPE && args.length == 1) {
         TownyPermission.PermLevel[] var8 = TownyPermission.PermLevel.values;
         int var5 = var8.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            TownyPermission.PermLevel permLevel = var8[var6];
            this.perms[permLevel.getIndex()][((TownyPermission.ActionType)args[0]).getIndex()] = toValue;
         }
      } else if (permChange == TownyPermissionChange.Action.ALL_PERMS) {
         this.setAllNonEnvironmental(toValue);
      } else if (permChange == TownyPermissionChange.Action.RESET && args.length == 1) {
         TownBlock tb = (TownBlock)args[0];
         tb.setType(tb.getType());
      }

   }

   public void setAllNonEnvironmental(boolean b) {
      boolean[][] var2 = this.perms;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         boolean[] permLevel = var2[var4];
         Arrays.fill(permLevel, b);
      }

   }

   public boolean equalsNonEnvironmental(TownyPermission other) {
      return Arrays.deepEquals(this.perms, other.perms);
   }

   public void setAll(boolean b) {
      this.setAllNonEnvironmental(b);
      this.pvp = b;
      this.fire = b;
      this.explosion = b;
      this.mobs = b;
   }

   public void set(String s, boolean b) {
      String var3 = s.toLowerCase(Locale.ROOT);
      byte var4 = -1;
      switch(var3.hashCode()) {
      case -2033203068:
         if (var3.equals("residentswitch")) {
            var4 = 3;
         }
         break;
      case -1642886244:
         if (var3.equals("allyitemuse")) {
            var4 = 16;
         }
         break;
      case -1149282260:
         if (var3.equals("allyswitch")) {
            var4 = 15;
         }
         break;
      case -1051178210:
         if (var3.equals("residentbuild")) {
            var4 = 1;
         }
         break;
      case -1032113951:
         if (var3.equals("outsiderswitch")) {
            var4 = 7;
         }
         break;
      case -891210437:
         if (var3.equals("nationswitch")) {
            var4 = 11;
         }
         break;
      case 111402:
         if (var3.equals("pvp")) {
            var4 = 17;
         }
         break;
      case 3143222:
         if (var3.equals("fire")) {
            var4 = 18;
         }
         break;
      case 3357043:
         if (var3.equals("mobs")) {
            var4 = 20;
         }
         break;
      case 94038919:
         if (var3.equals("nationbuild")) {
            var4 = 9;
         }
         break;
      case 333722389:
         if (var3.equals("explosion")) {
            var4 = 19;
         }
         break;
      case 461486250:
         if (var3.equals("residentdestroy")) {
            var4 = 2;
         }
         break;
      case 639903350:
         if (var3.equals("allybuild")) {
            var4 = 13;
         }
         break;
      case 782230305:
         if (var3.equals("outsiderbuild")) {
            var4 = 5;
         }
         break;
      case 1020339780:
         if (var3.equals("residentitemuse")) {
            var4 = 4;
         }
         break;
      case 1430477805:
         if (var3.equals("outsiderdestroy")) {
            var4 = 6;
         }
         break;
      case 1503519443:
         if (var3.equals("nationdestroy")) {
            var4 = 10;
         }
         break;
      case 1552887829:
         if (var3.equals("denyall")) {
            var4 = 0;
         }
         break;
      case 1989331335:
         if (var3.equals("outsideritemuse")) {
            var4 = 8;
         }
         break;
      case 2062372973:
         if (var3.equals("nationitemuse")) {
            var4 = 12;
         }
         break;
      case 2093227522:
         if (var3.equals("allydestroy")) {
            var4 = 14;
         }
      }

      switch(var4) {
      case 0:
         this.reset();
         break;
      case 1:
         this.perms[TownyPermission.PermLevel.RESIDENT.getIndex()][TownyPermission.ActionType.BUILD.getIndex()] = b;
         break;
      case 2:
         this.perms[TownyPermission.PermLevel.RESIDENT.getIndex()][TownyPermission.ActionType.DESTROY.getIndex()] = b;
         break;
      case 3:
         this.perms[TownyPermission.PermLevel.RESIDENT.getIndex()][TownyPermission.ActionType.SWITCH.getIndex()] = b;
         break;
      case 4:
         this.perms[TownyPermission.PermLevel.RESIDENT.getIndex()][TownyPermission.ActionType.ITEM_USE.getIndex()] = b;
         break;
      case 5:
         this.perms[TownyPermission.PermLevel.OUTSIDER.getIndex()][TownyPermission.ActionType.BUILD.getIndex()] = b;
         break;
      case 6:
         this.perms[TownyPermission.PermLevel.OUTSIDER.getIndex()][TownyPermission.ActionType.DESTROY.getIndex()] = b;
         break;
      case 7:
         this.perms[TownyPermission.PermLevel.OUTSIDER.getIndex()][TownyPermission.ActionType.SWITCH.getIndex()] = b;
         break;
      case 8:
         this.perms[TownyPermission.PermLevel.OUTSIDER.getIndex()][TownyPermission.ActionType.ITEM_USE.getIndex()] = b;
         break;
      case 9:
         this.perms[TownyPermission.PermLevel.NATION.getIndex()][TownyPermission.ActionType.BUILD.getIndex()] = b;
         break;
      case 10:
         this.perms[TownyPermission.PermLevel.NATION.getIndex()][TownyPermission.ActionType.DESTROY.getIndex()] = b;
         break;
      case 11:
         this.perms[TownyPermission.PermLevel.NATION.getIndex()][TownyPermission.ActionType.SWITCH.getIndex()] = b;
         break;
      case 12:
         this.perms[TownyPermission.PermLevel.NATION.getIndex()][TownyPermission.ActionType.ITEM_USE.getIndex()] = b;
         break;
      case 13:
         this.perms[TownyPermission.PermLevel.ALLY.getIndex()][TownyPermission.ActionType.BUILD.getIndex()] = b;
         break;
      case 14:
         this.perms[TownyPermission.PermLevel.ALLY.getIndex()][TownyPermission.ActionType.DESTROY.getIndex()] = b;
         break;
      case 15:
         this.perms[TownyPermission.PermLevel.ALLY.getIndex()][TownyPermission.ActionType.SWITCH.getIndex()] = b;
         break;
      case 16:
         this.perms[TownyPermission.PermLevel.ALLY.getIndex()][TownyPermission.ActionType.ITEM_USE.getIndex()] = b;
         break;
      case 17:
         this.pvp = b;
         break;
      case 18:
         this.fire = b;
         break;
      case 19:
         this.explosion = b;
         break;
      case 20:
         this.mobs = b;
      }

   }

   public void load(String s) {
      this.setAll(false);
      String[] tokens = s.split(",");
      String[] var3 = tokens;
      int var4 = tokens.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String token = var3[var5];
         this.set(token, true);
      }

   }

   public String toString() {
      StringBuilder output = new StringBuilder();
      TownyPermission.PermLevel[] var2 = TownyPermission.PermLevel.values;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         TownyPermission.PermLevel permLevel = var2[var4];
         String permLevelName = permLevel.name().toLowerCase(Locale.ROOT);
         TownyPermission.ActionType[] var7 = TownyPermission.ActionType.values;
         int var8 = var7.length;

         for(int var9 = 0; var9 < var8; ++var9) {
            TownyPermission.ActionType actionType = var7[var9];
            if (this.perms[permLevel.getIndex()][actionType.getIndex()]) {
               if (output.length() != 0) {
                  output.append(',');
               }

               output.append(permLevelName).append(actionType.getCommonName());
            }
         }
      }

      if (this.pvp) {
         output.append(output.length() > 0 ? "," : "").append("pvp");
      }

      if (this.fire) {
         output.append(output.length() > 0 ? "," : "").append("fire");
      }

      if (this.explosion) {
         output.append(output.length() > 0 ? "," : "").append("explosion");
      }

      if (this.mobs) {
         output.append(output.length() > 0 ? "," : "").append("mobs");
      }

      if (output.length() == 0) {
         return "denyAll";
      } else {
         return output.toString();
      }
   }

   public boolean getPerm(TownyPermission.PermLevel permLevel, TownyPermission.ActionType type) {
      return this.perms[permLevel.getIndex()][type.getIndex()];
   }

   public boolean getResidentPerm(TownyPermission.ActionType type) {
      return this.getPerm(TownyPermission.PermLevel.RESIDENT, type);
   }

   public boolean getOutsiderPerm(TownyPermission.ActionType type) {
      return this.getPerm(TownyPermission.PermLevel.OUTSIDER, type);
   }

   public boolean getAllyPerm(TownyPermission.ActionType type) {
      return this.getPerm(TownyPermission.PermLevel.ALLY, type);
   }

   public boolean getNationPerm(TownyPermission.ActionType type) {
      return this.getPerm(TownyPermission.PermLevel.NATION, type);
   }

   public String getColoredPermLevel(TownyPermission.ActionType type) {
      return this.getColoredPermLevel(type, type.getCommonName());
   }

   public String getColoredPermLevel(TownyPermission.ActionType type, String typeCommonName) {
      StringBuilder output = new StringBuilder(Translation.of("status_perm_line_format", typeCommonName));
      TownyPermission.PermLevel[] var4 = TownyPermission.PermLevel.values;
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         TownyPermission.PermLevel permLevel = var4[var6];
         if (this.perms[permLevel.getIndex()][type.getIndex()]) {
            output.append(permLevel.getShortChar());
         } else {
            output.append('-');
         }
      }

      return output.toString();
   }

   public String getColourString() {
      String var10000 = this.getColoredPermLevel(TownyPermission.ActionType.BUILD);
      return var10000 + " " + this.getColoredPermLevel(TownyPermission.ActionType.DESTROY) + " " + this.getColoredPermLevel(TownyPermission.ActionType.SWITCH) + " " + this.getColoredPermLevel(TownyPermission.ActionType.ITEM_USE);
   }

   public void loadDefault(TownBlockOwner owner) {
      TownyPermission.PermLevel[] var2 = TownyPermission.PermLevel.values;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         TownyPermission.PermLevel permLevel = var2[var4];
         TownyPermission.ActionType[] var6 = TownyPermission.ActionType.values;
         int var7 = var6.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            TownyPermission.ActionType actionType = var6[var8];
            this.perms[permLevel.getIndex()][actionType.getIndex()] = TownySettings.getDefaultPermission(owner, permLevel, actionType);
         }
      }

      if (owner instanceof Town) {
         this.pvp = TownySettings.getPermFlag_Town_Default_PVP();
         this.fire = TownySettings.getPermFlag_Town_Default_FIRE();
         this.explosion = TownySettings.getPermFlag_Town_Default_Explosion();
         this.mobs = TownySettings.getPermFlag_Town_Default_Mobs();
      } else {
         this.pvp = owner.getPermissions().pvp;
         this.fire = owner.getPermissions().fire;
         this.explosion = owner.getPermissions().explosion;
         this.mobs = owner.getPermissions().mobs;
      }

   }

   public int hashCode() {
      int prime = true;
      int result = 1;
      int result = 31 * result + Arrays.deepHashCode(this.perms);
      result = 31 * result + Objects.hash(new Object[]{this.explosion, this.fire, this.mobs, this.pvp});
      return result;
   }

   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      } else if (obj == null) {
         return false;
      } else if (this.getClass() != obj.getClass()) {
         return false;
      } else {
         TownyPermission other = (TownyPermission)obj;
         return this.explosion == other.explosion && this.fire == other.fire && this.mobs == other.mobs && Arrays.deepEquals(this.perms, other.perms) && this.pvp == other.pvp;
      }
   }

   public static enum PermLevel {
      RESIDENT(0, 'f'),
      NATION(1, 'n'),
      ALLY(2, 'a'),
      OUTSIDER(3, 'o');

      private static final TownyPermission.PermLevel[] values = values();
      private final int index;
      private final char shortVal;

      private PermLevel(int index, char shortVal) {
         this.index = index;
         this.shortVal = shortVal;
      }

      public int getIndex() {
         return this.index;
      }

      public char getShortChar() {
         return this.shortVal;
      }

      public String toString() {
         return super.toString().toLowerCase(Locale.ROOT);
      }

      // $FF: synthetic method
      private static TownyPermission.PermLevel[] $values() {
         return new TownyPermission.PermLevel[]{RESIDENT, NATION, ALLY, OUTSIDER};
      }
   }

   public static enum ActionType {
      BUILD(0, "Build"),
      DESTROY(1, "Destroy"),
      SWITCH(2, "Switch"),
      ITEM_USE(3, "ItemUse");

      private static final TownyPermission.ActionType[] values = values();
      private final int index;
      private final String commonName;

      private ActionType(int index, String commonName) {
         this.index = index;
         this.commonName = commonName;
      }

      public int getIndex() {
         return this.index;
      }

      public String getCommonName() {
         return this.commonName;
      }

      public String toString() {
         return super.toString().toLowerCase(Locale.ROOT);
      }

      // $FF: synthetic method
      private static TownyPermission.ActionType[] $values() {
         return new TownyPermission.ActionType[]{BUILD, DESTROY, SWITCH, ITEM_USE};
      }
   }
}
