package com.palmergames.bukkit.towny.object;

import com.google.common.collect.Lists;
import com.palmergames.adventure.audience.Audience;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.BonusBlockPurchaseCostCalculationEvent;
import com.palmergames.bukkit.towny.event.DeleteNationEvent;
import com.palmergames.bukkit.towny.event.NationAddTownEvent;
import com.palmergames.bukkit.towny.event.NationRemoveTownEvent;
import com.palmergames.bukkit.towny.event.TownBlockClaimCostCalculationEvent;
import com.palmergames.bukkit.towny.event.TownyObjectFormattedNameEvent;
import com.palmergames.bukkit.towny.event.town.TownAddAlliedTownEvent;
import com.palmergames.bukkit.towny.event.town.TownAddEnemiedTownEvent;
import com.palmergames.bukkit.towny.event.town.TownCalculateTownLevelNumberEvent;
import com.palmergames.bukkit.towny.event.town.TownConqueredEvent;
import com.palmergames.bukkit.towny.event.town.TownIsTownOverClaimedEvent;
import com.palmergames.bukkit.towny.event.town.TownMapColourLocalCalculationEvent;
import com.palmergames.bukkit.towny.event.town.TownMapColourNationalCalculationEvent;
import com.palmergames.bukkit.towny.event.town.TownMayorChangedEvent;
import com.palmergames.bukkit.towny.event.town.TownMayorChosenBySuccessionEvent;
import com.palmergames.bukkit.towny.event.town.TownRemoveAlliedTownEvent;
import com.palmergames.bukkit.towny.event.town.TownRemoveEnemiedTownEvent;
import com.palmergames.bukkit.towny.event.town.TownUnconquerEvent;
import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.EmptyNationException;
import com.palmergames.bukkit.towny.exceptions.EmptyTownException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.metadata.CustomDataField;
import com.palmergames.bukkit.towny.permissions.TownyPerms;
import com.palmergames.bukkit.towny.utils.CombatUtil;
import com.palmergames.bukkit.towny.utils.MoneyUtil;
import com.palmergames.bukkit.towny.utils.ProximityUtil;
import com.palmergames.bukkit.towny.utils.TownUtil;
import com.palmergames.bukkit.towny.utils.TownyComponents;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;

public class Town extends Government implements TownBlockOwner {
   private static final String ECONOMY_ACCOUNT_PREFIX = TownySettings.getTownAccountPrefix();
   private final List<Resident> residents;
   private final List<Resident> outlaws;
   private Map<UUID, Town> allies;
   private Map<UUID, Town> enemies;
   private final Set<Resident> trustedResidents;
   private final Map<UUID, Town> trustedTowns;
   private final List<Position> outpostSpawns;
   private List<Jail> jails;
   private HashMap<String, PlotGroup> plotGroups;
   private TownBlockTypeCache plotTypeCache;
   private HashMap<String, District> districts;
   private Resident mayor;
   private String founderName;
   private int bonusBlocks;
   private int purchasedBlocks;
   private double plotTax;
   private double commercialPlotTax;
   private double plotPrice;
   private double embassyPlotTax;
   private double maxPercentTaxAmount;
   private double commercialPlotPrice;
   private double embassyPlotPrice;
   private double debtBalance;
   private Nation nation;
   private boolean hasUpkeep;
   private boolean hasUnlimitedClaims;
   private boolean isForSale;
   private double forSalePrice;
   private boolean isTaxPercentage;
   private TownBlock homeBlock;
   private TownyWorld world;
   private boolean adminEnabledMobs;
   private boolean adminDisabledPVP;
   private boolean adminEnabledPVP;
   private boolean allowedToWar;
   private boolean isConquered;
   private int conqueredDays;
   private int nationZoneOverride;
   private boolean nationZoneEnabled;
   private final ConcurrentHashMap<WorldCoord, TownBlock> townBlocks;
   private final TownyPermission permissions;
   private boolean ruined;
   private long ruinedTime;
   private long joinedNationAt;
   private long movedHomeBlockAt;
   private Jail primaryJail;
   private int manualTownLevel;
   private boolean visibleOnTopLists;
   private boolean residentsSorted;

   public Town(String name) {
      super(name);
      this.residents = new ArrayList();
      this.outlaws = new ArrayList();
      this.allies = new LinkedHashMap();
      this.enemies = new LinkedHashMap();
      this.trustedResidents = new HashSet();
      this.trustedTowns = new LinkedHashMap();
      this.outpostSpawns = new ArrayList();
      this.jails = null;
      this.plotGroups = null;
      this.plotTypeCache = new TownBlockTypeCache();
      this.districts = null;
      this.bonusBlocks = 0;
      this.purchasedBlocks = 0;
      this.plotTax = TownySettings.getTownDefaultPlotTax();
      this.commercialPlotTax = TownySettings.getTownDefaultShopTax();
      this.plotPrice = 0.0D;
      this.embassyPlotTax = TownySettings.getTownDefaultEmbassyTax();
      this.maxPercentTaxAmount = TownySettings.getMaxTownTaxPercentAmount();
      this.debtBalance = 0.0D;
      this.hasUpkeep = true;
      this.hasUnlimitedClaims = false;
      this.isForSale = false;
      this.forSalePrice = 0.0D;
      this.isTaxPercentage = TownySettings.getTownDefaultTaxPercentage();
      this.adminEnabledMobs = false;
      this.adminDisabledPVP = false;
      this.adminEnabledPVP = false;
      this.allowedToWar = TownySettings.getTownDefaultAllowedToWar();
      this.isConquered = false;
      this.nationZoneOverride = 0;
      this.nationZoneEnabled = true;
      this.townBlocks = new ConcurrentHashMap();
      this.permissions = new TownyPermission();
      this.ruined = false;
      this.manualTownLevel = -1;
      this.visibleOnTopLists = true;
      this.residentsSorted = false;
      this.permissions.loadDefault(this);
      this.setTaxes(TownySettings.getTownDefaultTax());
      this.setOpen(TownySettings.getTownDefaultOpen());
      this.setBoard(TownySettings.getTownDefaultBoard());
      this.setNeutral(TownySettings.getTownDefaultNeutral());
      this.setPublic(TownySettings.getTownDefaultPublic());
   }

   public Town(String name, UUID uuid) {
      this(name);
      this.setUUID(uuid);
   }

   public boolean equals(Object other) {
      if (other == this) {
         return true;
      } else if (other instanceof Town) {
         Town otherTown = (Town)other;
         return this.getName().equals(otherTown.getName());
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.getUUID(), this.getName()});
   }

   public Collection<TownBlock> getTownBlocks() {
      return Collections.unmodifiableCollection(this.townBlocks.values());
   }

   public int getNumTownBlocks() {
      return this.getTownBlocks().size();
   }

   public boolean hasTownBlock(TownBlock townBlock) {
      return this.hasTownBlock(townBlock.getWorldCoord());
   }

   public boolean hasTownBlock(WorldCoord worldCoord) {
      return this.townBlocks.containsKey(worldCoord);
   }

   public void addTownBlock(TownBlock townBlock) throws AlreadyRegisteredException {
      if (this.hasTownBlock(townBlock)) {
         throw new AlreadyRegisteredException();
      } else {
         this.townBlocks.put(townBlock.getWorldCoord(), townBlock);
         if (this.townBlocks.size() < 2 && !this.hasHomeBlock()) {
            this.setHomeBlock(townBlock);
         }

         this.getTownBlockTypeCache().addTownBlockOfType(townBlock.getType());
      }
   }

   public TownBlock getTownBlock(WorldCoord worldCoord) {
      return this.hasTownBlock(worldCoord) ? (TownBlock)this.townBlocks.get(worldCoord) : null;
   }

   public ConcurrentMap<WorldCoord, TownBlock> getTownBlockMap() {
      return this.townBlocks;
   }

   public TownBlockTypeCache getTownBlockTypeCache() {
      return this.plotTypeCache;
   }

   public Resident getMayor() {
      return this.mayor;
   }

   public void setTaxes(double taxes) {
      this.taxes = Math.min(taxes, this.isTaxPercentage ? TownySettings.getMaxTownTaxPercent() : TownySettings.getMaxTownTax());
      if (this.taxes < 0.0D && !TownySettings.isNegativeTownTaxAllowed()) {
         this.taxes = TownySettings.getTownDefaultTax();
      }

   }

   public void forceSetMayor(Resident mayor) throws TownyException {
      if (!this.hasResident(mayor)) {
         throw new TownyException(Translation.of("msg_err_mayor_doesnt_belong_to_town"));
      } else {
         this.setMayor(mayor, false);
      }
   }

   public void setMayor(Resident mayor) {
      this.setMayor(mayor, true);
   }

   public void setMayor(Resident mayor, boolean callEvent) {
      if (this.hasResident(mayor)) {
         if (callEvent) {
            BukkitTools.fireEvent(new TownMayorChangedEvent(this.mayor, mayor));
         }

         this.mayor = mayor;
         TownyPerms.assignPermissions(mayor, (Player)null);
      }
   }

   public String getFounder() {
      return this.founderName != null ? this.founderName : (this.getMayor() != null ? this.getMayor().getName() : "None");
   }

   public void setFounder(String founderName) {
      this.founderName = founderName;
   }

   public Nation getNation() throws NotRegisteredException {
      if (this.hasNation()) {
         return this.nation;
      } else {
         throw new NotRegisteredException(Translation.of("msg_err_town_doesnt_belong_to_any_nation"));
      }
   }

   @Nullable
   public Nation getNationOrNull() {
      return this.nation;
   }

   public void removeNation() {
      if (this.hasNation()) {
         Nation oldNation = this.nation;
         Iterator var2 = this.getResidents().iterator();

         while(var2.hasNext()) {
            Resident res = (Resident)var2.next();
            if (res.hasTitle() || res.hasSurname()) {
               res.setTitle("");
               res.setSurname("");
            }

            res.updatePermsForNationRemoval();
            res.save();
         }

         try {
            oldNation.removeTown(this);
         } catch (EmptyNationException var5) {
            if (TownyUniverse.getInstance().getDataSource().removeNation(oldNation, DeleteNationEvent.Cause.NO_TOWNS)) {
               TownyMessaging.sendGlobalMessage(Translatable.of("msg_del_nation", var5.getNation().getName()));
            }
         }

         try {
            this.setNation((Nation)null);
         } catch (AlreadyRegisteredException var4) {
         }

         this.isConquered = false;
         this.conqueredDays = 0;
         this.setJoinedNationAt(0L);
         this.save();
         BukkitTools.fireEvent(new NationRemoveTownEvent(this, oldNation));
         ProximityUtil.removeOutOfRangeTowns(oldNation);
      }
   }

   public void setNation(Nation nation) throws AlreadyRegisteredException {
      this.setNation(nation, true);
   }

   public void setNation(Nation nation, boolean updateJoinedAt) throws AlreadyRegisteredException {
      if (this.nation != nation) {
         if (nation == null) {
            this.nation = null;
         } else if (this.hasNation()) {
            throw new AlreadyRegisteredException();
         } else {
            this.nation = nation;
            nation.addTown(this);
            if (updateJoinedAt) {
               this.setJoinedNationAt(System.currentTimeMillis());
            }

            TownyPerms.updateTownPerms(this);
            BukkitTools.fireEvent(new NationAddTownEvent(this, nation));
         }
      }
   }

   public List<Resident> getResidents() {
      if (!this.residentsSorted) {
         this.sortResidents();
      }

      return Collections.unmodifiableList(this.residents);
   }

   public List<Resident> getRank(String rank) {
      List<Resident> residentsWithRank = new ArrayList();
      Iterator var3 = this.getResidents().iterator();

      while(var3.hasNext()) {
         Resident resident = (Resident)var3.next();
         if (resident.hasTownRank(rank)) {
            residentsWithRank.add(resident);
         }
      }

      return Collections.unmodifiableList(residentsWithRank);
   }

   public boolean hasResident(String name) {
      Iterator var2 = this.residents.iterator();

      Resident resident;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         resident = (Resident)var2.next();
      } while(!resident.getName().equalsIgnoreCase(name));

      return true;
   }

   public boolean hasResident(Resident resident) {
      return this.residents.contains(resident);
   }

   public boolean hasResident(Player player) {
      return this.hasResident(player.getUniqueId());
   }

   public boolean hasResident(UUID uuid) {
      Resident resident = TownyAPI.getInstance().getResident(uuid);
      return resident != null && this.hasResident(resident);
   }

   public boolean hasResidentWithRank(Resident resident, String rank) {
      return this.hasResident(resident) && resident.hasTownRank(rank);
   }

   void addResident(Resident resident) {
      this.residents.add(resident);
   }

   public void addResidentCheck(Resident resident) throws AlreadyRegisteredException {
      if (this.hasResident(resident)) {
         throw new AlreadyRegisteredException(Translation.of("msg_err_already_in_town", resident.getName(), this.getFormattedName()));
      } else {
         Town residentTown = resident.getTownOrNull();
         if (residentTown != null && !this.equals(residentTown)) {
            throw new AlreadyRegisteredException(Translation.of("msg_err_already_in_town", resident.getName(), residentTown.getFormattedName()));
         }
      }
   }

   public boolean isMayor(Resident resident) {
      return resident == this.mayor;
   }

   public boolean hasNation() {
      return this.nation != null;
   }

   public int getNumResidents() {
      return this.residents.size();
   }

   public boolean isCapital() {
      return this.hasNation() && this.nation.isCapital(this);
   }

   public void setHasUpkeep(boolean hasUpkeep) {
      this.hasUpkeep = hasUpkeep;
   }

   public boolean hasUpkeep() {
      return this.hasUpkeep;
   }

   public boolean hasUnlimitedClaims() {
      return TownySettings.areTownBlocksUnlimited() || this.hasUnlimitedClaims;
   }

   public void setHasUnlimitedClaims(boolean hasUnlimitedClaims) {
      this.hasUnlimitedClaims = hasUnlimitedClaims;
   }

   public void setHasMobs(boolean hasMobs) {
      this.permissions.mobs = hasMobs;
   }

   public boolean hasMobs() {
      return this.permissions.mobs;
   }

   public void setAdminEnabledMobs(boolean isMobsForced) {
      this.adminEnabledMobs = isMobsForced;
   }

   public boolean isAdminEnabledMobs() {
      return this.adminEnabledMobs;
   }

   public void setPVP(boolean isPVP) {
      this.permissions.pvp = isPVP;
   }

   public void setAdminDisabledPVP(boolean isPVPDisabled) {
      this.adminDisabledPVP = isPVPDisabled;
   }

   public void setAdminEnabledPVP(boolean isPVPEnabled) {
      this.adminEnabledPVP = isPVPEnabled;
   }

   public boolean isPVP() {
      if (this.isAdminEnabledPVP()) {
         return true;
      } else {
         return this.isAdminDisabledPVP() ? false : this.permissions.pvp;
      }
   }

   public boolean isAdminDisabledPVP() {
      return this.adminDisabledPVP;
   }

   public boolean isAdminEnabledPVP() {
      return this.adminEnabledPVP;
   }

   public boolean isAllowedToWar() {
      return this.allowedToWar;
   }

   public void setAllowedToWar(boolean allowedToWar) {
      this.allowedToWar = allowedToWar;
   }

   public void setExplosion(boolean isExplosion) {
      this.permissions.explosion = isExplosion;
   }

   public boolean isExplosion() {
      return this.permissions.explosion;
   }

   public void setTaxPercentage(boolean isPercentage) {
      this.isTaxPercentage = isPercentage;
      if (isPercentage && this.getTaxes() > 100.0D) {
         this.setTaxes(0.0D);
      }

   }

   public boolean isTaxPercentage() {
      return this.isTaxPercentage;
   }

   public void setFire(boolean isFire) {
      this.permissions.fire = isFire;
   }

   public boolean isFire() {
      return this.permissions.fire;
   }

   public void setBonusBlocks(int bonusBlocks) {
      this.bonusBlocks = bonusBlocks;
   }

   public String getMaxTownBlocksAsAString() {
      return this.hasUnlimitedClaims() ? "∞" : String.valueOf(this.getMaxTownBlocks());
   }

   public int getMaxTownBlocks() {
      return TownySettings.getMaxTownBlocks(this);
   }

   public int getBonusBlocks() {
      return this.bonusBlocks;
   }

   public double getBonusBlockCost() {
      double price = Math.pow(TownySettings.getPurchasedBonusBlocksIncreaseValue(), (double)this.getPurchasedBlocks()) * TownySettings.getPurchasedBonusBlocksCost();
      double maxprice = TownySettings.getPurchasedBonusBlocksMaxPrice();
      BonusBlockPurchaseCostCalculationEvent event = new BonusBlockPurchaseCostCalculationEvent(this, maxprice == -1.0D ? price : Math.min(price, maxprice), 1);
      BukkitTools.fireEvent(event);
      return event.getPrice();
   }

   public double getTownBlockCost() {
      double price = (double)Math.round(Math.pow(TownySettings.getClaimPriceIncreaseValue(), (double)this.getTownBlocks().size()) * TownySettings.getClaimPrice());
      double maxprice = TownySettings.getMaxClaimPrice();
      TownBlockClaimCostCalculationEvent event = new TownBlockClaimCostCalculationEvent(this, maxprice == -1.0D ? price : Math.min(price, maxprice), 1);
      BukkitTools.fireEvent(event);
      return event.getPrice();
   }

   public double getTownBlockCostN(int inputN) throws TownyException {
      if (inputN < 0) {
         throw new TownyException(Translation.of("msg_err_negative"));
      } else if (inputN == 0) {
         return (double)inputN;
      } else {
         double nextprice = this.getTownBlockCost();
         int i = 1;
         double cost = nextprice;
         boolean hasmaxprice = TownySettings.getMaxClaimPrice() != -1.0D;

         for(double maxprice = TownySettings.getMaxClaimPrice(); i < inputN; ++i) {
            nextprice = (double)Math.round(Math.pow(TownySettings.getClaimPriceIncreaseValue(), (double)this.getTownBlocks().size() + (double)i) * TownySettings.getClaimPrice());
            if (hasmaxprice && nextprice > maxprice) {
               cost += maxprice * (double)(inputN - i);
               break;
            }

            cost += nextprice;
         }

         TownBlockClaimCostCalculationEvent event = new TownBlockClaimCostCalculationEvent(this, (double)Math.round(cost), inputN);
         BukkitTools.fireEvent(event);
         return event.getPrice();
      }
   }

   public double getBonusBlockCostN(int n) throws TownyException {
      if (n < 0) {
         throw new TownyException(Translation.of("msg_err_negative"));
      } else {
         double cost = MoneyUtil.returnPurchasedBlocksCost(this.getPurchasedBlocks(), n, this);
         BonusBlockPurchaseCostCalculationEvent event = new BonusBlockPurchaseCostCalculationEvent(this, cost, n);
         BukkitTools.fireEvent(event);
         return event.getPrice();
      }
   }

   public void addBonusBlocks(int bonusBlocks) {
      this.bonusBlocks += bonusBlocks;
   }

   public void setPurchasedBlocks(int purchasedBlocks) {
      this.purchasedBlocks = purchasedBlocks;
   }

   public int getPurchasedBlocks() {
      return this.purchasedBlocks;
   }

   public void addPurchasedBlocks(int purchasedBlocks) {
      this.purchasedBlocks += purchasedBlocks;
   }

   public void playerSetsHomeBlock(TownBlock townBlock, Location location, Player player) {
      this.setHomeBlock(townBlock);
      this.setSpawn(location);
      this.setMovedHomeBlockAt(System.currentTimeMillis());
      TownyMessaging.sendMsg((CommandSender)player, (Translatable)Translatable.of("msg_set_town_home", townBlock.getCoord().toString()));
   }

   public void setHomeBlock(@Nullable TownBlock homeBlock) {
      this.homeBlock = homeBlock;
      if (homeBlock != null) {
         if (this.world == null || !this.getHomeblockWorld().getName().equals(homeBlock.getWorld().getName())) {
            this.setWorld(homeBlock.getWorld());
         }

         if (this.spawn != null && !homeBlock.getWorldCoord().equals(this.spawn.worldCoord())) {
            TownyUniverse.getInstance().removeSpawnPoint(SpawnPointLocation.parsePos(this.spawn));
            this.spawn = null;
         }

         if (this.hasNation() && !(TownySettings.getNationProximityToCapital() <= 0.0D) && !this.isCapital()) {
            Nation townNation = this.getNationOrNull();
            if (townNation != null && townNation.getCapital().hasHomeBlock() && ProximityUtil.isTownTooFarFromNation(this, townNation.getCapital(), townNation.getTowns())) {
               TownyMessaging.sendNationMessagePrefixed(townNation, Translatable.of("msg_nation_town_moved_their_homeblock_too_far", this.getName()));
               this.removeNation();
            }
         }
      }
   }

   public void forceSetHomeBlock(TownBlock homeBlock) throws TownyException {
      if (homeBlock == null) {
         this.homeBlock = null;
         TownyMessaging.sendErrorMsg("town.forceSetHomeblock() is returning null.");
      } else {
         this.homeBlock = homeBlock;
         if (this.world != homeBlock.getWorld()) {
            this.setWorld(homeBlock.getWorld());
         }

      }
   }

   public TownBlock getHomeBlock() throws TownyException {
      if (this.hasHomeBlock()) {
         return this.homeBlock;
      } else {
         throw new TownyException(this.getName() + " has not set a home block.");
      }
   }

   @Nullable
   public TownBlock getHomeBlockOrNull() {
      return this.homeBlock;
   }

   public void setWorld(TownyWorld world) {
      if (world == null) {
         this.world = null;
      } else if (this.world != world) {
         if (this.hasWorld()) {
            try {
               world.removeTown(this);
            } catch (NotRegisteredException var3) {
            }
         }

         this.world = world;
         this.world.addTown(this);
      }
   }

   public TownyWorld getHomeblockWorld() {
      if (this.world != null) {
         return this.world;
      } else {
         return this.homeBlock != null ? this.homeBlock.getWorld() : (TownyWorld)TownyUniverse.getInstance().getTownyWorlds().get(0);
      }
   }

   public boolean hasMayor() {
      return this.mayor != null;
   }

   public void removeResident(Resident resident) throws EmptyTownException {
      if (this.hasResident(resident)) {
         this.remove(resident);
         resident.setJoinedTownAt(0L);
         if (this.getNumResidents() == 0) {
            throw new EmptyTownException(this);
         }
      }
   }

   private void remove(Resident resident) {
      if (this.isMayor(resident) && this.residents.size() > 1) {
         this.findNewMayor();
         this.save();
      }

      this.residents.remove(resident);
   }

   public void findNewMayor() {
      Iterator var1 = TownySettings.getOrderOfMayoralSuccession().iterator();

      String rank;
      do {
         if (!var1.hasNext()) {
            this.findNewMayor(this.getResidents());
            return;
         }

         rank = (String)var1.next();
      } while(!this.findNewMayor(this.getRank(rank)));

   }

   private boolean findNewMayor(List<Resident> potentialResidents) {
      Iterator var2 = potentialResidents.iterator();

      Resident newMayor;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         newMayor = (Resident)var2.next();
      } while(newMayor.equals(this.mayor));

      TownMayorChosenBySuccessionEvent tmcbse = new TownMayorChosenBySuccessionEvent(this.mayor, newMayor, potentialResidents);
      this.setMayor(tmcbse.getNewMayor());
      return true;
   }

   public void setSpawn(@Nullable Location spawn) {
      this.spawnPosition(spawn == null ? null : Position.ofLocation(spawn));
   }

   @NotNull
   public Location getSpawn() throws TownyException {
      if (this.hasHomeBlock() && this.spawn != null) {
         return this.spawn.asLocation();
      } else {
         this.spawn = null;
         throw new TownyException(Translation.of("msg_err_town_has_not_set_a_spawn_location"));
      }
   }

   @Nullable
   public Location getSpawnOrNull() {
      return this.spawn != null ? this.spawn.asLocation() : null;
   }

   @Nullable
   public Position spawnPosition() {
      return this.spawn;
   }

   public void spawnPosition(@Nullable Position spawn) {
      if (this.spawn != null) {
         TownyUniverse.getInstance().removeSpawnPoint(SpawnPointLocation.parsePos(this.spawn));
      }

      this.spawn = spawn;
      if (spawn != null) {
         TownyUniverse.getInstance().addSpawnPoint(new SpawnPoint(spawn, SpawnPoint.SpawnPointType.TOWN_SPAWN));
      }

   }

   public boolean hasHomeBlock() {
      return this.homeBlock != null;
   }

   public boolean hasWorld() {
      return this.world != null;
   }

   public void removeTownBlock(TownBlock townBlock) {
      if (this.hasTownBlock(townBlock)) {
         if (townBlock.isOutpost() || this.isAnOutpost(townBlock.getCoord())) {
            this.removeOutpostSpawn(townBlock.getCoord());
            townBlock.setOutpost(false);
            townBlock.save();
         }

         if (townBlock.isJail()) {
            this.removeJail(townBlock.getJail());
         }

         try {
            if (this.getHomeBlock() == townBlock) {
               this.setHomeBlock((TownBlock)null);
            }
         } catch (TownyException var5) {
         }

         Nation testNation = this.getNationOrNull();

         try {
            if (this.hasNation() && testNation != null && testNation.hasSpawn() && townBlock.getWorldCoord().equals(WorldCoord.parseWorldCoord(testNation.getSpawn()))) {
               testNation.setSpawn((Location)null);
            }
         } catch (TownyException var4) {
         }

         this.townBlocks.remove(townBlock.getWorldCoord());
         this.getTownBlockTypeCache().removeTownBlockOfType(townBlock.getType());
         if (townBlock.isForSale()) {
            this.getTownBlockTypeCache().removeTownBlockOfTypeForSale(townBlock.getType());
         }

         if (townBlock.hasResident()) {
            this.getTownBlockTypeCache().removeTownBlockOfTypeResidentOwned(townBlock.getType());
         }

         this.save();
      }

   }

   public void setPermissions(String line) {
      this.permissions.load(line);
   }

   public TownyPermission getPermissions() {
      return this.permissions;
   }

   public void addOutpostSpawn(Location location) {
      this.addOutpostSpawn(Position.ofLocation(location));
   }

   public void addOutpostSpawn(Position position) {
      TownBlock townBlock = position.worldCoord().getTownBlockOrNull();
      if (townBlock != null && this.equals(townBlock.getTownOrNull())) {
         this.removeOutpostSpawn((Coord)position.worldCoord());
         if (!townBlock.isOutpost()) {
            townBlock.setOutpost(true);
            townBlock.save();
         }

         this.outpostSpawns.add(position);
         TownyUniverse.getInstance().addSpawnPoint(new SpawnPoint(this.spawn, SpawnPoint.SpawnPointType.OUTPOST_SPAWN));
         this.save();
      }
   }

   @Internal
   public void forceAddOutpostSpawn(Position position) {
      this.outpostSpawns.add(position);
      TownyUniverse.getInstance().addSpawnPoint(new SpawnPoint(position, SpawnPoint.SpawnPointType.OUTPOST_SPAWN));
   }

   public Location getOutpostSpawn(Integer index) throws TownyException {
      if (this.getMaxOutpostSpawn() == 0 && TownySettings.isOutpostsLimitedByLevels()) {
         throw new TownyException(Translation.of("msg_err_town_has_no_outpost_spawns_set"));
      } else {
         return ((Position)this.outpostSpawns.get(Math.min(this.getMaxOutpostSpawn() - 1, Math.max(0, index - 1)))).asLocation();
      }
   }

   public int getMaxOutpostSpawn() {
      return this.outpostSpawns.size();
   }

   public boolean hasOutpostSpawn() {
      return !this.outpostSpawns.isEmpty();
   }

   private boolean isAnOutpost(Coord coord) {
      return (new ArrayList(this.outpostSpawns)).stream().anyMatch((spawn) -> {
         return spawn.worldCoord().equals(coord);
      });
   }

   public List<Location> getAllOutpostSpawns() {
      return Collections.unmodifiableList(Lists.transform(this.outpostSpawns, Position::asLocation));
   }

   public Collection<Position> getOutpostSpawns() {
      return Collections.unmodifiableList(this.outpostSpawns);
   }

   public void removeOutpostSpawn(Coord coord) {
      (new ArrayList(this.getAllOutpostSpawns())).stream().filter((spawn) -> {
         return Coord.parseCoord(spawn).equals(coord);
      }).forEach((spawn) -> {
         this.removeOutpostSpawn(spawn);
         TownyUniverse.getInstance().removeSpawnPoint(spawn);
      });
   }

   public void removeOutpostSpawn(Location loc) {
      this.outpostSpawns.remove(Position.ofLocation(loc));
   }

   public List<String> getOutpostNames() {
      List<String> outpostNames = new ArrayList();
      int i = 0;
      Iterator var3 = this.getAllOutpostSpawns().iterator();

      while(var3.hasNext()) {
         Location loc = (Location)var3.next();
         ++i;
         TownBlock tboutpost = TownyAPI.getInstance().getTownBlock(loc);
         if (tboutpost != null) {
            String name = !tboutpost.hasPlotObjectGroup() ? tboutpost.getName() : tboutpost.getPlotObjectGroup().getName();
            if (!name.isEmpty()) {
               outpostNames.add(name);
            } else {
               outpostNames.add(String.valueOf(i));
            }
         }
      }

      return outpostNames;
   }

   public final void setForSale(boolean isForSale) {
      this.isForSale = isForSale;
      if (!isForSale) {
         this.forSalePrice = 0.0D;
      }

   }

   public final boolean isForSale() {
      return this.isForSale;
   }

   public final void setForSalePrice(double forSalePrice) {
      this.forSalePrice = Math.min(forSalePrice, TownySettings.maxBuyTownPrice());
   }

   public final double getForSalePrice() {
      return this.forSalePrice;
   }

   public void setPlotPrice(double plotPrice) {
      if (plotPrice < 0.0D) {
         plotPrice = -1.0D;
      }

      this.plotPrice = Math.min(plotPrice, TownySettings.getMaxPlotPrice());
   }

   public double getPlotPrice() {
      return this.plotPrice;
   }

   public double getPlotTypePrice(TownBlockType type) {
      String var4 = type.getName().toLowerCase(Locale.ROOT);
      byte var5 = -1;
      switch(var4.hashCode()) {
      case -1637322286:
         if (var4.equals("embassy")) {
            var5 = 1;
         }
         break;
      case 3529462:
         if (var4.equals("shop")) {
            var5 = 0;
         }
      }

      double var10000;
      switch(var5) {
      case 0:
         var10000 = this.getCommercialPlotPrice();
         break;
      case 1:
         var10000 = this.getEmbassyPlotPrice();
         break;
      default:
         var10000 = this.getPlotPrice();
      }

      double plotPrice = var10000;
      return Math.max(plotPrice, 0.0D);
   }

   public void setCommercialPlotPrice(double commercialPlotPrice) {
      if (commercialPlotPrice < 0.0D) {
         commercialPlotPrice = -1.0D;
      }

      this.commercialPlotPrice = Math.min(commercialPlotPrice, TownySettings.getMaxPlotPrice());
   }

   public double getCommercialPlotPrice() {
      return this.commercialPlotPrice;
   }

   public void setEmbassyPlotPrice(double embassyPlotPrice) {
      if (embassyPlotPrice < 0.0D) {
         embassyPlotPrice = -1.0D;
      }

      this.embassyPlotPrice = Math.min(embassyPlotPrice, TownySettings.getMaxPlotPrice());
   }

   public double getEmbassyPlotPrice() {
      return this.embassyPlotPrice;
   }

   public boolean isHomeBlock(TownBlock townBlock) {
      return this.hasHomeBlock() && townBlock == this.homeBlock;
   }

   public void setPlotTax(double plotTax) {
      this.plotTax = Math.min(plotTax, TownySettings.getMaxPlotTax());
   }

   public double getPlotTax() {
      return this.plotTax;
   }

   public void setCommercialPlotTax(double commercialTax) {
      this.commercialPlotTax = Math.min(commercialTax, TownySettings.getMaxPlotTax());
   }

   public double getCommercialPlotTax() {
      return this.commercialPlotTax;
   }

   public void setEmbassyPlotTax(double embassyPlotTax) {
      this.embassyPlotTax = Math.min(embassyPlotTax, TownySettings.getMaxPlotTax());
   }

   public double getEmbassyPlotTax() {
      return this.embassyPlotTax;
   }

   public void collect(double amount) {
      if (TownyEconomyHandler.isActive()) {
         double bankcap = this.getBankCap();
         if (bankcap > 0.0D && amount + this.getAccount().getHoldingBalance() > bankcap) {
            TownyMessaging.sendPrefixedTownMessage(this, Translatable.of("msg_err_deposit_capped", bankcap));
            return;
         }

         this.getAccount().deposit(amount, (String)null);
      }

   }

   public List<String> getTreeString(int depth) {
      List<String> out = new ArrayList();
      String var10001 = this.getTreeDepth(depth);
      out.add(var10001 + "Town (" + this.getName() + ")");
      var10001 = this.getTreeDepth(depth + 1);
      out.add(var10001 + "Mayor: " + (this.hasMayor() ? this.getMayor().getName() : "None"));
      var10001 = this.getTreeDepth(depth + 1);
      out.add(var10001 + "Home: " + this.homeBlock);
      var10001 = this.getTreeDepth(depth + 1);
      out.add(var10001 + "Bonus: " + this.bonusBlocks);
      var10001 = this.getTreeDepth(depth + 1);
      out.add(var10001 + "TownBlocks (" + this.getTownBlocks().size() + "): ");
      List<Resident> assistants = this.getRank("assistant");
      if (!assistants.isEmpty()) {
         var10001 = this.getTreeDepth(depth + 1);
         out.add(var10001 + "Assistants (" + assistants.size() + "): " + Arrays.toString(assistants.toArray(new Resident[0])));
      }

      var10001 = this.getTreeDepth(depth + 1);
      out.add(var10001 + "Residents (" + this.getResidents().size() + "):");
      Iterator var4 = this.getResidents().iterator();

      while(var4.hasNext()) {
         Resident resident = (Resident)var4.next();
         out.addAll(resident.getTreeString(depth + 2));
      }

      return out;
   }

   public Collection<Resident> getOutlaws() {
      return Collections.unmodifiableList(this.outlaws);
   }

   public boolean hasOutlaw(String name) {
      return this.outlaws.stream().anyMatch((outlaw) -> {
         return outlaw.getName().equalsIgnoreCase(name);
      });
   }

   public boolean hasOutlaw(Resident outlaw) {
      return this.outlaws.contains(outlaw);
   }

   public void addOutlaw(Resident resident) throws AlreadyRegisteredException {
      this.addOutlawCheck(resident);
      this.outlaws.add(resident);
   }

   public void addOutlawCheck(Resident resident) throws AlreadyRegisteredException {
      if (this.hasOutlaw(resident)) {
         throw new AlreadyRegisteredException(Translation.of("msg_err_resident_already_an_outlaw"));
      } else {
         Town residentTown = resident.getTownOrNull();
         if (this.equals(residentTown)) {
            throw new AlreadyRegisteredException(Translation.of("msg_err_not_outlaw_in_your_town"));
         }
      }
   }

   public void removeOutlaw(Resident resident) {
      if (this.hasOutlaw(resident)) {
         this.outlaws.remove(resident);
      }

   }

   public void loadOutlaws(List<Resident> outlaws) {
      outlaws.stream().forEach((o) -> {
         try {
            this.addOutlaw(o);
         } catch (AlreadyRegisteredException var3) {
         }

      });
   }

   public boolean hasValidUUID() {
      return this.uuid != null;
   }

   public void setOutpostSpawns(List<Location> outpostSpawns) {
      this.outpostSpawns.clear();
      Iterator var2 = outpostSpawns.iterator();

      while(var2.hasNext()) {
         Location location = (Location)var2.next();
         this.addOutpostSpawn(location);
      }

   }

   public boolean isAlliedWith(Town othertown) {
      return CombatUtil.isAlly(this, othertown);
   }

   public int getOutpostLimit() {
      return TownySettings.getMaxOutposts(this);
   }

   public boolean isOverOutpostLimit() {
      return TownySettings.isOutpostsLimitedByLevels() && this.getMaxOutpostSpawn() > this.getOutpostLimit();
   }

   public boolean isOverClaimed() {
      if (!this.hasUnlimitedClaims() && this.getTownBlocks().size() > this.getMaxTownBlocks()) {
         TownIsTownOverClaimedEvent event = new TownIsTownOverClaimedEvent(this);
         return !BukkitTools.isEventCancelled(event);
      } else {
         return false;
      }
   }

   public int availableTownBlocks() {
      return this.getMaxTownBlocks() - this.getTownBlocks().size();
   }

   public void addMetaData(@NotNull CustomDataField<?> md) {
      this.addMetaData(md, true);
   }

   public void removeMetaData(@NotNull CustomDataField<?> md) {
      this.removeMetaData(md, true);
   }

   public void setConquered(boolean conquered) {
      this.setConquered(conquered, true);
   }

   public void setConquered(boolean conquered, boolean callEvent) {
      if (conquered != this.isConquered) {
         this.isConquered = conquered;
         if (callEvent) {
            if (this.isConquered) {
               BukkitTools.fireEvent(new TownConqueredEvent(this));
            } else {
               BukkitTools.fireEvent(new TownUnconquerEvent(this));
            }

         }
      }
   }

   public boolean isConquered() {
      return this.isConquered;
   }

   public void setConqueredDays(int conqueredDays) {
      this.conqueredDays = conqueredDays;
   }

   public int getConqueredDays() {
      return this.conqueredDays;
   }

   public void addJail(Jail jail) {
      if (!this.hasJails()) {
         this.jails = new ArrayList(1);
      }

      this.jails.add(jail);
   }

   public void removeJail(Jail jail) {
      if (this.hasJails() && this.hasJail(jail)) {
         this.jails.remove(jail);
      }

      if (this.getPrimaryJail() != null && this.getPrimaryJail().getUUID().equals(jail.getUUID())) {
         this.setPrimaryJail((Jail)null);
      }

   }

   public boolean hasJails() {
      return this.jails != null;
   }

   public boolean hasJail(Jail jail) {
      return this.jails.contains(jail);
   }

   @Nullable
   public Collection<Jail> getJails() {
      return !this.hasJails() ? null : Collections.unmodifiableCollection(this.jails);
   }

   @Nullable
   public Jail getJail(int i) {
      if (this.hasJails() && this.jails.size() >= i) {
         --i;
         return (Jail)this.jails.get(i);
      } else {
         return null;
      }
   }

   public void setPrimaryJail(Jail jail) {
      this.primaryJail = jail;
   }

   @Nullable
   public Jail getPrimaryJail() {
      return this.primaryJail == null && this.hasJails() ? this.getJail(1) : this.primaryJail;
   }

   public int getJailedPlayerCount() {
      return this.getJailedResidents().size();
   }

   public List<Resident> getJailedResidents() {
      return Collections.unmodifiableList((List)(new ArrayList(TownyUniverse.getInstance().getJailedResidentMap())).stream().filter((res) -> {
         return res.hasJailTown(this.getName());
      }).collect(Collectors.toList()));
   }

   public void renamePlotGroup(String oldName, PlotGroup group) {
      this.plotGroups.remove(oldName);
      this.plotGroups.put(group.getName(), group);
   }

   public void addPlotGroup(PlotGroup group) {
      if (!this.hasPlotGroups()) {
         this.plotGroups = new HashMap();
      }

      this.plotGroups.put(group.getName(), group);
   }

   public void removePlotGroup(PlotGroup plotGroup) {
      if (this.hasPlotGroups() && this.plotGroups.remove(plotGroup.getName()) != null) {
         Iterator var2 = (new ArrayList(plotGroup.getTownBlocks())).iterator();

         while(var2.hasNext()) {
            TownBlock tb = (TownBlock)var2.next();
            if (tb.hasPlotObjectGroup() && tb.getPlotObjectGroup().getUUID().equals(plotGroup.getUUID())) {
               plotGroup.removeTownBlock(tb);
               tb.removePlotObjectGroup();
               tb.save();
            }
         }
      }

   }

   public Collection<PlotGroup> getPlotGroups() {
      return (Collection)(this.plotGroups != null && !this.plotGroups.isEmpty() ? Collections.unmodifiableCollection(this.plotGroups.values()) : Collections.emptyList());
   }

   public boolean hasPlotGroups() {
      return this.plotGroups != null;
   }

   public boolean hasPlotGroupName(String name) {
      return this.hasPlotGroups() && this.plotGroups.containsKey(name);
   }

   @Nullable
   public PlotGroup getPlotObjectGroupFromName(String name) {
      return this.hasPlotGroups() && this.hasPlotGroupName(name) ? (PlotGroup)this.plotGroups.get(name) : null;
   }

   public void renameDistrict(String oldName, District district) {
      this.districts.remove(oldName);
      this.districts.put(district.getName(), district);
   }

   public void addDistrict(District district) {
      if (!this.hasDistricts()) {
         this.districts = new HashMap();
      }

      this.districts.put(district.getName(), district);
   }

   public void removeDistrict(District district) {
      if (this.hasDistricts() && this.districts.remove(district.getName()) != null) {
         Iterator var2 = (new ArrayList(district.getTownBlocks())).iterator();

         while(var2.hasNext()) {
            TownBlock tb = (TownBlock)var2.next();
            if (tb.hasDistrict() && tb.getDistrict().getUUID().equals(district.getUUID())) {
               district.removeTownBlock(tb);
               tb.removeDistrict();
               tb.save();
            }
         }
      }

   }

   public Collection<District> getDistricts() {
      return (Collection)(this.districts != null && !this.districts.isEmpty() ? Collections.unmodifiableCollection(this.districts.values()) : Collections.emptyList());
   }

   public boolean hasDistricts() {
      return this.districts != null;
   }

   public boolean hasDistrictName(String name) {
      return this.hasDistricts() && this.districts.containsKey(name);
   }

   @Nullable
   public District getDistrictFromName(String name) {
      return this.hasDistricts() && this.hasDistrictName(name) ? (District)this.districts.get(name) : null;
   }

   public double getBankCap() {
      return TownySettings.getTownBankCap(this);
   }

   public World getWorld() {
      return this.hasWorld() ? BukkitTools.getWorld(this.getHomeblockWorld().getName()) : (World)BukkitTools.getWorlds().get(0);
   }

   public String getBankAccountPrefix() {
      return ECONOMY_ACCOUNT_PREFIX;
   }

   public String getFormattedName() {
      String prefix = this.isCapital() && !TownySettings.getCapitalPrefix(this).isEmpty() ? TownySettings.getCapitalPrefix(this) : TownySettings.getTownPrefix(this);
      String postfix = this.isCapital() && !TownySettings.getCapitalPostfix(this).isEmpty() ? TownySettings.getCapitalPostfix(this) : TownySettings.getTownPostfix(this);
      TownyObjectFormattedNameEvent event = new TownyObjectFormattedNameEvent(this, prefix, postfix);
      BukkitTools.fireEvent(event);
      String var10000 = event.getPrefix();
      return var10000 + this.getName().replace("_", " ") + event.getPostfix();
   }

   public String getPrefix() {
      return TownySettings.getTownPrefix(this);
   }

   public String getPostfix() {
      return TownySettings.getTownPostfix(this);
   }

   public double getMaxPercentTaxAmount() {
      return this.maxPercentTaxAmount;
   }

   public void setMaxPercentTaxAmount(double maxPercentTaxAmount) {
      this.maxPercentTaxAmount = Math.min(maxPercentTaxAmount, TownySettings.getMaxTownTaxPercentAmount());
   }

   public boolean isBankrupt() {
      return TownyEconomyHandler.isActive() && this.debtBalance > 0.0D;
   }

   public double getDebtBalance() {
      return this.debtBalance;
   }

   public void setDebtBalance(double balance) {
      this.debtBalance = balance;
   }

   public boolean isRuined() {
      return this.ruined;
   }

   public void setRuined(boolean b) {
      this.ruined = b;
   }

   public void setRuinedTime(long time) {
      this.ruinedTime = time;
   }

   public long getRuinedTime() {
      return this.ruinedTime;
   }

   @Nullable
   public String getMapColorHexCode() {
      String rawMapColorHexCode = super.getMapColorHexCode();
      TownMapColourLocalCalculationEvent event = new TownMapColourLocalCalculationEvent(this, rawMapColorHexCode);
      BukkitTools.fireEvent(event);
      return event.getMapColorHexCode();
   }

   @Nullable
   public String getNationMapColorHexCode() {
      String rawMapColorHexCode = this.hasNation() ? this.nation.getMapColorHexCode() : null;
      TownMapColourNationalCalculationEvent event = new TownMapColourNationalCalculationEvent(this, rawMapColorHexCode);
      BukkitTools.fireEvent(event);
      return event.getMapColorHexCode();
   }

   public void save() {
      TownyUniverse.getInstance().getDataSource().saveTown(this);
   }

   public void saveTownBlocks() {
      this.townBlocks.values().stream().forEach((tb) -> {
         tb.save();
      });
   }

   public int getNationZoneOverride() {
      return this.nationZoneOverride;
   }

   public void setNationZoneOverride(int size) {
      this.nationZoneOverride = size;
   }

   public boolean hasNationZoneOverride() {
      return this.nationZoneOverride > 0;
   }

   public long getJoinedNationAt() {
      return this.joinedNationAt;
   }

   public void setJoinedNationAt(long joinedNationAt) {
      this.joinedNationAt = joinedNationAt;
   }

   public long getMovedHomeBlockAt() {
      return this.movedHomeBlockAt;
   }

   public void setMovedHomeBlockAt(long movedHomeBlockAt) {
      this.movedHomeBlockAt = movedHomeBlockAt;
   }

   private void sortResidents() {
      List<Resident> sortedResidents = (List)this.residents.stream().sorted(Comparator.comparingLong(Resident::getJoinedTownAt)).collect(Collectors.toList());
      this.residents.clear();
      this.residents.addAll(sortedResidents);
      this.residentsSorted = true;
   }

   public Set<Resident> getTrustedResidents() {
      return this.trustedResidents;
   }

   public boolean hasTrustedResident(Resident resident) {
      Town residentsTown = resident.getTownOrNull();
      return this.trustedResidents.contains(resident) || residentsTown != null && this.hasTrustedTown(residentsTown);
   }

   public void addTrustedResident(Resident resident) {
      this.trustedResidents.add(resident);
   }

   public void removeTrustedResident(Resident resident) {
      this.trustedResidents.remove(resident);
   }

   public int getNationZoneSize() {
      if (TownySettings.getNationZonesEnabled() && this.hasNation()) {
         if (!this.isCapital() && TownySettings.getNationZonesCapitalsOnly()) {
            return 0;
         } else {
            return this.hasNationZoneOverride() ? this.getNationZoneOverride() : this.nation.getNationZoneSize() + (this.isCapital() ? TownySettings.getNationZonesCapitalBonusSize() : 0);
         }
      } else {
         return 0;
      }
   }

   public void loadAllies(List<Town> towns) {
      Iterator var2 = towns.iterator();

      while(var2.hasNext()) {
         Town town = (Town)var2.next();
         this.allies.put(town.getUUID(), town);
      }

   }

   public void addAlly(Town town) {
      TownAddAlliedTownEvent taate = new TownAddAlliedTownEvent(this, town);
      if (BukkitTools.isEventCancelled(taate)) {
         TownyMessaging.sendMsg(taate.getCancelMessage());
      } else {
         this.enemies.remove(town.getUUID());
         this.allies.put(town.getUUID(), town);
      }
   }

   public void removeAlly(Town town) {
      TownRemoveAlliedTownEvent trate = new TownRemoveAlliedTownEvent(this, town);
      if (BukkitTools.isEventCancelled(trate)) {
         TownyMessaging.sendMsg(trate.getCancelMessage());
      } else {
         this.allies.remove(town.getUUID());
      }
   }

   public boolean removeAllAllies() {
      Iterator var1 = (new ArrayList(this.getAllies())).iterator();

      while(var1.hasNext()) {
         Town ally = (Town)var1.next();
         this.removeAlly(ally);
         ally.removeAlly(this);
      }

      return this.getAllies().isEmpty();
   }

   public boolean hasAlly(Town town) {
      return this.allies.containsKey(town.getUUID());
   }

   public boolean hasMutualAlly(Town town) {
      return this.hasAlly(town) && town.hasAlly(this);
   }

   public void loadTrustedTowns(List<Town> towns) {
      Iterator var2 = towns.iterator();

      while(var2.hasNext()) {
         Town trustTown = (Town)var2.next();
         this.trustedTowns.put(trustTown.getUUID(), trustTown);
      }

   }

   public void addTrustedTown(Town town) {
      this.trustedTowns.put(town.getUUID(), town);
   }

   public void removeTrustedTown(Town town) {
      this.trustedTowns.remove(town.getUUID());
   }

   public boolean removeAllTrustedTowns() {
      Iterator var1 = (new ArrayList(this.getTrustedTowns())).iterator();

      while(var1.hasNext()) {
         Town trusted = (Town)var1.next();
         this.removeTrustedTown(trusted);
      }

      return this.getTrustedTowns().isEmpty();
   }

   public boolean hasTrustedTown(Town town) {
      return this.trustedTowns.containsKey(town.getUUID());
   }

   public void loadEnemies(List<Town> towns) {
      Iterator var2 = towns.iterator();

      while(var2.hasNext()) {
         Town town = (Town)var2.next();
         this.enemies.put(town.getUUID(), town);
      }

   }

   public void addEnemy(Town town) {
      TownAddEnemiedTownEvent taete = new TownAddEnemiedTownEvent(this, town);
      if (BukkitTools.isEventCancelled(taete)) {
         TownyMessaging.sendMsg(taete.getCancelMessage());
      } else {
         this.allies.remove(town.getUUID());
         this.enemies.put(town.getUUID(), town);
      }
   }

   public void removeEnemy(Town town) {
      TownRemoveEnemiedTownEvent trete = new TownRemoveEnemiedTownEvent(this, town);
      if (BukkitTools.isEventCancelled(trete)) {
         TownyMessaging.sendMsg(trete.getCancelMessage());
      } else {
         this.enemies.remove(town.getUUID());
      }
   }

   public boolean removeAllEnemies() {
      Iterator var1 = (new ArrayList(this.getEnemies())).iterator();

      while(var1.hasNext()) {
         Town enemy = (Town)var1.next();
         this.removeEnemy(enemy);
         enemy.removeEnemy(this);
      }

      return this.getEnemies().isEmpty();
   }

   public boolean hasEnemy(Town town) {
      return this.enemies.containsKey(town.getUUID());
   }

   public List<Town> getEnemies() {
      return Collections.unmodifiableList((List)this.enemies.values().stream().collect(Collectors.toList()));
   }

   public List<Town> getAllies() {
      return Collections.unmodifiableList((List)this.allies.values().stream().collect(Collectors.toList()));
   }

   public List<Town> getTrustedTowns() {
      return Collections.unmodifiableList((List)this.trustedTowns.values().stream().collect(Collectors.toList()));
   }

   public List<Town> getMutualAllies() {
      List<Town> result = new ArrayList();
      Iterator var2 = this.getAllies().iterator();

      while(var2.hasNext()) {
         Town ally = (Town)var2.next();
         if (ally.hasAlly(this)) {
            result.add(ally);
         }
      }

      return result;
   }

   public List<UUID> getAlliesUUIDs() {
      return Collections.unmodifiableList((List)this.allies.keySet().stream().collect(Collectors.toList()));
   }

   public List<UUID> getEnemiesUUIDs() {
      return Collections.unmodifiableList((List)this.enemies.keySet().stream().collect(Collectors.toList()));
   }

   public List<UUID> getTrustedTownsUUIDS() {
      return Collections.unmodifiableList((List)this.trustedTowns.keySet().stream().collect(Collectors.toList()));
   }

   public boolean isNationZoneEnabled() {
      return this.nationZoneEnabled;
   }

   public void setNationZoneEnabled(boolean nationZoneEnabled) {
      this.nationZoneEnabled = nationZoneEnabled;
   }

   public boolean isInsideTown(@NotNull Location location) {
      return this.equals(WorldCoord.parseWorldCoord(location).getTownOrNull());
   }

   public boolean isInsideTown(@NotNull Position position) {
      return this.equals(position.worldCoord().getTownOrNull());
   }

   public boolean isNeutral() {
      return (!TownySettings.nationCapitalsCantBeNeutral() || !this.isCapital()) && this.isNeutral;
   }

   public TownySettings.TownLevel getTownLevel() {
      return TownySettings.getTownLevel(this);
   }

   public int getLevelNumber() {
      int townLevelNumber = this.getManualTownLevel() > -1 ? TownySettings.getTownLevelWhichIsManuallySet(this.getManualTownLevel()) : TownySettings.getTownLevelFromGivenInt(this.getNumResidents(), this);
      TownCalculateTownLevelNumberEvent tctle = new TownCalculateTownLevelNumberEvent(this, townLevelNumber);
      BukkitTools.fireEvent(tctle);
      return tctle.getTownLevelNumber();
   }

   /** @deprecated */
   @Deprecated
   public int getLevel() {
      return this.getLevelNumber();
   }

   /** @deprecated */
   @Deprecated
   public int getLevel(int populationSize) {
      return TownySettings.getTownLevelFromGivenInt(populationSize, this);
   }

   /** @deprecated */
   @Deprecated
   public int getMaxLevel() {
      return TownySettings.getConfigTownLevel().size();
   }

   /** @deprecated */
   @Deprecated
   public int getLevelID() {
      return this.getLevelNumber();
   }

   public int getManualTownLevel() {
      return this.manualTownLevel;
   }

   public void setManualTownLevel(int manualTownLevel) {
      this.manualTownLevel = manualTownLevel;
   }

   public int getTownBlockTypeLimit(TownBlockType type) {
      return !TownySettings.areLevelTypeLimitsConfigured() ? -1 : (Integer)this.getTownLevel().townBlockTypeLimits().getOrDefault(type.getName().toLowerCase(Locale.ROOT), -1);
   }

   @NotNull
   public Iterable<? extends Audience> audiences() {
      return (Iterable)TownyAPI.getInstance().getOnlinePlayers(this).stream().map((player) -> {
         return Towny.getAdventure().player(player);
      }).collect(Collectors.toSet());
   }

   @Internal
   public boolean exists() {
      return TownyUniverse.getInstance().hasTown(this.getName());
   }

   public boolean isVisibleOnTopLists() {
      return this.visibleOnTopLists;
   }

   public void setVisibleOnTopLists(boolean visibleOnTopLists) {
      this.visibleOnTopLists = visibleOnTopLists;
   }

   public void playerBroadCastMessageToTown(Player player, String message) {
      TownyMessaging.sendPrefixedTownMessage(this, Translatable.of("town_say_format", player.getName(), TownyComponents.stripClickTags(message)));
   }

   public void checkTownHasEnoughResidentsForNationRequirements() {
      TownUtil.checkNationResidentsRequirementsOfTown(this);
   }

   public boolean hasEnoughResidentsToJoinANation() {
      return TownUtil.townHasEnoughResidentsToJoinANation(this);
   }

   public boolean hasEnoughResidentsToBeANationCapital() {
      return TownUtil.townHasEnoughResidentsToBeANationCapital(this);
   }

   public boolean isAllowedThisAmountOfResidents(int residentCount, boolean isCapital) {
      return TownUtil.townCanHaveThisAmountOfResidents(this, residentCount, isCapital);
   }

   public int getMaxAllowedNumberOfResidentsWithoutNation() {
      return TownUtil.getMaxAllowedNumberOfResidentsWithoutNation(this);
   }
}
