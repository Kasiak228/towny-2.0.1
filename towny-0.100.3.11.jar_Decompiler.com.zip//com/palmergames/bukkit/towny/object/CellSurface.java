package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.utils.BorderUtil;
import com.palmergames.bukkit.util.DrawSmokeTaskFactory;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.bukkit.Color;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

public class CellSurface {
   private static final long PARTICLE_DELAY = 1L;
   private final DustOptions CLAIMING_PARTICLE;
   private final WorldCoord worldCoord;

   public CellSurface(WorldCoord worldCoord) {
      this.CLAIMING_PARTICLE = new DustOptions(Color.LIME, 2.0F);
      this.worldCoord = worldCoord;
   }

   public static CellSurface getCellSurface(WorldCoord worldCoord) {
      return new CellSurface(worldCoord);
   }

   public void runClaimingParticleOverSurfaceAtPlayer(Player player) {
      World world = this.worldCoord.getBukkitWorld();
      if (world != null) {
         Map<Integer, Set<CellSurface.BlockPos>> toRender = this.mapRingsOfClaimParticles(this.getX(player.getLocation()), this.getZ(player.getLocation()));
         toRender.forEach((key, value) -> {
            value.forEach((pos) -> {
               Towny.getPlugin().getScheduler().runLater((Entity)player, (Runnable)(() -> {
                  this.drawClaimingParticleOnTopOfBlock(player, world, pos.x, pos.z);
               }), (long)key * 1L);
            });
         });
         long finalDelay = (long)toRender.keySet().size() + 1L;
         Towny.getPlugin().getScheduler().runLater((Entity)player, (Runnable)(() -> {
            BorderUtil.getPlotBorder(this.worldCoord).runBorderedOnSurface(2, 2, DrawSmokeTaskFactory.showToPlayer(player, Color.GREEN));
         }), finalDelay);
      }
   }

   private Map<Integer, Set<CellSurface.BlockPos>> mapRingsOfClaimParticles(int startingX, int startingZ) {
      Set<CellSurface.BlockPos> traveled = new HashSet();
      Map<Integer, Set<CellSurface.BlockPos>> toRender = new HashMap();
      Set<CellSurface.BlockPos> localRing = new HashSet();
      int maxRadius = TownySettings.getTownBlockSize();
      BoundingBox worldCoordBB = this.worldCoord.getBoundingBox();

      for(int ringNum = 1; ringNum <= maxRadius; ++ringNum) {
         for(int x = startingX + Math.negateExact(ringNum); x <= startingX + ringNum; ++x) {
            for(int z = startingZ + Math.negateExact(ringNum); z <= startingZ + ringNum; ++z) {
               CellSurface.BlockPos pos = new CellSurface.BlockPos(x, z);
               if (!traveled.contains(pos)) {
                  traveled.add(pos);
                  if (worldCoordBB.contains((double)x, 1.0D, (double)z)) {
                     localRing.add(pos);
                  }
               }
            }
         }

         if (localRing.isEmpty()) {
            break;
         }

         toRender.put(ringNum, new HashSet(localRing));
         localRing.clear();
      }

      return toRender;
   }

   private void drawClaimingParticleOnTopOfBlock(Player player, World world, int x, int z) {
      Location loc = this.getParticleLocation(world, x, z);
      Towny.getPlugin().getScheduler().runAsync(() -> {
         player.spawnParticle(Particle.REDSTONE, loc, 5, this.CLAIMING_PARTICLE);
      });
   }

   private Location getParticleLocation(World world, int x, int z) {
      return (new Location(world, (double)x, (double)world.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES), (double)z)).add(0.5D, 0.95D, 0.5D);
   }

   private int getX(Location playerLoc) {
      return WorldCoord.parseWorldCoord(playerLoc).equals(this.worldCoord) ? playerLoc.getBlockX() : this.findSuitableXorZ(playerLoc.getBlockX(), this.worldCoord.getBoundingBox().getMaxX(), this.worldCoord.getBoundingBox().getMinX());
   }

   private int getZ(Location playerLoc) {
      return WorldCoord.parseWorldCoord(playerLoc).equals(this.worldCoord) ? playerLoc.getBlockZ() : this.findSuitableXorZ(playerLoc.getBlockZ(), this.worldCoord.getBoundingBox().getMaxZ(), this.worldCoord.getBoundingBox().getMinZ());
   }

   private int findSuitableXorZ(int player, double max, double min) {
      return (int)Math.max(Math.min((double)player, max), min);
   }

   private static record BlockPos(int x, int z) {
      private BlockPos(int x, int z) {
         this.x = x;
         this.z = z;
      }

      public int x() {
         return this.x;
      }

      public int z() {
         return this.z;
      }
   }
}
