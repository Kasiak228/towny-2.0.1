package com.palmergames.bukkit.towny.object;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;

/** @deprecated */
@Deprecated
public class Transaction {
   private final TransactionType type;
   private final CommandSender sender;
   private final double amount;

   public Transaction(TransactionType type, CommandSender sender, double amount) {
      this.type = type;
      this.sender = sender;
      this.amount = amount;
   }

   public TransactionType getType() {
      return this.type;
   }

   public CommandSender getCommandSender() {
      return this.sender;
   }

   /** @deprecated */
   @Deprecated
   @Nullable
   public Player getPlayer() {
      CommandSender var2 = this.sender;
      Player var10000;
      if (var2 instanceof Player) {
         Player player = (Player)var2;
         var10000 = player;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public double getAmount() {
      return this.amount;
   }
}
