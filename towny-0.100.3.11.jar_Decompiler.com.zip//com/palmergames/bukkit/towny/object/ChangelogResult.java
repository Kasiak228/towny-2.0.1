package com.palmergames.bukkit.towny.object;

import java.util.Collection;

public record ChangelogResult(Collection<String> lines, boolean successful, boolean limitReached, int nextVersionIndex, int totalSize) {
   public ChangelogResult(Collection<String> lines, boolean successful, boolean limitReached, int nextVersionIndex, int totalSize) {
      this.lines = lines;
      this.successful = successful;
      this.limitReached = limitReached;
      this.nextVersionIndex = nextVersionIndex;
      this.totalSize = totalSize;
   }

   public Collection<String> lines() {
      return this.lines;
   }

   public boolean successful() {
      return this.successful;
   }

   public boolean limitReached() {
      return this.limitReached;
   }

   public int nextVersionIndex() {
      return this.nextVersionIndex;
   }

   public int totalSize() {
      return this.totalSize;
   }
}
