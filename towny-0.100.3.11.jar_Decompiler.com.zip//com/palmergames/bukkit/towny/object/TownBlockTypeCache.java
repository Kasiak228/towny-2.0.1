package com.palmergames.bukkit.towny.object;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TownBlockTypeCache {
   private Map<TownBlockType, Integer> typeCache = new ConcurrentHashMap();
   private Map<TownBlockType, Integer> forSaleCache = new ConcurrentHashMap(0);
   private Map<TownBlockType, Integer> residentOwnedCache = new ConcurrentHashMap(0);

   public int getNumTownBlocks(TownBlockType townBlockType, TownBlockTypeCache.CacheType cacheType) {
      int var10000;
      switch(cacheType) {
      case ALL:
         var10000 = (Integer)this.typeCache.getOrDefault(townBlockType, 0);
         break;
      case FORSALE:
         var10000 = (Integer)this.forSaleCache.getOrDefault(townBlockType, 0);
         break;
      case RESIDENTOWNED:
         var10000 = (Integer)this.residentOwnedCache.getOrDefault(townBlockType, 0);
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public Map<TownBlockType, Integer> getCache(TownBlockTypeCache.CacheType cacheType) {
      Map var10000;
      switch(cacheType) {
      case ALL:
         var10000 = Collections.unmodifiableMap(this.typeCache);
         break;
      case FORSALE:
         var10000 = Collections.unmodifiableMap(this.forSaleCache);
         break;
      case RESIDENTOWNED:
         var10000 = Collections.unmodifiableMap(this.residentOwnedCache);
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public void removeTownBlockOfType(TownBlock townBlock) {
      this.typeCache.merge(townBlock.getType(), -1, Integer::sum);
   }

   public void addTownBlockOfType(TownBlock townBlock) {
      this.typeCache.merge(townBlock.getType(), 1, Integer::sum);
   }

   public void removeTownBlockOfType(TownBlockType type) {
      this.typeCache.merge(type, -1, Integer::sum);
   }

   public void addTownBlockOfType(TownBlockType type) {
      this.typeCache.merge(type, 1, Integer::sum);
   }

   public void removeTownBlockOfTypeForSale(TownBlock townBlock) {
      this.forSaleCache.merge(townBlock.getType(), -1, Integer::sum);
   }

   public void addTownBlockOfTypeForSale(TownBlock townBlock) {
      this.forSaleCache.merge(townBlock.getType(), 1, Integer::sum);
   }

   public void removeTownBlockOfTypeForSale(TownBlockType type) {
      this.forSaleCache.merge(type, -1, Integer::sum);
   }

   public void addTownBlockOfTypeForSale(TownBlockType type) {
      this.forSaleCache.merge(type, 1, Integer::sum);
   }

   public int getNumberOfResidentOwnedTownBlocks() {
      return this.residentOwnedCache.values().stream().mapToInt((d) -> {
         return d;
      }).sum();
   }

   public void removeTownBlockOfTypeResidentOwned(TownBlock townBlock) {
      this.residentOwnedCache.merge(townBlock.getType(), -1, Integer::sum);
   }

   public void addTownBlockOfTypeResidentOwned(TownBlock townBlock) {
      this.residentOwnedCache.merge(townBlock.getType(), 1, Integer::sum);
   }

   public void removeTownBlockOfTypeResidentOwned(TownBlockType type) {
      this.residentOwnedCache.merge(type, -1, Integer::sum);
   }

   public void addTownBlockOfTypeResidentOwned(TownBlockType type) {
      this.residentOwnedCache.merge(type, 1, Integer::sum);
   }

   public static enum CacheType {
      ALL,
      FORSALE,
      RESIDENTOWNED;

      // $FF: synthetic method
      private static TownBlockTypeCache.CacheType[] $values() {
         return new TownBlockTypeCache.CacheType[]{ALL, FORSALE, RESIDENTOWNED};
      }
   }
}
