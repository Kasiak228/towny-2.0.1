package com.palmergames.bukkit.towny.object;

import com.palmergames.adventure.audience.Audience;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.TownyObjectFormattedNameEvent;
import com.palmergames.bukkit.towny.event.nation.NationCalculateNationLevelNumberEvent;
import com.palmergames.bukkit.towny.exceptions.EmptyNationException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.invites.Invite;
import com.palmergames.bukkit.towny.invites.InviteHandler;
import com.palmergames.bukkit.towny.invites.exceptions.TooManyInvitesException;
import com.palmergames.bukkit.towny.object.metadata.CustomDataField;
import com.palmergames.bukkit.towny.permissions.TownyPerms;
import com.palmergames.bukkit.towny.utils.NationUtil;
import com.palmergames.bukkit.towny.utils.ProximityUtil;
import com.palmergames.bukkit.towny.utils.TownyComponents;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;

public class Nation extends Government {
   private static final String ECONOMY_ACCOUNT_PREFIX = TownySettings.getNationAccountPrefix();
   private final List<Town> towns = new ArrayList();
   private final List<Town> sanctionedTowns = new ArrayList();
   private List<Nation> allies = new ArrayList();
   private List<Nation> enemies = new ArrayList();
   private Town capital;
   private final List<Invite> sentAllyInvites = new ArrayList();
   private boolean isTaxPercentage = TownySettings.getNationDefaultTaxPercentage();
   private double maxPercentTaxAmount = TownySettings.getMaxNationTaxPercentAmount();
   private double conqueredTax = TownySettings.getDefaultNationConqueredTaxAmount();

   public Nation(String name) {
      super(name);
      this.setTaxes(TownySettings.getNationDefaultTax());
      this.setBoard(TownySettings.getNationDefaultBoard());
      this.setOpen(TownySettings.getNationDefaultOpen());
   }

   public boolean equals(Object other) {
      if (other == this) {
         return true;
      } else if (other instanceof Nation) {
         Nation otherNation = (Nation)other;
         return this.getName().equals(otherNation.getName());
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.getUUID(), this.getName()});
   }

   public void addAlly(Nation nation) {
      if (!this.hasAlly(nation)) {
         this.removeEnemy(nation);
         this.getAllies().add(nation);
      }

   }

   public boolean removeAlly(Nation nation) {
      return !this.hasAlly(nation) ? false : this.getAllies().remove(nation);
   }

   public boolean removeAllAllies() {
      Iterator var1 = (new ArrayList(this.getAllies())).iterator();

      while(var1.hasNext()) {
         Nation ally = (Nation)var1.next();
         this.removeAlly(ally);
         ally.removeAlly(this);
      }

      return this.getAllies().isEmpty();
   }

   public boolean hasAlly(Nation nation) {
      return this.getAllies().contains(nation);
   }

   public boolean hasMutualAlly(Nation nation) {
      return this.getAllies().contains(nation) && nation.getAllies().contains(this);
   }

   public void addEnemy(Nation nation) {
      if (!this.hasEnemy(nation)) {
         this.removeAlly(nation);
         this.getEnemies().add(nation);
      }

   }

   public boolean removeEnemy(Nation nation) {
      return !this.hasEnemy(nation) ? false : this.getEnemies().remove(nation);
   }

   public boolean removeAllEnemies() {
      Iterator var1 = (new ArrayList(this.getEnemies())).iterator();

      while(var1.hasNext()) {
         Nation enemy = (Nation)var1.next();
         this.removeEnemy(enemy);
         enemy.removeEnemy(this);
      }

      return this.getEnemies().isEmpty();
   }

   public boolean hasEnemy(Nation nation) {
      return this.getEnemies().contains(nation);
   }

   public List<Town> getTowns() {
      return Collections.unmodifiableList(this.towns);
   }

   public boolean isKing(Resident resident) {
      return this.hasCapital() && this.getCapital().isMayor(resident);
   }

   public boolean hasCapital() {
      return this.getCapital() != null;
   }

   public boolean hasAssistant(Resident resident) {
      return this.getAssistants().contains(resident);
   }

   public boolean isCapital(Town town) {
      return town == this.getCapital();
   }

   public boolean hasTown(String name) {
      Iterator var2 = this.towns.iterator();

      Town town;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         town = (Town)var2.next();
      } while(!town.getName().equalsIgnoreCase(name));

      return true;
   }

   public boolean hasTown(Town town) {
      return this.towns.contains(town);
   }

   public void addTown(Town town) {
      this.towns.add(town);
   }

   public void forceSetCapital(Town capital) throws EmptyNationException {
      if (this.towns.isEmpty()) {
         throw new EmptyNationException(this);
      } else if (this.hasTown(capital)) {
         this.setCapital(capital);
      } else if (!this.findNewCapital()) {
         throw new EmptyNationException(this);
      }
   }

   public void setCapital(Town capital) {
      String var10000 = this.getName();
      TownyMessaging.sendDebugMsg("Nation " + var10000 + " has set a capital city of " + capital.getName());
      this.capital = capital;
      if (this.spawn != null && TownySettings.isNationSpawnOnlyAllowedInCapital() && !capital.isInsideTown(this.spawn)) {
         this.spawn = capital.spawnPosition();
      }

      try {
         TownyPerms.assignPermissions(capital.getMayor(), (Player)null);
      } catch (Exception var3) {
      }

      this.capital.save();
   }

   public Town getCapital() {
      return this.capital;
   }

   public boolean findNewCapital() {
      int numResidents = 0;
      Town tempCapital = null;
      Iterator var3 = this.getTowns().iterator();

      while(var3.hasNext()) {
         Town newCapital = (Town)var3.next();
         if (newCapital.getNumResidents() > numResidents) {
            tempCapital = newCapital;
            numResidents = newCapital.getNumResidents();
         }
      }

      if (tempCapital != null) {
         this.setCapital(tempCapital);
         return true;
      } else {
         return false;
      }
   }

   @NotNull
   public Location getSpawn() throws TownyException {
      if (this.spawn == null) {
         throw new TownyException(Translatable.of("msg_err_nation_has_not_set_a_spawn_location"));
      } else {
         return this.spawn.asLocation();
      }
   }

   @Nullable
   public Position spawnPosition() {
      return this.spawn;
   }

   public void setSpawn(@Nullable Location spawn) {
      this.spawnPosition(spawn == null ? null : Position.ofLocation(spawn));
   }

   public void spawnPosition(@Nullable Position spawn) {
      if (this.spawn != null) {
         TownyUniverse.getInstance().removeSpawnPoint(SpawnPointLocation.parsePos(this.spawn));
      }

      this.spawn = spawn;
      if (spawn != null) {
         TownyUniverse.getInstance().addSpawnPoint(new SpawnPoint(spawn, SpawnPoint.SpawnPointType.NATION_SPAWN));
      }

   }

   public List<Resident> getAssistants() {
      return (List)this.getResidents().stream().filter((assistant) -> {
         return assistant.hasNationRank("assistant");
      }).collect(Collectors.toList());
   }

   public void setEnemies(List<Nation> enemies) {
      this.enemies = enemies;
   }

   public List<Nation> getEnemies() {
      return this.enemies;
   }

   public void setAllies(List<Nation> allies) {
      this.allies = allies;
   }

   public List<Nation> getAllies() {
      return this.allies;
   }

   public boolean hasReachedMaximumAllies() {
      return NationUtil.hasReachedMaximumAllies(this);
   }

   public List<Nation> getMutualAllies() {
      List<Nation> result = new ArrayList();
      Iterator var2 = this.getAllies().iterator();

      while(var2.hasNext()) {
         Nation ally = (Nation)var2.next();
         if (ally.hasAlly(this)) {
            result.add(ally);
         }
      }

      return result;
   }

   public int getNumTowns() {
      return this.towns.size();
   }

   public int getNumResidents() {
      int numResidents = 0;

      Town town;
      for(Iterator var2 = this.getTowns().iterator(); var2.hasNext(); numResidents += town.getNumResidents()) {
         town = (Town)var2.next();
      }

      return numResidents;
   }

   public boolean canAddResidents(int additionalResidents) {
      return NationUtil.canAddTownsResidentCount(this, additionalResidents);
   }

   public boolean hasReachedMaxResidents() {
      return NationUtil.hasReachedMaximumResidents(this);
   }

   public boolean hasReachedMaxTowns() {
      return NationUtil.hasReachedMaximumTowns(this);
   }

   protected void removeTown(Town town) throws EmptyNationException {
      boolean isCapital = town.isCapital();
      this.remove(town);
      if (this.getNumTowns() == 0) {
         throw new EmptyNationException(this);
      } else {
         if (isCapital) {
            this.findNewCapital();
         }

         this.save();
      }
   }

   private void remove(Town town) {
      this.towns.remove(town);
   }

   private void removeAllTowns() {
      this.towns.clear();
   }

   public void setTaxes(double taxes) {
      this.taxes = Math.min(taxes, this.isTaxPercentage ? TownySettings.getMaxNationTaxPercent() : TownySettings.getMaxNationTax());
      if (this.taxes < 0.0D && !TownySettings.isNegativeNationTaxAllowed()) {
         this.taxes = TownySettings.getNationDefaultTax();
      }

   }

   public double getMaxPercentTaxAmount() {
      return this.maxPercentTaxAmount;
   }

   public void setMaxPercentTaxAmount(double maxPercentTaxAmount) {
      this.maxPercentTaxAmount = Math.min(maxPercentTaxAmount, TownySettings.getMaxNationTaxPercentAmount());
   }

   public void setTaxPercentage(boolean isPercentage) {
      this.isTaxPercentage = isPercentage;
      if (isPercentage && this.getTaxes() > 100.0D) {
         this.setTaxes(0.0D);
      }

   }

   public boolean isTaxPercentage() {
      return this.isTaxPercentage;
   }

   public void clear() {
      this.removeAllAllies();
      this.removeAllEnemies();
      this.removeAllTowns();
      this.capital = null;
   }

   /** @deprecated */
   @Deprecated
   public void removeOutOfRangeTowns() {
      ProximityUtil.removeOutOfRangeTowns(this);
   }

   /** @deprecated */
   @Deprecated
   public List<Town> gatherOutOfRangeTowns(List<Town> towns, Town capital) {
      return ProximityUtil.gatherOutOfRangeTowns(this);
   }

   public void setKing(Resident king) throws TownyException {
      if (!this.hasResident(king)) {
         throw new TownyException(Translatable.of("msg_err_king_not_in_nation"));
      } else if (!king.isMayor()) {
         throw new TownyException(Translatable.of("msg_err_new_king_notmayor"));
      } else {
         this.setCapital(king.getTown());
         this.save();
      }
   }

   public boolean hasResident(Resident resident) {
      Iterator var2 = this.getTowns().iterator();

      Town town;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         town = (Town)var2.next();
      } while(!town.hasResident(resident));

      return true;
   }

   public void collect(double amount) {
      if (TownyEconomyHandler.isActive()) {
         double bankCap = this.getBankCap();
         if (bankCap > 0.0D && amount + this.getAccount().getHoldingBalance() > bankCap) {
            TownyMessaging.sendPrefixedNationMessage(this, Translatable.of("msg_err_deposit_capped", bankCap));
            return;
         }

         this.getAccount().deposit(amount, (String)null);
      }

   }

   public List<Resident> getResidents() {
      List<Resident> out = new ArrayList();
      Iterator var2 = this.getTowns().iterator();

      while(var2.hasNext()) {
         Town town = (Town)var2.next();
         out.addAll(town.getResidents());
      }

      return out;
   }

   public List<String> getTreeString(int depth) {
      List<String> out = new ArrayList();
      out.add(String.format("%sNation (%s)", this.getTreeDepth(depth), this.getName()));
      out.add(String.format("%sCapital: %s", this.getTreeDepth(depth + 1), this.getCapital().getName()));
      List<Resident> assistants = this.getAssistants();
      if (!assistants.isEmpty()) {
         out.add(String.format("%sAssistants (%s): %s", this.getTreeDepth(depth + 1), assistants.size(), Arrays.toString(assistants.toArray(new Resident[0]))));
      }

      if (!this.getAllies().isEmpty()) {
         out.add(String.format("%sAllies (%s): %s", this.getTreeDepth(depth + 1), this.getAllies().size(), Arrays.toString(this.getAllies().toArray(new Nation[0]))));
      }

      if (!this.getEnemies().isEmpty()) {
         out.add(String.format("%sEnemies (%s): %s", this.getTreeDepth(depth + 1), this.getEnemies().size(), Arrays.toString(this.getEnemies().toArray(new Nation[0]))));
      }

      out.add(String.format("%sTowns (%s):", this.getTreeDepth(depth + 1), this.getTowns().size()));
      Iterator var4 = this.getTowns().iterator();

      while(var4.hasNext()) {
         Town town = (Town)var4.next();
         out.addAll(town.getTreeString(depth + 2));
      }

      return out;
   }

   public boolean hasResident(String name) {
      Iterator var2 = this.getTowns().iterator();

      Town town;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         town = (Town)var2.next();
      } while(!town.hasResident(name));

      return true;
   }

   public Collection<Resident> getOutlaws() {
      List<Resident> out = new ArrayList();
      Iterator var2 = this.getTowns().iterator();

      while(var2.hasNext()) {
         Town town = (Town)var2.next();
         out.addAll(town.getOutlaws());
      }

      return Collections.unmodifiableList(out);
   }

   public boolean hasValidUUID() {
      return this.uuid != null;
   }

   public void newSentAllyInvite(Invite invite) throws TooManyInvitesException {
      if (this.sentAllyInvites.size() <= InviteHandler.getSentAllyRequestsMaxAmount(this) - 1) {
         this.sentAllyInvites.add(invite);
      } else {
         throw new TooManyInvitesException(Translation.of("msg_err_nation_sent_too_many_requests"));
      }
   }

   public void deleteSentAllyInvite(Invite invite) {
      this.sentAllyInvites.remove(invite);
   }

   public List<Invite> getSentAllyInvites() {
      return Collections.unmodifiableList(this.sentAllyInvites);
   }

   public Collection<TownBlock> getTownBlocks() {
      List<TownBlock> townBlocks = new ArrayList();
      Iterator var2 = this.getTowns().iterator();

      while(var2.hasNext()) {
         Town town = (Town)var2.next();
         townBlocks.addAll(town.getTownBlocks());
      }

      return Collections.unmodifiableCollection(townBlocks);
   }

   public int getNumTownblocks() {
      return this.getTownBlocks().size();
   }

   public Resident getKing() {
      return this.capital.getMayor();
   }

   public boolean hasKing() {
      if (this.capital == null) {
         return false;
      } else {
         return this.capital.getMayor() != null;
      }
   }

   public String getFormattedName() {
      TownyObjectFormattedNameEvent event = new TownyObjectFormattedNameEvent(this, TownySettings.getNationPrefix(this), TownySettings.getNationPostfix(this));
      BukkitTools.fireEvent(event);
      String var10000 = event.getPrefix();
      return var10000 + this.getName().replace("_", " ") + event.getPostfix();
   }

   public void addMetaData(@NotNull CustomDataField<?> md) {
      this.addMetaData(md, true);
   }

   public void removeMetaData(@NotNull CustomDataField<?> md) {
      this.removeMetaData(md, true);
   }

   public World getWorld() {
      return this.hasCapital() && this.getCapital().hasWorld() ? BukkitTools.getWorld(this.getCapital().getHomeblockWorld().getName()) : (World)BukkitTools.getWorlds().get(0);
   }

   public String getBankAccountPrefix() {
      return ECONOMY_ACCOUNT_PREFIX;
   }

   public double getBankCap() {
      return TownySettings.getNationBankCap(this);
   }

   public boolean isAlliedWith(Nation nation) {
      return this.allies.contains(nation);
   }

   public void save() {
      TownyUniverse.getInstance().getDataSource().saveNation(this);
   }

   public int getNationZoneSize() {
      return !TownySettings.getNationZonesEnabled() ? 0 : this.getNationLevel().nationZonesSize();
   }

   public TownySettings.NationLevel getNationLevel() {
      return TownySettings.getNationLevel(this);
   }

   public int getLevelNumber() {
      int modifier = TownySettings.isNationLevelDeterminedByTownCount() ? this.getNumTowns() : this.getNumResidents();
      int nationLevelNumber = TownySettings.getNationLevelFromGivenInt(modifier);
      NationCalculateNationLevelNumberEvent ncnle = new NationCalculateNationLevelNumberEvent(this, nationLevelNumber);
      BukkitTools.fireEvent(ncnle);
      return ncnle.getNationLevelNumber();
   }

   @NotNull
   public Iterable<? extends Audience> audiences() {
      return (Iterable)TownyAPI.getInstance().getOnlinePlayers(this).stream().map((player) -> {
         return Towny.getAdventure().player(player);
      }).collect(Collectors.toSet());
   }

   public double getConqueredTax() {
      return this.conqueredTax;
   }

   public void setConqueredTax(double conqueredTax) {
      this.conqueredTax = Math.min(conqueredTax, TownySettings.getMaxNationConqueredTaxAmount());
   }

   @Internal
   public boolean exists() {
      return TownyUniverse.getInstance().hasNation(this.getName());
   }

   /** @deprecated */
   @Deprecated
   public int getLevel() {
      return this.getLevelNumber();
   }

   /** @deprecated */
   @Deprecated
   public int getMaxLevel() {
      return TownySettings.getConfigNationLevel().size();
   }

   /** @deprecated */
   @Deprecated
   public int getLevel(int populationSize) {
      return TownySettings.getNationLevelFromGivenInt(populationSize);
   }

   public void playerBroadCastMessageToNation(Player player, String message) {
      TownyMessaging.sendPrefixedNationMessage(this, Translatable.of("town_say_format", player.getName(), TownyComponents.stripClickTags(message)));
   }

   public List<Town> getSanctionedTowns() {
      return this.sanctionedTowns;
   }

   public boolean hasSanctionedTown(Town town) {
      return this.sanctionedTowns.contains(town);
   }

   public void addSanctionedTown(Town town) {
      if (!this.sanctionedTowns.contains(town)) {
         this.sanctionedTowns.add(town);
      }

   }

   public void removeSanctionedTown(Town town) {
      this.sanctionedTowns.remove(town);
   }

   public List<String> getSanctionedTownsForSaving() {
      return (List)this.sanctionedTowns.stream().map((t) -> {
         return t.getUUID().toString();
      }).collect(Collectors.toList());
   }

   public void loadSanctionedTowns(String[] tokens) {
      String[] var2 = tokens;
      int var3 = tokens.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String stringUUID = var2[var4];

         try {
            Town town = TownyAPI.getInstance().getTown(UUID.fromString(stringUUID));
            if (town != null) {
               this.sanctionedTowns.add(town);
            }
         } catch (IllegalArgumentException var7) {
         }
      }

   }
}
