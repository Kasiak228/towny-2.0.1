package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.object.economy.Account;

public interface EconomyHandler extends Nameable {
   Account getAccount();
}
