package com.palmergames.bukkit.towny.object;

import com.palmergames.adventure.text.format.NamedTextColor;
import com.palmergames.bukkit.config.CommentedConfiguration;
import com.palmergames.bukkit.config.ConfigNodes;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.TownBlockTypeRegisterEvent;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.Colors;
import com.palmergames.bukkit.util.ItemLists;
import com.palmergames.util.StringMgmt;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.Material;
import org.bukkit.Registry;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class TownBlockTypeHandler {
   private static final Map<String, TownBlockType> townBlockTypeMap = new ConcurrentHashMap();

   public static void initialize() {
      Map<String, TownBlockType> newData = new ConcurrentHashMap();
      Field[] var1 = TownBlockType.class.getFields();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         Field field = var1[var3];

         try {
            TownBlockType type = (TownBlockType)field.get((Object)null);
            newData.put(type.getName().toLowerCase(Locale.ROOT), type);
         } catch (Exception var6) {
         }
      }

      applyConfigSettings(newData);
      townBlockTypeMap.putAll(newData);
      BukkitTools.fireEvent(new TownBlockTypeRegisterEvent());
      Towny.getPlugin().getLogger().info(String.format("Config: Loaded %d townblock types: %s.", townBlockTypeMap.size(), StringMgmt.join((Collection)townBlockTypeMap.keySet(), ", ")));
   }

   public static void registerType(@NotNull TownBlockType type) throws TownyException {
      if (exists(type.getName())) {
         throw new TownyException(String.format("API: A type named '%s' is already registered!", type.getName()));
      } else {
         townBlockTypeMap.put(type.getName().toLowerCase(Locale.ROOT), type);
         Towny.getPlugin().getLogger().info(String.format("API: A new townblock type was registered: %s", type.getName()));
      }
   }

   public static Map<String, TownBlockType> getTypes() {
      return Collections.unmodifiableMap(townBlockTypeMap);
   }

   public static List<String> getTypeNames() {
      return new ArrayList(townBlockTypeMap.keySet());
   }

   @Nullable
   public static TownBlockType getType(@NotNull String typeName) {
      return (TownBlockType)townBlockTypeMap.get(typeName.toLowerCase(Locale.ROOT));
   }

   public static TownBlockType getTypeInternal(@NotNull String input) {
      try {
         int id = Integer.parseInt(input);
         return getType((String)TownBlockType.getLegacylookupmap().getOrDefault(id, "default"));
      } catch (NumberFormatException var2) {
         return getType(input);
      }
   }

   public static boolean exists(@NotNull String typeName) {
      return getType(typeName) != null;
   }

   private static void applyConfigSettings(Map<String, TownBlockType> newData) {
      List<Map<?, ?>> types = TownySettings.getConfig().getMapList("townblocktypes.types");
      Iterator var2 = types.iterator();

      while(var2.hasNext()) {
         Map<?, ?> genericType = (Map)var2.next();
         String name = "unknown type";

         try {
            name = String.valueOf(genericType.get("name"));
            double cost = parseDouble(genericType.getOrDefault("cost", 0.0D).toString());
            double tax = parseDouble(genericType.getOrDefault("tax", 0.0D).toString());
            String mapKey = String.valueOf(genericType.getOrDefault("mapKey", "+"));
            String colourName = String.valueOf(genericType.getOrDefault("colour", ""));
            NamedTextColor colour = colourName.isEmpty() ? null : Colors.toNamedTextColor(colourName);
            Set<Material> itemUseIds = loadMaterialList("itemUseIds", String.valueOf(genericType.getOrDefault("itemUseIds", "")), name);
            Set<Material> switchIds = loadMaterialList("switchIds", String.valueOf(genericType.getOrDefault("switchIds", "")), name);
            Set<Material> allowedBlocks = loadMaterialList("allowedBlocks", String.valueOf(genericType.getOrDefault("allowedBlocks", "")), name);
            TownBlockType townBlockType = (TownBlockType)newData.get(name.toLowerCase(Locale.ROOT));
            TownBlockData data;
            if (townBlockType == null) {
               data = new TownBlockData();
               townBlockType = new TownBlockType(name, data);
            } else {
               data = townBlockType.getData();
            }

            data.setCost(cost);
            data.setTax(tax);
            data.setMapKey(mapKey);
            data.setColour(colour);
            data.setItemUseIds((Collection)itemUseIds);
            data.setSwitchIds((Collection)switchIds);
            data.setAllowedBlocks((Collection)allowedBlocks);
            newData.put(name.toLowerCase(Locale.ROOT), townBlockType);
         } catch (Exception var18) {
            Towny.getPlugin().getLogger().log(Level.WARNING, String.format("Config: Error while loading townblock type '%s', skipping...", name), var18);
         }
      }

   }

   private static Set<Material> loadMaterialList(String listName, String materialList, String typeName) {
      if (!materialList.isEmpty()) {
         Set<Material> set = new HashSet();
         String[] var4 = materialList.split(",");
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            String materialName = var4[var6];
            if (ItemLists.GROUPS.contains(materialName)) {
               set.addAll(ItemLists.getGrouping(materialName));
            } else {
               Material material = matchMaterial(materialName, listName, typeName);
               if (material != null) {
                  set.add(material);
               }
            }
         }

         return set;
      } else {
         return new HashSet();
      }
   }

   @Nullable
   private static Material matchMaterial(String materialName, String listName, String typeName) {
      Material material = (Material)BukkitTools.matchRegistry(Registry.MATERIAL, materialName);
      if (material == null) {
         TownyMessaging.sendDebugMsg(String.format("Could not find a material named '%s' while loading the " + listName + " list for the %s type.", materialName, typeName));
      }

      return material;
   }

   private static double parseDouble(String string) {
      try {
         return Double.parseDouble(string);
      } catch (NullPointerException | NumberFormatException var2) {
         return 0.0D;
      }
   }

   private TownBlockTypeHandler() {
   }

   public static class Migrator {
      private static final Set<TownBlockTypeHandler.Migrator.Migration> migrations = new HashSet();

      public static void checkForLegacyOptions(CommentedConfiguration config) {
         if (!config.contains(ConfigNodes.TOWNBLOCKTYPES_TYPES.getRoot())) {
            double shopCost = TownBlockTypeHandler.parseDouble(config.getString("economy.plot_type_costs.set_commercial"));
            double arenaCost = TownBlockTypeHandler.parseDouble(config.getString("economy.plot_type_costs.set_arena"));
            double embassyCost = TownBlockTypeHandler.parseDouble(config.getString("economy.plot_type_costs.set_embassy"));
            double wildsCost = TownBlockTypeHandler.parseDouble(config.getString("economy.plot_type_costs.set_wilds"));
            double innCost = TownBlockTypeHandler.parseDouble(config.getString("economy.plot_type_costs.set_inn"));
            double jailCost = TownBlockTypeHandler.parseDouble(config.getString("economy.plot_type_costs.set_jail"));
            double farmCost = TownBlockTypeHandler.parseDouble(config.getString("economy.plot_type_costs.set_farm"));
            double bankCost = TownBlockTypeHandler.parseDouble(config.getString("economy.plot_type_costs.set_bank"));
            String farmPlotBlocks = config.getString("global_town_settings.farm_plot_allow_blocks", TownySettings.getDefaultFarmblocks());
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("shop", "cost", shopCost));
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("arena", "cost", arenaCost));
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("embassy", "cost", embassyCost));
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("wilds", "cost", wildsCost));
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("inn", "cost", innCost));
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("jail", "cost", jailCost));
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("farm", "cost", farmCost));
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("farm", "allowedBlocks", farmPlotBlocks));
            migrations.add(new TownBlockTypeHandler.Migrator.Migration("bank", "cost", bankCost));
         }
      }

      public static void migrate() {
         if (!migrations.isEmpty()) {
            List<Map<?, ?>> mapList = TownySettings.getConfig().getMapList("townblocktypes.types");
            Iterator var1 = migrations.iterator();

            while(var1.hasNext()) {
               TownBlockTypeHandler.Migrator.Migration migration = (TownBlockTypeHandler.Migrator.Migration)var1.next();
               Iterator var3 = mapList.iterator();

               while(var3.hasNext()) {
                  Map<?, ?> map = (Map)var3.next();
                  if (map.get("name").toString().equalsIgnoreCase(migration.type())) {
                     map.put(migration.key(), migration.value());
                  }
               }
            }

            TownySettings.getConfig().set("townblocktypes.types", mapList);
            TownySettings.getConfig().save();
            migrations.clear();
         }
      }

      private static record Migration(String type, String key, Object value) {
         private Migration(String type, String key, Object value) {
            this.type = type;
            this.key = key;
            this.value = value;
         }

         public String type() {
            return this.type;
         }

         public String key() {
            return this.key;
         }

         public Object value() {
            return this.value;
         }
      }
   }
}
