package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownyUniverse;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.jetbrains.annotations.Nullable;

public class PlotGroup extends ObjectGroup implements TownBlockOwner, Savable {
   private Resident resident = null;
   private List<TownBlock> townBlocks;
   private double price = -1.0D;
   private Town town;
   private TownyPermission permissions;
   private Set<Resident> trustedResidents = new HashSet();
   private Map<Resident, PermissionData> permissionOverrides = new HashMap();

   public PlotGroup(UUID id, String name, Town town) {
      super(id, name);
      this.town = town;
   }

   public String toString() {
      String var10000 = super.toString();
      return var10000 + "," + this.getTown().toString() + "," + this.getPrice();
   }

   public boolean exists() {
      return this.town != null && this.town.exists() && this.town.hasPlotGroupName(this.getName());
   }

   public void setName(String name) {
      if (this.getName() == null) {
         super.setName(name);
      } else {
         String oldName = this.getName();
         super.setName(name);
         this.town.renamePlotGroup(oldName, this);
      }

   }

   public void setTown(Town town) {
      this.town = town;

      try {
         town.addPlotGroup(this);
      } catch (Exception var3) {
         TownyMessaging.sendErrorMsg(var3.getMessage());
      }

   }

   public Town getTown() {
      return this.town;
   }

   public String toModeString() {
      return "Group{" + this.toString() + "}";
   }

   public double getPrice() {
      return this.price;
   }

   public void setResident(Resident resident) {
      if (this.hasResident()) {
         this.resident = resident;
      }

   }

   @Nullable
   public Resident getResident() {
      return this.resident;
   }

   public boolean hasResident() {
      return this.resident != null;
   }

   public void addTownBlock(TownBlock townBlock) {
      if (this.townBlocks == null) {
         this.townBlocks = new ArrayList();
      }

      this.townBlocks.add(townBlock);
   }

   public void removeTownBlock(TownBlock townBlock) {
      if (this.townBlocks != null) {
         this.townBlocks.remove(townBlock);
      }

   }

   public void setTownblocks(List<TownBlock> townBlocks) {
      this.townBlocks = townBlocks;
   }

   public Collection<TownBlock> getTownBlocks() {
      return (Collection)(this.townBlocks == null ? Collections.emptyList() : Collections.unmodifiableCollection(this.townBlocks));
   }

   public boolean hasTownBlocks() {
      return this.townBlocks != null && !this.townBlocks.isEmpty();
   }

   public boolean hasTownBlock(TownBlock townBlock) {
      return this.townBlocks != null && this.townBlocks.contains(townBlock);
   }

   public void setPrice(double price) {
      this.price = price;
   }

   public void addPlotPrice(double pPrice) {
      if (this.getPrice() == -1.0D) {
         this.price = pPrice;
      } else {
         this.price += pPrice;
      }
   }

   public void setPermissions(String line) {
      this.permissions.load(line);
   }

   public TownyPermission getPermissions() {
      return this.permissions;
   }

   public void setPermissions(TownyPermission permissions) {
      this.permissions = permissions;
   }

   public TownBlockType getTownBlockType() {
      return ((TownBlock)this.townBlocks.get(0)).getType();
   }

   public void save() {
      TownyUniverse.getInstance().getDataSource().savePlotGroup(this);
   }

   public void setTrustedResidents(Set<Resident> trustedResidents) {
      this.trustedResidents = new HashSet(trustedResidents);
   }

   public Set<Resident> getTrustedResidents() {
      return this.trustedResidents;
   }

   public void setPermissionOverrides(Map<Resident, PermissionData> permissionOverrides) {
      this.permissionOverrides = new HashMap(permissionOverrides);
   }

   public Map<Resident, PermissionData> getPermissionOverrides() {
      return this.permissionOverrides;
   }

   public boolean hasTrustedResident(Resident resident) {
      return this.trustedResidents.contains(resident);
   }

   public void addTrustedResident(Resident resident) {
      Iterator var2 = this.townBlocks.iterator();

      while(var2.hasNext()) {
         TownBlock townBlock = (TownBlock)var2.next();
         if (!townBlock.hasTrustedResident(resident)) {
            townBlock.addTrustedResident(resident);
            townBlock.save();
         }
      }

      this.trustedResidents.add(resident);
   }

   public void removeTrustedResident(Resident resident) {
      if (this.hasTrustedResident(resident)) {
         this.trustedResidents.remove(resident);
         Iterator var2 = this.townBlocks.iterator();

         while(var2.hasNext()) {
            TownBlock townBlock = (TownBlock)var2.next();
            if (townBlock.hasTrustedResident(resident)) {
               townBlock.removeTrustedResident(resident);
               townBlock.save();
            }
         }

      }
   }

   public void putPermissionOverride(Resident resident, PermissionData permissionData) {
      this.permissionOverrides.put(resident, permissionData);
      Iterator var3 = this.townBlocks.iterator();

      while(var3.hasNext()) {
         TownBlock townBlock = (TownBlock)var3.next();
         townBlock.getPermissionOverrides().put(resident, permissionData);
         townBlock.save();
      }

   }

   public void removePermissionOverride(Resident resident) {
      if (this.permissionOverrides.containsKey(resident)) {
         this.permissionOverrides.remove(resident);
         Iterator var2 = this.townBlocks.iterator();

         while(var2.hasNext()) {
            TownBlock townBlock = (TownBlock)var2.next();
            if (townBlock.getPermissionOverrides().containsKey(resident)) {
               townBlock.getPermissionOverrides().remove(resident);
               townBlock.save();
            }
         }

      }
   }

   public int getMinTownMembershipDays() {
      return this.hasTownBlocks() ? ((TownBlock)this.townBlocks.get(0)).getMinTownMembershipDays() : -1;
   }

   public int getMaxTownMembershipDays() {
      return this.hasTownBlocks() ? ((TownBlock)this.townBlocks.get(0)).getMaxTownMembershipDays() : -1;
   }
}
