package com.palmergames.bukkit.towny.object;

public interface Savable {
   void save();
}
