package com.palmergames.bukkit.towny.object.map;

import com.palmergames.adventure.text.TextComponent;
import com.palmergames.bukkit.towny.object.WorldCoord;

public class TownyMapData {
   private final WorldCoord worldCoord;
   private final long time;
   private final String symbol;
   private final TextComponent hoverText;
   private final String clickCommand;

   public TownyMapData(WorldCoord worldCoord, String symbol, TextComponent hoverText, String clickCommand) {
      this.worldCoord = worldCoord;
      this.time = System.currentTimeMillis();
      this.symbol = symbol;
      this.hoverText = hoverText;
      this.clickCommand = clickCommand;
   }

   public WorldCoord getWorldCoord() {
      return this.worldCoord;
   }

   public long getTime() {
      return this.time;
   }

   public String getSymbol() {
      return this.symbol;
   }

   public TextComponent getHoverText() {
      return this.hoverText;
   }

   public String getClickCommand() {
      return this.clickCommand;
   }

   public boolean isOld() {
      return System.currentTimeMillis() - this.getTime() > 30000L;
   }
}
