package com.palmergames.bukkit.towny.object;

public interface Nameable {
   String getName();

   default String getFormattedName() {
      return this.getName().replace('_', ' ');
   }
}
