package com.palmergames.bukkit.towny.object;

import org.jetbrains.annotations.Nullable;

public interface SpawnPosition {
   void spawnPosition(@Nullable Position var1);

   @Nullable
   Position spawnPosition();
}
