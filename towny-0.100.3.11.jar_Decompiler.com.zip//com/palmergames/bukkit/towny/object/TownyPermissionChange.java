package com.palmergames.bukkit.towny.object;

public class TownyPermissionChange {
   private final Object[] args;
   private final TownyPermissionChange.Action changeAction;
   private final boolean changeValue;

   public TownyPermissionChange(TownyPermissionChange.Action changeAction, boolean changeValue, Object... args) {
      this.changeAction = changeAction;
      this.changeValue = changeValue;
      this.args = args;
   }

   public TownyPermissionChange.Action getChangeAction() {
      return this.changeAction;
   }

   public boolean getChangeValue() {
      return this.changeValue;
   }

   public Object[] getArgs() {
      return this.args;
   }

   public static enum Action {
      ALL_PERMS,
      SINGLE_PERM,
      PERM_LEVEL,
      ACTION_TYPE,
      RESET;

      // $FF: synthetic method
      private static TownyPermissionChange.Action[] $values() {
         return new TownyPermissionChange.Action[]{ALL_PERMS, SINGLE_PERM, PERM_LEVEL, ACTION_TYPE, RESET};
      }
   }
}
