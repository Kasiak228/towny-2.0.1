package com.palmergames.bukkit.towny.object.spawnlevel;

public enum SpawnLevel {
   TRUE,
   FALSE,
   WAR,
   PEACE;

   // $FF: synthetic method
   private static SpawnLevel[] $values() {
      return new SpawnLevel[]{TRUE, FALSE, WAR, PEACE};
   }
}
