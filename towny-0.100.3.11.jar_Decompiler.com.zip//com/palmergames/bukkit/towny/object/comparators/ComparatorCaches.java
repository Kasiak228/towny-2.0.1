package com.palmergames.bukkit.towny.object.comparators;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.palmergames.adventure.text.Component;
import com.palmergames.adventure.text.event.ClickEvent;
import com.palmergames.adventure.text.event.HoverEvent;
import com.palmergames.adventure.text.format.NamedTextColor;
import com.palmergames.adventure.text.format.TextColor;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyFormatter;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.nation.DisplayedNationsListSortEvent;
import com.palmergames.bukkit.towny.event.nation.NationListDisplayedNumOnlinePlayersCalculationEvent;
import com.palmergames.bukkit.towny.event.nation.NationListDisplayedNumResidentsCalculationEvent;
import com.palmergames.bukkit.towny.event.nation.NationListDisplayedNumTownBlocksCalculationEvent;
import com.palmergames.bukkit.towny.event.nation.NationListDisplayedNumTownsCalculationEvent;
import com.palmergames.bukkit.towny.event.town.TownListDisplayedNumResidentsCalculationEvent;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.Pair;
import com.palmergames.util.StringMgmt;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.stream.Collectors;
import org.jetbrains.annotations.NotNull;

public class ComparatorCaches {
   private static final LoadingCache<ComparatorType, List<Pair<UUID, Component>>> townCompCache;
   private static final LoadingCache<ComparatorType, List<Pair<UUID, Component>>> nationCompCache;

   public static List<Pair<UUID, Component>> getTownListCache(ComparatorType compType) {
      try {
         return (List)townCompCache.get(compType);
      } catch (ExecutionException var2) {
         Towny.getPlugin().getLogger().log(Level.WARNING, "exception occurred while updating town comparator cache", var2);
         return new ArrayList();
      }
   }

   public static List<Pair<UUID, Component>> getNationListCache(ComparatorType compType) {
      try {
         return (List)nationCompCache.get(compType);
      } catch (ExecutionException var2) {
         Towny.getPlugin().getLogger().log(Level.WARNING, "exception occurred while updating nation comparator cache", var2);
         return new ArrayList();
      }
   }

   private static List<Pair<UUID, Component>> gatherTownLines(ComparatorType compType) {
      List<Pair<UUID, Component>> output = new ArrayList();
      List<Town> towns = (List)TownyUniverse.getInstance().getTowns().stream().filter(Town::isVisibleOnTopLists).collect(Collectors.toList());
      towns.sort(compType.getComparator());
      Iterator var3 = towns.iterator();

      while(var3.hasNext()) {
         Town town = (Town)var3.next();
         Component townName = Component.text(StringMgmt.remUnderscore(town.getName()), (TextColor)NamedTextColor.AQUA).clickEvent(ClickEvent.runCommand("/towny:town spawn " + town + " -ignore"));
         String slug = "";
         int var8;
         switch(compType) {
         case BALANCE:
            slug = "(" + TownyEconomyHandler.getFormattedBalance(town.getAccount().getCachedBalance()) + ")";
            break;
         case TOWNBLOCKS:
            slug = "(" + town.getTownBlocks().size() + ")";
            break;
         case RUINED:
            var8 = getResidentCount(town);
            slug = "(" + var8 + ") " + (town.isRuined() ? Translation.of("msg_ruined") : "");
            break;
         case BANKRUPT:
            var8 = getResidentCount(town);
            slug = "(" + var8 + ") " + (town.isBankrupt() ? Translation.of("msg_bankrupt") : "");
            break;
         case ONLINE:
            var8 = TownyAPI.getInstance().getOnlinePlayersInTown(town).size();
            slug = "(" + var8 + ")";
            break;
         case FOUNDED:
            if (town.getRegistered() != 0L) {
               SimpleDateFormat var10000 = TownyFormatter.registeredFormat;
               slug = "(" + var10000.format(town.getRegistered()) + ")";
            }
            break;
         case UPKEEP:
            slug = "(" + TownyEconomyHandler.getFormattedBalance(TownySettings.getTownUpkeepCost(town)) + ")";
            break;
         default:
            slug = "(" + getResidentCount(town) + ")";
         }

         townName = townName.append((Component)Component.text(" - ", (TextColor)NamedTextColor.DARK_GRAY)).append((Component)Component.text(slug, (TextColor)NamedTextColor.AQUA));
         if (town.isOpen()) {
            townName = townName.append((Component)Component.space()).append(Translatable.of("status_title_open").component());
         }

         Translatable spawnCost = Translatable.of("msg_spawn_cost_free");
         if (TownyEconomyHandler.isActive()) {
            spawnCost = Translatable.of("msg_spawn_cost", TownyEconomyHandler.getFormattedBalance(town.getSpawnCost()));
         }

         townName = townName.hoverEvent(HoverEvent.showText(Translatable.of("msg_click_spawn", town).append("\n").append(spawnCost).component()));
         output.add(Pair.pair(town.getUUID(), townName));
      }

      return output;
   }

   private static int getResidentCount(Town town) {
      TownListDisplayedNumResidentsCalculationEvent resCountEvent = new TownListDisplayedNumResidentsCalculationEvent(town.getResidents().size(), town);
      BukkitTools.fireEvent(resCountEvent);
      return resCountEvent.getDisplayedValue();
   }

   private static List<Pair<UUID, Component>> gatherNationLines(ComparatorType compType) {
      List<Pair<UUID, Component>> output = new ArrayList();
      List<Nation> nations = new ArrayList(TownyUniverse.getInstance().getNations());
      nations.sort(compType.getComparator());
      DisplayedNationsListSortEvent nationListSortEvent = new DisplayedNationsListSortEvent(nations, compType);
      BukkitTools.fireEvent(nationListSortEvent);
      List<Nation> nations = nationListSortEvent.getNations();
      Iterator var4 = nations.iterator();

      while(var4.hasNext()) {
         Nation nation = (Nation)var4.next();
         Component nationName = Component.text(StringMgmt.remUnderscore(nation.getName()), (TextColor)NamedTextColor.AQUA).clickEvent(ClickEvent.runCommand("/towny:nation spawn " + nation + " -ignore"));
         String slug = "";
         switch(compType) {
         case BALANCE:
            slug = TownyEconomyHandler.getFormattedBalance(nation.getAccount().getCachedBalance());
            break;
         case TOWNBLOCKS:
            int rawNumTownsBlocks = nation.getTownBlocks().size();
            NationListDisplayedNumTownBlocksCalculationEvent tbEvent = new NationListDisplayedNumTownBlocksCalculationEvent(nation, rawNumTownsBlocks);
            BukkitTools.fireEvent(tbEvent);
            slug = tbEvent.getDisplayedValue().makeConcatWithConstants<invokedynamic>(tbEvent.getDisplayedValue());
            break;
         case RUINED:
         case BANKRUPT:
         default:
            int rawNumResidents = nation.getResidents().size();
            NationListDisplayedNumResidentsCalculationEvent rEvent = new NationListDisplayedNumResidentsCalculationEvent(nation, rawNumResidents);
            BukkitTools.fireEvent(rEvent);
            slug = rEvent.getDisplayedValue().makeConcatWithConstants<invokedynamic>(rEvent.getDisplayedValue());
            break;
         case ONLINE:
            int rawNumOnlinePlayers = TownyAPI.getInstance().getOnlinePlayersInNation(nation).size();
            NationListDisplayedNumOnlinePlayersCalculationEvent opEvent = new NationListDisplayedNumOnlinePlayersCalculationEvent(nation, rawNumOnlinePlayers);
            BukkitTools.fireEvent(opEvent);
            slug = opEvent.getDisplayedValue().makeConcatWithConstants<invokedynamic>(opEvent.getDisplayedValue());
            break;
         case FOUNDED:
            if (nation.getRegistered() != 0L) {
               slug = TownyFormatter.registeredFormat.format(nation.getRegistered());
            }
            break;
         case UPKEEP:
            slug = TownyEconomyHandler.getFormattedBalance(TownySettings.getNationUpkeepCost(nation));
            break;
         case TOWNS:
            int rawNumTowns = nation.getTowns().size();
            NationListDisplayedNumTownsCalculationEvent tEvent = new NationListDisplayedNumTownsCalculationEvent(nation, rawNumTowns);
            BukkitTools.fireEvent(tEvent);
            slug = tEvent.getDisplayedValue().makeConcatWithConstants<invokedynamic>(tEvent.getDisplayedValue());
         }

         nationName = nationName.append((Component)Component.text(" - ", (TextColor)NamedTextColor.DARK_GRAY)).append((Component)Component.text("(" + slug + ")", (TextColor)NamedTextColor.AQUA));
         if (nation.isOpen()) {
            nationName = nationName.append((Component)Component.space()).append(Translatable.of("status_title_open").component());
         }

         Translatable spawnCost = Translatable.of("msg_spawn_cost_free");
         if (TownyEconomyHandler.isActive()) {
            spawnCost = Translatable.of("msg_spawn_cost", TownyEconomyHandler.getFormattedBalance(nation.getSpawnCost()));
         }

         nationName = nationName.hoverEvent(HoverEvent.showText(Translatable.of("msg_click_spawn", nation).append("\n").append(spawnCost).component()));
         output.add(Pair.pair(nation.getUUID(), nationName));
      }

      return output;
   }

   static {
      townCompCache = CacheBuilder.newBuilder().expireAfterWrite(10L, TimeUnit.MINUTES).build(new CacheLoader<ComparatorType, List<Pair<UUID, Component>>>() {
         @NotNull
         public List<Pair<UUID, Component>> load(@NotNull ComparatorType compType) {
            return ComparatorCaches.gatherTownLines(compType);
         }
      });
      nationCompCache = CacheBuilder.newBuilder().expireAfterWrite(10L, TimeUnit.MINUTES).build(new CacheLoader<ComparatorType, List<Pair<UUID, Component>>>() {
         @NotNull
         public List<Pair<UUID, Component>> load(@NotNull ComparatorType compType) {
            return ComparatorCaches.gatherNationLines(compType);
         }
      });
   }
}
