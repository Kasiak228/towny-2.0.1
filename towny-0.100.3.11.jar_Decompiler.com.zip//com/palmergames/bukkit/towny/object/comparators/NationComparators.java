package com.palmergames.bukkit.towny.object.comparators;

import com.palmergames.bukkit.towny.object.Nation;
import java.util.Collections;
import java.util.Comparator;

public class NationComparators {
   public static final Comparator<Nation> BY_NUM_TOWNS = Collections.reverseOrder(Comparator.comparingInt((nation) -> {
      return nation.getTowns().size();
   }));
}
