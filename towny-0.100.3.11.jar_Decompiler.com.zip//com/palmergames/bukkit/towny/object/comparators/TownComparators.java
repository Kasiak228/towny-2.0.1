package com.palmergames.bukkit.towny.object.comparators;

import com.palmergames.bukkit.towny.object.Town;
import java.util.Comparator;

public class TownComparators {
   public static final Comparator<Town> BY_RUINED = (t1, t2) -> {
      if (t1.isRuined() && t2.isRuined()) {
         return t2.getResidents().size() - t1.getResidents().size();
      } else {
         return t2.isRuined() ? 1 : -1;
      }
   };
   public static final Comparator<Town> BY_BANKRUPT = (t1, t2) -> {
      if (t1.isBankrupt() && t2.isBankrupt()) {
         return t2.getResidents().size() - t1.getResidents().size();
      } else {
         return t2.isBankrupt() ? 1 : -1;
      }
   };
}
