package com.palmergames.bukkit.towny.object.jail;

public enum UnJailReason {
   LEFT_TOWN("Left Town"),
   PARDONED("Pardoned"),
   ESCAPE("Escaped"),
   BAIL("Paid Bail"),
   SENTENCE_SERVED("Sentence Served"),
   JAILBREAK("JailBreak"),
   JAIL_DELETED(""),
   OUT_OF_SPACE("Released For Space"),
   INSUFFICIENT_FUNDS("Insufficient Funds"),
   ADMIN("Freed by an Admin");

   private final String cause;

   private UnJailReason(String cause) {
      this.cause = cause;
   }

   public String getCause() {
      return this.cause;
   }

   // $FF: synthetic method
   private static UnJailReason[] $values() {
      return new UnJailReason[]{LEFT_TOWN, PARDONED, ESCAPE, BAIL, SENTENCE_SERVED, JAILBREAK, JAIL_DELETED, OUT_OF_SPACE, INSUFFICIENT_FUNDS, ADMIN};
   }
}
