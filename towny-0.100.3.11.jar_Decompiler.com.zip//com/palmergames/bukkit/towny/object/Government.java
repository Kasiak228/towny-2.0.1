package com.palmergames.bukkit.towny.object;

import com.palmergames.adventure.audience.ForwardingAudience;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.GovernmentTagChangeEvent;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.invites.Invite;
import com.palmergames.bukkit.towny.invites.InviteHandler;
import com.palmergames.bukkit.towny.invites.exceptions.TooManyInvitesException;
import com.palmergames.bukkit.towny.object.economy.AccountAuditor;
import com.palmergames.bukkit.towny.object.economy.BankAccount;
import com.palmergames.bukkit.towny.object.economy.BankEconomyHandler;
import com.palmergames.bukkit.towny.object.economy.GovernmentAccountAuditor;
import com.palmergames.bukkit.util.BookFactory;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.StringMgmt;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;

public abstract class Government extends TownyObject implements BankEconomyHandler, ResidentList, Inviteable, Identifiable, SpawnLocation, SpawnPosition, ForwardingAudience {
   protected UUID uuid;
   protected BankAccount account;
   protected Position spawn;
   protected String tag = "";
   protected String board = null;
   private final transient List<Invite> receivedInvites = new ArrayList();
   private final transient List<Invite> sentInvites = new ArrayList();
   private boolean isPublic = false;
   private boolean isOpen = false;
   protected boolean isNeutral = false;
   private long registered;
   private double spawnCost = TownySettings.getSpawnTravelCost();
   protected double taxes;
   protected String mapColorHexCode = "";
   private final AccountAuditor accountAuditor = new GovernmentAccountAuditor();
   private boolean hasActiveWar = false;

   protected Government(String name) {
      super(name);
   }

   public final List<Invite> getReceivedInvites() {
      return Collections.unmodifiableList(this.receivedInvites);
   }

   public final void newReceivedInvite(Invite invite) throws TooManyInvitesException {
      if (this.receivedInvites.size() <= InviteHandler.getReceivedInvitesMaxAmount(this) - 1) {
         this.receivedInvites.add(invite);
      } else {
         throw new TooManyInvitesException(String.format(Translation.of("msg_err_town_has_too_many_invites", this.getName())));
      }
   }

   public final void deleteReceivedInvite(Invite invite) {
      this.receivedInvites.remove(invite);
   }

   public final List<Invite> getSentInvites() {
      return Collections.unmodifiableList(this.sentInvites);
   }

   public final void newSentInvite(Invite invite) throws TooManyInvitesException {
      if (this.sentInvites.size() <= InviteHandler.getSentInvitesMaxAmount(this) - 1) {
         this.sentInvites.add(invite);
      } else {
         throw new TooManyInvitesException(Translation.of("msg_err_town_sent_too_many_invites"));
      }
   }

   public final void deleteSentInvite(Invite invite) {
      this.sentInvites.remove(invite);
   }

   public final void setBoard(String board) {
      this.board = board;
   }

   public String getBoard() {
      return this.board;
   }

   public final void setPublic(boolean isPublic) {
      this.isPublic = isPublic;
   }

   public final boolean isPublic() {
      return this.isPublic;
   }

   public final void setOpen(boolean isOpen) {
      this.isOpen = isOpen;
   }

   public final boolean isOpen() {
      return this.isOpen;
   }

   public final void setNeutral(boolean neutral) {
      this.isNeutral = neutral;
   }

   public boolean isNeutral() {
      return this.isNeutral;
   }

   public final void setRegistered(long registered) {
      this.registered = registered;
   }

   public final long getRegistered() {
      return this.registered;
   }

   public final void setSpawnCost(double spawnCost) {
      this.spawnCost = spawnCost;
   }

   public final double getSpawnCost() {
      return this.spawnCost;
   }

   public final void setTag(String text) {
      this.tag = text.toUpperCase();
      if (this.tag.matches(" ")) {
         this.tag = "";
      }

      BukkitTools.fireEvent(new GovernmentTagChangeEvent(this.tag, this));
   }

   public final String getTag() {
      return this.tag;
   }

   public final boolean hasTag() {
      return !this.tag.isEmpty();
   }

   public final synchronized void withdrawFromBank(Resident resident, int amount) throws TownyException {
      if (!TownyEconomyHandler.isActive()) {
         throw new TownyException(Translation.of("msg_err_no_economy"));
      } else if (!this.getAccount().payTo((double)amount, resident, "Withdraw by " + resident.getName())) {
         throw new TownyException(Translation.of("msg_err_no_money"));
      }
   }

   public final synchronized void depositToBank(Resident resident, int amount) throws TownyException {
      if (!TownyEconomyHandler.isActive()) {
         throw new TownyException(Translation.of("msg_err_no_economy"));
      } else if (!resident.getAccount().payTo((double)amount, (EconomyHandler)this, "Deposit from " + resident.getName())) {
         throw new TownyException(Translation.of("msg_insuf_funds"));
      }
   }

   public BankAccount getAccount() {
      if (this.account == null) {
         String accountName = StringMgmt.trimMaxLength(this.getBankAccountPrefix() + this.getName(), 32);
         World world = this.getWorld();
         this.account = new BankAccount(accountName, world, this);
         this.account.setAuditor(this.accountAuditor);
      }

      return this.account;
   }

   public abstract void setTaxes(double var1);

   public double getTaxes() {
      return this.taxes;
   }

   public abstract World getWorld();

   public UUID getUUID() {
      return this.uuid;
   }

   public void setUUID(UUID uuid) {
      this.uuid = uuid;
   }

   public String getMapColorHexCode() {
      return this.mapColorHexCode;
   }

   @Nullable
   public Color getMapColor() {
      try {
         return Color.decode("#" + this.getMapColorHexCode());
      } catch (NumberFormatException var2) {
         return null;
      }
   }

   public void setMapColorHexCode(String mapColorHexCode) {
      this.mapColorHexCode = mapColorHexCode;
   }

   public abstract Collection<TownBlock> getTownBlocks();

   public boolean hasActiveWar() {
      return this.hasActiveWar;
   }

   public void setActiveWar(boolean active) {
      this.hasActiveWar = active;
   }

   public abstract int getNationZoneSize();

   public void generateBankHistoryBook(Player player, int desiredPages) {
      int size = this.getAccount().getAuditor().getAuditHistory().size();
      if (size < 1) {
         TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_err_no_pages_to_display"));
      } else {
         if (desiredPages < 1) {
            desiredPages = 1;
         }

         desiredPages = Math.min(desiredPages, size);
         List<String> pages = new ArrayList(desiredPages);

         for(int i = 1; i <= desiredPages; ++i) {
            pages.add((String)this.getAccount().getAuditor().getAuditHistory().get(size - i));
         }

         player.openBook(BookFactory.makeBook("Bank History", this.getName(), (List)pages));
      }
   }
}
