package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.exceptions.initialization.TownyInitException;
import com.palmergames.util.FileMgmt;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.CopyOption;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.plugin.Plugin;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;

public class TranslationLoader {
   private final Path langFolderPath;
   private final Plugin plugin;
   private final Class<?> clazz;
   private boolean updateReferenceFiles = true;
   private Map<String, Map<String, String>> newTranslations = new HashMap();

   public TranslationLoader(Path langFolderPath, Plugin plugin, Class<?> clazz) {
      this.langFolderPath = langFolderPath;
      this.plugin = plugin;
      this.clazz = clazz;
   }

   public TranslationLoader(Plugin plugin) {
      this.langFolderPath = Paths.get(plugin.getDataFolder().getPath()).resolve("lang");
      this.plugin = plugin;
      this.clazz = plugin.getClass();
   }

   public void load() {
      this.newTranslations = new HashMap();
      this.loadTranslationsIntoMemory();
      this.loadOverrideFiles();
      this.loadGlobalFile();
      this.plugin.getLogger().info(String.format("Successfully loaded translations for %d languages.", this.newTranslations.keySet().size()));
   }

   public Map<String, Map<String, String>> getTranslations() {
      return this.newTranslations;
   }

   void setTranslations(Map<String, Map<String, String>> translations) {
      this.newTranslations = translations;
   }

   void loadTranslationsIntoMemory() {
      try {
         Files.createDirectories(this.langFolderPath.resolve("reference"));
      } catch (IOException var16) {
         throw new TownyInitException("Failed to create language reference folder.", TownyInitException.TownyError.LOCALIZATION, var16);
      }

      String defaultLangContent = null;
      if (this.updateReferenceFiles) {
         try {
            InputStream is = this.clazz.getResourceAsStream("/lang/en-US.yml");

            try {
               if (is != null) {
                  BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

                  try {
                     defaultLangContent = (String)reader.lines().collect(Collectors.joining("\n"));
                  } catch (Throwable var15) {
                     try {
                        reader.close();
                     } catch (Throwable var14) {
                        var15.addSuppressed(var14);
                     }

                     throw var15;
                  }

                  reader.close();
               }
            } catch (Throwable var20) {
               if (is != null) {
                  try {
                     is.close();
                  } catch (Throwable var13) {
                     var20.addSuppressed(var13);
                  }
               }

               throw var20;
            }

            if (is != null) {
               is.close();
            }
         } catch (IOException var21) {
         }
      }

      Iterator var22 = this.getLangFileNamesFromPlugin().iterator();

      while(var22.hasNext()) {
         String lang = (String)var22.next();

         try {
            InputStream is = this.clazz.getResourceAsStream("/lang/" + lang + ".yml");

            try {
               if (is == null) {
                  throw new TownyInitException("Could not find '/lang/" + lang + ".yml' in the JAR", TownyInitException.TownyError.LOCALIZATION);
               }

               BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

               try {
                  String content = (String)reader.lines().collect(Collectors.joining("\n"));
                  Map<String, Object> values = (Map)(new Yaml(new SafeConstructor(new LoaderOptions()))).load(content);
                  if (this.updateReferenceFiles) {
                     this.saveReferenceFile(lang, defaultLangContent, content, values);
                  }

                  lang = lang.replace("-", "_");
                  Map<String, String> translations = (Map)this.newTranslations.computeIfAbsent(lang, (k) -> {
                     return new HashMap();
                  });
                  Iterator var9 = values.entrySet().iterator();

                  while(var9.hasNext()) {
                     Entry<String, Object> entry = (Entry)var9.next();
                     translations.put(((String)entry.getKey()).toLowerCase(Locale.ROOT), String.valueOf(entry.getValue()));
                  }
               } catch (Throwable var17) {
                  try {
                     reader.close();
                  } catch (Throwable var12) {
                     var17.addSuppressed(var12);
                  }

                  throw var17;
               }

               reader.close();
            } catch (Throwable var18) {
               if (is != null) {
                  try {
                     is.close();
                  } catch (Throwable var11) {
                     var18.addSuppressed(var11);
                  }
               }

               throw var18;
            }

            if (is != null) {
               is.close();
            }
         } catch (Exception var19) {
            this.plugin.getLogger().log(Level.WARNING, "Unabled to read yaml file: '" + lang + ".yml' from within the " + this.plugin.getName() + ".jar.", var19);
         }
      }

   }

   private Set<String> getLangFileNamesFromPlugin() {
      HashSet lang = new HashSet();

      try {
         URL root = this.clazz.getResource("");
         if (root == null) {
            return lang;
         }

         FileSystem fs = FileSystems.newFileSystem(root.toURI(), Collections.emptyMap());

         try {
            Stream stream = Files.list(((Path)fs.getRootDirectories().iterator().next()).resolve("/lang"));

            try {
               Stream var10000 = stream.map(FileMgmt::getFileName).filter(TownySettings::isLanguageEnabled);
               Objects.requireNonNull(lang);
               var10000.forEach(lang::add);
            } catch (Throwable var9) {
               if (stream != null) {
                  try {
                     stream.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (stream != null) {
               stream.close();
            }
         } catch (Throwable var10) {
            if (fs != null) {
               try {
                  fs.close();
               } catch (Throwable var7) {
                  var10.addSuppressed(var7);
               }
            }

            throw var10;
         }

         if (fs != null) {
            fs.close();
         }
      } catch (IOException | URISyntaxException var11) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred while getting language file names from the plugin jar", var11);
      }

      return lang;
   }

   private void saveReferenceFile(String lang, String defaultLangContent, String content, Map<String, Object> translations) {
      Path langPath = this.langFolderPath.resolve("reference").resolve(lang + ".yml");

      try {
         if (!Files.exists(langPath, new LinkOption[0])) {
            Files.createFile(langPath);
         }

         if (defaultLangContent == null || lang.equals("en-US")) {
            Stream lines = Files.lines(langPath);

            try {
               if (!content.equals(lines.collect(Collectors.joining("\n")))) {
                  Files.writeString(langPath, content, new OpenOption[0]);
               }
            } catch (Throwable var13) {
               if (lines != null) {
                  try {
                     lines.close();
                  } catch (Throwable var12) {
                     var13.addSuppressed(var12);
                  }
               }

               throw var13;
            }

            if (lines != null) {
               lines.close();
            }

            return;
         }

         List<String> list = Arrays.asList(defaultLangContent.split("\n"));
         ListIterator iterator = list.listIterator();

         while(iterator.hasNext()) {
            String line = (String)iterator.next();
            if (line.contains(":")) {
               String key = line.substring(0, line.indexOf(":"));
               Object translated = translations.get(key);
               if (translated != null) {
                  String replace = String.valueOf(translated);
                  if (replace.contains("'")) {
                     replace = "\"" + replace + "\"";
                  } else {
                     replace = "'" + replace + "'";
                  }

                  iterator.set(key + ": " + replace);
               }
            }
         }

         Files.writeString(langPath, String.join("\n", list), new OpenOption[0]);
      } catch (IOException var14) {
         this.plugin.getLogger().log(Level.WARNING, "Failed to copy '/lang/" + lang + ".yml' from the JAR to '" + langPath.toAbsolutePath() + "' during a reference language file update.", var14);
      }

   }

   void loadOverrideFiles() {
      try {
         Path overrides = Files.createDirectories(this.langFolderPath.resolve("override"));
         Stream overrideStream = Files.list(overrides);

         label94: {
            label95: {
               try {
                  Iterator var3 = ((List)overrideStream.collect(Collectors.toList())).iterator();

                  while(var3.hasNext()) {
                     Path path = (Path)var3.next();
                     if (!FileMgmt.getExtension(path).equalsIgnoreCase("yml")) {
                        break label94;
                     }

                     String fileName = FileMgmt.getFileName(path);
                     if (fileName.equals("global") || !TownySettings.isLanguageEnabled(fileName)) {
                        break label95;
                     }

                     InputStream is = Files.newInputStream(path);

                     try {
                        Map<String, Object> values = (Map)(new Yaml(new SafeConstructor(new LoaderOptions()))).load(is);
                        String lang = fileName.replaceAll("-", "_");
                        Map<String, String> translations = (Map)this.newTranslations.computeIfAbsent(lang, (k) -> {
                           return new HashMap();
                        });
                        Iterator var10 = values.entrySet().iterator();

                        while(var10.hasNext()) {
                           Entry<String, Object> entry = (Entry)var10.next();
                           translations.put(((String)entry.getKey()).toLowerCase(Locale.ROOT), getTranslationValue(entry));
                        }
                     } catch (Throwable var14) {
                        if (is != null) {
                           try {
                              is.close();
                           } catch (Throwable var13) {
                              var14.addSuppressed(var13);
                           }
                        }

                        throw var14;
                     }

                     if (is != null) {
                        is.close();
                     }
                  }
               } catch (Throwable var15) {
                  if (overrideStream != null) {
                     try {
                        overrideStream.close();
                     } catch (Throwable var12) {
                        var15.addSuppressed(var12);
                     }
                  }

                  throw var15;
               }

               if (overrideStream != null) {
                  overrideStream.close();
               }

               return;
            }

            if (overrideStream != null) {
               overrideStream.close();
            }

            return;
         }

         if (overrideStream != null) {
            overrideStream.close();
         }

      } catch (IOException var16) {
         throw new TownyInitException("Failed to read language override folder.", TownyInitException.TownyError.LOCALIZATION, var16);
      }
   }

   private static String getTranslationValue(Entry<String, Object> entry) {
      if (((String)entry.getKey()).toLowerCase(Locale.ROOT).startsWith("msg_ptw_warning")) {
         String msg = String.valueOf(entry.getValue());
         Towny.getPlugin().getLogger().warning("Attempted to override an protected string. Skipped " + (String)entry.getKey());
         if (!msg.contains("Towny")) {
            String var2 = (String)entry.getKey();
            byte var3 = -1;
            switch(var2.hashCode()) {
            case -248913468:
               if (var2.equals("msg_ptw_warning_1")) {
                  var3 = 0;
               }
               break;
            case -248913467:
               if (var2.equals("msg_ptw_warning_2")) {
                  var3 = 1;
               }
               break;
            case -248913466:
               if (var2.equals("msg_ptw_warning_3")) {
                  var3 = 2;
               }
            }

            String var10000;
            switch(var3) {
            case 0:
               var10000 = "If you have paid any real-life money for these townblocks please understand: the server you play on is in violation of the Minecraft EULA and the Towny license.";
               break;
            case 1:
               var10000 = "The Towny team never intended for townblocks to be purchaseable with real money.";
               break;
            case 2:
               var10000 = "If you did pay real money you should consider playing on a Towny server that respects the wishes of the Towny Team.";
               break;
            default:
               throw new IllegalArgumentException("Unexpected value: " + (String)entry.getKey());
            }

            return var10000;
         } else {
            return msg;
         }
      } else {
         return String.valueOf(entry.getValue());
      }
   }

   void createReadmeFile() {
      try {
         InputStream resourceAsStream = this.clazz.getResourceAsStream("/README - Translations.txt");

         label69: {
            label75: {
               try {
                  if (resourceAsStream == null) {
                     break label75;
                  }

                  Path readmePath = this.langFolderPath.resolve("README - Translations.txt");
                  if (Files.exists(readmePath, new LinkOption[0])) {
                     break label69;
                  }

                  if (!FileMgmt.checkOrCreateFile(readmePath.toString())) {
                     throw new TownyInitException("Failed to touch '" + readmePath + "'.", TownyInitException.TownyError.LOCALIZATION);
                  }

                  try {
                     Files.copy(resourceAsStream, readmePath, new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
                  } catch (FileAlreadyExistsException var5) {
                  } catch (IOException var6) {
                     throw new TownyInitException("Failed to copy README - Translations.txt from the JAR to '" + readmePath + "'", TownyInitException.TownyError.LOCALIZATION, var6);
                  }
               } catch (Throwable var7) {
                  if (resourceAsStream != null) {
                     try {
                        resourceAsStream.close();
                     } catch (Throwable var4) {
                        var7.addSuppressed(var4);
                     }
                  }

                  throw var7;
               }

               if (resourceAsStream != null) {
                  resourceAsStream.close();
               }

               return;
            }

            if (resourceAsStream != null) {
               resourceAsStream.close();
            }

            return;
         }

         if (resourceAsStream != null) {
            resourceAsStream.close();
         }

      } catch (IOException var8) {
      }
   }

   void loadGlobalFile() {
      try {
         InputStream resourceAsStream = this.clazz.getResourceAsStream("/global.yml");

         label57: {
            try {
               if (resourceAsStream != null) {
                  Path globalYMLPath = this.langFolderPath.resolve("override").resolve("global.yml");
                  Path glitchedGlobalPath = this.langFolderPath.resolve("global.yml");
                  if (Files.exists(glitchedGlobalPath, new LinkOption[0])) {
                     Files.move(glitchedGlobalPath, globalYMLPath, StandardCopyOption.REPLACE_EXISTING);
                  }

                  if (!Files.exists(globalYMLPath, new LinkOption[0])) {
                     this.createGlobalYML(globalYMLPath, resourceAsStream);
                  }

                  Map<String, Object> globalOverrides = this.loadGlobalFile(globalYMLPath);
                  if (globalOverrides != null) {
                     this.overwriteKeysWithGlobalOverrides(globalOverrides);
                  }
                  break label57;
               }
            } catch (Throwable var6) {
               if (resourceAsStream != null) {
                  try {
                     resourceAsStream.close();
                  } catch (Throwable var5) {
                     var6.addSuppressed(var5);
                  }
               }

               throw var6;
            }

            if (resourceAsStream != null) {
               resourceAsStream.close();
            }

            return;
         }

         if (resourceAsStream != null) {
            resourceAsStream.close();
         }
      } catch (IOException var7) {
      }

   }

   private void createGlobalYML(Path globalYMLPath, InputStream resource) {
      if (!FileMgmt.checkOrCreateFile(globalYMLPath.toString())) {
         throw new TownyInitException("Failed to touch '" + globalYMLPath + "'.", TownyInitException.TownyError.LOCALIZATION);
      } else {
         try {
            if (resource == null) {
               throw new TownyInitException("Could not find global.yml in the JAR", TownyInitException.TownyError.LOCALIZATION);
            }

            Files.copy(resource, globalYMLPath, new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
         } catch (FileAlreadyExistsException var4) {
         } catch (IOException var5) {
            throw new TownyInitException("Failed to copy global.yml from the JAR to '" + globalYMLPath + "'", TownyInitException.TownyError.LOCALIZATION, var5);
         }

      }
   }

   private Map<String, Object> loadGlobalFile(Path globalYMLPath) {
      Object globalOverrides = new HashMap();

      try {
         InputStream is = Files.newInputStream(globalYMLPath);

         try {
            globalOverrides = (Map)(new Yaml(new SafeConstructor(new LoaderOptions()))).load(is);
         } catch (Throwable var7) {
            if (is != null) {
               try {
                  is.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (is != null) {
            is.close();
         }
      } catch (Exception var8) {
         this.plugin.getLogger().log(Level.WARNING, "An exception occurred while reading the global.yml file", var8);
      }

      return (Map)globalOverrides;
   }

   private void overwriteKeysWithGlobalOverrides(Map<String, Object> globalOverrides) {
      Iterator var2 = globalOverrides.entrySet().iterator();

      while(var2.hasNext()) {
         Entry<String, Object> entry = (Entry)var2.next();
         Iterator var4 = this.newTranslations.keySet().iterator();

         while(var4.hasNext()) {
            String lang = (String)var4.next();
            ((Map)this.newTranslations.get(lang)).put(((String)entry.getKey()).toLowerCase(Locale.ROOT), getTranslationValue(entry));
         }
      }

   }

   public void updateReferenceFiles(boolean update) {
      this.updateReferenceFiles = update;
   }
}
