package com.palmergames.bukkit.towny.object;

import com.google.common.base.Preconditions;
import com.palmergames.adventure.audience.Audience;
import com.palmergames.adventure.audience.ForwardingAudience;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.command.BaseCommand;
import com.palmergames.bukkit.towny.confirmations.Confirmation;
import com.palmergames.bukkit.towny.event.DeleteTownEvent;
import com.palmergames.bukkit.towny.event.TownAddResidentEvent;
import com.palmergames.bukkit.towny.event.TownRemoveResidentEvent;
import com.palmergames.bukkit.towny.event.TownyObjectFormattedNameEvent;
import com.palmergames.bukkit.towny.event.resident.ResidentToggleModeEvent;
import com.palmergames.bukkit.towny.event.town.TownPreRemoveResidentEvent;
import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.EmptyTownException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.invites.Invite;
import com.palmergames.bukkit.towny.invites.InviteHandler;
import com.palmergames.bukkit.towny.invites.InviteReceiver;
import com.palmergames.bukkit.towny.invites.exceptions.TooManyInvitesException;
import com.palmergames.bukkit.towny.object.economy.Account;
import com.palmergames.bukkit.towny.object.gui.SelectionGUI;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.metadata.BooleanDataField;
import com.palmergames.bukkit.towny.object.metadata.CustomDataField;
import com.palmergames.bukkit.towny.permissions.TownyPerms;
import com.palmergames.bukkit.towny.scheduling.ScheduledTask;
import com.palmergames.bukkit.towny.tasks.SetDefaultModes;
import com.palmergames.bukkit.towny.tasks.TeleportWarmupTimerTask;
import com.palmergames.bukkit.towny.utils.CombatUtil;
import com.palmergames.bukkit.towny.utils.MetaDataUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.Colors;
import com.palmergames.util.StringMgmt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;
import org.jetbrains.annotations.ApiStatus.Obsolete;

public class Resident extends TownyObject implements InviteReceiver, EconomyHandler, TownBlockOwner, Identifiable, ForwardingAudience.Single {
   private List<Resident> friends = new ArrayList();
   private UUID uuid = null;
   private Town town = null;
   private long lastOnline;
   private long registered;
   private long joinedTownAt;
   private boolean isNPC = false;
   private String title = "";
   private String surname = "";
   private String about = TownySettings.getDefaultResidentAbout();
   private final List<String> modes = new ArrayList();
   private transient Confirmation confirmation;
   private final transient List<Invite> receivedInvites = new ArrayList();
   private transient EconomyAccount account;
   private Jail jail = null;
   private int jailCell;
   private int jailHours;
   private double jailBail;
   private final List<String> townRanks = new ArrayList();
   private final List<String> nationRanks = new ArrayList();
   private List<TownBlock> townBlocks = new ArrayList();
   private final TownyPermission permissions = new TownyPermission();
   private ArrayList<Inventory> guiPages;
   private int guiPageNum = 0;
   private SelectionGUI.SelectionType guiSelectionType;
   private ScheduledTask respawnProtectionTask = null;
   private boolean respawnPickupWarningShown = false;
   private String plotGroupName = null;
   private String districtName = null;
   protected Resident.CachedTaxOwing cachedTaxOwing = null;

   public Resident(String name) {
      super(name);
      this.permissions.loadDefault(this);
   }

   public boolean equals(Object other) {
      if (other == this) {
         return true;
      } else if (other instanceof Resident) {
         Resident otherResident = (Resident)other;
         return this.getName().equals(otherResident.getName());
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.getUUID(), this.getName()});
   }

   public void setLastOnline(long lastOnline) {
      this.lastOnline = lastOnline;
   }

   public long getLastOnline() {
      return this.lastOnline;
   }

   public void setNPC(boolean isNPC) {
      this.isNPC = isNPC;
   }

   public boolean isNPC() {
      return this.isNPC;
   }

   public UUID getUUID() {
      return this.uuid;
   }

   public void setUUID(UUID uuid) {
      this.uuid = uuid;
   }

   public boolean hasUUID() {
      return this.uuid != null;
   }

   public Jail getJail() {
      return this.jail;
   }

   public void setJail(Jail jail) {
      this.jail = jail;
   }

   public boolean isJailed() {
      return this.jail != null;
   }

   public int getJailCell() {
      return this.jailCell;
   }

   public void setJailCell(int i) {
      if (this.jail.hasJailCell(i)) {
         this.jailCell = i;
      } else {
         this.jailCell = 0;
      }

   }

   public Town getJailTown() {
      return this.jail.getTown();
   }

   public boolean hasJailTown(String jailtown) {
      return this.getJailTown().getName().equalsIgnoreCase(jailtown);
   }

   public int getJailHours() {
      return this.jailHours;
   }

   public void setJailHours(Integer hours) {
      this.jailHours = hours;
   }

   public double getJailBailCost() {
      return this.jailBail;
   }

   public void setJailBailCost(double bail) {
      this.jailBail = bail;
   }

   public boolean hasJailTime() {
      return this.jailHours > 0;
   }

   public Location getJailSpawn() {
      return (Location)this.getJail().getJailCellLocations().get(this.getJailCell());
   }

   public String getPrimaryRankPrefix() {
      return TownyPerms.getResidentPrimaryRankPrefix(this);
   }

   public void setTitle(String title) {
      this.title = title.trim();
   }

   public String getTitle() {
      return this.title;
   }

   public boolean hasTitle() {
      return !this.title.isEmpty();
   }

   public void setSurname(String surname) {
      this.surname = surname.trim();
   }

   public String getSurname() {
      return this.surname;
   }

   public boolean hasSurname() {
      return !this.surname.isEmpty();
   }

   public void setAbout(@NotNull String about) {
      Preconditions.checkNotNull(about, "about");
      this.about = about;
   }

   @NotNull
   public String getAbout() {
      return this.about;
   }

   public boolean isKing() {
      return this.hasNation() && this.town.getNationOrNull().isKing(this);
   }

   public boolean isMayor() {
      return this.hasTown() && this.town.isMayor(this);
   }

   public boolean hasTown() {
      return this.town != null;
   }

   public boolean hasNation() {
      return this.hasTown() && this.town.hasNation();
   }

   public Town getTown() throws NotRegisteredException {
      if (this.hasTown()) {
         return this.town;
      } else {
         throw new NotRegisteredException(Translation.of("msg_err_resident_doesnt_belong_to_any_town"));
      }
   }

   @Nullable
   public Town getTownOrNull() {
      return this.town;
   }

   public void setTown(Town town) throws AlreadyRegisteredException {
      this.setTown(town, true);
   }

   public void setTown(Town town, boolean updateJoinedAt) throws AlreadyRegisteredException {
      if (this.town != town) {
         Towny.getPlugin().deleteCache(this);
         this.setTitle("");
         this.setSurname("");
         if (town == null) {
            this.town = null;
            this.updatePerms();
         } else {
            if (this.hasTown()) {
               town.addResidentCheck(this);
            }

            this.town = town;
            this.updatePerms();
            town.addResident(this);
            if (updateJoinedAt) {
               this.setJoinedTownAt(System.currentTimeMillis());
               BukkitTools.fireEvent(new TownAddResidentEvent(this, town));
            }

         }
      }
   }

   public void removeTown() {
      this.removeTown(false);
   }

   public void removeTown(boolean townDeleted) {
      if (this.hasTown()) {
         Town town = this.town;
         BukkitTools.fireEvent(new TownPreRemoveResidentEvent(this, town));
         Iterator var3 = town.getTownBlocks().iterator();

         while(var3.hasNext()) {
            TownBlock townBlock = (TownBlock)var3.next();
            if (townBlock.getType() != TownBlockType.EMBASSY && townBlock.hasResident(this) && townBlock.removeResident()) {
               this.townBlocks.remove(townBlock);
               townBlock.setPlotPrice(town.getPlotPrice());
               townBlock.setType(townBlock.getType());
               townBlock.save();
            }
         }

         BukkitTools.fireEvent(new TownRemoveResidentEvent(this, town));

         try {
            town.removeResident(this);
         } catch (EmptyTownException var6) {
            if (!townDeleted) {
               TownyMessaging.sendMsg(Translatable.of("msg_town_being_deleted_because_no_residents", town.getName()));
               TownyUniverse.getInstance().getDataSource().removeTown(town, DeleteTownEvent.Cause.NO_RESIDENTS, (CommandSender)null, false);
            }
         }

         try {
            this.setTown((Town)null);
         } catch (AlreadyRegisteredException var5) {
         }

         this.save();
         Towny.getPlugin().resetCache();
      }
   }

   public void setFriends(List<Resident> newFriends) {
      this.friends = newFriends;
   }

   public List<Resident> getFriends() {
      return Collections.unmodifiableList(this.friends);
   }

   public void removeFriend(Resident resident) {
      if (this.hasFriend(resident)) {
         this.friends.remove(resident);
      }

   }

   public boolean hasFriend(Resident resident) {
      return this.friends.contains(resident);
   }

   public void addFriend(Resident resident) {
      if (!this.hasFriend(resident) && !this.equals(resident) && !resident.isNPC()) {
         this.friends.add(resident);
      }
   }

   public void removeAllFriends() {
      this.friends.clear();
   }

   public void updatePerms() {
      this.townRanks.clear();
      this.nationRanks.clear();
      TownyPerms.assignPermissions(this, (Player)null);
   }

   public void updatePermsForNationRemoval() {
      this.nationRanks.clear();
      TownyPerms.assignPermissions(this, (Player)null);
   }

   public void setRegistered(long registered) {
      this.registered = registered;
   }

   public long getRegistered() {
      return this.registered;
   }

   public List<String> getTreeString(int depth) {
      List<String> out = new ArrayList();
      String var10001 = this.getTreeDepth(depth);
      out.add(var10001 + "Resident (" + this.getName() + ")");
      var10001 = this.getTreeDepth(depth + 1);
      out.add(var10001 + "Registered: " + this.getRegistered());
      var10001 = this.getTreeDepth(depth + 1);
      out.add(var10001 + "Last Online: " + this.getLastOnline());
      if (this.getFriends().size() > 0) {
         var10001 = this.getTreeDepth(depth + 1);
         out.add(var10001 + "Friends (" + this.getFriends().size() + "): " + Arrays.toString(this.getFriends().toArray(new Resident[0])));
      }

      return out;
   }

   /** @deprecated */
   @Deprecated
   public void clearTeleportRequest() {
   }

   /** @deprecated */
   @Deprecated
   public void setTeleportRequestTime() {
   }

   @Obsolete
   public long getTeleportRequestTime() {
      TeleportRequest request = TeleportWarmupTimerTask.getTeleportRequest(this);
      return request == null ? -1L : request.requestTime();
   }

   /** @deprecated */
   @Deprecated
   public void setTeleportDestination(Location spawnLoc) {
   }

   @Obsolete
   public Location getTeleportDestination() {
      TeleportRequest request = TeleportWarmupTimerTask.getTeleportRequest(this);
      return request == null ? null : request.destinationLocation();
   }

   /** @deprecated */
   @Deprecated
   public void setTeleportCooldown(int cooldown) {
   }

   @Obsolete
   public int getTeleportCooldown() {
      TeleportRequest request = TeleportWarmupTimerTask.getTeleportRequest(this);
      return request == null ? -1 : request.cooldown();
   }

   public boolean hasRequestedTeleport() {
      return TeleportWarmupTimerTask.hasTeleportRequest(this);
   }

   /** @deprecated */
   @Deprecated
   public void setTeleportCost(double cost) {
   }

   @Obsolete
   public double getTeleportCost() {
      TeleportRequest request = TeleportWarmupTimerTask.getTeleportRequest(this);
      return request == null ? 0.0D : request.teleportCost();
   }

   /** @deprecated */
   @Deprecated
   public void setTeleportAccount(Account payee) {
   }

   @Obsolete
   public Account getTeleportAccount() {
      TeleportRequest request = TeleportWarmupTimerTask.getTeleportRequest(this);
      return request == null ? null : request.teleportAccount();
   }

   public boolean hasPermissionNode(String node) {
      return this.getPlayer() != null && TownyUniverse.getInstance().getPermissionSource().testPermission((org.bukkit.permissions.Permissible)this.getPlayer(), node);
   }

   public boolean isAdmin() {
      return this.getPlayer() != null && TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((org.bukkit.permissions.Permissible)this.getPlayer());
   }

   public List<String> getModes() {
      return Collections.unmodifiableList(this.modes);
   }

   public boolean hasMode(String mode) {
      return this.modes.contains(mode.toLowerCase(Locale.ROOT));
   }

   public void toggleMode(String[] newModes, boolean notify) {
      for(int i = 0; i < newModes.length; ++i) {
         String mode = newModes[i].toLowerCase(Locale.ROOT);
         Optional<Boolean> choice = Optional.empty();
         if (i + 1 < newModes.length) {
            String bool = newModes[i + 1].toLowerCase(Locale.ROOT);
            if (BaseCommand.setOnOffCompletes.contains(bool)) {
               choice = Optional.of(bool.equalsIgnoreCase("on"));
               ++i;
            }
         }

         boolean modeEnabled = this.modes.contains(mode);
         ResidentToggleModeEvent event = new ResidentToggleModeEvent(this, mode);
         if (BukkitTools.isEventCancelled(event)) {
            TownyMessaging.sendErrorMsg((Object)this, (String)event.getCancelMessage());
         } else if ((Boolean)choice.orElse(!modeEnabled)) {
            if (!modeEnabled) {
               this.modes.add(mode);
            }
         } else {
            this.modes.remove(mode);
         }
      }

      if (this.modes.isEmpty()) {
         this.clearModes();
      } else {
         if (notify) {
            TownyMessaging.sendMsg(this, Translatable.of("msg_modes_set").append(StringMgmt.join((Collection)this.getModes(), ",")));
         }

      }
   }

   public void setModes(String[] modes, boolean notify) {
      this.modes.clear();
      this.toggleMode(modes, false);
      if (notify) {
         TownyMessaging.sendMsg(this, Translatable.of("msg_modes_set").append(StringMgmt.join((Collection)this.getModes(), ",")));
      }

   }

   public void clearModes() {
      this.clearModes(true);
   }

   public void clearModes(boolean notify) {
      this.modes.clear();
      if (notify) {
         TownyMessaging.sendMsg(this, Translatable.of("msg_modes_set"));
      }

      Towny.getPlugin().getScheduler().runAsyncLater(new SetDefaultModes(this.getName(), notify), 1L);
   }

   public void resetModes(String[] modes, boolean notify) {
      if (modes.length > 0) {
         this.toggleMode(modes, false);
      }

      if (notify) {
         TownyMessaging.sendMsg(this, Translatable.of("msg_modes_set").append(StringMgmt.join((Collection)this.getModes(), ",")));
      }

   }

   @Nullable
   public Player getPlayer() {
      return BukkitTools.getPlayerExact(this.getName());
   }

   public boolean addTownRank(String rank) {
      if (!this.hasTownRank(rank)) {
         this.townRanks.add(rank);
         if (this.isOnline()) {
            TownyPerms.assignPermissions(this, (Player)null);
         }

         return true;
      } else {
         return false;
      }
   }

   public void setTownRanks(List<String> ranks) {
      Iterator var2 = ranks.iterator();

      while(var2.hasNext()) {
         String rank = (String)var2.next();
         rank = TownyPerms.matchTownRank(rank);
         if (rank != null && !this.hasTownRank(rank)) {
            this.townRanks.add(rank);
         }
      }

   }

   public boolean hasTownRank(String rank) {
      rank = TownyPerms.matchTownRank(rank);
      if (rank != null) {
         Iterator var2 = this.townRanks.iterator();

         while(var2.hasNext()) {
            String ownedRank = (String)var2.next();
            if (ownedRank.equalsIgnoreCase(rank)) {
               return true;
            }
         }
      }

      return false;
   }

   public List<String> getTownRanks() {
      return Collections.unmodifiableList(this.townRanks);
   }

   public boolean removeTownRank(String rank) {
      if (this.hasTownRank(rank)) {
         this.townRanks.remove(rank);
         if (this.isOnline()) {
            TownyPerms.assignPermissions(this, (Player)null);
         }

         return true;
      } else {
         return false;
      }
   }

   @Nullable
   public String getHighestPriorityTownRank() {
      return this.getTownRanks().isEmpty() ? null : TownyPerms.getHighestPriorityRank(this, this.getTownRanks(), (r) -> {
         return TownyPerms.getTownRankPermissions(r);
      });
   }

   public boolean addNationRank(String rank) {
      if (!this.hasNationRank(rank)) {
         this.nationRanks.add(rank);
         if (this.isOnline()) {
            TownyPerms.assignPermissions(this, (Player)null);
         }

         return true;
      } else {
         return false;
      }
   }

   public void setNationRanks(List<String> ranks) {
      Iterator var2 = ranks.iterator();

      while(var2.hasNext()) {
         String rank = (String)var2.next();
         rank = TownyPerms.matchNationRank(rank);
         if (rank != null && !this.hasNationRank(rank)) {
            this.nationRanks.add(rank);
         }
      }

   }

   public boolean hasNationRank(String rank) {
      rank = TownyPerms.matchNationRank(rank);
      if (rank != null) {
         Iterator var2 = this.nationRanks.iterator();

         while(var2.hasNext()) {
            String ownedRank = (String)var2.next();
            if (ownedRank.equalsIgnoreCase(rank)) {
               return true;
            }
         }
      }

      return false;
   }

   public List<String> getNationRanks() {
      return Collections.unmodifiableList(this.nationRanks);
   }

   public boolean removeNationRank(String rank) {
      if (this.hasNationRank(rank)) {
         this.nationRanks.remove(rank);
         if (BukkitTools.isOnline(this.getName())) {
            TownyPerms.assignPermissions(this, (Player)null);
         }

         return true;
      } else {
         return false;
      }
   }

   @Nullable
   public String getHighestPriorityNationRank() {
      return this.getNationRanks().isEmpty() ? null : TownyPerms.getHighestPriorityRank(this, this.getNationRanks(), (r) -> {
         return TownyPerms.getNationRankPermissions(r);
      });
   }

   public boolean isAlliedWith(Resident otherresident) {
      return CombatUtil.isAlly(this, otherresident);
   }

   public List<Invite> getReceivedInvites() {
      return Collections.unmodifiableList(this.receivedInvites);
   }

   public void newReceivedInvite(Invite invite) throws TooManyInvitesException {
      if (this.receivedInvites.size() <= InviteHandler.getReceivedInvitesMaxAmount(this) - 1) {
         this.receivedInvites.add(invite);
      } else {
         throw new TooManyInvitesException(Translation.of("msg_err_player_has_too_many_invites", this.getName()));
      }
   }

   public void deleteReceivedInvite(Invite invite) {
      this.receivedInvites.remove(invite);
   }

   public void addMetaData(@NotNull CustomDataField<?> md) {
      this.addMetaData(md, true);
   }

   public void removeMetaData(@NotNull CustomDataField<?> md) {
      this.removeMetaData(md, true);
   }

   public Account getAccount() {
      if (this.account == null) {
         String accountName = StringMgmt.trimMaxLength(this.getName(), 32);
         Player player = this.getPlayer();
         World world;
         if (player != null) {
            world = player.getWorld();
         } else {
            world = (World)BukkitTools.getWorlds().get(0);
         }

         this.account = new EconomyAccount(this, accountName, world);
      }

      return this.account;
   }

   @Nullable
   public Account getAccountOrNull() {
      return this.account;
   }

   public String getFormattedName() {
      String prefix = Colors.translateColorCodes(this.hasTitle() ? this.getTitle() + " " : (this.isKing() && !TownySettings.getKingPrefix(this).isEmpty() ? TownySettings.getKingPrefix(this) : (this.isMayor() && !TownySettings.getMayorPrefix(this).isEmpty() ? TownySettings.getMayorPrefix(this) : "")));
      String postfix = Colors.translateColorCodes(this.hasSurname() ? " " + this.getSurname() : (this.isKing() && !TownySettings.getKingPostfix(this).isEmpty() ? TownySettings.getKingPostfix(this) : (this.isMayor() && !TownySettings.getMayorPostfix(this).isEmpty() ? TownySettings.getMayorPostfix(this) : "")));
      TownyObjectFormattedNameEvent event = new TownyObjectFormattedNameEvent(this, prefix, postfix);
      BukkitTools.fireEvent(event);
      String var10000 = event.getPrefix();
      return var10000 + this.getName() + event.getPostfix();
   }

   public String getNamePrefix() {
      if (this.isKing()) {
         return TownySettings.getKingPrefix(this);
      } else {
         return this.isMayor() ? TownySettings.getMayorPrefix(this) : "";
      }
   }

   public String getNamePostfix() {
      if (this.isKing()) {
         return TownySettings.getKingPostfix(this);
      } else {
         return this.isMayor() ? TownySettings.getMayorPostfix(this) : "";
      }
   }

   public String getFormattedTitleName() {
      if (!this.hasTitle()) {
         return this.getFormattedName();
      } else {
         String var10000 = this.getTitle();
         return var10000 + " " + this.getName();
      }
   }

   public void setTownblocks(Collection<TownBlock> townBlocks) {
      this.townBlocks = new ArrayList(townBlocks);
   }

   public Collection<TownBlock> getTownBlocks() {
      return Collections.unmodifiableCollection(this.townBlocks);
   }

   public List<Town> getTownsOutlawedIn() {
      return (List)TownyUniverse.getInstance().getTowns().stream().filter((t) -> {
         return t.hasOutlaw(this);
      }).collect(Collectors.toList());
   }

   public boolean hasTownBlock(TownBlock townBlock) {
      return this.townBlocks.contains(townBlock);
   }

   public void addTownBlock(TownBlock townBlock) throws AlreadyRegisteredException {
      if (this.hasTownBlock(townBlock)) {
         throw new AlreadyRegisteredException();
      } else {
         this.townBlocks.add(townBlock);
      }
   }

   public void removeTownBlock(TownBlock townBlock) {
      this.townBlocks.remove(townBlock);
   }

   public void setPermissions(String line) {
      this.permissions.load(line);
   }

   public TownyPermission getPermissions() {
      return this.permissions;
   }

   public Confirmation getConfirmation() {
      return this.confirmation;
   }

   public void setConfirmation(Confirmation confirmation) {
      this.confirmation = confirmation;
   }

   public Inventory getGUIPage() {
      return (Inventory)this.guiPages.get(this.guiPageNum);
   }

   public ArrayList<Inventory> getGUIPages() {
      return this.guiPages;
   }

   public void setGUIPages(ArrayList<Inventory> inventory) {
      this.guiPages = inventory;
   }

   public int getGUIPageNum() {
      return this.guiPageNum;
   }

   public void setGUIPageNum(int currentInventoryPage) {
      this.guiPageNum = currentInventoryPage;
   }

   public SelectionGUI.SelectionType getGUISelectionType() {
      return this.guiSelectionType;
   }

   public void setGUISelectionType(SelectionGUI.SelectionType selectionType) {
      this.guiSelectionType = selectionType;
   }

   public void save() {
      TownyUniverse.getInstance().getDataSource().saveResident(this);
   }

   public List<Town> getEmbassyTowns() {
      List<Town> townEmbassies = new ArrayList();
      Iterator var2 = this.getTownBlocks().iterator();

      while(var2.hasNext()) {
         TownBlock tB = (TownBlock)var2.next();
         Town town = tB.getTownOrNull();
         if (town != null && !townEmbassies.contains(town) && !town.hasResident(this)) {
            townEmbassies.add(town);
         }
      }

      return townEmbassies;
   }

   public long getJoinedTownAt() {
      return this.joinedTownAt;
   }

   public void setJoinedTownAt(long joinedTownAt) {
      this.joinedTownAt = joinedTownAt;
   }

   public Nation getNation() throws TownyException {
      return this.getTown().getNation();
   }

   @Nullable
   public Nation getNationOrNull() {
      return !this.hasNation() ? null : this.getTownOrNull().getNationOrNull();
   }

   public boolean isOnline() {
      return BukkitTools.isOnline(this.getName());
   }

   public boolean hasRespawnProtection() {
      return this.respawnProtectionTask != null && !this.respawnProtectionTask.isCancelled();
   }

   public void addRespawnProtection(long protectionTime) {
      if (protectionTime > 0L) {
         if (this.respawnProtectionTask != null) {
            this.respawnProtectionTask.cancel();
         }

         this.respawnPickupWarningShown = false;
         this.respawnProtectionTask = Towny.getPlugin().getScheduler().runAsyncLater(this::removeRespawnProtection, protectionTime);
      }
   }

   public void removeRespawnProtection() {
      if (this.respawnProtectionTask != null) {
         this.respawnProtectionTask.cancel();
         this.respawnProtectionTask = null;
         TownyMessaging.sendMsg(this, Translatable.of("msg_you_have_lost_your_respawn_protection"));
      }
   }

   public boolean isRespawnPickupWarningShown() {
      return this.respawnPickupWarningShown;
   }

   public void setRespawnPickupWarningShown(boolean respawnPickupWarningShown) {
      this.respawnPickupWarningShown = respawnPickupWarningShown;
   }

   @NotNull
   public Audience audience() {
      Player player = this.getPlayer();
      return player == null ? Audience.empty() : Towny.getAdventure().player(player);
   }

   public boolean isSeeingBorderTitles() {
      BooleanDataField borderMeta = new BooleanDataField("bordertitles");
      return !MetaDataUtil.hasMeta(this, (BooleanDataField)borderMeta) || MetaDataUtil.getBoolean(this, borderMeta);
   }

   public boolean hasPlotGroupName() {
      return this.plotGroupName != null;
   }

   public String getPlotGroupName() {
      return this.plotGroupName;
   }

   public void setPlotGroupName(String plotGroupName) {
      this.plotGroupName = plotGroupName;
   }

   public boolean hasDistrictName() {
      return this.districtName != null;
   }

   public String getDistrictName() {
      return this.districtName;
   }

   public void setDistrictName(String districtName) {
      this.districtName = districtName;
   }

   @Internal
   public boolean exists() {
      return TownyUniverse.getInstance().hasResident(this.getName());
   }

   public double getTaxOwing(boolean useCache) {
      if (useCache) {
         return this.getCachedTaxOwing();
      } else {
         boolean taxExempt = this.hasPermissionNode("towny.tax_exempt");
         double plotTax = 0.0D;
         double townTax = 0.0D;
         Town town;
         if (this.hasTown() && !taxExempt) {
            town = this.getTownOrNull();
            townTax = town.getTaxes();
            if (town.isTaxPercentage()) {
               townTax = Math.min(this.getAccount().getHoldingBalance() * townTax / 100.0D, town.getMaxPercentTaxAmount());
            }
         }

         if (this.getTownBlocks().size() > 0) {
            Iterator var8 = (new ArrayList(this.getTownBlocks())).iterator();

            while(true) {
               TownBlock townBlock;
               do {
                  do {
                     if (!var8.hasNext()) {
                        return plotTax + townTax;
                     }

                     townBlock = (TownBlock)var8.next();
                     town = townBlock.getTownOrNull();
                  } while(town == null);
               } while(taxExempt && town.hasResident(this));

               plotTax += townBlock.getType().getTax(town);
            }
         } else {
            return plotTax + townTax;
         }
      }
   }

   public double getCachedTaxOwing() {
      return this.getCachedTaxOwing(true);
   }

   public synchronized double getCachedTaxOwing(boolean refreshIfStale) {
      if (this.cachedTaxOwing == null) {
         this.cachedTaxOwing = new Resident.CachedTaxOwing(this.getTaxOwing(false));
      } else if (refreshIfStale && this.cachedTaxOwing.isStale()) {
         this.cachedTaxOwing.updateCache();
      }

      return this.cachedTaxOwing.getOwing();
   }

   class CachedTaxOwing {
      private double owing = 0.0D;
      private long time;

      CachedTaxOwing(double _owing) {
         this.owing = _owing;
         this.time = System.currentTimeMillis();
      }

      double getOwing() {
         return this.owing;
      }

      boolean isStale() {
         return System.currentTimeMillis() - this.time > TownySettings.getCachedBankTimeout();
      }

      void setOwing(double _balance) {
         this.owing = _balance;
         this.time = System.currentTimeMillis();
      }

      void updateCache() {
         this.time = System.currentTimeMillis();
         TownyEconomyHandler.economyExecutor().execute(() -> {
            this.setOwing(Resident.this.getTaxOwing(false));
         });
      }
   }
}
