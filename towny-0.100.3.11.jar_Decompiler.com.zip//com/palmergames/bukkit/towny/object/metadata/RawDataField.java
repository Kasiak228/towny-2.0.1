package com.palmergames.bukkit.towny.object.metadata;

class RawDataField extends CustomDataField<String> {
   private final String typeID;

   RawDataField(String typeID, String key, String value, String label) {
      super(key, value, label);
      this.typeID = typeID;
   }

   public String getTypeID() {
      return this.typeID;
   }

   protected boolean canParseFromString(String strValue) {
      return false;
   }

   public void setValueFromString(String strValue) {
      this.setValue(strValue);
   }

   public String displayFormattedValue() {
      return "UNLOADED - " + (String)this.getValue();
   }

   public boolean shouldDisplayInStatus() {
      return false;
   }

   public RawDataField clone() {
      return new RawDataField(this.typeID, this.getKey(), (String)this.getValue(), this.label);
   }
}
