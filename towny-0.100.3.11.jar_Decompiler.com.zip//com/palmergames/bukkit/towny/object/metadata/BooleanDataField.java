package com.palmergames.bukkit.towny.object.metadata;

public class BooleanDataField extends CustomDataField<Boolean> {
   public BooleanDataField(String key, Boolean value) {
      super(key, (Object)value);
   }

   public BooleanDataField(String key, Boolean value, String label) {
      super(key, value, label);
   }

   public BooleanDataField(String key) {
      super(key, (Object)false);
   }

   public String getTypeID() {
      return typeID();
   }

   public static String typeID() {
      return "towny_booldf";
   }

   public void setValueFromString(String strValue) {
      this.setValue(Boolean.parseBoolean(strValue));
   }

   public String displayFormattedValue() {
      boolean val = (Boolean)this.getValue();
      return (val ? "§a" : "§4") + val;
   }

   public CustomDataField<Boolean> clone() {
      return new BooleanDataField(this.getKey(), (Boolean)this.getValue(), this.label);
   }
}
