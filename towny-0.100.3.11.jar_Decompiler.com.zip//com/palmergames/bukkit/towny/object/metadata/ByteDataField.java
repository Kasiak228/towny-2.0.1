package com.palmergames.bukkit.towny.object.metadata;

import org.jetbrains.annotations.NotNull;

public class ByteDataField extends CustomDataField<Byte> {
   public ByteDataField(String key) {
      super(key);
   }

   public ByteDataField(String key, byte value, String label) {
      super(key, value, label);
   }

   public ByteDataField(String key, byte value) {
      super(key, (Object)value);
   }

   @NotNull
   public String getTypeID() {
      return typeID();
   }

   public static String typeID() {
      return "towny_bytedf";
   }

   public void setValueFromString(String strValue) {
      this.setValue(Byte.parseByte(strValue));
   }

   public boolean canParseFromString(String str) {
      try {
         Byte.parseByte(str);
         return true;
      } catch (NumberFormatException var3) {
         return false;
      }
   }

   public String displayFormattedValue() {
      return String.valueOf(this.getValue());
   }

   @NotNull
   public CustomDataField<Byte> clone() {
      return new ByteDataField(this.getKey(), (Byte)this.getValue(), this.label);
   }
}
