package com.palmergames.bukkit.towny.object.metadata;

import com.google.gson.JsonArray;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import org.jetbrains.annotations.NotNull;

public class ListDataField extends CustomDataField<List<CustomDataField<?>>> {
   public ListDataField(String key, List<CustomDataField<?>> value, String label) {
      super(key, value, label);
   }

   public ListDataField(String key) {
      super(key, (Object)(new ArrayList()));
   }

   @NotNull
   public String getTypeID() {
      return typeID();
   }

   public static String typeID() {
      return "towny_listdf";
   }

   public void setValueFromString(String strValue) {
      ((List)this.getValue()).clear();

      try {
         ((List)this.getValue()).addAll(DataFieldIO.deserializeMeta(strValue));
      } catch (IOException var3) {
      }

   }

   public String serializeValueToString() {
      return ((List)this.value).isEmpty() ? (new JsonArray()).toString() : DataFieldIO.serializeCDFs((Collection)this.value);
   }

   protected String displayFormattedValue() {
      return ((List)this.getValue()).toString();
   }

   @NotNull
   public CustomDataField<List<CustomDataField<?>>> clone() {
      return new ListDataField(this.key, (List)((List)this.getValue()).stream().map(CustomDataField::clone).collect(Collectors.toList()), this.label);
   }
}
