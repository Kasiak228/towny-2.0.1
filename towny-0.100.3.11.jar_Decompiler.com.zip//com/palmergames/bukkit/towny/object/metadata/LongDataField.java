package com.palmergames.bukkit.towny.object.metadata;

public class LongDataField extends CustomDataField<Long> {
   public LongDataField(String key, Long value) {
      super(key, (Object)value);
   }

   public LongDataField(String key, Long value, String label) {
      super(key, value, label);
   }

   public LongDataField(String key) {
      this(key, 0L);
   }

   public String getTypeID() {
      return typeID();
   }

   public static String typeID() {
      return "towny_longdf";
   }

   public void setValueFromString(String strValue) {
      this.setValue(Long.parseLong(strValue));
   }

   public boolean canParseFromString(String str) {
      try {
         Long.parseLong(str);
         return true;
      } catch (NumberFormatException var3) {
         return false;
      }
   }

   public String displayFormattedValue() {
      long lval = (Long)this.getValue();
      return (lval <= 0L ? "§4" : "§a") + lval;
   }

   public CustomDataField<Long> clone() {
      return new LongDataField(this.getKey(), (Long)this.getValue(), this.label);
   }
}
