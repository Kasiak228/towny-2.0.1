package com.palmergames.bukkit.towny.object.metadata;

public class StringDataField extends CustomDataField<String> {
   public StringDataField(String key) {
      super(key);
   }

   public StringDataField(String key, String value, String label) {
      super(key, value, label);
   }

   public StringDataField(String key, String value) {
      super(key, value, (String)null);
   }

   public String getTypeID() {
      return typeID();
   }

   public static String typeID() {
      return "towny_stringdf";
   }

   public void setValueFromString(String strValue) {
      this.setValue(strValue);
   }

   public String displayFormattedValue() {
      return "§f" + (String)this.getValue();
   }

   public CustomDataField<String> clone() {
      return new StringDataField(this.getKey(), (String)this.getValue(), this.label);
   }
}
