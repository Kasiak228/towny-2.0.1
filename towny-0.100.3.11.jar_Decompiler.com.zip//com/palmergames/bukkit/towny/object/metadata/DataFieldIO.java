package com.palmergames.bukkit.towny.object.metadata;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.jetbrains.annotations.ApiStatus.Internal;

@Internal
public class DataFieldIO {
   public static String serializeCDFs(Collection<CustomDataField<?>> cdfs) {
      if (cdfs.isEmpty()) {
         return "";
      } else {
         JsonArray array = new JsonArray();
         Iterator var2 = cdfs.iterator();

         while(var2.hasNext()) {
            CustomDataField<?> cdf = (CustomDataField)var2.next();
            JsonArray serializedArray = serializeCDF(cdf);
            array.add(serializedArray);
         }

         return array.toString();
      }
   }

   private static JsonArray serializeCDF(CustomDataField<?> cdf) {
      JsonArray array = new JsonArray();
      array.add(cdf.getTypeID());
      array.add(cdf.getKey());
      if (cdf.getValue() != null) {
         array.add(cdf.serializeValueToString());
      } else {
         array.add(JsonNull.INSTANCE);
      }

      if (cdf.hasLabel()) {
         array.add(cdf.getLabel());
      }

      return array;
   }

   public static Collection<CustomDataField<?>> deserializeMeta(String metadata) throws IOException {
      if (metadata != null && !metadata.isEmpty()) {
         return metadata.charAt(0) != '[' ? deserializeLegacyMeta(metadata) : deserializeMetaToRaw(metadata);
      } else {
         return Collections.emptyList();
      }
   }

   private static JsonArray convertToArray(String metadata) throws IOException {
      try {
         JsonElement element = (new JsonParser()).parse(metadata);
         if (!element.isJsonArray()) {
            throw new IOException("Metadata cannot be read as a JSON Array!");
         } else {
            return element.getAsJsonArray();
         }
      } catch (JsonSyntaxException var2) {
         throw new IOException(var2.getMessage(), var2.getCause());
      }
   }

   public static Collection<CustomDataField<?>> deserializeMetaToRaw(String metadata) throws IOException {
      JsonArray array = convertToArray(metadata);
      List<CustomDataField<?>> cdfList = new ArrayList(array.size());
      Iterator var3 = array.iterator();

      while(var3.hasNext()) {
         JsonElement element = (JsonElement)var3.next();
         if (element.isJsonArray()) {
            JsonArray cdfArray = element.getAsJsonArray();
            if (cdfArray.size() >= 2) {
               RawDataField rdf = deserializeCDFToRaw(cdfArray);
               cdfList.add(rdf);
            }
         }
      }

      return cdfList;
   }

   private static RawDataField deserializeCDFToRaw(JsonArray array) {
      String typeID = array.get(0).getAsString();
      String key = array.get(1).getAsString();
      String value = array.get(2).isJsonNull() ? null : array.get(2).getAsString();
      String label = null;
      if (array.size() == 4 && !array.get(3).isJsonNull()) {
         label = array.get(3).getAsString();
      }

      return new RawDataField(typeID, key, value, label);
   }

   public static Collection<CustomDataField<?>> deserializeLegacyMeta(String metadata) {
      String[] split = metadata.split(";");
      List<CustomDataField<?>> cdfList = new ArrayList(split.length);
      String[] var3 = split;
      int var4 = split.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String cdfStr = var3[var5];
         CustomDataField<?> cdf = deserializeLegacyCDF(cdfStr);
         if (cdf != null) {
            cdfList.add(cdf);
         }
      }

      return cdfList;
   }

   private static CustomDataField<?> deserializeLegacyCDF(String str) {
      String[] tokens = str.split(",");
      if (tokens.length < 2) {
         return null;
      } else {
         int typeInt = Integer.parseInt(tokens[0]);
         String key = tokens[1];
         CustomDataField<?> field = null;
         switch(typeInt) {
         case 0:
            field = new IntegerDataField(key);
            break;
         case 1:
            field = new StringDataField(key);
            break;
         case 2:
            field = new BooleanDataField(key);
            break;
         case 3:
            field = new DecimalDataField(key);
            break;
         case 4:
            field = new LongDataField(key);
         }

         if (((CustomDataField)field).canParseFromString(tokens[2])) {
            ((CustomDataField)field).setValueFromString(tokens[2]);
         }

         String label;
         if (tokens[3] != null && !tokens[3].equalsIgnoreCase("nil")) {
            label = tokens[3];
         } else {
            label = null;
         }

         ((CustomDataField)field).setLabel(label);
         return (CustomDataField)field;
      }
   }
}
