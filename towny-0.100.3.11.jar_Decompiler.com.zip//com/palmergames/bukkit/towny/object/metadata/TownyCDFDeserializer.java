package com.palmergames.bukkit.towny.object.metadata;

public class TownyCDFDeserializer {
   static final DataFieldDeserializer<IntegerDataField> INTEGER_DF = (key, value) -> {
      return (IntegerDataField)deserializeDF(new IntegerDataField(key), value);
   };
   static final DataFieldDeserializer<BooleanDataField> BOOLEAN_DF = (key, value) -> {
      return (BooleanDataField)deserializeDF(new BooleanDataField(key), value);
   };
   static final DataFieldDeserializer<StringDataField> STRING_DF = (key, value) -> {
      return (StringDataField)deserializeDF(new StringDataField(key), value);
   };
   static final DataFieldDeserializer<DecimalDataField> DECIMAL_DF = (key, value) -> {
      return (DecimalDataField)deserializeDF(new DecimalDataField(key), value);
   };
   static final DataFieldDeserializer<LongDataField> LONG_DF = (key, value) -> {
      return (LongDataField)deserializeDF(new LongDataField(key), value);
   };
   static final DataFieldDeserializer<ByteDataField> BYTE_DF = (key, value) -> {
      return (ByteDataField)deserializeDF(new ByteDataField(key), value);
   };
   static final DataFieldDeserializer<LocationDataField> LOCATION_DF = (key, value) -> {
      return (LocationDataField)deserializeDF(new LocationDataField(key), value);
   };
   static final DataFieldDeserializer<ListDataField> LIST_DF = (key, value) -> {
      return (ListDataField)deserializeDF(new ListDataField(key), value);
   };

   private static <T extends CustomDataField<?>> T deserializeDF(T cdf, String value) {
      if (value != null && cdf.canParseFromString(value)) {
         cdf.setValueFromString(value);
      }

      return cdf;
   }
}
