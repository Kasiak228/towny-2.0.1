package com.palmergames.bukkit.towny.object.metadata;

public class DecimalDataField extends CustomDataField<Double> {
   public DecimalDataField(String key, Double value) {
      super(key, (Object)value);
   }

   public DecimalDataField(String key, Double value, String label) {
      super(key, value, label);
   }

   public DecimalDataField(String key) {
      super(key, (Object)0.0D);
   }

   public String getTypeID() {
      return typeID();
   }

   public static String typeID() {
      return "towny_decdf";
   }

   public void setValueFromString(String strValue) {
      this.setValue(Double.parseDouble(strValue));
   }

   public boolean canParseFromString(String str) {
      try {
         Double.parseDouble(str);
         return true;
      } catch (NumberFormatException var3) {
         return false;
      }
   }

   public String displayFormattedValue() {
      double val = (Double)this.getValue();
      return (val <= 0.0D ? "§4" : "§a") + val;
   }

   public CustomDataField<Double> clone() {
      return new DecimalDataField(this.getKey(), (Double)this.getValue(), this.label);
   }
}
