package com.palmergames.bukkit.towny.object.metadata;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.event.LoadedMetadataEvent;
import com.palmergames.bukkit.towny.object.TownyObject;
import com.palmergames.bukkit.util.BukkitTools;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public class MetadataLoader {
   private static final MetadataLoader INSTANCE = new MetadataLoader();
   private final Map<String, DataFieldDeserializer<?>> deserializerMap = new HashMap();
   private final ArrayList<TownyObject> storedMetadata = new ArrayList();

   public static MetadataLoader getInstance() {
      return INSTANCE;
   }

   private MetadataLoader() {
      this.deserializerMap.put(IntegerDataField.typeID(), TownyCDFDeserializer.INTEGER_DF);
      this.deserializerMap.put(StringDataField.typeID(), TownyCDFDeserializer.STRING_DF);
      this.deserializerMap.put(BooleanDataField.typeID(), TownyCDFDeserializer.BOOLEAN_DF);
      this.deserializerMap.put(DecimalDataField.typeID(), TownyCDFDeserializer.DECIMAL_DF);
      this.deserializerMap.put(LongDataField.typeID(), TownyCDFDeserializer.LONG_DF);
      this.deserializerMap.put(ByteDataField.typeID(), TownyCDFDeserializer.BYTE_DF);
      this.deserializerMap.put(LocationDataField.typeID(), TownyCDFDeserializer.LOCATION_DF);
      this.deserializerMap.put(ListDataField.typeID(), TownyCDFDeserializer.LIST_DF);
   }

   public boolean registerDeserializer(String typeID, DataFieldDeserializer<?> deserializer) {
      if (this.deserializerMap.containsKey(typeID)) {
         return false;
      } else {
         this.deserializerMap.put(typeID, deserializer);
         return true;
      }
   }

   public void deserializeMetadata(TownyObject object, String serializedMetadata) {
      this.initialDeserialization(object, serializedMetadata);
   }

   private void initialDeserialization(TownyObject object, String serializedMetadata) {
      if (serializedMetadata != null && !serializedMetadata.isEmpty()) {
         Object fields = Collections.emptyList();

         try {
            fields = DataFieldIO.deserializeMeta(serializedMetadata);
         } catch (IOException var8) {
            Towny.getPlugin().getLogger().log(Level.WARNING, "Error loading metadata for towny object " + object.getClass().getName() + object.getName() + "!", var8);
         }

         if (!((Collection)fields).isEmpty()) {
            boolean hasCustomTypes = false;
            Iterator var5 = ((Collection)fields).iterator();

            while(true) {
               CustomDataField cdf;
               do {
                  if (!var5.hasNext()) {
                     if (hasCustomTypes) {
                        this.storedMetadata.add(object);
                     }

                     return;
                  }

                  cdf = (CustomDataField)var5.next();
                  if (cdf instanceof RawDataField) {
                     cdf = this.convertRawMetadata((RawDataField)cdf);
                  }
               } while(cdf == null);

               label44: {
                  if (!(cdf instanceof RawDataField)) {
                     if (!(cdf instanceof ListDataField)) {
                        break label44;
                     }

                     ListDataField listField = (ListDataField)cdf;
                     if (!((List)listField.getValue()).stream().anyMatch((field) -> {
                        return field instanceof RawDataField;
                     })) {
                        break label44;
                     }
                  }

                  hasCustomTypes = true;
               }

               object.addMetaData(cdf, false);
            }
         }
      }
   }

   public void scheduleDeserialization() {
      Towny.getPlugin().getScheduler().run(this::runDeserialization);
   }

   private void runDeserialization() {
      Iterator var1 = this.storedMetadata.iterator();

      while(var1.hasNext()) {
         TownyObject tObj = (TownyObject)var1.next();
         List<CustomDataField<?>> deserializedFields = this.deserializeStoredMeta(tObj.getMetadata());
         Iterator var4 = deserializedFields.iterator();

         while(var4.hasNext()) {
            CustomDataField<?> cdf = (CustomDataField)var4.next();
            tObj.addMetaData(cdf, false);
         }
      }

      this.storedMetadata.clear();
      this.storedMetadata.trimToSize();
      BukkitTools.fireEvent(new LoadedMetadataEvent());
   }

   private List<CustomDataField<?>> deserializeStoredMeta(Collection<CustomDataField<?>> meta) {
      List<CustomDataField<?>> deserializedFields = new ArrayList();
      Iterator var3 = meta.iterator();

      while(var3.hasNext()) {
         CustomDataField<?> cdf = (CustomDataField)var3.next();
         if (cdf instanceof ListDataField) {
            ListDataField listField = (ListDataField)cdf;

            try {
               listField.setValue(this.deserializeStoredMeta((Collection)listField.getValue()));
            } catch (StackOverflowError var7) {
            }
         }

         if (cdf instanceof RawDataField) {
            RawDataField raw = (RawDataField)cdf;
            CustomDataField<?> convertedCDF = this.convertRawMetadata(raw);
            if (convertedCDF != null && !(convertedCDF instanceof RawDataField)) {
               deserializedFields.add(convertedCDF);
            }
         }
      }

      return deserializedFields;
   }

   private CustomDataField<?> convertRawMetadata(RawDataField rdf) {
      String typeID = rdf.getTypeID();
      DataFieldDeserializer<?> deserializer = (DataFieldDeserializer)this.deserializerMap.get(typeID);
      if (deserializer == null) {
         return rdf;
      } else {
         CustomDataField<?> deserializedCDF = deserializer.deserialize(rdf.getKey(), (String)rdf.getValue());
         if (deserializedCDF == null) {
            return null;
         } else {
            if (rdf.hasLabel()) {
               deserializedCDF.setLabel(rdf.getLabel());
            }

            return deserializedCDF;
         }
      }
   }
}
