package com.palmergames.bukkit.towny.object.metadata;

public class IntegerDataField extends CustomDataField<Integer> {
   public IntegerDataField(String key) {
      super(key);
   }

   public IntegerDataField(String key, Integer value, String label) {
      super(key, value, label);
   }

   public IntegerDataField(String key, Integer value) {
      super(key, (Object)value);
   }

   public String getTypeID() {
      return typeID();
   }

   public static String typeID() {
      return "towny_intdf";
   }

   public void setValueFromString(String strValue) {
      this.setValue(Integer.parseInt(strValue));
   }

   public boolean canParseFromString(String str) {
      try {
         Integer.parseInt(str);
         return true;
      } catch (NumberFormatException var3) {
         return false;
      }
   }

   public String displayFormattedValue() {
      int val = (Integer)this.getValue();
      return (val <= 0 ? "§4" : "§a") + val;
   }

   public CustomDataField<Integer> clone() {
      return new IntegerDataField(this.getKey(), (Integer)this.getValue(), this.label);
   }
}
