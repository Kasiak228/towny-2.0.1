package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Tag;
import org.jetbrains.annotations.NotNull;

public abstract class AbstractRegistryList<T extends Keyed> {
   private final Registry<T> registry;
   protected final Set<T> tagged = new HashSet();

   public AbstractRegistryList(@NotNull Registry<T> registry, @NotNull Collection<T> collection) {
      this.registry = registry;
      this.tagged.addAll(collection);
   }

   public boolean contains(@NotNull T element) {
      return this.tagged.contains(element);
   }

   public boolean contains(@NotNull NamespacedKey key) {
      T element = this.registry.get(key);
      return element != null && this.contains(element);
   }

   public boolean contains(@NotNull String element) {
      if (element.isEmpty()) {
         return false;
      } else {
         T matched = BukkitTools.matchRegistry(this.registry, element);
         return matched != null && this.contains(matched);
      }
   }

   protected Collection<T> tagged() {
      return this.tagged;
   }

   public static class Builder<T extends Keyed, F extends AbstractRegistryList<T>> {
      private final Registry<T> registry;
      private final Class<T> clazz;
      private final Function<Collection<T>, F> convertFunction;
      private final Set<Predicate<T>> allMatchPredicates = new HashSet();
      private final Set<Predicate<T>> anyMatchPredicates = new HashSet();

      public Builder(Registry<T> registry, Class<T> clazz, Function<Collection<T>, F> function) {
         this.registry = registry;
         this.clazz = clazz;
         this.convertFunction = function;
      }

      public F build() {
         Set<T> matches = new HashSet();
         if (!this.allMatchPredicates.isEmpty() || !this.anyMatchPredicates.isEmpty()) {
            Iterator var2 = this.registry.iterator();

            while(true) {
               Keyed element;
               do {
                  do {
                     if (!var2.hasNext()) {
                        return (AbstractRegistryList)this.convertFunction.apply(matches);
                     }

                     element = (Keyed)var2.next();
                  } while(!this.allMatchPredicates.stream().allMatch((predicate) -> {
                     return predicate.test(element);
                  }));
               } while(!this.anyMatchPredicates.isEmpty() && !this.anyMatchPredicates.stream().anyMatch((predicate) -> {
                  return predicate.test(element);
               }));

               matches.add(element);
            }
         } else {
            return (AbstractRegistryList)this.convertFunction.apply(matches);
         }
      }

      public AbstractRegistryList.Builder<T, F> startsWith(String startingWith) {
         this.anyMatchPredicates.add((s) -> {
            return s.getKey().getKey().regionMatches(true, 0, startingWith, 0, startingWith.length());
         });
         return this;
      }

      public AbstractRegistryList.Builder<T, F> endsWith(@NotNull String endingWith) {
         String endingWithLower = endingWith.toLowerCase(Locale.ROOT);
         this.anyMatchPredicates.add((s) -> {
            return s.getKey().getKey().endsWith(endingWithLower);
         });
         return this;
      }

      public AbstractRegistryList.Builder<T, F> not(@NotNull String name) {
         this.allMatchPredicates.add((s) -> {
            return !s.getKey().getKey().equalsIgnoreCase(name);
         });
         return this;
      }

      public AbstractRegistryList.Builder<T, F> notStartsWith(@NotNull String notStartingWith) {
         this.allMatchPredicates.add((s) -> {
            return !s.getKey().getKey().regionMatches(true, 0, notStartingWith, 0, notStartingWith.length());
         });
         return this;
      }

      public AbstractRegistryList.Builder<T, F> notEndsWith(@NotNull String notEndingWith) {
         String notEndingLower = notEndingWith.toLowerCase(Locale.ROOT);
         this.allMatchPredicates.add((s) -> {
            return !s.getKey().getKey().endsWith(notEndingLower);
         });
         return this;
      }

      public AbstractRegistryList.Builder<T, F> contains(@NotNull String containing) {
         String containingLower = containing.toLowerCase(Locale.ROOT);
         this.allMatchPredicates.add((s) -> {
            return s.getKey().getKey().contains(containingLower);
         });
         return this;
      }

      public AbstractRegistryList.Builder<T, F> notContains(@NotNull String notContaining) {
         String notContainingLower = notContaining.toLowerCase(Locale.ROOT);
         this.allMatchPredicates.add((s) -> {
            return !s.getKey().getKey().contains(notContainingLower);
         });
         return this;
      }

      public AbstractRegistryList.Builder<T, F> withTag(@NotNull String registry, @NotNull NamespacedKey key) {
         Tag<T> tag = Bukkit.getServer().getTag(registry, key, this.clazz);
         if (tag != null) {
            Set var10000 = this.anyMatchPredicates;
            Objects.requireNonNull(tag);
            var10000.add(tag::isTagged);
         }

         return this;
      }

      public AbstractRegistryList.Builder<T, F> excludeTag(@NotNull String registry, @NotNull NamespacedKey key) {
         Tag<T> tag = Bukkit.getServer().getTag(registry, key, this.clazz);
         if (tag != null) {
            this.allMatchPredicates.add((s) -> {
               return !tag.isTagged(s);
            });
         }

         return this;
      }

      public AbstractRegistryList.Builder<T, F> add(@NotNull String... names) {
         String[] var2 = names;
         int var3 = names.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            String name = var2[var4];
            T match = BukkitTools.matchRegistry(this.registry, name);
            if (match != null) {
               this.anyMatchPredicates.add((t) -> {
                  return t.equals(match);
               });
            } else {
               try {
                  TownyMessaging.sendDebugMsg("Expected element with name '" + name + "' was not found in the " + this.clazz.getSimpleName() + " registry.");
               } catch (Exception var8) {
               }

               this.anyMatchPredicates.add((t) -> {
                  return false;
               });
            }
         }

         return this;
      }

      public AbstractRegistryList.Builder<T, F> includeList(@NotNull AbstractRegistryList<T> list) {
         Iterator var2 = list.tagged.iterator();

         while(var2.hasNext()) {
            T element = (Keyed)var2.next();
            this.anyMatchPredicates.add((t) -> {
               return t.equals(element);
            });
         }

         return this;
      }

      public AbstractRegistryList.Builder<T, F> filter(@NotNull Predicate<T> predicate) {
         this.allMatchPredicates.add(predicate);
         return this;
      }

      public AbstractRegistryList.Builder<T, F> conditionally(@NotNull BooleanSupplier supplier, @NotNull Consumer<AbstractRegistryList.Builder<T, F>> consumer) {
         if (supplier.getAsBoolean()) {
            consumer.accept(this);
         }

         return this;
      }
   }
}
