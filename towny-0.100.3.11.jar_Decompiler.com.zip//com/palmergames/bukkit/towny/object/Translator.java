package com.palmergames.bukkit.towny.object;

import com.palmergames.adventure.text.Component;
import java.util.Locale;
import org.bukkit.command.CommandSender;

public class Translator {
   private final Locale locale;

   public Translator(Locale locale) {
      this.locale = locale;
   }

   public static Translator locale(Locale locale) {
      return new Translator(locale);
   }

   public static Translator locale(CommandSender sender) {
      return new Translator(Translation.getLocale(sender));
   }

   public String of(String key) {
      return Translation.of(key, this.locale);
   }

   public String of(String key, Object... args) {
      return Translation.of(key, this.locale, args);
   }

   public Component component(String key) {
      return Translatable.of(key).locale(this.locale).component();
   }

   public Component component(String key, Object... args) {
      return Translatable.of(key, args).locale(this.locale).component();
   }
}
