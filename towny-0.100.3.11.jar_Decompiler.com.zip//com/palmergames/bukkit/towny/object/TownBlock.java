package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.PlotChangeTypeEvent;
import com.palmergames.bukkit.towny.event.plot.changeowner.PlotClaimEvent;
import com.palmergames.bukkit.towny.event.plot.changeowner.PlotPreClaimEvent;
import com.palmergames.bukkit.towny.event.plot.changeowner.PlotPreUnclaimEvent;
import com.palmergames.bukkit.towny.event.plot.changeowner.PlotUnclaimEvent;
import com.palmergames.bukkit.towny.exceptions.AlreadyRegisteredException;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.metadata.CustomDataField;
import com.palmergames.bukkit.towny.tasks.CooldownTimerTask;
import com.palmergames.bukkit.towny.utils.JailUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.TimeTools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;

public class TownBlock extends TownyObject {
   private Town town = null;
   private Resident resident = null;
   private int minTownMembershipDays = -1;
   private int maxTownMembershipDays = -1;
   private TownBlockType type;
   private final WorldCoord worldCoord;
   private double plotPrice;
   private boolean taxed;
   private boolean outpost;
   private PlotGroup plotGroup;
   private District district;
   private long claimedAt;
   private Jail jail;
   private Map<Resident, PermissionData> permissionOverrides;
   private Set<Resident> trustedResidents;
   protected TownyPermission permissions;
   protected boolean isChanged;

   public TownBlock(int x, int z, TownyWorld world) {
      super("");
      this.type = TownBlockType.RESIDENTIAL;
      this.plotPrice = -1.0D;
      this.taxed = true;
      this.outpost = false;
      this.permissionOverrides = new HashMap();
      this.trustedResidents = new HashSet();
      this.permissions = new TownyPermission();
      this.isChanged = false;
      this.worldCoord = new WorldCoord(world.getName(), world.getUUID(), x, z);
   }

   public TownBlock(WorldCoord worldCoord) {
      super("");
      this.type = TownBlockType.RESIDENTIAL;
      this.plotPrice = -1.0D;
      this.taxed = true;
      this.outpost = false;
      this.permissionOverrides = new HashMap();
      this.trustedResidents = new HashSet();
      this.permissions = new TownyPermission();
      this.isChanged = false;
      this.worldCoord = worldCoord;
   }

   public void setTown(Town town) {
      this.setTown(town, true);
   }

   public void setTown(Town town, boolean updateClaimedAt) {
      if (this.hasTown()) {
         this.town.removeTownBlock(this);
         this.setTaxed(true);
      }

      this.town = town;

      try {
         TownyUniverse.getInstance().addTownBlock(this);
         town.addTownBlock(this);
         if (updateClaimedAt) {
            this.setClaimedAt(System.currentTimeMillis());
         }

         this.permissionOverrides.clear();
         this.minTownMembershipDays = -1;
         this.maxTownMembershipDays = -1;
      } catch (NullPointerException | AlreadyRegisteredException var4) {
      }

   }

   public Town getTown() throws NotRegisteredException {
      if (!this.hasTown()) {
         throw new NotRegisteredException(String.format("The TownBlock at (%s, %d, %d) is not registered to a town.", this.getWorld().getName(), this.getX(), this.getZ()));
      } else {
         return this.town;
      }
   }

   @Nullable
   public Town getTownOrNull() {
      return this.town;
   }

   public boolean hasTown() {
      return this.town != null;
   }

   public boolean removeResident() {
      return this.setResident((Resident)null, true);
   }

   public boolean setResident(@Nullable Resident resident) {
      return this.setResident(resident, true);
   }

   public boolean setResident(@Nullable Resident resident, boolean callEvent) {
      if (callEvent) {
         if (this.resident != null && !this.resident.equals(resident)) {
            PlotPreUnclaimEvent plotPreUnclaimEvent = new PlotPreUnclaimEvent(this.resident, resident, this);
            if (BukkitTools.isEventCancelled(plotPreUnclaimEvent)) {
               if (!plotPreUnclaimEvent.getCancelMessage().isEmpty()) {
                  if (this.resident != null) {
                     TownyMessaging.sendErrorMsg((Object)this.resident, (String)plotPreUnclaimEvent.getCancelMessage());
                  }

                  if (resident != null) {
                     TownyMessaging.sendErrorMsg((Object)resident, (String)plotPreUnclaimEvent.getCancelMessage());
                  }
               }

               return false;
            }
         }

         if (resident != null && !resident.equals(this.resident)) {
            PlotPreClaimEvent plotPreClaimEvent = new PlotPreClaimEvent(this.resident, resident, this);
            if (BukkitTools.isEventCancelled(plotPreClaimEvent)) {
               if (!plotPreClaimEvent.getCancelMessage().isEmpty()) {
                  TownyMessaging.sendErrorMsg((Object)resident, (String)plotPreClaimEvent.getCancelMessage());
               }

               return false;
            }
         }
      }

      boolean successful = false;
      boolean unclaim = false;
      if (this.hasResident()) {
         this.resident.removeTownBlock(this);
         unclaim = true;
         this.town.getTownBlockTypeCache().removeTownBlockOfTypeResidentOwned(this);
         (new ArrayList(this.getTrustedResidents())).forEach(this::removeTrustedResident);
      }

      this.resident = resident;
      if (resident != null && !resident.hasTownBlock(this)) {
         try {
            resident.addTownBlock(this);
            successful = true;
            this.town.getTownBlockTypeCache().addTownBlockOfTypeResidentOwned(this);
         } catch (AlreadyRegisteredException var6) {
         }
      }

      if (successful && callEvent) {
         BukkitTools.fireEvent(new PlotClaimEvent(this.resident, resident, this));
      }

      if (unclaim && callEvent) {
         BukkitTools.fireEvent(new PlotUnclaimEvent(this.resident, resident, this));
      }

      this.permissionOverrides.clear();
      return true;
   }

   public Resident getResident() throws NotRegisteredException {
      if (!this.hasResident()) {
         throw new NotRegisteredException(String.format("The TownBlock at (%s, %d, %d) is not registered to a resident.", this.getWorld().getName(), this.getX(), this.getZ()));
      } else {
         return this.resident;
      }
   }

   @Nullable
   public Resident getResidentOrNull() {
      return this.resident;
   }

   public boolean hasResident() {
      return this.resident != null;
   }

   public boolean isOwner(@NotNull TownBlockOwner owner) {
      if (this.hasTown() && owner == this.getTownOrNull()) {
         return true;
      } else {
         return this.hasResident() && owner == this.getResidentOrNull();
      }
   }

   public void setPlotPrice(double price) {
      if (this.town != null) {
         if (this.isForSale() && price < 0.0D) {
            this.town.getTownBlockTypeCache().removeTownBlockOfTypeForSale(this);
         } else if (!this.isForSale() && price >= 0.0D) {
            this.town.getTownBlockTypeCache().addTownBlockOfTypeForSale(this);
         }
      }

      if (price < 0.0D) {
         price = -1.0D;
      }

      this.plotPrice = price;
   }

   public double getPlotPrice() {
      return this.plotPrice;
   }

   public boolean isForSale() {
      return this.getPlotPrice() >= 0.0D;
   }

   public boolean isTaxed() {
      return this.taxed;
   }

   public void setTaxed(boolean value) {
      this.taxed = value;
   }

   public double getPlotTax() {
      return this.getType().getTax(this.town);
   }

   public void setPermissions(String line) {
      this.permissions.load(line);
   }

   public TownyPermission getPermissions() {
      return this.permissions;
   }

   public boolean isChanged() {
      return this.isChanged;
   }

   public void setChanged(boolean isChanged) {
      this.isChanged = isChanged;
   }

   public boolean isOutpost() {
      return this.outpost;
   }

   public void setOutpost(boolean outpost) {
      this.outpost = outpost;
   }

   public TownBlockType getType() {
      return this.type;
   }

   public String getTypeName() {
      return this.type.getName();
   }

   public void setType(@NotNull String type) {
      this.setType(TownBlockTypeHandler.getType(type));
   }

   public void setType(@Nullable TownBlockType type) {
      if (type == null || !TownBlockTypeHandler.exists(type.getName())) {
         type = TownBlockType.RESIDENTIAL;
      }

      if (!type.equals(this.type)) {
         this.permissions.reset();
      }

      if (this.getTownOrNull() != null) {
         this.adjustTownBlockTypeCache(this.getTownOrNull().getTownBlockTypeCache(), type);
      }

      this.type = type;
      BukkitTools.fireEvent(new PlotChangeTypeEvent(this.type, type, this));
      String var2 = type.getName().toLowerCase(Locale.ROOT);
      byte var3 = -1;
      switch(var2.hashCode()) {
      case -1637322286:
         if (var2.equals("embassy")) {
            var3 = 6;
         }
         break;
      case 104425:
         if (var2.equals("inn")) {
            var3 = 8;
         }
         break;
      case 3016252:
         if (var2.equals("bank")) {
            var3 = 7;
         }
         break;
      case 3135542:
         if (var2.equals("farm")) {
            var3 = 2;
         }
         break;
      case 3254426:
         if (var2.equals("jail")) {
            var3 = 1;
         }
         break;
      case 3529462:
         if (var2.equals("shop")) {
            var3 = 5;
         }
         break;
      case 93078279:
         if (var2.equals("arena")) {
            var3 = 0;
         }
         break;
      case 113134057:
         if (var2.equals("wilds")) {
            var3 = 3;
         }
         break;
      case 1544803905:
         if (var2.equals("default")) {
            var3 = 4;
         }
      }

      switch(var3) {
      case 0:
         this.setPermissions("pvp");
         break;
      case 1:
         this.setPermissions("denyAll");
         break;
      case 2:
      case 3:
         this.setPermissions("residentBuild,residentDestroy");
         break;
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      default:
         if (this.hasResident()) {
            this.setPermissions(this.resident.getPermissions().toString());
         } else {
            this.setPermissions(this.town.getPermissions().toString());
         }
      }

      this.setChanged(false);
   }

   public void setType(TownBlockType type, Resident resident) throws TownyException {
      int typeLimit = this.town.getTownBlockTypeLimit(type);
      if (typeLimit < 0 || typeLimit != 0 && this.town.getTownBlockTypeCache().getNumTownBlocks(type, TownBlockTypeCache.CacheType.ALL) < typeLimit) {
         if (this.isJail() && !TownBlockType.JAIL.equals(type) && this.getJail() != null) {
            TownyUniverse.getInstance().getDataSource().removeJail(this.getJail());
            this.setJail((Jail)null);
         }

         if (!TownBlockType.ARENA.equals(this.type) && (!TownBlockType.ARENA.equals(type) || TownySettings.getPVPCoolDownTime() <= 0 || TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((org.bukkit.permissions.Permissible)resident.getPlayer()))) {
            this.setType(type);
         } else {
            if (CooldownTimerTask.hasCooldown(this.town.getUUID().toString(), CooldownTimerTask.CooldownType.PVP)) {
               throw new TownyException(Translatable.of("msg_err_cannot_toggle_pvp_x_seconds_remaining", CooldownTimerTask.getCooldownRemaining(this.town.getUUID().toString(), CooldownTimerTask.CooldownType.PVP)));
            }

            if (CooldownTimerTask.hasCooldown(this.getWorldCoord().toString(), CooldownTimerTask.CooldownType.PVP)) {
               throw new TownyException(Translation.of("msg_err_cannot_toggle_pvp_x_seconds_remaining", CooldownTimerTask.getCooldownRemaining(this.getWorldCoord().toString(), CooldownTimerTask.CooldownType.PVP)));
            }

            this.setType(type);
            CooldownTimerTask.addCooldownTimer(this.getWorldCoord().toString(), CooldownTimerTask.CooldownType.PVP);
         }

         if (this.isJail() && resident.getPlayer() != null) {
            JailUtil.createJailPlot(this, this.getTown(), resident.getPlayer().getLocation());
         }

         this.save();
      } else {
         throw new TownyException(Translatable.of("msg_town_plot_type_limit_reached", typeLimit, type.getFormattedName()));
      }
   }

   private void adjustTownBlockTypeCache(@Nullable TownBlockTypeCache townBlockTypeCache, @NotNull TownBlockType type) {
      if (townBlockTypeCache != null) {
         if (this.type != null) {
            townBlockTypeCache.removeTownBlockOfType(this.type);
            if (this.isForSale()) {
               townBlockTypeCache.removeTownBlockOfTypeForSale(this.type);
            }

            if (this.hasResident()) {
               townBlockTypeCache.removeTownBlockOfTypeResidentOwned(this.type);
            }
         }

         townBlockTypeCache.addTownBlockOfType(type);
         if (this.isForSale()) {
            townBlockTypeCache.addTownBlockOfTypeForSale(type);
         }

         if (this.hasResident()) {
            townBlockTypeCache.addTownBlockOfTypeResidentOwned(type);
         }

      }
   }

   public boolean isHomeBlock() {
      return this.town != null && this.town.isHomeBlock(this);
   }

   public void setName(String newName) {
      super.setName(newName.replace("_", " "));
   }

   /** @deprecated */
   @Deprecated
   public void setX(int x) {
   }

   public int getX() {
      return this.worldCoord.getX();
   }

   /** @deprecated */
   @Deprecated
   public void setZ(int z) {
   }

   public int getZ() {
      return this.worldCoord.getZ();
   }

   public Coord getCoord() {
      return this.worldCoord;
   }

   public WorldCoord getWorldCoord() {
      return this.worldCoord;
   }

   /** @deprecated */
   @Deprecated
   public void setWorld(TownyWorld world) {
   }

   public TownyWorld getWorld() {
      return this.worldCoord.getTownyWorld();
   }

   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else if (o != null && this.getClass() == o.getClass()) {
         TownBlock townBlock = (TownBlock)o;
         return this.worldCoord.equals(townBlock.worldCoord);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.getWorld(), this.getX(), this.getZ()});
   }

   public void clear() {
      this.setTown((Town)null);
      this.removeResident();
   }

   public String toString() {
      String var10000 = this.getWorld().getName();
      return var10000 + " (" + this.getCoord() + ")";
   }

   public boolean isJail() {
      return this.getType() == TownBlockType.JAIL;
   }

   public Jail getJail() {
      return this.jail;
   }

   public void setJail(Jail _jail) {
      this.jail = _jail;
   }

   public void addMetaData(@NotNull CustomDataField<?> md) {
      this.addMetaData(md, true);
   }

   public void removeMetaData(@NotNull CustomDataField<?> md) {
      this.removeMetaData(md, true);
   }

   public boolean hasPlotObjectGroup() {
      return this.plotGroup != null;
   }

   public PlotGroup getPlotObjectGroup() {
      return this.plotGroup;
   }

   public void removePlotObjectGroup() {
      this.plotGroup = null;
   }

   public void setPlotObjectGroup(PlotGroup group) {
      this.plotGroup = group;

      try {
         group.addTownBlock(this);
         this.setTrustedResidents(group.getTrustedResidents());
         this.setPermissionOverrides(group.getPermissionOverrides());
      } catch (NullPointerException var3) {
         TownyMessaging.sendErrorMsg("Townblock failed to setPlotObjectGroup(group), group is null. ");
      }

   }

   public boolean hasDistrict() {
      return this.district != null;
   }

   public District getDistrict() {
      return this.district;
   }

   public void removeDistrict() {
      this.district = null;
   }

   public void setDistrict(District district) {
      this.district = district;

      try {
         district.addTownBlock(this);
      } catch (NullPointerException var3) {
         TownyMessaging.sendErrorMsg("Townblock failed to setDistrict(district), district is null. ");
      }

   }

   public void save() {
      TownyUniverse.getInstance().getDataSource().saveTownBlock(this);
   }

   public long getClaimedAt() {
      return this.claimedAt;
   }

   public void setClaimedAt(long claimedAt) {
      this.claimedAt = claimedAt;
   }

   public Map<Resident, PermissionData> getPermissionOverrides() {
      return this.permissionOverrides;
   }

   public void addTrustedResidents(List<Resident> residents) {
      residents.forEach(this::addTrustedResident);
   }

   public Set<Resident> getTrustedResidents() {
      return this.trustedResidents;
   }

   public boolean hasTrustedResident(Resident resident) {
      return this.trustedResidents.contains(resident);
   }

   public void addTrustedResident(Resident resident) {
      this.trustedResidents.add(resident);
   }

   public void removeTrustedResident(Resident resident) {
      this.trustedResidents.remove(resident);
   }

   public boolean hasResident(Resident resident) {
      return this.resident != null && resident != null ? resident.equals(this.resident) : false;
   }

   public void setTrustedResidents(Set<Resident> trustedResidents) {
      this.trustedResidents = new HashSet(trustedResidents);
   }

   public void setPermissionOverrides(Map<Resident, PermissionData> permissionOverrides) {
      this.permissionOverrides = new HashMap(permissionOverrides);
   }

   @Nullable
   public TownBlockOwner getTownBlockOwner() {
      return (TownBlockOwner)(this.hasResident() ? this.getResidentOrNull() : this.getTownOrNull());
   }

   public TownBlockData getData() {
      return this.type.getData();
   }

   public void evictOwnerFromTownBlock() {
      this.removeResident();
      this.setPlotPrice(-1.0D);
      this.setType(this.getType());
      this.save();
   }

   public void testTownMembershipAgePreventsThisClaimOrThrow(Resident resident) throws TownyException {
      if ((!this.getType().equals(TownBlockType.EMBASSY) || this.town.hasResident(resident)) && (this.hasMinTownMembershipDays() || this.hasMaxTownMembershipDays())) {
         Town residentTown = resident.getTownOrNull();
         if (residentTown != null && residentTown.equals(this.town)) {
            long joinDate = resident.getJoinedTownAt();
            if (this.hasMaxTownMembershipDays() && TimeTools.getTimeInMillisXDaysAgo(this.getMaxTownMembershipDays()) > joinDate) {
               throw new TownyException(Translatable.of("msg_err_cannot_claim_plot_join_date_too_high", this.getMaxTownMembershipDays()));
            } else if (this.hasMinTownMembershipDays() && TimeTools.getTimeInMillisXDaysAgo(this.getMinTownMembershipDays()) < joinDate) {
               throw new TownyException(Translatable.of("msg_err_cannot_claim_plot_join_date_too_low", this.getMinTownMembershipDays()));
            }
         }
      }
   }

   public boolean hasMinTownMembershipDays() {
      return this.minTownMembershipDays > 0;
   }

   public int getMinTownMembershipDays() {
      return this.minTownMembershipDays;
   }

   public void setMinTownMembershipDays(int minTownMembershipDays) {
      this.minTownMembershipDays = Math.min(32766, minTownMembershipDays);
   }

   public boolean hasMaxTownMembershipDays() {
      return this.maxTownMembershipDays > 0;
   }

   public int getMaxTownMembershipDays() {
      return this.maxTownMembershipDays;
   }

   public void setMaxTownMembershipDays(int maxTownMembershipDays) {
      this.maxTownMembershipDays = Math.min(32766, maxTownMembershipDays);
   }

   @Internal
   public boolean exists() {
      return TownyUniverse.getInstance().hasTownBlock(this.getWorldCoord());
   }
}
