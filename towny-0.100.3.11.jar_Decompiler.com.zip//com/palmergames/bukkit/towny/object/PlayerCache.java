package com.palmergames.bukkit.towny.object;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class PlayerCache {
   private final Map<Material, Boolean> buildMatPermission = new HashMap();
   private final Map<Material, Boolean> destroyMatPermission = new HashMap();
   private final Map<Material, Boolean> switchMatPermission = new HashMap();
   private final Map<Material, Boolean> itemUseMatPermission = new HashMap();
   private WorldCoord lastWorldCoord;
   private String blockErrMsg;
   private final UUID playerUUID;
   private PlayerCache.TownBlockStatus townBlockStatus;

   public PlayerCache(Player player) {
      this.townBlockStatus = PlayerCache.TownBlockStatus.UNKNOWN;
      this.lastWorldCoord = WorldCoord.parseWorldCoord((Entity)player);
      this.playerUUID = player.getUniqueId();
   }

   public void setLastTownBlock(@NotNull WorldCoord worldCoord) {
      this.lastWorldCoord = worldCoord;
   }

   public void resetAndUpdate(@NotNull WorldCoord worldCoord) {
      this.reset(worldCoord);
   }

   @NotNull
   public WorldCoord getLastTownBlock() {
      return this.lastWorldCoord;
   }

   public boolean updateCoord(@NotNull WorldCoord pos) {
      if (!this.getLastTownBlock().equals(pos)) {
         this.reset(pos);
         return true;
      } else {
         return false;
      }
   }

   public boolean getCachePermission(Material material, TownyPermission.ActionType action) throws NullPointerException {
      boolean var10000;
      switch(action) {
      case BUILD:
         var10000 = this.getBlockPermission(this.buildMatPermission, material);
         break;
      case DESTROY:
         var10000 = this.getBlockPermission(this.destroyMatPermission, material);
         break;
      case SWITCH:
         var10000 = this.getBlockPermission(this.switchMatPermission, material);
         break;
      case ITEM_USE:
         var10000 = this.getBlockPermission(this.itemUseMatPermission, material);
         break;
      default:
         throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public void setBuildPermission(Material material, Boolean value) {
      this.updateMaps(this.buildMatPermission, material, value);
   }

   public void setDestroyPermission(Material material, Boolean value) {
      this.updateMaps(this.destroyMatPermission, material, value);
   }

   public void setSwitchPermission(Material material, Boolean value) {
      this.updateMaps(this.switchMatPermission, material, value);
   }

   public void setItemUsePermission(Material material, Boolean value) {
      this.updateMaps(this.itemUseMatPermission, material, value);
   }

   public boolean getBuildPermission(Material material) throws NullPointerException {
      return this.getBlockPermission(this.buildMatPermission, material);
   }

   public boolean getDestroyPermission(Material material) throws NullPointerException {
      return this.getBlockPermission(this.destroyMatPermission, material);
   }

   public boolean getSwitchPermission(Material material) throws NullPointerException {
      return this.getBlockPermission(this.switchMatPermission, material);
   }

   public boolean getItemUsePermission(Material material) throws NullPointerException {
      return this.getBlockPermission(this.itemUseMatPermission, material);
   }

   private void updateMaps(Map<Material, Boolean> blockMap, Material material, Boolean value) {
      blockMap.putIfAbsent(material, value);
   }

   private boolean getBlockPermission(Map<Material, Boolean> blockMap, Material material) throws NullPointerException {
      return (Boolean)blockMap.get(material);
   }

   private void reset(WorldCoord wc) {
      this.lastWorldCoord = wc;
      this.townBlockStatus = null;
      this.blockErrMsg = null;
      this.buildMatPermission.clear();
      this.destroyMatPermission.clear();
      this.switchMatPermission.clear();
      this.itemUseMatPermission.clear();
   }

   public void setStatus(PlayerCache.TownBlockStatus townBlockStatus) {
      this.townBlockStatus = townBlockStatus;
   }

   public PlayerCache.TownBlockStatus getStatus() throws NullPointerException {
      if (this.townBlockStatus == null) {
         throw new NullPointerException();
      } else {
         return this.townBlockStatus;
      }
   }

   public void setBlockErrMsg(String blockErrMsg) {
      this.blockErrMsg = blockErrMsg;
   }

   public String getBlockErrMsg() {
      String temp = this.blockErrMsg;
      this.setBlockErrMsg((String)null);
      return temp;
   }

   public boolean hasBlockErrMsg() {
      return this.blockErrMsg != null;
   }

   /** @deprecated */
   @Deprecated
   public void setLastLocation(Location lastLocation) {
   }

   /** @deprecated */
   @Deprecated
   public Location getLastLocation() throws NullPointerException {
      Player player = Bukkit.getServer().getPlayer(this.playerUUID);
      if (player == null) {
         throw new NullPointerException();
      } else {
         return player.getLocation();
      }
   }

   public static enum TownBlockStatus {
      UNKNOWN,
      NOT_REGISTERED,
      OFF_WORLD,
      ADMIN,
      UNCLAIMED_ZONE,
      NATION_ZONE,
      WARZONE,
      OUTSIDER,
      PLOT_OWNER,
      PLOT_FRIEND,
      PLOT_TOWN,
      PLOT_ALLY,
      TOWN_OWNER,
      TOWN_RESIDENT,
      TOWN_ALLY,
      TOWN_NATION,
      ENEMY,
      TOWN_TRUSTED,
      PLOT_TRUSTED;

      // $FF: synthetic method
      private static PlayerCache.TownBlockStatus[] $values() {
         return new PlayerCache.TownBlockStatus[]{UNKNOWN, NOT_REGISTERED, OFF_WORLD, ADMIN, UNCLAIMED_ZONE, NATION_ZONE, WARZONE, OUTSIDER, PLOT_OWNER, PLOT_FRIEND, PLOT_TOWN, PLOT_ALLY, TOWN_OWNER, TOWN_RESIDENT, TOWN_ALLY, TOWN_NATION, ENEMY, TOWN_TRUSTED, PLOT_TRUSTED};
      }
   }
}
