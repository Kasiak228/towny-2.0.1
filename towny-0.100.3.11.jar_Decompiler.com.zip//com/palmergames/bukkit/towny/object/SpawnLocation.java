package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.exceptions.TownyException;
import org.bukkit.Location;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface SpawnLocation {
   @NotNull
   Location getSpawn() throws TownyException;

   default boolean hasSpawn() {
      return this.getSpawnOrNull() != null;
   }

   void setSpawn(@Nullable Location var1) throws TownyException;

   @Nullable
   default Location getSpawnOrNull() {
      try {
         return this.getSpawn();
      } catch (TownyException var2) {
         return null;
      }
   }
}
