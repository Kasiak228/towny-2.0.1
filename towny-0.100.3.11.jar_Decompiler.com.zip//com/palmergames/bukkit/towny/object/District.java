package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownyUniverse;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class District extends ObjectGroup implements Nameable, Savable {
   private List<TownBlock> townBlocks;
   private Town town;

   public District(UUID id, String name, Town town) {
      super(id, name);
      this.town = town;
   }

   public String toString() {
      String var10000 = super.toString();
      return var10000 + "," + this.getTown().toString();
   }

   public boolean exists() {
      return this.town != null && this.town.exists() && this.town.hasDistrictName(this.getName());
   }

   public void setName(String name) {
      if (this.getName() == null) {
         super.setName(name);
      } else {
         String oldName = this.getName();
         super.setName(name);
         this.town.renameDistrict(oldName, this);
      }

   }

   public void setTown(Town town) {
      this.town = town;

      try {
         town.addDistrict(this);
      } catch (Exception var3) {
         TownyMessaging.sendErrorMsg(var3.getMessage());
      }

   }

   public int hashCode() {
      int prime = true;
      int result = super.hashCode();
      result = 31 * result + Objects.hash(new Object[]{this.town, this.townBlocks, this.getName()});
      return result;
   }

   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      } else if (!super.equals(obj)) {
         return false;
      } else if (this.getClass() != obj.getClass()) {
         return false;
      } else {
         District other = (District)obj;
         return Objects.equals(this.town, other.town) && Objects.equals(this.getName(), other.getName());
      }
   }

   public Town getTown() {
      return this.town;
   }

   public String toModeString() {
      return "District{" + this.toString() + "}";
   }

   public void addTownBlock(TownBlock townBlock) {
      if (this.townBlocks == null) {
         this.townBlocks = new ArrayList();
      }

      this.townBlocks.add(townBlock);
   }

   public void removeTownBlock(TownBlock townBlock) {
      if (this.townBlocks != null) {
         this.townBlocks.remove(townBlock);
      }

   }

   public void setTownblocks(List<TownBlock> townBlocks) {
      this.townBlocks = townBlocks;
   }

   public Collection<TownBlock> getTownBlocks() {
      return Collections.unmodifiableCollection(this.townBlocks);
   }

   public boolean hasTownBlocks() {
      return this.townBlocks != null && !this.townBlocks.isEmpty();
   }

   public boolean hasTownBlock(TownBlock townBlock) {
      return this.townBlocks.contains(townBlock);
   }

   public void save() {
      TownyUniverse.getInstance().getDataSource().saveDistrict(this);
   }
}
