package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.Towny;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;

public class SpawnPoint {
   private final Position position;
   private final WorldCoord wc;
   private final SpawnPoint.SpawnPointType type;
   private final SpawnPointLocation spawnLocation;
   private static final List<SpawnPoint.RingCoord> RING_PATTERN = createRingOffsets();
   public static final int RING_POINT_COUNT = 12;
   public static final int RING_DELAY_TICKS = 4;

   public SpawnPoint(Location loc, SpawnPoint.SpawnPointType type) {
      this(Position.ofLocation(loc), type);
   }

   public SpawnPoint(Position pos, SpawnPoint.SpawnPointType type) {
      this.position = pos;
      this.type = type;
      this.wc = pos.worldCoord();
      this.spawnLocation = SpawnPointLocation.parsePos(pos);
   }

   public WorldCoord getWorldCoord() {
      return this.wc;
   }

   public SpawnPoint.SpawnPointType getType() {
      return this.type;
   }

   public Location getBukkitLocation() {
      return this.position.asLocation();
   }

   public Position getPosition() {
      return this.position;
   }

   public SpawnPointLocation getSpawnPointLocation() {
      return this.spawnLocation;
   }

   public void drawParticle() {
      if (Towny.getPlugin().isEnabled()) {
         World world = this.position.world().getBukkitWorld();
         if (world != null) {
            Location origin = this.centreLocation(this.position.asLocation());
            int i = 0;

            for(Iterator var4 = RING_PATTERN.iterator(); var4.hasNext(); ++i) {
               SpawnPoint.RingCoord ringPosition = (SpawnPoint.RingCoord)var4.next();
               Location point = origin.clone().add(ringPosition.x(), 0.0D, ringPosition.z());
               Towny.getPlugin().getScheduler().runAsyncLater(() -> {
                  try {
                     world.spawnParticle(Particle.CRIT_MAGIC, point, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                  } catch (Exception var3) {
                  }

               }, (long)i * 4L);
            }

         }
      }
   }

   private Location centreLocation(Location loc) {
      loc.setX(Math.floor(loc.getX()) + 0.5D);
      loc.setY(Math.floor(loc.getY()) + 0.1D);
      loc.setZ(Math.floor(loc.getZ()) + 0.5D);
      return loc;
   }

   private static List<SpawnPoint.RingCoord> createRingOffsets() {
      ArrayList<SpawnPoint.RingCoord> ring = new ArrayList();
      double radius = 0.45D;
      double angleIncrement = 0.5235987755982988D;

      for(int i = 0; i < 12; ++i) {
         double angle = (double)i * 0.5235987755982988D;
         double x = 0.45D * Math.sin(angle);
         double y = 0.45D * Math.cos(angle);
         ring.add(SpawnPoint.RingCoord.offset(x, y));
      }

      return ring;
   }

   public static enum SpawnPointType {
      TOWN_SPAWN,
      NATION_SPAWN,
      OUTPOST_SPAWN,
      JAIL_SPAWN;

      // $FF: synthetic method
      private static SpawnPoint.SpawnPointType[] $values() {
         return new SpawnPoint.SpawnPointType[]{TOWN_SPAWN, NATION_SPAWN, OUTPOST_SPAWN, JAIL_SPAWN};
      }
   }

   private static record RingCoord(double x, double z) {
      private RingCoord(double x, double z) {
         this.x = x;
         this.z = z;
      }

      private static SpawnPoint.RingCoord offset(double a, double b) {
         return new SpawnPoint.RingCoord(a, b);
      }

      public double x() {
         return this.x;
      }

      public double z() {
         return this.z;
      }
   }
}
