package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.object.spawnlevel.NationSpawnLevel;
import com.palmergames.bukkit.towny.object.spawnlevel.TownSpawnLevel;

public class SpawnInformation {
   public boolean eventCancelled = false;
   public String eventCancellationMessage = null;
   public double travelCost = 0.0D;
   public TownSpawnLevel townSpawnLevel = null;
   public NationSpawnLevel nationSpawnLevel = null;
   public int cooldown = 0;
}
