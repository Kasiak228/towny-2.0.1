package com.palmergames.bukkit.towny.object;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.paperlib.PaperLib;
import com.palmergames.util.Pair;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.util.BoundingBox;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

public class WorldCoord extends Coord {
   private final String worldName;
   private UUID worldUUID;
   private Reference<World> worldRef;

   public WorldCoord(String worldName, int x, int z) {
      super(x, z);
      this.worldRef = new WeakReference((Object)null);
      this.worldName = worldName;
      World world = Bukkit.getServer().getWorld(worldName);
      if (world != null) {
         this.worldUUID = world.getUID();
      }

   }

   public WorldCoord(String worldName, Coord coord) {
      this(worldName, coord.getX(), coord.getZ());
   }

   public WorldCoord(String worldName, UUID worldUUID, int x, int z) {
      super(x, z);
      this.worldRef = new WeakReference((Object)null);
      this.worldName = worldName;
      this.worldUUID = worldUUID;
   }

   public WorldCoord(String worldName, UUID worldUUID, Coord coord) {
      this(worldName, worldUUID, coord.getX(), coord.getZ());
   }

   public WorldCoord(@NotNull World world, int x, int z) {
      super(x, z);
      this.worldRef = new WeakReference((Object)null);
      this.worldName = world.getName();
      this.worldUUID = world.getUID();
   }

   public WorldCoord(@NotNull World world, Coord coord) {
      this(world, coord.getX(), coord.getZ());
   }

   public WorldCoord(WorldCoord worldCoord) {
      super(worldCoord);
      this.worldRef = new WeakReference((Object)null);
      this.worldName = worldCoord.getWorldName();
      this.worldUUID = worldCoord.worldUUID;
      this.worldRef = new WeakReference((World)worldCoord.worldRef.get());
   }

   public String getWorldName() {
      return this.worldName;
   }

   public Coord getCoord() {
      return new Coord(this.getX(), this.getZ());
   }

   public static WorldCoord parseWorldCoord(Entity entity) {
      return parseWorldCoord(entity.getLocation());
   }

   public static WorldCoord parseWorldCoord(String worldName, int blockX, int blockZ) {
      return new WorldCoord(worldName, toCell(blockX), toCell(blockZ));
   }

   public static WorldCoord parseWorldCoord(Location loc) {
      World world = loc.getWorld();
      if (world == null) {
         throw new IllegalArgumentException("Provided location does not have an associated world");
      } else {
         return new WorldCoord(world, toCell(loc.getBlockX()), toCell(loc.getBlockZ()));
      }
   }

   public static WorldCoord parseWorldCoord(Block block) {
      return new WorldCoord(block.getWorld(), toCell(block.getX()), toCell(block.getZ()));
   }

   public WorldCoord add(int xOffset, int zOffset) {
      return new WorldCoord(this.getWorldName(), this.worldUUID, this.getX() + xOffset, this.getZ() + zOffset);
   }

   public int hashCode() {
      int hash = 17;
      int hash = hash * 27 + this.worldName.hashCode();
      hash = hash * 27 + this.getX();
      hash = hash * 27 + this.getZ();
      return hash;
   }

   public boolean equals(Object obj) {
      if (obj == this) {
         return true;
      } else if (!(obj instanceof Coord)) {
         return false;
      } else if (!(obj instanceof WorldCoord)) {
         Coord that = (Coord)obj;
         return this.getX() == that.getZ() && this.getZ() == that.getZ();
      } else {
         WorldCoord that = (WorldCoord)obj;
         return this.getX() == that.getX() && this.getZ() == that.getZ() && Objects.equals(this.getWorldName(), that.getWorldName());
      }
   }

   public String toString() {
      String var10000 = this.getWorldName();
      return var10000 + "," + super.toString();
   }

   @Nullable
   public World getBukkitWorld() {
      World world = (World)this.worldRef.get();
      if (world == null) {
         world = Bukkit.getServer().getWorld(this.worldName);
         this.worldRef = new WeakReference(world);
         if (this.worldUUID == null && world != null) {
            this.worldUUID = world.getUID();
         }
      }

      return world;
   }

   @Nullable
   public TownyWorld getTownyWorld() {
      return TownyAPI.getInstance().getTownyWorld(this.worldName);
   }

   public TownBlock getTownBlock() throws NotRegisteredException {
      if (!this.hasTownBlock()) {
         throw new NotRegisteredException();
      } else {
         return TownyUniverse.getInstance().getTownBlock(this);
      }
   }

   @Nullable
   public TownBlock getTownBlockOrNull() {
      return TownyUniverse.getInstance().getTownBlockOrNull(this);
   }

   public boolean hasTownBlock() {
      return TownyUniverse.getInstance().hasTownBlock(this);
   }

   public boolean hasTown(Town town) {
      return town != null && town.equals(this.getTownOrNull());
   }

   public boolean isWilderness() {
      return !this.hasTownBlock();
   }

   public void loadChunks() {
      Towny plugin = Towny.getPlugin();
      if (!plugin.getScheduler().isRegionThread(this.getLowerMostCornerLocation())) {
         plugin.getScheduler().run(this.getLowerMostCornerLocation(), () -> {
            this.loadChunks(plugin);
         });
      } else {
         this.loadChunks(plugin);
      }

   }

   private void loadChunks(Towny plugin) {
      this.getChunks().forEach((future) -> {
         future.thenAccept((chunk) -> {
            chunk.addPluginChunkTicket(plugin);
         });
      });
   }

   public void unloadChunks() {
      Towny plugin = Towny.getPlugin();
      if (!plugin.getScheduler().isRegionThread(this.getLowerMostCornerLocation())) {
         plugin.getScheduler().run(this.getLowerMostCornerLocation(), () -> {
            this.unloadChunks(plugin);
         });
      } else {
         this.unloadChunks(plugin);
      }

   }

   private void unloadChunks(Towny plugin) {
      this.getChunks().forEach((future) -> {
         future.thenAccept((chunk) -> {
            chunk.removePluginChunkTicket(plugin);
         });
      });
   }

   @Unmodifiable
   public Collection<CompletableFuture<Chunk>> getChunks() {
      World world = this.getBukkitWorld();
      if (world == null) {
         return Collections.emptyList();
      } else if (getCellSize() <= 16) {
         return Collections.singleton(PaperLib.getChunkAtAsync(this.getCorner()));
      } else {
         Set<CompletableFuture<Chunk>> chunkFutures = new HashSet();
         Iterator var3 = this.getChunkPositions().iterator();

         while(var3.hasNext()) {
            Pair<Integer, Integer> chunkPos = (Pair)var3.next();
            chunkFutures.add(PaperLib.getChunkAtAsync(world, (Integer)chunkPos.left(), (Integer)chunkPos.right()));
         }

         return Collections.unmodifiableSet(chunkFutures);
      }
   }

   protected Collection<Pair<Integer, Integer>> getChunkPositions() {
      return this.getChunkPositions(getCellSize());
   }

   protected Collection<Pair<Integer, Integer>> getChunkPositions(int cellSize) {
      Set<Pair<Integer, Integer>> chunks = new HashSet();
      int side = (int)Math.ceil((double)((float)cellSize / 16.0F));

      for(int x = 0; x < side; ++x) {
         for(int z = 0; z < side; ++z) {
            chunks.add(Pair.pair(x + this.getX(), z + this.getZ()));
         }
      }

      return chunks;
   }

   public boolean isFullyLoaded() {
      World bukkitWorld = this.getBukkitWorld();
      if (bukkitWorld == null) {
         return false;
      } else {
         Iterator var2 = this.getChunkPositions().iterator();

         Pair chunkPos;
         do {
            if (!var2.hasNext()) {
               return true;
            }

            chunkPos = (Pair)var2.next();
         } while(bukkitWorld.isChunkLoaded((Integer)chunkPos.left(), (Integer)chunkPos.right()));

         return false;
      }
   }

   private Location getCorner() {
      return new Location(this.getBukkitWorld(), (double)(this.getX() * getCellSize()), 0.0D, (double)(this.getZ() * getCellSize()));
   }

   public BoundingBox getBoundingBox() {
      return BoundingBox.of(this.getLowerMostCornerLocation(), this.getUpperMostCornerLocation());
   }

   public Location getLowerMostCornerLocation() {
      return new Location(this.getBukkitWorld(), (double)(this.getX() * getCellSize()), (double)this.getBukkitWorld().getMinHeight(), (double)(this.getZ() * getCellSize()));
   }

   public Location getUpperMostCornerLocation() {
      return this.getCorner().add((double)getCellSize(), (double)this.getBukkitWorld().getMaxHeight(), (double)getCellSize());
   }

   @Nullable
   public Town getTownOrNull() {
      TownBlock townBlock = this.getTownBlockOrNull();
      return townBlock != null ? townBlock.getTownOrNull() : null;
   }

   public static boolean cellChanged(Location from, Location to) {
      return toCell(from.getBlockX()) != toCell(to.getBlockX()) || toCell(from.getBlockZ()) != toCell(to.getBlockZ()) || !Objects.equals(from.getWorld(), to.getWorld());
   }

   public List<WorldCoord> getCardinallyAdjacentWorldCoords(boolean... includeOrdinalFlag) {
      boolean includeOrdinal = includeOrdinalFlag.length >= 1 ? includeOrdinalFlag[0] : false;
      List<WorldCoord> list = new ArrayList(includeOrdinal ? 8 : 4);
      list.add(this.add(0, -1));
      list.add(this.add(0, 1));
      list.add(this.add(1, 0));
      list.add(this.add(-1, 0));
      if (includeOrdinal) {
         list.add(this.add(1, 1));
         list.add(this.add(1, -1));
         list.add(this.add(-1, -1));
         list.add(this.add(-1, 1));
      }

      return list;
   }

   public boolean canBeStolen() {
      return TownySettings.isOverClaimingAllowingStolenLand() && this.hasTownBlock() && this.getTownOrNull().isOverClaimed();
   }
}
