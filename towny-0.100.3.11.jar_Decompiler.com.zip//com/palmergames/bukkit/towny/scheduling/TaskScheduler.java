package com.palmergames.bukkit.towny.scheduling;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.jetbrains.annotations.ApiStatus.Experimental;

public interface TaskScheduler {
   boolean isGlobalThread();

   boolean isTickThread();

   boolean isEntityThread(Entity var1);

   boolean isRegionThread(Location var1);

   ScheduledTask run(Consumer<ScheduledTask> var1);

   default ScheduledTask run(Entity entity, Consumer<ScheduledTask> task) {
      return this.run(task);
   }

   default ScheduledTask run(Location location, Consumer<ScheduledTask> task) {
      return this.run(task);
   }

   ScheduledTask runLater(Consumer<ScheduledTask> var1, long var2);

   default ScheduledTask runLater(Entity entity, Consumer<ScheduledTask> task, long delay) {
      return this.runLater(task, delay);
   }

   default ScheduledTask runLater(Location location, Consumer<ScheduledTask> task, long delay) {
      return this.runLater(task, delay);
   }

   ScheduledTask runRepeating(Consumer<ScheduledTask> var1, long var2, long var4);

   default ScheduledTask runRepeating(Entity entity, Consumer<ScheduledTask> task, long delay, long period) {
      return this.runRepeating(task, delay, period);
   }

   default ScheduledTask runRepeating(Location location, Consumer<ScheduledTask> task, long delay, long period) {
      return this.runRepeating(task, delay, period);
   }

   ScheduledTask runAsync(Consumer<ScheduledTask> var1);

   ScheduledTask runAsyncLater(Consumer<ScheduledTask> var1, long var2, TimeUnit var4);

   ScheduledTask runAsyncRepeating(Consumer<ScheduledTask> var1, long var2, long var4, TimeUnit var6);

   @Experimental
   default ScheduledTask runGlobal(Consumer<ScheduledTask> task) {
      return this.run(task);
   }

   @Experimental
   default ScheduledTask runGlobalLater(Consumer<ScheduledTask> task, long delay) {
      return this.runLater(task, delay);
   }

   @Experimental
   default ScheduledTask runGlobalRepeating(Consumer<ScheduledTask> task, long delay, long period) {
      return this.runRepeating(task, delay, period);
   }

   default ScheduledTask run(Runnable runnable) {
      return this.run((task) -> {
         runnable.run();
      });
   }

   default ScheduledTask run(Entity entity, Runnable runnable) {
      return this.run(entity, (task) -> {
         runnable.run();
      });
   }

   default ScheduledTask run(Location location, Runnable runnable) {
      return this.run(location, (task) -> {
         runnable.run();
      });
   }

   default ScheduledTask runLater(Runnable runnable, long delay) {
      return this.runLater((task) -> {
         runnable.run();
      }, delay);
   }

   default ScheduledTask runLater(Entity entity, Runnable runnable, long delay) {
      return this.runLater(entity, (task) -> {
         runnable.run();
      }, delay);
   }

   default ScheduledTask runLater(Location location, Runnable runnable, long delay) {
      return this.runLater(location, (task) -> {
         runnable.run();
      }, delay);
   }

   default ScheduledTask runRepeating(Runnable runnable, long delay, long period) {
      return this.runRepeating((task) -> {
         runnable.run();
      }, delay, period);
   }

   default ScheduledTask runRepeating(Entity entity, Runnable runnable, long delay, long period) {
      return this.runRepeating(entity, (task) -> {
         runnable.run();
      }, delay, period);
   }

   default ScheduledTask runRepeating(Location location, Runnable runnable, long delay, long period) {
      return this.runRepeating(location, (task) -> {
         runnable.run();
      }, delay, period);
   }

   default ScheduledTask runAsync(Runnable runnable) {
      return this.runAsync((task) -> {
         runnable.run();
      });
   }

   default ScheduledTask runAsyncLater(Runnable runnable, long delay) {
      return this.runAsyncLater((task) -> {
         runnable.run();
      }, delay * 50L, TimeUnit.MILLISECONDS);
   }

   default ScheduledTask runAsyncRepeating(Runnable runnable, long delay, long period) {
      return this.runAsyncRepeating((task) -> {
         runnable.run();
      }, delay * 50L, period * 50L, TimeUnit.MILLISECONDS);
   }
}
