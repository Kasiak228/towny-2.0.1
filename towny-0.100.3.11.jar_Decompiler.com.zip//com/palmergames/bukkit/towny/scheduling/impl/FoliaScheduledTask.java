package com.palmergames.bukkit.towny.scheduling.impl;

import com.palmergames.bukkit.towny.scheduling.ScheduledTask;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask.ExecutionState;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

public class FoliaScheduledTask implements ScheduledTask {
   private final io.papermc.paper.threadedregions.scheduler.ScheduledTask task;

   public FoliaScheduledTask(io.papermc.paper.threadedregions.scheduler.ScheduledTask task) {
      this.task = task;
   }

   public void cancel() {
      this.task.cancel();
   }

   public boolean isCancelled() {
      return this.task.isCancelled();
   }

   @NotNull
   public Plugin getOwningPlugin() {
      return this.task.getOwningPlugin();
   }

   public boolean isCurrentlyRunning() {
      ExecutionState state = this.task.getExecutionState();
      return state == ExecutionState.RUNNING || state == ExecutionState.CANCELLED_RUNNING;
   }

   public boolean isRepeatingTask() {
      return this.task.isRepeatingTask();
   }
}
