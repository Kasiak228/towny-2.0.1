package com.palmergames.bukkit.towny.scheduling.impl;

import com.palmergames.bukkit.towny.scheduling.ScheduledTask;
import com.palmergames.bukkit.towny.scheduling.TaskScheduler;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitScheduler;

public class BukkitTaskScheduler implements TaskScheduler {
   private final Plugin plugin;
   private final BukkitScheduler scheduler = Bukkit.getServer().getScheduler();

   public BukkitTaskScheduler(Plugin plugin) {
      this.plugin = plugin;
   }

   public boolean isGlobalThread() {
      return Bukkit.getServer().isPrimaryThread();
   }

   public boolean isTickThread() {
      return Bukkit.getServer().isPrimaryThread();
   }

   public boolean isEntityThread(Entity entity) {
      return Bukkit.getServer().isPrimaryThread();
   }

   public boolean isRegionThread(Location location) {
      return Bukkit.getServer().isPrimaryThread();
   }

   public ScheduledTask run(Consumer<ScheduledTask> task) {
      AtomicReference<ScheduledTask> taskRef = new AtomicReference();
      taskRef.set(new BukkitScheduledTask(this.scheduler.runTask(this.plugin, () -> {
         task.accept((ScheduledTask)taskRef.get());
      })));
      return (ScheduledTask)taskRef.get();
   }

   public ScheduledTask runLater(Consumer<ScheduledTask> task, long delay) {
      AtomicReference<ScheduledTask> taskRef = new AtomicReference();
      taskRef.set(new BukkitScheduledTask(this.scheduler.runTaskLater(this.plugin, () -> {
         task.accept((ScheduledTask)taskRef.get());
      }, delay)));
      return (ScheduledTask)taskRef.get();
   }

   public ScheduledTask runRepeating(Consumer<ScheduledTask> task, long delay, long period) {
      AtomicReference<ScheduledTask> taskRef = new AtomicReference();
      taskRef.set(new BukkitScheduledTask(this.scheduler.runTaskTimer(this.plugin, () -> {
         task.accept((ScheduledTask)taskRef.get());
      }, delay, period), true));
      return (ScheduledTask)taskRef.get();
   }

   public ScheduledTask runAsync(Consumer<ScheduledTask> task) {
      AtomicReference<ScheduledTask> taskRef = new AtomicReference();
      taskRef.set(new BukkitScheduledTask(this.scheduler.runTaskAsynchronously(this.plugin, () -> {
         task.accept((ScheduledTask)taskRef.get());
      })));
      return (ScheduledTask)taskRef.get();
   }

   public ScheduledTask runAsyncLater(Consumer<ScheduledTask> task, long delay, TimeUnit timeUnit) {
      AtomicReference<ScheduledTask> taskRef = new AtomicReference();
      taskRef.set(new BukkitScheduledTask(this.scheduler.runTaskLaterAsynchronously(this.plugin, () -> {
         task.accept((ScheduledTask)taskRef.get());
      }, timeUnit.toMillis(delay) / 50L)));
      return (ScheduledTask)taskRef.get();
   }

   public ScheduledTask runAsyncRepeating(Consumer<ScheduledTask> task, long delay, long period, TimeUnit timeUnit) {
      AtomicReference<ScheduledTask> taskRef = new AtomicReference();
      taskRef.set(new BukkitScheduledTask(this.scheduler.runTaskTimerAsynchronously(this.plugin, () -> {
         task.accept((ScheduledTask)taskRef.get());
      }, timeUnit.toMillis(delay) / 50L, timeUnit.toMillis(period) / 50L), true));
      return (ScheduledTask)taskRef.get();
   }
}
