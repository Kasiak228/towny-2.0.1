package com.palmergames.bukkit.towny.scheduling.impl;

import com.palmergames.bukkit.towny.scheduling.ScheduledTask;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public class PaperTaskScheduler extends FoliaTaskScheduler {
   public PaperTaskScheduler(Plugin plugin) {
      super(plugin);
   }

   public boolean isGlobalThread() {
      return Bukkit.getServer().isPrimaryThread();
   }

   public ScheduledTask run(Consumer<ScheduledTask> task) {
      AtomicReference<ScheduledTask> taskRef = new AtomicReference();
      taskRef.set(new FoliaScheduledTask(this.globalRegionScheduler.run(this.plugin, (t) -> {
         task.accept((ScheduledTask)taskRef.get());
      })));
      return (ScheduledTask)taskRef.get();
   }

   public ScheduledTask runLater(Consumer<ScheduledTask> task, long delay) {
      if (delay == 0L) {
         return this.run(task);
      } else {
         AtomicReference<ScheduledTask> taskRef = new AtomicReference();
         taskRef.set(new FoliaScheduledTask(this.globalRegionScheduler.runDelayed(this.plugin, (t) -> {
            task.accept((ScheduledTask)taskRef.get());
         }, delay)));
         return (ScheduledTask)taskRef.get();
      }
   }

   public ScheduledTask runRepeating(Consumer<ScheduledTask> task, long delay, long period) {
      AtomicReference<ScheduledTask> taskRef = new AtomicReference();
      taskRef.set(new FoliaScheduledTask(this.globalRegionScheduler.runAtFixedRate(this.plugin, (t) -> {
         task.accept((ScheduledTask)taskRef.get());
      }, delay, period)));
      return (ScheduledTask)taskRef.get();
   }
}
