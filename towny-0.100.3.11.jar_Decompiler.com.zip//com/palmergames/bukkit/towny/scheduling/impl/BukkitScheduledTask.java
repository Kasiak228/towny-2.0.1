package com.palmergames.bukkit.towny.scheduling.impl;

import com.palmergames.bukkit.towny.scheduling.ScheduledTask;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.NotNull;

public class BukkitScheduledTask implements ScheduledTask {
   private final BukkitTask task;
   private final boolean repeating;

   public BukkitScheduledTask(BukkitTask task) {
      this.task = task;
      this.repeating = false;
   }

   public BukkitScheduledTask(BukkitTask task, boolean repeating) {
      this.task = task;
      this.repeating = repeating;
   }

   public void cancel() {
      this.task.cancel();
   }

   public boolean isCancelled() {
      return !Bukkit.getScheduler().isQueued(this.task.getTaskId()) && !Bukkit.getScheduler().isCurrentlyRunning(this.task.getTaskId());
   }

   @NotNull
   public Plugin getOwningPlugin() {
      return this.task.getOwner();
   }

   public boolean isCurrentlyRunning() {
      return Bukkit.getServer().getScheduler().isCurrentlyRunning(this.task.getTaskId());
   }

   public boolean isRepeatingTask() {
      return this.repeating;
   }
}
