package com.palmergames.bukkit.towny;

import com.palmergames.adventure.audience.Audience;
import com.palmergames.adventure.bossbar.BossBar;
import com.palmergames.adventure.text.Component;
import com.palmergames.adventure.text.TextComponent;
import com.palmergames.adventure.text.event.ClickEvent;
import com.palmergames.adventure.text.event.HoverEvent;
import com.palmergames.adventure.text.event.HoverEventSource;
import com.palmergames.adventure.text.format.NamedTextColor;
import com.palmergames.adventure.text.format.TextColor;
import com.palmergames.bukkit.towny.confirmations.Confirmation;
import com.palmergames.bukkit.towny.invites.Invite;
import com.palmergames.bukkit.towny.invites.InviteSender;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.PlotGroup;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyObject;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.towny.object.Translator;
import com.palmergames.bukkit.towny.object.comparators.ComparatorType;
import com.palmergames.bukkit.towny.object.jail.Jail;
import com.palmergames.bukkit.towny.object.statusscreens.StatusScreen;
import com.palmergames.bukkit.towny.permissions.PermissionNodes;
import com.palmergames.bukkit.towny.utils.TownyComponents;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.ChatTools;
import com.palmergames.bukkit.util.Colors;
import com.palmergames.util.Pair;
import com.palmergames.util.StringMgmt;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;

public class TownyMessaging {
   private static final Logger LOGGER = LogManager.getLogger("Towny");

   public static void sendErrorMsg(String msg) {
      LOGGER.warn(Colors.strip("Error: " + msg));
   }

   public static void sendErrorMsg(Object sender, String msg) {
      if (sender != null && msg != null && !msg.isEmpty()) {
         if (sender instanceof CommandSender) {
            CommandSender toSend = (CommandSender)sender;
            sendMessage((Object)toSend, (String)Translatable.of("default_towny_prefix").stripColors(sender instanceof ConsoleCommandSender).append("§4" + msg).forLocale(toSend));
         } else if (sender instanceof TownyObject) {
            TownyObject townySender = (TownyObject)sender;
            if (townySender instanceof Resident) {
               Resident resident = (Resident)townySender;
               String var10001 = Translation.of("default_towny_prefix");
               sendMessage((Object)resident, (String)(var10001 + "§4" + msg));
            } else if (townySender instanceof Town) {
               Town town = (Town)townySender;
               sendPrefixedTownMessage(town, "§4" + msg);
            } else if (townySender instanceof Nation) {
               Nation nation = (Nation)townySender;
               sendPrefixedNationMessage(nation, "§4" + msg);
            }
         } else {
            sendErrorMsg(String.format("Unsupported TownyMessaging#sendErrorMsg sender class type: %s", sender.getClass().getName()));
         }

         sendDevMsg(msg);
      }
   }

   public static void sendMsg(String msg) {
      LOGGER.info(Colors.strip(msg));
   }

   public static void sendMsg(CommandSender sender, String msg) {
      if (sender != null && msg != null && !msg.isEmpty()) {
         String var10001;
         if (sender instanceof Player) {
            Player p = (Player)sender;
            var10001 = Translatable.of("default_towny_prefix").forLocale((CommandSender)p);
            sendMessage((Object)p, (String)(var10001 + "§a" + msg));
         } else if (sender instanceof ConsoleCommandSender) {
            var10001 = Translatable.of("default_towny_prefix").stripColors(true).defaultLocale();
            sendMessage((Object)sender, (String)(var10001 + Colors.strip(msg)));
         } else {
            var10001 = Translatable.of("default_towny_prefix").forLocale(sender);
            sendMessage((Object)sender, (String)(var10001 + "§a" + msg));
         }

         sendDevMsg(msg);
      }
   }

   public static void sendDevMsg(String msg) {
      if (TownySettings.isDevMode()) {
         Player townyDev = BukkitTools.getPlayerExact(TownySettings.getDevName());
         if (townyDev != null) {
            String var10001 = Translatable.of("default_towny_prefix").forLocale((CommandSender)townyDev);
            sendMessage((Object)townyDev, (String)(var10001 + " DevMode: §4" + msg));
         }
      }

   }

   public static void sendDevMsg(String[] msg) {
      String[] var1 = msg;
      int var2 = msg.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String line = var1[var3];
         sendDevMsg(line);
      }

   }

   public static void sendDebugMsg(String msg) {
      if (TownySettings.getDebug()) {
         LOGGER.debug(Colors.strip(msg));
      }

      sendDevMsg(msg);
   }

   public static void sendMessage(Object sender, String line) {
      if (!line.isEmpty()) {
         if (sender instanceof Player) {
            Player player = (Player)sender;
            Towny.getAdventure().player(player).sendMessage(TownyComponents.miniMessage(line));
         } else if (sender instanceof CommandSender) {
            CommandSender commandSender = (CommandSender)sender;
            commandSender.sendMessage(Colors.strip(line));
         } else if (sender instanceof Resident) {
            Resident resident = (Resident)sender;
            resident.sendMessage(TownyComponents.miniMessage(line));
         }

      }
   }

   public static void sendMessage(Object sender, List<String> lines) {
      sendMessage(sender, (String[])lines.toArray(new String[0]));
   }

   public static void sendMessage(Object sender, String[] lines) {
      String[] var2 = lines;
      int var3 = lines.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String line = var2[var4];
         sendMessage(sender, line);
      }

   }

   public static void sendGlobalMessage(String line) {
      LOGGER.info(Colors.strip("[Global Message] " + line));
      Iterator var1 = BukkitTools.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player player = (Player)var1.next();
         if (player != null && TownyAPI.getInstance().isTownyWorld(player.getWorld())) {
            String var10001 = Translation.of("default_towny_prefix");
            sendMessage((Object)player, (String)(var10001 + line));
         }
      }

   }

   public static void sendPlainGlobalMessage(String line) {
      LOGGER.info(Colors.strip("[Global Message] " + line));
      Iterator var1 = BukkitTools.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player player = (Player)var1.next();
         if (player != null && TownyAPI.getInstance().isTownyWorld(player.getWorld())) {
            sendMessage((Object)player, (String)line);
         }
      }

   }

   public static void sendPrefixedTownMessage(Town town, String line) {
      Logger var10000 = LOGGER;
      String var10001 = StringMgmt.remUnderscore(town.getName());
      var10000.info(Colors.strip("[Town Msg] " + var10001 + ": " + line));
      Iterator var2 = TownyAPI.getInstance().getOnlinePlayers(town).iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         var10001 = Translation.of("default_town_prefix", StringMgmt.remUnderscore(town.getName()));
         sendMessage((Object)player, (String)(var10001 + line));
      }

   }

   public static void sendPrefixedNationMessage(Nation nation, String line) {
      Logger var10000 = LOGGER;
      String var10001 = StringMgmt.remUnderscore(nation.getName());
      var10000.info(Colors.strip("[Nation Msg] " + var10001 + ": " + line));
      Iterator var2 = TownyAPI.getInstance().getOnlinePlayers(nation).iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         var10001 = Translation.of("default_nation_prefix", StringMgmt.remUnderscore(nation.getName()));
         sendMessage((Object)player, (String)(var10001 + line));
      }

   }

   public static void sendTownBoard(CommandSender sender, Town town) {
      String tbColor1 = Translation.of("townboard_message_colour_1");
      String tbColor2 = Translation.of("townboard_message_colour_2");
      sendMessage((Object)sender, (String)(tbColor1 + "[" + StringMgmt.remUnderscore(town.getName()) + "] " + tbColor2 + town.getBoard()));
   }

   public static void sendNationBoard(CommandSender sender, Nation nation) {
      String nbColor1 = Translation.of("nationboard_message_colour_1");
      String nbColor2 = Translation.of("nationboard_message_colour_2");
      sendMessage((Object)sender, (String)(nbColor1 + "[" + StringMgmt.remUnderscore(nation.getName()) + "] " + nbColor2 + nation.getBoard()));
   }

   public static void sendTitleMessageToResident(Resident resident, String title, String subtitle, int duration) {
      Player player = resident.getPlayer();
      if (player != null) {
         sendTitle(player, title, subtitle, duration);
      }
   }

   public static void sendTitleMessageToResident(Resident resident, String title, String subtitle) {
      sendTitleMessageToResident(resident, title, subtitle, 70);
   }

   public static void sendTitleMessageToTown(Town town, String title, String subtitle, int duration) {
      Iterator var4 = TownyAPI.getInstance().getOnlinePlayers(town).iterator();

      while(var4.hasNext()) {
         Player player = (Player)var4.next();
         sendTitle(player, title, subtitle, duration);
      }

   }

   public static void sendTitleMessageToTown(Town town, String title, String subtitle) {
      sendTitleMessageToTown(town, title, subtitle, 70);
   }

   public static void sendTitleMessageToNation(Nation nation, String title, String subtitle, int duration) {
      Iterator var4 = TownyAPI.getInstance().getOnlinePlayers(nation).iterator();

      while(var4.hasNext()) {
         Player player = (Player)var4.next();
         sendTitle(player, title, subtitle, duration);
      }

   }

   public static void sendTitleMessageToNation(Nation nation, String title, String subtitle) {
      sendTitleMessageToNation(nation, title, subtitle, 70);
   }

   public static void sendTitle(Player player, String title, String subtitle, int duration) {
      player.sendTitle(title.isEmpty() ? " " : title, subtitle.isEmpty() ? " " : subtitle, 10, duration, 10);
   }

   public static void sendTitle(Player player, String title, String subtitle) {
      sendTitle(player, title, subtitle, 70);
   }

   public static void sendRequestMessage(CommandSender player, Invite invite) {
      Translator translator = Translator.locale(player);
      String senderName = invite.getSender().getName();
      InviteSender var5 = invite.getSender();
      String var10000;
      String cancelline;
      String confirmline;
      if (var5 instanceof Town) {
         Town town = (Town)var5;
         confirmline = town.hasNation() ? translator.of("invitation_prefix") + translator.of("you_have_been_invited_to_join3", Colors.colorTown(senderName), Colors.colorNation(town.getNationOrNull())) : translator.of("invitation_prefix") + translator.of("you_have_been_invited_to_join2", Colors.colorTown(senderName));
         var10000 = TownySettings.getAcceptCommand();
         cancelline = var10000 + " " + senderName;
         var10000 = TownySettings.getDenyCommand();
         String cancelline = var10000 + " " + senderName;
         sendInvitationMessage(player, confirmline, cancelline, cancelline);
      }

      if (invite.getSender() instanceof Nation) {
         String firstline;
         if (invite.getReceiver() instanceof Town) {
            var10000 = translator.of("invitation_prefix");
            firstline = var10000 + translator.of("your_town_has_been_invited_to_join_nation", Colors.colorNation(senderName));
            confirmline = "t invite accept " + senderName;
            cancelline = "t invite deny " + senderName;
            sendInvitationMessage(player, firstline, confirmline, cancelline);
         }

         if (invite.getReceiver() instanceof Nation) {
            var10000 = translator.of("invitation_prefix");
            firstline = var10000 + translator.of("you_have_been_requested_to_ally2", Colors.colorNation(senderName));
            confirmline = "n ally accept " + senderName;
            cancelline = "n ally deny " + senderName;
            sendInvitationMessage(player, firstline, confirmline, cancelline);
         }
      }

   }

   public static void sendInvitationMessage(CommandSender player, String firstline, String confirmline, String cancelline) {
      Translator translator = Translator.locale(player);
      TextComponent confirmComponent = (TextComponent)((TextComponent)((TextComponent)Component.text("[/" + confirmline + "]").color(NamedTextColor.GREEN)).hoverEvent(HoverEvent.showText(translator.component("msg_confirmation_spigot_click_accept", confirmline, "/" + confirmline)))).clickEvent(ClickEvent.runCommand("/towny:" + confirmline));
      TextComponent cancelComponent = (TextComponent)((TextComponent)((TextComponent)Component.text("[/" + cancelline + "]").color(NamedTextColor.RED)).hoverEvent(HoverEvent.showText(translator.component("msg_confirmation_spigot_click_cancel", cancelline, "/" + cancelline)))).clickEvent(ClickEvent.runCommand("/towny:" + cancelline));
      Towny.getAdventure().sender(player).sendMessage(((TextComponent)((TextComponent)((TextComponent)Component.text(firstline).append(Component.newline())).append(confirmComponent)).append(Component.space())).append(cancelComponent));
   }

   public static void sendConfirmationMessage(CommandSender sender, Confirmation confirmation) {
      Translator translator = Translator.locale(sender);
      Component firstLineComponent = translator.component("confirmation_prefix").append(confirmation.getTitle().locale(sender).component());
      Component lastLineComponent = translator.component("this_message_will_expire2", confirmation.getDuration());
      TextComponent var10000 = (TextComponent)Component.text("[/" + confirmation.getConfirmCommand() + "]", (TextColor)NamedTextColor.GREEN).hoverEvent(HoverEvent.showText(translator.component("msg_confirmation_spigot_click_accept", confirmation.getConfirmCommand(), "/" + confirmation.getConfirmCommand())));
      String var10001 = confirmation.getPluginPrefix();
      Component confirmComponent = var10000.clickEvent(ClickEvent.runCommand("/" + var10001 + ":" + confirmation.getConfirmCommand()));
      var10000 = (TextComponent)Component.text("[/" + confirmation.getCancelCommand() + "]", (TextColor)NamedTextColor.RED).hoverEvent(HoverEvent.showText(translator.component("msg_confirmation_spigot_click_cancel", confirmation.getCancelCommand(), "/" + confirmation.getCancelCommand())));
      var10001 = confirmation.getPluginPrefix();
      Component cancelComponent = var10000.clickEvent(ClickEvent.runCommand("/" + var10001 + ":" + confirmation.getCancelCommand()));
      Towny.getAdventure().sender(sender).sendMessage(firstLineComponent.append((Component)Component.newline()).append(confirmComponent).append((Component)Component.space()).append(cancelComponent).append((Component)Component.newline()).append(lastLineComponent));
   }

   public static void sendTownList(CommandSender sender, List<Pair<UUID, Component>> towns, ComparatorType compType, int page, int total) {
      Translator translator = Translator.locale(sender);
      int iMax = Math.min(page * 10, towns.size());
      Component[] townsformatted;
      if (page * 10 > towns.size()) {
         townsformatted = new Component[towns.size() % 10];
      } else {
         townsformatted = new Component[10];
      }

      for(int i = (page - 1) * 10; i < iMax; ++i) {
         townsformatted[i % 10] = (Component)((Pair)towns.get(i)).value();
      }

      Audience audience = Towny.getAdventure().sender(sender);
      sendMessage((Object)sender, (String)ChatTools.formatTitle(translator.of("town_plu")));
      String var10001 = translator.of("town_name");
      sendMessage((Object)sender, (String)("§3" + var10001 + (TownySettings.isTownListRandom() ? "" : "§8 - §b" + translator.of(compType.getName()))));
      Component[] var9 = townsformatted;
      int var10 = townsformatted.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         Component textComponent = var9[var11];
         audience.sendMessage(textComponent);
      }

      Component pageFooter = getPageNavigationFooter("towny:town list", page, compType.getCommandString(), total, translator);
      audience.sendMessage(pageFooter);
   }

   public static Component getPageNavigationFooter(String prefix, int page, String arg, int total, Translator translator) {
      Component backButton = ((TextComponent)Component.text("<<<", (TextColor)NamedTextColor.GOLD).clickEvent(ClickEvent.runCommand("/" + prefix + " " + (arg.isEmpty() ? "" : arg + " ") + (page - 1)))).hoverEvent(HoverEvent.showText(translator.component("msg_hover_previous_page")));
      Component forwardButton = ((TextComponent)Component.text(">>>", (TextColor)NamedTextColor.GOLD).clickEvent(ClickEvent.runCommand("/" + prefix + " " + (arg.isEmpty() ? "" : arg + " ") + (page + 1)))).hoverEvent(HoverEvent.showText(translator.component("msg_hover_next_page")));
      Component pageText = ((TextComponent)Component.text("   ").append(translator.component("list_page", page, total))).append(Component.text("   "));
      if (page == 1 && page == total) {
         backButton = backButton.clickEvent((ClickEvent)null).hoverEvent((HoverEventSource)null).color(NamedTextColor.DARK_GRAY);
         forwardButton = forwardButton.clickEvent((ClickEvent)null).hoverEvent((HoverEventSource)null).color(NamedTextColor.DARK_GRAY);
      } else if (page == 1) {
         backButton = backButton.clickEvent((ClickEvent)null).hoverEvent((HoverEventSource)null).color(NamedTextColor.DARK_GRAY);
      } else if (page == total) {
         forwardButton = forwardButton.clickEvent((ClickEvent)null).hoverEvent((HoverEventSource)null).color(NamedTextColor.DARK_GRAY);
      }

      return backButton.append(pageText).append(forwardButton);
   }

   public static void sendNationList(CommandSender sender, List<Pair<UUID, Component>> nations, ComparatorType compType, int page, int total) {
      Translator translator = Translator.locale(sender);
      int iMax = Math.min(page * 10, nations.size());
      Component[] nationsformatted;
      if (page * 10 > nations.size()) {
         nationsformatted = new Component[nations.size() % 10];
      } else {
         nationsformatted = new Component[10];
      }

      for(int i = (page - 1) * 10; i < iMax; ++i) {
         nationsformatted[i % 10] = (Component)((Pair)nations.get(i)).value();
      }

      sendMessage((Object)sender, (String)ChatTools.formatTitle(translator.of("nation_plu")));
      String var10001 = translator.of("nation_name");
      sendMessage((Object)sender, (String)("§3" + var10001 + "§8 - §b" + translator.of(compType.getName())));
      Audience audience = Towny.getAdventure().sender(sender);
      Component[] var9 = nationsformatted;
      int var10 = nationsformatted.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         Component textComponent = var9[var11];
         audience.sendMessage(textComponent);
      }

      Component pageFooter = getPageNavigationFooter("towny:nation list", page, compType.getCommandString(), total, translator);
      audience.sendMessage(pageFooter);
   }

   public static void sendOutpostList(Player player, Town town, int page, int total) {
      Translator translator = Translator.locale((CommandSender)player);
      int outpostsCount = town.getAllOutpostSpawns().size();
      int iMax = Math.min(page * 10, outpostsCount);
      List<Location> outposts = town.getAllOutpostSpawns();
      TextComponent[] outpostsFormatted;
      if (page * 10 > outpostsCount) {
         outpostsFormatted = new TextComponent[outpostsCount % 10];
      } else {
         outpostsFormatted = new TextComponent[10];
      }

      TextComponent dash;
      for(int i = (page - 1) * 10; i < iMax; ++i) {
         Location outpost = (Location)outposts.get(i);
         TownBlock tb = TownyAPI.getInstance().getTownBlock(outpost);
         if (tb != null) {
            String name = !tb.hasPlotObjectGroup() ? tb.getName() : tb.getPlotObjectGroup().getName();
            dash = Component.text(" - ", (TextColor)NamedTextColor.DARK_GRAY);
            TextComponent line = (TextComponent)((TextComponent)Component.text(Integer.toString(i + 1), (TextColor)NamedTextColor.GOLD).clickEvent(ClickEvent.runCommand("/towny:town outpost " + (i + 1)))).append(dash);
            TextComponent outpostName = Component.text(name, (TextColor)NamedTextColor.GREEN);
            TextComponent worldName = Component.text((String)Optional.ofNullable(outpost.getWorld()).map((w) -> {
               return w.getName();
            }).orElse("null"), (TextColor)NamedTextColor.BLUE);
            TextComponent coords = Component.text("(" + outpost.getBlockX() + "," + outpost.getBlockZ() + ")", (TextColor)NamedTextColor.BLUE);
            if (!name.equalsIgnoreCase("")) {
               line = (TextComponent)((TextComponent)line.append(outpostName)).append(dash);
            }

            line = (TextComponent)((TextComponent)((TextComponent)line.append(worldName)).append(dash)).append(coords);
            Translatable spawnCost = Translatable.of("msg_spawn_cost_free");
            if (TownyEconomyHandler.isActive()) {
               spawnCost = Translatable.of("msg_spawn_cost", TownyEconomyHandler.getFormattedBalance(town.getSpawnCost()));
            }

            line = (TextComponent)line.hoverEvent(HoverEvent.showText(Translatable.of("msg_click_spawn", name.equalsIgnoreCase("") ? "outpost" : name).append("\n").append(spawnCost).locale((CommandSender)player).component()));
            outpostsFormatted[i % 10] = line;
         }
      }

      Audience audience = Towny.getAdventure().player(player);
      sendMessage((Object)player, (String)ChatTools.formatTitle(translator.of("outpost_plu")));
      TextComponent[] var20 = outpostsFormatted;
      int var22 = outpostsFormatted.length;

      for(int var23 = 0; var23 < var22; ++var23) {
         dash = var20[var23];
         audience.sendMessage((Component)dash);
      }

      Component pageFooter = getPageNavigationFooter("towny:town outpost list", page, "", total, translator);
      audience.sendMessage(pageFooter);
   }

   public static void sendJailList(CommandSender sender, Town town, int page, int total) {
      Translator translator = Translator.locale(sender);
      List<Jail> jails = town.getJails() == null ? new ArrayList() : new ArrayList(town.getJails());
      int jailCount = jails.size();
      int iMax = Math.min(page * 10, jailCount);
      TextComponent[] jailsFormatted;
      if (page * 10 > jailCount) {
         jailsFormatted = new TextComponent[jailCount % 10];
      } else {
         jailsFormatted = new TextComponent[10];
      }

      String headerMsg = ChatColor.GOLD + "# " + ChatColor.DARK_GRAY + "- " + ChatColor.GREEN + "Jail Name " + ChatColor.DARK_GRAY + "- " + ChatColor.BLUE + "Coord " + ChatColor.DARK_GRAY + "- " + ChatColor.YELLOW + "Cell Count " + ChatColor.DARK_GRAY + "- " + ChatColor.RED + "Primary Jail";

      TextComponent textComponent;
      for(int i = (page - 1) * 10; i < iMax; ++i) {
         Jail jail = (Jail)jails.get(i);
         TextComponent name = Component.text(jail.getName(), (TextColor)NamedTextColor.GREEN);
         TextComponent coord = Component.text(jail.getTownBlock().getWorldCoord().toString(), (TextColor)NamedTextColor.BLUE);
         textComponent = Component.text((int)jail.getJailCellCount(), (TextColor)NamedTextColor.YELLOW);
         TextComponent dash = Component.text(" - ", (TextColor)NamedTextColor.DARK_GRAY);
         TextComponent line = Component.text(Integer.toString(i + 1), (TextColor)NamedTextColor.GOLD);
         if (jail.hasName()) {
            line = (TextComponent)((TextComponent)line.append(dash)).append(name);
         }

         line = (TextComponent)((TextComponent)((TextComponent)((TextComponent)line.append(dash)).append(coord)).append(dash)).append(textComponent);
         Jail primaryJail = town.getPrimaryJail();
         if (primaryJail != null && primaryJail.getUUID().equals(jail.getUUID())) {
            line = (TextComponent)((TextComponent)line.append(dash)).append(Component.text("(Primary Jail)", (TextColor)NamedTextColor.RED));
         }

         jailsFormatted[i % 10] = line;
      }

      Audience audience = Towny.getAdventure().sender(sender);
      sendMessage((Object)sender, (String)ChatTools.formatTitle(Translatable.of("jail_plu").forLocale(sender)));
      sendMessage((Object)sender, (String)headerMsg);
      TextComponent[] var19 = jailsFormatted;
      int var21 = jailsFormatted.length;

      for(int var22 = 0; var22 < var21; ++var22) {
         textComponent = var19[var22];
         audience.sendMessage((Component)textComponent);
      }

      Component pageFooter = getPageNavigationFooter("towny:town jail list", page, "", total, translator);
      audience.sendMessage(pageFooter);
   }

   public static void sendPlotGroupList(CommandSender sender, Town town, int page, int total) {
      Translator translator = Translator.locale(sender);
      int groupCount = town.getPlotGroups().size();
      int iMax = Math.min(page * 10, groupCount);
      List<PlotGroup> groups = new ArrayList(town.getPlotGroups());
      TextComponent[] groupsFormatted;
      if (page * 10 > groupCount) {
         groupsFormatted = new TextComponent[groupCount % 10];
      } else {
         groupsFormatted = new TextComponent[10];
      }

      String headerMsg = ChatColor.GOLD + "# " + ChatColor.DARK_GRAY + "- " + ChatColor.GREEN + "Group Name " + ChatColor.DARK_GRAY + "- " + ChatColor.YELLOW + "Plot Size " + ChatColor.DARK_GRAY + "- " + ChatColor.BLUE + "For Sale";

      TextComponent textComponent;
      for(int i = (page - 1) * 10; i < iMax; ++i) {
         PlotGroup group = (PlotGroup)groups.get(i);
         TextComponent name = Component.text(group.getFormattedName(), (TextColor)NamedTextColor.GREEN);
         TextComponent size = Component.text(String.valueOf(group.getTownBlocks().size()), (TextColor)NamedTextColor.YELLOW);
         textComponent = Component.text(" - ", (TextColor)NamedTextColor.DARK_GRAY);
         TextComponent line = Component.text(Integer.toString(i + 1), (TextColor)NamedTextColor.GOLD);
         line = (TextComponent)((TextComponent)((TextComponent)((TextComponent)line.append(textComponent)).append(name)).append(textComponent)).append(size);
         if (TownyEconomyHandler.isActive() && group.getPrice() != -1.0D) {
            line = (TextComponent)((TextComponent)line.append(textComponent)).append(((TextComponent)Component.text("(", (TextColor)NamedTextColor.BLUE).append(translator.component("towny_map_forsale"))).append(Component.text(": " + TownyEconomyHandler.getFormattedBalance(group.getPrice()) + ")", (TextColor)NamedTextColor.BLUE)));
         }

         groupsFormatted[i % 10] = line;
      }

      Audience audience = Towny.getAdventure().sender(sender);
      String var10001 = town.getName();
      sendMessage((Object)sender, (String)ChatTools.formatTitle(var10001 + " " + translator.of("plotgroup_plu")));
      sendMessage((Object)sender, (String)headerMsg);
      TextComponent[] var17 = groupsFormatted;
      int var19 = groupsFormatted.length;

      for(int var20 = 0; var20 < var19; ++var20) {
         textComponent = var17[var20];
         audience.sendMessage((Component)textComponent);
      }

      Component pageFooter = getPageNavigationFooter("towny:town plotgrouplist " + town.getName(), page, "", total, translator);
      audience.sendMessage(pageFooter);
   }

   public static void sendPlotList(CommandSender sender, Resident resident, int page, int totalPages) {
      Translator translator = Translator.locale(sender);
      boolean hasTPPermission = TownyUniverse.getInstance().getPermissionSource().testPermission((Permissible)sender, PermissionNodes.TOWNY_COMMAND_TOWNYADMIN_TPPLOT.getNode());
      int plotCount = resident.getTownBlocks().size();
      int iMax = Math.min(page * 10, plotCount);
      List<TownBlock> townblocks = new ArrayList(resident.getTownBlocks());
      Component[] plotsFormatted = page * 10 > plotCount ? new Component[plotCount % 10] : new Component[10];
      String headerMsg = ChatColor.GOLD + "# " + ChatColor.DARK_GRAY + "-    " + ChatColor.GREEN + "Coord " + ChatColor.DARK_GRAY + "    -    " + ChatColor.AQUA + "Town" + ChatColor.DARK_GRAY + "    -    " + ChatColor.GREEN + "Type" + ChatColor.DARK_GRAY + "    -    " + ChatColor.YELLOW + "Name";

      String var10001;
      for(int i = (page - 1) * 10; i < iMax; ++i) {
         TownBlock tb = (TownBlock)townblocks.get(i);
         String tbName = tb.getName().isEmpty() ? translator.of("msg_unnamed") : tb.getName();
         Component coord = Component.text(tb.getWorldCoord().toString(), (TextColor)NamedTextColor.GREEN);
         Component town = Component.text(tb.getTownOrNull().getName(), (TextColor)NamedTextColor.AQUA);
         Component type = Component.text(tb.getTypeName(), (TextColor)NamedTextColor.GREEN);
         Component name = Component.text(tbName, (TextColor)NamedTextColor.YELLOW);
         Component dash = Component.text(" - ", (TextColor)NamedTextColor.DARK_GRAY);
         Component line = Component.text(Integer.toString(i + 1), (TextColor)NamedTextColor.GOLD);
         Component line = line.append((Component)dash).append((Component)coord).append((Component)dash).append((Component)town).append((Component)dash).append((Component)type).append((Component)dash).append((Component)name);
         if (hasTPPermission) {
            var10001 = tb.getWorld().getName();
            line = line.clickEvent(ClickEvent.runCommand("/towny:ta tpplot " + var10001 + " " + tb.getX() + " " + tb.getZ()));
            line = line.hoverEvent(HoverEvent.showText(Translatable.of("msg_click_spawn", tb.getWorldCoord()).locale(sender).component()));
         }

         plotsFormatted[i % 10] = line;
      }

      Audience audience = Towny.getAdventure().sender(sender);
      var10001 = resident.getName();
      sendMessage((Object)sender, (String)ChatTools.formatTitle(var10001 + " " + translator.of("townblock_plu")));
      sendMessage((Object)sender, (String)headerMsg);
      Component[] var21 = plotsFormatted;
      int var23 = plotsFormatted.length;

      for(int var24 = 0; var24 < var23; ++var24) {
         Component component = var21[var24];
         audience.sendMessage(component);
      }

      Component pageFooter = getPageNavigationFooter("towny:resident plotlist " + resident.getName(), page, "", totalPages, translator);
      audience.sendMessage(pageFooter);
   }

   public static void sendMsg(CommandSender sender, Translatable... translatables) {
      sendMsg(sender, Translation.translateTranslatables(sender, translatables));
   }

   public static void sendMsg(CommandSender sender, Translatable translatable) {
      sendMsg(sender, translatable.locale(sender).translate());
   }

   public static void sendMessage(CommandSender sender, Translatable... translatables) {
      sendMessage((Object)sender, (String)Translation.translateTranslatables(sender, translatables));
   }

   public static void sendMessage(CommandSender sender, Translatable translatable) {
      sendMessage((Object)sender, (String)translatable.locale(sender).translate());
   }

   public static void sendErrorMsg(CommandSender sender, Translatable... translatables) {
      sendErrorMsg((Object)sender, (String)Translation.translateTranslatables(sender, translatables));
   }

   public static void sendErrorMsg(CommandSender sender, Translatable translatable) {
      sendErrorMsg((Object)sender, (String)translatable.locale(sender).translate());
   }

   public static void sendGlobalMessage(Translatable translatable) {
      Iterator var1 = Bukkit.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player player = (Player)var1.next();
         if (player != null && TownyAPI.getInstance().isTownyWorld(player.getWorld())) {
            sendMsg((CommandSender)player, (Translatable)translatable);
         }
      }

      LOGGER.info("[Global Message] " + translatable.stripColors(true).translate());
   }

   public static void sendPrefixedNationMessage(Nation nation, Translatable message) {
      Logger var10000 = LOGGER;
      String var10001 = StringMgmt.remUnderscore(nation.getName());
      var10000.info(Colors.strip("[Nation Msg] " + var10001 + ": " + message.translate()));
      Iterator var2 = TownyAPI.getInstance().getOnlinePlayers(nation).iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         sendMessage((CommandSender)player, (Translatable)Translatable.of("default_nation_prefix", StringMgmt.remUnderscore(nation.getName())).append(message));
      }

   }

   public static void sendPrefixedTownMessage(Town town, Translatable message) {
      Logger var10000 = LOGGER;
      String var10001 = StringMgmt.remUnderscore(town.getName());
      var10000.info(Colors.strip("[Town Msg] " + var10001 + ": " + message.translate()));
      Iterator var2 = TownyAPI.getInstance().getOnlinePlayers(town).iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         sendMessage((CommandSender)player, (Translatable)Translatable.of("default_town_prefix", StringMgmt.remUnderscore(town.getName())).append(message));
      }

   }

   public static void sendPrefixedTownMessage(Resident resident, Translatable message) {
      Town town = resident.getTownOrNull();
      if (town == null) {
         sendMsg(resident, message);
      } else {
         sendPrefixedTownMessage(town, message);
      }

   }

   public static void sendNationMessagePrefixed(Nation nation, Translatable message) {
      Logger var10000 = LOGGER;
      String var10001 = StringMgmt.remUnderscore(nation.getName());
      var10000.info(Colors.strip("[Nation Msg] " + var10001 + ": " + message.translate()));
      Iterator var2 = TownyAPI.getInstance().getOnlinePlayers(nation).iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         sendMsg((CommandSender)player, (Translatable)message);
      }

   }

   public static void sendTownMessagePrefixed(Town town, Translatable message) {
      Logger var10000 = LOGGER;
      String var10001 = Colors.strip("[Town Msg] " + StringMgmt.remUnderscore(town.getName()));
      var10000.info(var10001 + ": " + message.translate());
      Iterator var2 = TownyAPI.getInstance().getOnlinePlayers(town).iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         sendMsg((CommandSender)player, (Translatable)message);
      }

   }

   public static void sendMsg(Resident resident, Translatable message) {
      if (resident.isOnline()) {
         sendMsg((CommandSender)resident.getPlayer(), (Translatable)message);
      }

   }

   public static void sendMsg(Translatable message) {
      LOGGER.info(message.stripColors(true).translate());
   }

   public static void sendErrorMsg(Translatable message) {
      LOGGER.warn("Error: " + message.stripColors(true).translate());
   }

   public static void sendMsgToOnlineAdmins(Translatable message) {
      sendMsg(message);
      Iterator var1 = Bukkit.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player player = (Player)var1.next();
         if (TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((Permissible)player)) {
            sendMsg((CommandSender)player, (Translatable)message);
         }
      }

   }

   public static void sendStatusScreen(CommandSender sender, StatusScreen screen) {
      Towny.getAdventure().sender(sender).sendMessage(screen.getFormattedStatusScreen());
   }

   public static void sendActionBarMessageToPlayer(Player player, String message) {
      sendActionBarMessageToPlayer(player, TownyComponents.miniMessage(message));
   }

   public static void sendActionBarMessageToPlayer(Player player, Component component) {
      Towny.getAdventure().player(player).sendActionBar(component);
   }

   public static void sendBossBarMessageToPlayer(Player player, String message, float progress, BossBar.Color color, BossBar.Overlay overlay) {
      sendBossBarMessageToPlayer(player, TownyComponents.miniMessage(message), progress, color, overlay);
   }

   public static void sendBossBarMessageToPlayer(Player player, Component component, float progress, BossBar.Color color, BossBar.Overlay overlay) {
      Towny.getAdventure().player(player).showBossBar(BossBar.bossBar(component, progress, color, overlay));
   }

   public static void sendBossBarMessageToPlayer(Player player, BossBar bossBar) {
      Towny.getAdventure().player(player).showBossBar(bossBar);
   }
}
