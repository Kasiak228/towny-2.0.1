package com.palmergames.bukkit.towny.permissions;

import com.palmergames.adventure.util.TriState;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.exceptions.NoPermissionException;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownyPermission;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.Iterator;
import java.util.Locale;
import org.anjocaido.groupmanager.GroupManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permissible;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.jetbrains.annotations.NotNull;

public abstract class TownyPermissionSource {
   protected TownySettings settings;
   protected Towny plugin;
   protected GroupManager groupManager = null;

   public abstract String getPrefixSuffix(Resident var1, String var2);

   public abstract int getGroupPermissionIntNode(String var1, String var2);

   public abstract int getPlayerPermissionIntNode(String var1, String var2);

   public abstract String getPlayerGroup(Player var1);

   public abstract String getPlayerPermissionStringNode(String var1, String var2);

   protected int getEffectivePermIntNode(String playerName, String node) {
      Player player = BukkitTools.getPlayerExact(playerName);
      if (player == null) {
         return -1;
      } else {
         int biggest = -1;
         Iterator var5 = player.getEffectivePermissions().iterator();

         while(var5.hasNext()) {
            PermissionAttachmentInfo test = (PermissionAttachmentInfo)var5.next();
            if (test.getPermission().startsWith(node + ".")) {
               String[] split = test.getPermission().split("\\.");

               try {
                  int i = Integer.parseInt(split[split.length - 1]);
                  biggest = Math.max(biggest, i);
               } catch (NumberFormatException var9) {
               }
            }
         }

         return biggest;
      }
   }

   public boolean hasWildOverride(TownyWorld world, Player player, Material material, TownyPermission.ActionType action) {
      PermissionNodes var10000 = PermissionNodes.TOWNY_WILD_ALL;
      String var10001 = action.toString().toLowerCase(Locale.ROOT);
      String blockPerm = var10000.getNode(var10001 + "." + material);
      return this.testPermission((Permissible)player, blockPerm) || this.unclaimedZoneAction(world, material, action);
   }

   public boolean unclaimedZoneAction(TownyWorld world, Material material, TownyPermission.ActionType action) {
      switch(action) {
      case BUILD:
         return world.getUnclaimedZoneBuild() || world.isUnclaimedZoneIgnoreMaterial(material);
      case DESTROY:
         return world.getUnclaimedZoneDestroy() || world.isUnclaimedZoneIgnoreMaterial(material);
      case SWITCH:
         return world.getUnclaimedZoneSwitch() || world.isUnclaimedZoneIgnoreMaterial(material);
      case ITEM_USE:
         return world.getUnclaimedZoneItemUse() || world.isUnclaimedZoneIgnoreMaterial(material);
      default:
         return false;
      }
   }

   public boolean hasOwnTownOverride(Player player, Material material, TownyPermission.ActionType action) {
      PermissionNodes var10000 = PermissionNodes.TOWNY_CLAIMED_OWNTOWN_ALL;
      String var10001 = action.toString().toLowerCase(Locale.ROOT);
      String blockPerm = var10000.getNode(var10001 + "." + material);
      return this.testPermission((Permissible)player, blockPerm) || this.hasAllTownOverride(player, material, action);
   }

   public boolean hasTownOwnedOverride(Player player, Material material, TownyPermission.ActionType action) {
      PermissionNodes var10000 = PermissionNodes.TOWNY_CLAIMED_TOWNOWNED_ALL;
      String var10001 = action.toString().toLowerCase(Locale.ROOT);
      String blockPerm = var10000.getNode(var10001 + "." + material);
      return this.testPermission((Permissible)player, blockPerm) || this.hasOwnTownOverride(player, material, action) || this.hasAllTownOverride(player, material, action);
   }

   public boolean hasAllTownOverride(Player player, Material material, TownyPermission.ActionType action) {
      PermissionNodes var10000 = PermissionNodes.TOWNY_CLAIMED_ALLTOWN_ALL;
      String var10001 = action.toString().toLowerCase(Locale.ROOT);
      String blockPerm = var10000.getNode(var10001 + "." + material);
      return this.testPermission((Permissible)player, blockPerm);
   }

   public boolean isTownyAdmin(@NotNull Permissible permissible) {
      TriState has = this.strictHas(permissible, PermissionNodes.TOWNY_ADMIN.getNode());
      if (has != TriState.FALSE) {
         if (!(permissible instanceof Player)) {
            return has == TriState.TRUE || permissible.isOp();
         }

         Player player = (Player)permissible;
         if (!Towny.getPlugin().hasPlayerMode(player, "adminbypass")) {
            return has == TriState.TRUE || permissible.isOp();
         }
      }

      return false;
   }

   public void testPermissionOrThrow(Permissible permissible, String perm) throws NoPermissionException {
      if (!this.testPermission(permissible, perm)) {
         throw new NoPermissionException();
      }
   }

   public void testPermissionOrThrow(Permissible permissible, String perm, Translatable errormsg) throws NoPermissionException {
      if (!this.testPermission(permissible, perm)) {
         throw new NoPermissionException(errormsg);
      }
   }

   public boolean testPermission(Permissible permissible, String perm) {
      TriState has = this.strictHas(permissible, perm);
      if (has == TriState.FALSE) {
         return false;
      } else {
         return has == TriState.TRUE || this.isTownyAdmin(permissible);
      }
   }

   private TriState strictHas(Permissible permissible, String node) {
      if (permissible.isPermissionSet(node)) {
         return TriState.byBoolean(permissible.hasPermission(node));
      } else {
         String[] parts = node.split("\\.");
         StringBuilder builder = new StringBuilder(node.length());
         String[] var5 = parts;
         int var6 = parts.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            String part = var5[var7];
            builder.append('*');
            String newNode = builder.toString();
            if (permissible.isPermissionSet(newNode)) {
               return TriState.byBoolean(permissible.hasPermission(newNode));
            }

            builder.deleteCharAt(builder.length() - 1);
            builder.append(part).append('.');
         }

         return TriState.NOT_SET;
      }
   }
}
