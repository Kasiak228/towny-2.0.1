package com.palmergames.bukkit.towny.permissions;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.Colors;
import java.util.Iterator;
import org.anjocaido.groupmanager.GroupManager;
import org.anjocaido.groupmanager.data.Group;
import org.anjocaido.groupmanager.events.GMGroupEvent;
import org.anjocaido.groupmanager.events.GMSystemEvent;
import org.anjocaido.groupmanager.events.GMUserEvent;
import org.anjocaido.groupmanager.permissions.AnjoPermissionsHandler;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.IllegalPluginAccessException;
import org.bukkit.plugin.Plugin;

public class GroupManagerSource extends TownyPermissionSource {
   public GroupManagerSource(Towny towny, Plugin test) {
      this.groupManager = (GroupManager)test;
      this.plugin = towny;

      try {
         this.plugin.getServer().getPluginManager().registerEvents(new GroupManagerSource.GMCustomEventListener(), this.plugin);
      } catch (IllegalPluginAccessException var4) {
         this.plugin.getLogger().warning("Your Version of GroupManager is out of date. Please update.");
      }

   }

   public String getPrefixSuffix(Resident resident, String node) {
      Player player = resident.getPlayer();
      if (player == null) {
         return "";
      } else {
         String group = "";
         String user = "";
         AnjoPermissionsHandler handler = this.groupManager.getWorldsHolder().getWorldData(player).getPermissionsHandler();
         if (node.equals("prefix")) {
            group = handler.getGroupPrefix(handler.getPrimaryGroup(player.getName()));
            user = handler.getUserPrefix(player.getName());
         } else if (node.equals("suffix")) {
            group = handler.getGroupSuffix(handler.getPrimaryGroup(player.getName()));
            user = handler.getUserSuffix(player.getName());
         } else if (node.equals("userprefix")) {
            group = "";
            user = handler.getUserPrefix(player.getName());
         } else if (node.equals("usersuffix")) {
            group = "";
            user = handler.getUserSuffix(player.getName());
         } else if (node.equals("groupprefix")) {
            group = handler.getGroupPrefix(handler.getPrimaryGroup(player.getName()));
            user = "";
         } else if (node.equals("groupsuffix")) {
            group = handler.getGroupSuffix(handler.getPrimaryGroup(player.getName()));
            user = "";
         }

         if (group == null) {
            group = "";
         }

         if (user == null) {
            user = "";
         }

         if (!group.equals(user)) {
            user = group + user;
         }

         user = Colors.translateColorCodes(user);
         return user;
      }
   }

   public int getGroupPermissionIntNode(String playerName, String node) {
      int iReturn = true;
      Player player = BukkitTools.getPlayerExact(playerName);
      AnjoPermissionsHandler handler = this.groupManager.getWorldsHolder().getWorldData(player).getPermissionsHandler();
      int iReturn = handler.getPermissionInteger(playerName, node);
      if (iReturn == -1) {
         iReturn = this.getEffectivePermIntNode(playerName, node);
      }

      return iReturn;
   }

   public int getPlayerPermissionIntNode(String playerName, String node) {
      Player player = BukkitTools.getPlayerExact(playerName);
      if (player == null) {
         return -1;
      } else {
         AnjoPermissionsHandler handler = this.groupManager.getWorldsHolder().getWorldData(player).getPermissionsHandler();
         int iReturn = handler.getPermissionInteger(playerName, node);
         if (iReturn == -1) {
            iReturn = this.getEffectivePermIntNode(playerName, node);
         }

         return iReturn;
      }
   }

   public String getPlayerPermissionStringNode(String playerName, String node) {
      Player player = BukkitTools.getPlayerExact(playerName);
      if (player == null) {
         return "";
      } else {
         AnjoPermissionsHandler handler = this.groupManager.getWorldsHolder().getWorldData(player).getPermissionsHandler();
         return handler.getPermissionString(playerName, node);
      }
   }

   public String getPlayerGroup(Player player) {
      AnjoPermissionsHandler handler = this.groupManager.getWorldsHolder().getWorldData(player).getPermissionsHandler();
      return handler.getGroup(player.getName());
   }

   protected class GMCustomEventListener implements Listener {
      public GMCustomEventListener() {
      }

      @EventHandler(
         priority = EventPriority.HIGH
      )
      public void onGMUserEvent(GMUserEvent event) {
         try {
            GroupManagerSource.PermissionEventEnums.GMUser_Action.valueOf(event.getAction().name());
         } catch (IllegalArgumentException var5) {
            return;
         }

         Resident resident = TownyUniverse.getInstance().getResident(event.getUserName());
         if (resident != null) {
            Player player = BukkitTools.getPlayerExact(resident.getName());
            if (player != null) {
               String[] modes = GroupManagerSource.this.getPlayerPermissionStringNode(player.getName(), PermissionNodes.TOWNY_DEFAULT_MODES.getNode()).split(",");
               GroupManagerSource.this.plugin.setPlayerMode(player, modes, false);
               GroupManagerSource.this.plugin.resetCache(player);
            }
         }

      }

      @EventHandler(
         priority = EventPriority.HIGH
      )
      public void onGMGroupEvent(GMGroupEvent event) {
         try {
            if (GroupManagerSource.PermissionEventEnums.GMGroup_Action.valueOf(event.getAction().name()) != null) {
               Group group = event.getGroup();
               Iterator var3 = BukkitTools.getOnlinePlayers().iterator();

               while(var3.hasNext()) {
                  Player toUpdate = (Player)var3.next();
                  if (toUpdate != null && group.toString().equals(GroupManagerSource.this.getPlayerGroup(toUpdate))) {
                     String[] modes = GroupManagerSource.this.getPlayerPermissionStringNode(toUpdate.getName(), PermissionNodes.TOWNY_DEFAULT_MODES.getNode()).split(",");
                     GroupManagerSource.this.plugin.setPlayerMode(toUpdate, modes, false);
                     GroupManagerSource.this.plugin.resetCache(toUpdate);
                  }
               }
            }
         } catch (IllegalArgumentException var6) {
         }

      }

      @EventHandler(
         priority = EventPriority.HIGH
      )
      public void onGMSystemEvent(GMSystemEvent event) {
         try {
            if (GroupManagerSource.PermissionEventEnums.GMSystem_Action.valueOf(event.getAction().name()) != null) {
               Iterator var2 = BukkitTools.getOnlinePlayers().iterator();

               while(var2.hasNext()) {
                  Player toUpdate = (Player)var2.next();
                  if (toUpdate != null) {
                     String[] modes = GroupManagerSource.this.getPlayerPermissionStringNode(toUpdate.getName(), PermissionNodes.TOWNY_DEFAULT_MODES.getNode()).split(",");
                     GroupManagerSource.this.plugin.setPlayerMode(toUpdate, modes, false);
                     GroupManagerSource.this.plugin.resetCache(toUpdate);
                  }
               }
            }
         } catch (IllegalArgumentException var5) {
         }

      }
   }

   protected class PermissionEventEnums {
      public static enum GMSystem_Action {
         RELOADED,
         DEFAULT_GROUP_CHANGED;

         // $FF: synthetic method
         private static GroupManagerSource.PermissionEventEnums.GMSystem_Action[] $values() {
            return new GroupManagerSource.PermissionEventEnums.GMSystem_Action[]{RELOADED, DEFAULT_GROUP_CHANGED};
         }
      }

      public static enum GMGroup_Action {
         GROUP_PERMISSIONS_CHANGED,
         GROUP_INHERITANCE_CHANGED,
         GROUP_INFO_CHANGED,
         GROUP_REMOVED;

         // $FF: synthetic method
         private static GroupManagerSource.PermissionEventEnums.GMGroup_Action[] $values() {
            return new GroupManagerSource.PermissionEventEnums.GMGroup_Action[]{GROUP_PERMISSIONS_CHANGED, GROUP_INHERITANCE_CHANGED, GROUP_INFO_CHANGED, GROUP_REMOVED};
         }
      }

      public static enum GMUser_Action {
         USER_PERMISSIONS_CHANGED,
         USER_INHERITANCE_CHANGED,
         USER_INFO_CHANGED,
         USER_GROUP_CHANGED,
         USER_SUBGROUP_CHANGED,
         USER_ADDED,
         USER_REMOVED;

         // $FF: synthetic method
         private static GroupManagerSource.PermissionEventEnums.GMUser_Action[] $values() {
            return new GroupManagerSource.PermissionEventEnums.GMUser_Action[]{USER_PERMISSIONS_CHANGED, USER_INHERITANCE_CHANGED, USER_INFO_CHANGED, USER_GROUP_CHANGED, USER_SUBGROUP_CHANGED, USER_ADDED, USER_REMOVED};
         }
      }
   }
}
