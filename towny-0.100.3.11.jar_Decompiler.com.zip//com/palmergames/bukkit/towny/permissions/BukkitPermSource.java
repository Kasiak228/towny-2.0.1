package com.palmergames.bukkit.towny.permissions;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.util.BukkitTools;
import java.util.Iterator;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;

public class BukkitPermSource extends TownyPermissionSource {
   public BukkitPermSource(Towny towny) {
      this.plugin = towny;
   }

   public String getPrefixSuffix(Resident resident, String node) {
      Player player = resident.getPlayer();
      if (player == null) {
         return "";
      } else {
         Iterator var4 = player.getEffectivePermissions().iterator();

         PermissionAttachmentInfo test;
         do {
            if (!var4.hasNext()) {
               return "";
            }

            test = (PermissionAttachmentInfo)var4.next();
         } while(!test.getPermission().startsWith(node + "."));

         String[] split = test.getPermission().split("\\.");
         return split[split.length - 1];
      }
   }

   public int getGroupPermissionIntNode(String playerName, String node) {
      return this.getEffectivePermIntNode(playerName, node);
   }

   public int getPlayerPermissionIntNode(String playerName, String node) {
      return this.getEffectivePermIntNode(playerName, node);
   }

   public String getPlayerPermissionStringNode(String playerName, String node) {
      Player player = BukkitTools.getPlayerExact(playerName);
      if (player == null) {
         return "";
      } else {
         Iterator var4 = player.getEffectivePermissions().iterator();

         PermissionAttachmentInfo test;
         do {
            if (!var4.hasNext()) {
               return "";
            }

            test = (PermissionAttachmentInfo)var4.next();
         } while(!test.getPermission().startsWith(node + "."));

         String[] split = test.getPermission().split("\\.");
         return split[split.length - 1];
      }
   }

   public String getPlayerGroup(Player player) {
      return "";
   }
}
