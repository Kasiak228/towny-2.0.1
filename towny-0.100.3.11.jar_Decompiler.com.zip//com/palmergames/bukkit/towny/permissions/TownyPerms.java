package com.palmergames.bukkit.towny.permissions;

import com.palmergames.bukkit.config.CommentedConfiguration;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.exceptions.initialization.TownyInitException;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.util.JavaUtil;
import java.io.IOException;
import java.io.InputStream;
import java.lang.invoke.MethodHandle;
import java.nio.file.CopyOption;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.logging.Level;
import org.bukkit.configuration.MemorySection;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.permissions.PermissionDefault;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TownyPerms {
   protected static final LinkedHashMap<String, Permission> registeredPermissions = new LinkedHashMap();
   protected static final Map<String, PermissionAttachment> attachments = new ConcurrentHashMap();
   private static final HashMap<String, List<String>> groupPermsMap = new HashMap();
   private static CommentedConfiguration perms;
   private static Towny plugin;
   private static final List<String> vitalGroups = Arrays.asList("nomad", "towns.default", "towns.mayor", "towns.ranks", "nations.default", "nations.king", "nations.ranks");
   private static final HashMap<UUID, String> residentPrefixMap = new HashMap();
   private static final String RANKPRIORITY_PREFIX = "towny.rankpriority.";
   private static final String RANKPREFIX_PREFIX = "towny.rankprefix.";
   private static final MethodHandle PERMISSIONS = (MethodHandle)Objects.requireNonNull(JavaUtil.getFieldHandle(PermissionAttachment.class, "permissions"), "Could not find expected PermissionAttachment.permissions field");

   public static void initialize(Towny plugin) {
      TownyPerms.plugin = plugin;
   }

   public static void loadPerms(@NotNull Path permsYMLPath) {
      try {
         InputStream resource = Towny.class.getResourceAsStream("/townyperms.yml");
         if (resource == null) {
            throw new TownyInitException("Could not find 'townyperms.yml' in the JAR.", TownyInitException.TownyError.PERMISSIONS);
         }

         Files.copy(resource, permsYMLPath, new CopyOption[0]);
      } catch (FileAlreadyExistsException var2) {
      } catch (IOException var3) {
         throw new TownyInitException("Could not copy townyperms.yml from JAR to '" + permsYMLPath + "'.", TownyInitException.TownyError.PERMISSIONS, var3);
      }

      perms = new CommentedConfiguration(permsYMLPath);
      if (!perms.load()) {
         throw new TownyInitException("Could not read townyperms.yml", TownyInitException.TownyError.PERMISSIONS);
      } else {
         groupPermsMap.clear();
         buildGroupPermsMap();
         checkForVitalGroups();
         buildComments();
         perms.save();
         collectPermissions();
      }
   }

   private static void checkForVitalGroups() {
      Iterator var0 = vitalGroups.iterator();

      String group;
      do {
         if (!var0.hasNext()) {
            return;
         }

         group = (String)var0.next();
      } while(groupPermsMap.containsKey(group));

      throw new TownyInitException(getErrorMessageForGroup(group), TownyInitException.TownyError.PERMISSIONS);
   }

   @NotNull
   private static String getErrorMessageForGroup(String group) {
      if (!group.contains(".")) {
         return "Your townyperms.yml is missing the " + group + " group. Maybe you renamed it?";
      } else {
         String[] split = group.split("\\.");
         return "Your townyperms.yml's " + split[0] + " section is missing the " + split[1] + " group. Maybe you renamed it?";
      }
   }

   public static void assignPermissions(Resident resident, Player player) {
      if (resident == null) {
         if (player != null) {
            resident = TownyAPI.getInstance().getResident(player);
         }

         if (resident == null) {
            return;
         }
      } else {
         player = resident.getPlayer();
      }

      if (player != null && player.isOnline()) {
         TownyWorld world = TownyAPI.getInstance().getTownyWorld(player.getWorld());
         if (world != null) {
            PermissionAttachment attachment = (PermissionAttachment)attachments.computeIfAbsent(resident.getName(), (k) -> {
               return player.addAttachment(plugin);
            });

            try {
               Map<String, Boolean> orig = PERMISSIONS.invokeExact(attachment);
               orig.clear();
               if (world.isUsingTowny()) {
                  orig.putAll(getResidentPerms(resident));
               }

               player.recalculatePermissions();
            } catch (Throwable var6) {
               plugin.getLogger().log(Level.WARNING, "exception occurred while assigning permissions to player " + player.getName(), var6);
            }

            attachments.put(resident.getName(), attachment);
            setResidentPrimaryRankPrefix(resident);
         }
      } else {
         attachments.remove(resident.getName());
      }
   }

   public static void removeAttachment(String name) {
      attachments.remove(name);
   }

   public static void updateOnlinePerms() {
      Iterator var0 = BukkitTools.getOnlinePlayers().iterator();

      while(var0.hasNext()) {
         Player player = (Player)var0.next();
         assignPermissions((Resident)null, player);
      }

   }

   public static void updateTownPerms(Town town) {
      Iterator var1 = town.getResidents().iterator();

      while(var1.hasNext()) {
         Resident resident = (Resident)var1.next();
         assignPermissions(resident, (Player)null);
      }

   }

   public static void updateNationPerms(Nation nation) {
      Iterator var1 = nation.getTowns().iterator();

      while(var1.hasNext()) {
         Town town = (Town)var1.next();
         updateTownPerms(town);
      }

   }

   private static List<String> getList(String path) {
      return (List)(perms.contains(path) ? perms.getStringList(path) : new ArrayList());
   }

   public static LinkedHashMap<String, Boolean> getResidentPerms(Resident resident) {
      Set<String> permList = new HashSet(getDefault());
      Town town = resident.getTownOrNull();
      if (town != null) {
         permList.addAll(getTownDefault(town.getName().toLowerCase(Locale.ROOT)));
         if (resident.isMayor()) {
            permList.addAll(getTownMayor());
         }

         Iterator var3 = resident.getTownRanks().iterator();

         while(var3.hasNext()) {
            String rank = (String)var3.next();
            permList.addAll(getTownRankPermissions(rank));
         }

         Nation nation = town.getNationOrNull();
         if (nation != null) {
            permList.addAll(getNationDefault(nation.getName().toLowerCase(Locale.ROOT)));
            if (resident.isKing()) {
               permList.addAll(getNationKing());
            }

            Iterator var10 = resident.getNationRanks().iterator();

            while(var10.hasNext()) {
               String rank = (String)var10.next();
               permList.addAll(getNationRankPermissions(rank));
            }
         } else {
            permList.add("towny.nationless");
         }

         if (isPeaceful(resident.getTownOrNull())) {
            permList.addAll(getList("peaceful"));
         }
      } else {
         permList.add("towny.townless");
         permList.add("towny.nationless");
      }

      List<String> playerPermArray = sort(permList);
      LinkedHashMap<String, Boolean> newPerms = new LinkedHashMap();
      Iterator var12 = playerPermArray.iterator();

      while(var12.hasNext()) {
         String permission = (String)var12.next();
         if (permission.contains("{townname}") && resident.getTownOrNull() != null) {
            permission = permission.replace("{townname}", resident.getTownOrNull().getName().toLowerCase(Locale.ROOT));
         }

         if (permission.contains("{nationname}") && resident.getNationOrNull() != null) {
            permission = permission.replace("{nationname}", resident.getNationOrNull().getName().toLowerCase(Locale.ROOT));
         }

         boolean value = !permission.startsWith("-");
         newPerms.put(value ? permission : permission.substring(1), value);
      }

      return newPerms;
   }

   public static void registerPermissionNodes() {
      plugin.getScheduler().runLater(() -> {
         Iterator var1 = getTownRanks().iterator();

         Permission perm;
         String rank;
         while(var1.hasNext()) {
            rank = (String)var1.next();
            perm = new Permission(PermissionNodes.TOWNY_COMMAND_TOWN_RANK.getNode(rank), "User can grant this town rank to others..", PermissionDefault.FALSE, (Map)null);
            perm.addParent(PermissionNodes.TOWNY_COMMAND_TOWN_RANK.getNode(), true);
         }

         var1 = getNationRanks().iterator();

         while(var1.hasNext()) {
            rank = (String)var1.next();
            perm = new Permission(PermissionNodes.TOWNY_COMMAND_NATION_RANK.getNode(rank), "User can grant this nation rank to others..", PermissionDefault.FALSE, (Map)null);
            perm.addParent(PermissionNodes.TOWNY_COMMAND_NATION_RANK.getNode(), true);
         }

      }, 1L);
   }

   public static List<String> getDefault() {
      return getList("nomad");
   }

   public static List<String> getTownRanks() {
      return new ArrayList(((MemorySection)perms.get("towns.ranks")).getKeys(false));
   }

   public static List<String> getTownDefault(String townName) {
      List<String> permsList = getList("towns.default");
      permsList.add("towny.town." + townName);
      return permsList;
   }

   public static List<String> getTownMayor() {
      return getList("towns.mayor");
   }

   public static List<String> getTownRankPermissions(String rank) {
      return getList("towns.ranks." + rank);
   }

   public static List<String> getNationRanks() {
      return new ArrayList(((MemorySection)perms.get("nations.ranks")).getKeys(false));
   }

   public static List<String> getNationDefault(String nationName) {
      List<String> permsList = getList("nations.default");
      permsList.add("towny.nation." + nationName);
      return permsList;
   }

   public static List<String> getNationKing() {
      return getList("nations.king");
   }

   public static List<String> getNationRankPermissions(String rank) {
      return getList("nations.ranks." + rank);
   }

   @Nullable
   public static String matchNationRank(String rank) {
      Iterator var1 = getNationRanks().iterator();

      String nationRank;
      do {
         if (!var1.hasNext()) {
            return null;
         }

         nationRank = (String)var1.next();
      } while(!nationRank.equalsIgnoreCase(rank));

      return nationRank;
   }

   @Nullable
   public static String matchTownRank(String rank) {
      Iterator var1 = getTownRanks().iterator();

      String townRank;
      do {
         if (!var1.hasNext()) {
            return null;
         }

         townRank = (String)var1.next();
      } while(!townRank.equalsIgnoreCase(rank));

      return townRank;
   }

   private static boolean isPeaceful(Town town) {
      return town.isNeutral() || town.hasNation() && town.getNationOrNull().isNeutral();
   }

   public static boolean hasPeacefulNodes() {
      return !getList("peaceful").isEmpty();
   }

   public static String getResidentPrimaryRankPrefix(Resident resident) {
      return (String)residentPrefixMap.getOrDefault(resident.getUUID(), setResidentPrimaryRankPrefix(resident));
   }

   private static String setResidentPrimaryRankPrefix(Resident resident) {
      String prefix = getPrimaryRankPrefix(resident);
      residentPrefixMap.put(resident.getUUID(), prefix);
      return prefix;
   }

   private static String getPrimaryRankPrefix(Resident resident) {
      String prefix = getHighestPriorityRankPrefix(resident);
      return prefix == null ? "" : prefix;
   }

   @Nullable
   private static String getHighestPriorityRankPrefix(Resident resident) {
      String rank;
      String prefix;
      if (resident.hasNation() && !resident.getNationRanks().isEmpty()) {
         rank = getHighestPriorityRank(resident, resident.getNationRanks(), (r) -> {
            return getNationRankPermissions(r);
         });
         prefix = getPrefixFromRank(getNationRankPermissions(rank));
         if (prefix != null) {
            return prefix;
         }
      }

      if (resident.hasTown() && !resident.getTownRanks().isEmpty()) {
         rank = getHighestPriorityRank(resident, resident.getTownRanks(), (r) -> {
            return getTownRankPermissions(r);
         });
         prefix = getPrefixFromRank(getTownRankPermissions(rank));
         if (prefix != null) {
            return prefix;
         }
      }

      return null;
   }

   private static String getPrefixFromRank(List<String> nodes) {
      Iterator var1 = nodes.iterator();

      String node;
      do {
         if (!var1.hasNext()) {
            return null;
         }

         node = (String)var1.next();
      } while(!node.startsWith("towny.rankprefix."));

      return node.substring("towny.rankprefix.".length());
   }

   public static String getHighestPriorityRank(Resident resident, List<String> ranks, Function<String, List<String>> rankFunction) {
      Map<String, Integer> rankPriorityMap = new HashMap();
      Iterator var4 = ranks.iterator();

      while(var4.hasNext()) {
         String rank = (String)var4.next();
         rankPriorityMap.put(rank, getRankPriority((List)rankFunction.apply(rank)));
      }

      return (String)((Entry)Collections.max(rankPriorityMap.entrySet(), Comparator.comparingInt(Entry::getValue))).getKey();
   }

   private static int getRankPriority(List<String> nodes) {
      int topValue = 0;
      Iterator var2 = nodes.iterator();

      while(var2.hasNext()) {
         String node = (String)var2.next();
         if (node.startsWith("towny.rankpriority.")) {
            int priorityValue = getNodePriority(node);
            if (topValue < priorityValue) {
               topValue = priorityValue;
            }
         }
      }

      return topValue;
   }

   private static int getNodePriority(String node) {
      try {
         return Integer.parseInt(node.substring("towny.rankpriority.".length()));
      } catch (NumberFormatException var2) {
         return 0;
      }
   }

   public static void collectPermissions() {
      registeredPermissions.clear();
      Iterator var0 = BukkitTools.getPluginManager().getPermissions().iterator();

      while(var0.hasNext()) {
         Permission perm = (Permission)var0.next();
         registeredPermissions.put(perm.getName().toLowerCase(Locale.ROOT), perm);
      }

   }

   private static List<String> sort(Iterable<String> permList) {
      List<String> result = new ArrayList();
      Iterator var2 = permList.iterator();

      while(var2.hasNext()) {
         String key = (String)var2.next();
         String a = key.charAt(0) == '-' ? key.substring(1) : key;
         Map<String, Boolean> allchildren = getAllChildren(a, new HashSet());
         if (allchildren != null) {
            ListIterator itr = result.listIterator();

            while(itr.hasNext()) {
               String node = (String)itr.next();
               String b = node.charAt(0) == '-' ? node.substring(1) : node;
               if (allchildren.containsKey(b)) {
                  itr.set(key);
                  itr.add(node);
                  break;
               }
            }
         }

         if (!result.contains(key)) {
            result.add(key);
         }
      }

      return result;
   }

   public List<String> getAllRegisteredPermissions(boolean includeChildren) {
      List<String> perms = new ArrayList();
      Iterator var3 = registeredPermissions.keySet().iterator();

      while(true) {
         Map children;
         do {
            String key;
            do {
               do {
                  if (!var3.hasNext()) {
                     return perms;
                  }

                  key = (String)var3.next();
               } while(perms.contains(key));

               perms.add(key);
            } while(!includeChildren);

            children = getAllChildren(key, new HashSet());
         } while(children == null);

         Iterator var6 = children.keySet().iterator();

         while(var6.hasNext()) {
            String node = (String)var6.next();
            if (!perms.contains(node)) {
               perms.add(node);
            }
         }
      }
   }

   public static Map<String, Boolean> getAllChildren(String node, Set<String> playerPermArray) {
      LinkedList<String> stack = new LinkedList();
      Map<String, Boolean> alreadyVisited = new HashMap();
      stack.push(node);
      alreadyVisited.put(node, true);

      while(true) {
         String now;
         Map children;
         do {
            do {
               if (stack.isEmpty()) {
                  alreadyVisited.remove(node);
                  if (!alreadyVisited.isEmpty()) {
                     return alreadyVisited;
                  }

                  return null;
               }

               now = (String)stack.pop();
               children = getChildren(now);
            } while(children == null);
         } while(playerPermArray.contains("-" + now));

         Iterator var6 = children.keySet().iterator();

         while(var6.hasNext()) {
            String childName = (String)var6.next();
            if (!alreadyVisited.containsKey(childName)) {
               stack.push(childName);
               alreadyVisited.put(childName, (Boolean)children.get(childName));
            }
         }
      }
   }

   public static Map<String, Boolean> getChildren(String node) {
      Permission perm = (Permission)registeredPermissions.get(node.toLowerCase(Locale.ROOT));
      return perm == null ? null : perm.getChildren();
   }

   public static List<String> getGroupList() {
      return new ArrayList(groupPermsMap.keySet());
   }

   public static boolean mapHasGroup(String group) {
      return groupPermsMap.containsKey(group);
   }

   public static List<String> getPermsOfGroup(String group) {
      return (List)(mapHasGroup(group) ? (groupPermsMap.get(group) != null ? (List)groupPermsMap.get(group) : new ArrayList()) : new ArrayList());
   }

   private static void buildGroupPermsMap() {
      perms.getKeys(true).forEach((key) -> {
         groupPermsMap.put(key, perms.getStringList(key));
      });
   }

   private static void buildComments() {
      perms.addComment("nomad", "#############################################################################################", "# This file contains custom permission sets which will be assigned to your players          #", "# depending on their current status. This file uses YAML formatting. Do not include tabs    #", "# and be very careful to align the spacing preceding the - symbols. Improperly editing this #", "# file will prevent Towny from loading correctly.                                           #", "#                                                                                           #", "# This is all managed by towny and pushed directly to CraftBukkit's SuperPerms.             #", "# These will be give in addition to any you manually assign in your specific permission     #", "# plugin. Note: You do not need to assign any Towny permission nodes to your players in     #", "# your server's permission plugin, ie: LuckPerms.                                           #", "#                                                                                           #", "# You may assign any Permission nodes here, including those from other plugins.             #", "#                                                                                           #", "# You may also create any custom ranks you require. Creating ranks can be done using the    #", "# /ta townyperms townrank addrank [name] or by carefully editing this file.                 #", "# You can add permission to a rank/group using the                                          #", "# /ta townyperms group [name] addperm [node] command.                                       #", "#                                                                                           #", "# You may change the names of any of the ranks except: nomad, default, mayor, king, ranks,  #", "# peaceful.                                                                                 #", "#                                                                                           #", "# If you want to, you can negate permissions nodes from nodes by doing the following:       #", "# Ex:                                                                                       #", "#    - towny.command.plot.*                                                                 #", "#    - -towny.command.plot.set.jail                                                         #", "# In this example the user is given full rights to all of the /plot command nodes,          #", "# but has had their ability to set a plot to a Jail plot type disabled.                     #", "#                                                                                           #", "# The towns.ranks and nations.ranks sections support adding prefix and priorities, this     #", "# is done using two nodes: towny.rankpriority.# and towny.rankprefix.<prefix_here>.         #", "# Residents will have their ranks parsed until one rank is determined to be the highest     #", "# priority, this rank will then be searched for a prefix node. This prefix can be shown     #", "# using the %townyadvanced_resident_primary_rank% placeholder for PlaceholderAPI. A prefix  #", "# from a Nation rank will take precendence over a prefix from a Town rank.                  #", "# Ex:                                                                                       #", "#    - towny.rankpriority.100                                                               #", "#    - towny.rankprefix.&a<&2Sheriff&a>                                                     #", "#                                                                                           #", "#############################################################################################", "", "", "# The 'nomad' permissions are given to all players in all Towny worlds, townless and players who are part of a town.");
      perms.addComment("towns", "", "# This section of permissions covers players who are members of a town.");
      perms.addComment("towns.default", "", "# 'default' is the permission set which is auto assigned to any normal town member.");
      perms.addComment("towns.mayor", "", "# Mayors get these permissions in addition to the default set.");
      perms.addComment("towns.ranks", "", "# Ranks contain additional permissions residents will be", "# granted if they are assigned that specific rank.");
      if (perms.getKeys(true).contains("towns.ranks.assistant")) {
         perms.addComment("towns.ranks.assistant", "", "# assistants are able to grant VIP and helper rank.");
      }

      if (perms.getKeys(true).contains("towns.ranks.donator")) {
         perms.addComment("towns.ranks.donator", "", "# Currently only an example rank holder with no extra permissions.");
      }

      if (perms.getKeys(true).contains("towns.ranks.vip")) {
         perms.addComment("towns.ranks.vip", "", "# Currently only an example rank holder with no extra permissions.");
      }

      if (perms.getKeys(true).contains("towns.ranks.sheriff")) {
         perms.addComment("towns.ranks.sheriff", "", "# Sheriff rank is able to jail other town members.");
      }

      perms.addComment("nations", "", "# This section of permissions covers players who are members of any town in a nation.");
      perms.addComment("nations.default", "", "# All nation members get these permissions.");
      perms.addComment("nations.king", "", "# Kings get these permissions in addition to the default set.");
      perms.addComment("peaceful", "", "# Nodes that are given to players who are in a peaceful/neutral town or nation.");
   }

   public static CommentedConfiguration getTownyPermsFile() {
      return perms;
   }
}
