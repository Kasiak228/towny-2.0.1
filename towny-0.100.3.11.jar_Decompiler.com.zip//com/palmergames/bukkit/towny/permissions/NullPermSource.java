package com.palmergames.bukkit.towny.permissions;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.entity.Player;

public class NullPermSource extends TownyPermissionSource {
   public NullPermSource(Towny towny) {
      this.plugin = towny;
   }

   public String getPrefixSuffix(Resident resident, String node) {
      return "";
   }

   public int getGroupPermissionIntNode(String playerName, String node) {
      return -1;
   }

   public int getPlayerPermissionIntNode(String playerName, String node) {
      return -1;
   }

   public String getPlayerPermissionStringNode(String playerName, String node) {
      return "";
   }

   public String getPlayerGroup(Player player) {
      return "";
   }
}
