package com.palmergames.bukkit.towny.listeners;

import com.palmergames.bukkit.towny.Towny;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginEnableEvent;

public class TownyServerListener implements Listener {
   private final Towny plugin;

   public TownyServerListener(Towny instance) {
      this.plugin = instance;
   }

   @EventHandler
   public void onTownyNameUpdaterEnabled(PluginEnableEvent event) {
      if (event.getPlugin().getName().equalsIgnoreCase("TownyNameUpdater")) {
         this.plugin.getLogger().info("Disabling unneeded TownyNameUpdater.jar, you may delete this .jar.");
         this.plugin.getServer().getPluginManager().disablePlugin(event.getPlugin());
      }

   }
}
