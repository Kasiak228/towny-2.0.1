package com.palmergames.bukkit.towny.listeners;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyTimerHandler;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.BedExplodeEvent;
import com.palmergames.bukkit.towny.event.PlayerChangePlotEvent;
import com.palmergames.bukkit.towny.event.TitleNotificationEvent;
import com.palmergames.bukkit.towny.event.executors.TownyActionEventExecutor;
import com.palmergames.bukkit.towny.event.player.PlayerDeniedBedUseEvent;
import com.palmergames.bukkit.towny.event.player.PlayerEntersIntoDistrictEvent;
import com.palmergames.bukkit.towny.event.player.PlayerEntersIntoTownBorderEvent;
import com.palmergames.bukkit.towny.event.player.PlayerExitsFromDistrictEvent;
import com.palmergames.bukkit.towny.event.player.PlayerExitsFromTownBorderEvent;
import com.palmergames.bukkit.towny.event.player.PlayerKeepsExperienceEvent;
import com.palmergames.bukkit.towny.event.player.PlayerKeepsInventoryEvent;
import com.palmergames.bukkit.towny.event.teleport.CancelledTownyTeleportEvent;
import com.palmergames.bukkit.towny.hooks.PluginIntegrations;
import com.palmergames.bukkit.towny.object.CommandList;
import com.palmergames.bukkit.towny.object.District;
import com.palmergames.bukkit.towny.object.PlayerCache;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownyPermission;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.object.jail.UnJailReason;
import com.palmergames.bukkit.towny.object.notification.TitleNotification;
import com.palmergames.bukkit.towny.permissions.PermissionNodes;
import com.palmergames.bukkit.towny.permissions.TownyPerms;
import com.palmergames.bukkit.towny.tasks.OnPlayerLogin;
import com.palmergames.bukkit.towny.tasks.TeleportWarmupTimerTask;
import com.palmergames.bukkit.towny.utils.ChunkNotificationUtil;
import com.palmergames.bukkit.towny.utils.CombatUtil;
import com.palmergames.bukkit.towny.utils.EntityTypeUtil;
import com.palmergames.bukkit.towny.utils.JailUtil;
import com.palmergames.bukkit.towny.utils.MinecraftVersion;
import com.palmergames.bukkit.towny.utils.ResidentUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.ChatTools;
import com.palmergames.bukkit.util.EntityLists;
import com.palmergames.bukkit.util.ItemLists;
import com.palmergames.paperlib.PaperLib;
import com.palmergames.util.JavaUtil;
import java.lang.invoke.MethodHandle;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.World.Environment;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Rotatable;
import org.bukkit.block.data.type.Bed;
import org.bukkit.block.data.type.Door;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerEggThrowEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTakeLecternBookEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerFishEvent.State;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.permissions.Permissible;

public class TownyPlayerListener implements Listener {
   private final Towny plugin;
   private CommandList blockedJailCommands;
   private CommandList blockedTownCommands;
   private CommandList blockedTouristCommands;
   private CommandList blockedOutlawCommands;
   private CommandList blockedWarCommands;
   private CommandList ownPlotLimitedCommands;
   private int teleportWarmupTime = TownySettings.getTeleportWarmupTime();
   private boolean isMovementCancellingWarmup = TownySettings.isMovementCancellingSpawnWarmup();
   private static final MethodHandle GET_RESPAWN_FLAGS = JavaUtil.getMethodHandle(PlayerRespawnEvent.class, "getRespawnFlags");

   public TownyPlayerListener(Towny plugin) {
      this.plugin = plugin;
      this.loadBlockedCommandLists();
      TownySettings.addReloadListener(NamespacedKey.fromString("blocked-commands", plugin), (config) -> {
         this.loadBlockedCommandLists();
      });
      TownySettings.addReloadListener(NamespacedKey.fromString("teleport-warmups", plugin), () -> {
         this.teleportWarmupTime = TownySettings.getTeleportWarmupTime();
         this.isMovementCancellingWarmup = TownySettings.isMovementCancellingSpawnWarmup();
      });
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      if (player.isOnline()) {
         if (player.getName().contains(" ")) {
            player.kickPlayer("Invalid name!");
         } else if (this.plugin.isError()) {
            this.sendSafeModeMessage(player);
         } else {
            this.plugin.getScheduler().run((Runnable)(new OnPlayerLogin(Towny.getPlugin(), player)));
         }
      }
   }

   private void sendSafeModeMessage(Player player) {
      try {
         Translatable tipMsg = !player.isOp() && !player.hasPermission("towny.admin") ? Translatable.of("msg_safe_mode_player") : Translatable.of("msg_safe_mode_admin");
         TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable[])(Translatable.of("msg_safe_mode_base"), tipMsg));
      } catch (Exception var4) {
         String msg = !player.isOp() && !player.hasPermission("towny.admin") ? "Tell an admin to check the server's console." : "Check the server's console for more information.";
         player.sendMessage(ChatColor.RED + "[Towny] [Error] Towny is locked in Safe Mode due to an error! " + msg);
      }

   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.plugin.deleteCache(event.getPlayer());
      TownyPerms.removeAttachment(event.getPlayer().getName());
      if (!this.plugin.isError()) {
         Resident resident = TownyUniverse.getInstance().getResident(event.getPlayer().getUniqueId());
         if (resident != null) {
            if (!event.getPlayer().getMetadata("vanished").stream().anyMatch(MetadataValue::asBoolean)) {
               resident.setLastOnline(System.currentTimeMillis());
            }

            resident.clearModes();
            resident.save();
            if (TownyTimerHandler.isTeleportWarmupRunning()) {
               TownyAPI.getInstance().abortTeleportRequest(resident);
            }

            if (JailUtil.isQueuedToBeJailed(resident)) {
               event.getPlayer().setHealth(0.0D);
            }
         }

         ChunkNotificationUtil.cancelPlayerTasks(event.getPlayer());
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerRespawn(PlayerRespawnEvent event) {
      if (!this.plugin.isError() && !this.isEndPortalRespawn(event)) {
         Player player = event.getPlayer();
         if (TownySettings.isTownRespawning()) {
            if (!event.isAnchorSpawn() || !TownySettings.isRespawnAnchorHigherPrecedence()) {
               Location respawn = TownyAPI.getInstance().getTownSpawnLocation(player);
               if (TownySettings.getBedUse()) {
                  Location bed = BukkitTools.getBedOrRespawnLocation(player);
                  if (bed != null) {
                     respawn = bed;
                  }
               }

               if (respawn != null) {
                  if (!TownySettings.isTownRespawningInOtherWorlds() || player.getWorld().equals(respawn.getWorld())) {
                     event.setRespawnLocation(respawn);
                     long protectionTime = TownySettings.getSpawnProtectionDuration();
                     if (protectionTime > 0L) {
                        Resident res = TownyAPI.getInstance().getResident(player);
                        if (res == null) {
                           return;
                        }

                        res.addRespawnProtection(protectionTime);
                     }

                  }
               }
            }
         }
      }
   }

   private boolean isEndPortalRespawn(PlayerRespawnEvent event) {
      try {
         Collection<Enum<?>> respawnFlags = GET_RESPAWN_FLAGS.invoke(event);
         Iterator var6 = respawnFlags.iterator();

         Enum flag;
         do {
            if (!var6.hasNext()) {
               return false;
            }

            flag = (Enum)var6.next();
         } while(!"END_PORTAL".equals(flag.name()));

         return true;
      } catch (Throwable var5) {
         Player player = event.getPlayer();
         if (player.getWorld().getEnvironment() != Environment.THE_END) {
            return false;
         } else {
            return player.getLocation().getBlock().getType() == Material.END_PORTAL || player.getEyeLocation().getBlock().getType() == Material.END_PORTAL;
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerJailRespawn(PlayerRespawnEvent event) {
      if (!this.plugin.isError()) {
         Resident resident = TownyUniverse.getInstance().getResident(event.getPlayer().getUniqueId());
         if (resident != null && resident.isJailed() && resident.getJailSpawn().isWorldLoaded()) {
            event.setRespawnLocation(resident.getJailSpawn());
         }

      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         event.setCancelled(!TownyActionEventExecutor.canBuild(event.getPlayer(), event.getBlock().getLocation(), event.getBucket()));
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onPlayerBucketFill(PlayerBucketFillEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         if (!event.getItemStack().getType().equals(Material.MILK_BUCKET) && !event.getBlockClicked().getType().equals(Material.AIR)) {
            event.setCancelled(!TownyActionEventExecutor.canDestroy(event.getPlayer(), event.getBlockClicked().getLocation(), event.getBlockClicked().getType()));
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerInteract(PlayerInteractEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         Action action = event.getAction();
         if (action == Action.RIGHT_CLICK_BLOCK || action == Action.RIGHT_CLICK_AIR || action == Action.PHYSICAL) {
            Player player = event.getPlayer();
            Block clickedBlock = event.getClickedBlock();
            Material item;
            if (event.hasItem()) {
               item = event.getItem().getType();
               Location loc = null;
               if (clickedBlock != null) {
                  loc = clickedBlock.getLocation();
               } else {
                  loc = player.getLocation();
               }

               if (TownySettings.isItemUseMaterial(item, loc) && !TownyActionEventExecutor.canItemuse(player, loc, item)) {
                  event.setCancelled(true);
                  return;
               }

               if (clickedBlock != null) {
                  Material clickedMat = clickedBlock.getType();
                  if (Tag.BEDS.isTagged(item) && Tag.CROPS.isTagged(clickedBlock.getType()) && clickedBlock.getLightLevel() == 0) {
                     event.setCancelled(true);
                     return;
                  }

                  if ((ItemLists.AXES.contains(item) && (ItemLists.UNSTRIPPED_WOOD.contains(clickedMat) || ItemLists.WAXED_BLOCKS.contains(clickedMat) || ItemLists.WEATHERABLE_BLOCKS.contains(clickedMat)) || ItemLists.DYES.contains(item) && ItemLists.SIGNS.contains(clickedMat) || item == Material.FLINT_AND_STEEL && clickedMat == Material.TNT || (item == Material.GLASS_BOTTLE || item == Material.SHEARS) && (clickedMat == Material.BEE_NEST || clickedMat == Material.BEEHIVE || clickedMat == Material.PUMPKIN) || clickedMat.getKey().equals(NamespacedKey.minecraft("rooted_dirt")) && ItemLists.HOES.contains(item) || ItemLists.BRUSHABLE_BLOCKS.contains(clickedMat) && item == Material.BRUSH) && !TownyActionEventExecutor.canDestroy(player, loc, clickedMat)) {
                     event.setCancelled(true);
                     return;
                  }

                  if ((ItemLists.CANDLES.contains(item) && clickedMat == Material.CAKE || ItemLists.PLANTS.contains(item) && clickedMat == Material.FLOWER_POT || item == Material.HONEYCOMB && ItemLists.WEATHERABLE_BLOCKS.contains(clickedMat) || ItemLists.PLACEABLE_BOOKS.contains(item) && ItemLists.BOOK_CONTAINERS.contains(clickedMat) || ItemLists.CAMPFIRES.contains(clickedMat) && item != Material.FLINT_AND_STEEL || item == Material.BONE_MEAL && !TownyActionEventExecutor.canBuild(player, loc, item)) && !TownyActionEventExecutor.canBuild(player, loc, item)) {
                     event.setCancelled(true);
                     return;
                  }

                  if ((item == Material.ARMOR_STAND || item == Material.END_CRYSTAL) && !TownyActionEventExecutor.canBuild(player, clickedBlock.getRelative(event.getBlockFace()).getLocation(), item)) {
                     event.setCancelled(true);
                     return;
                  }

                  if (item == Material.HONEYCOMB && ItemLists.SIGNS.contains(clickedMat) && !this.isSignWaxed(clickedBlock) && !TownyActionEventExecutor.canItemuse(player, clickedBlock.getLocation(), clickedMat)) {
                     event.setCancelled(true);
                     return;
                  }
               }
            }

            if (clickedBlock != null) {
               item = clickedBlock.getType();
               if (TownySettings.isSwitchMaterial(item, clickedBlock.getLocation()) && !TownyActionEventExecutor.canSwitch(player, clickedBlock.getLocation(), item)) {
                  event.setCancelled(true);
                  return;
               }

               if ((ItemLists.POTTED_PLANTS.contains(item) || ItemLists.HARVESTABLE_BERRIES.contains(item) || ItemLists.REDSTONE_INTERACTABLES.contains(item) || ItemLists.CANDLES.contains(item) || item.getKey().equals(NamespacedKey.minecraft("turtle_egg")) || item.getKey().equals(NamespacedKey.minecraft("chiseled_bookshelf")) || item == Material.BEACON || item == Material.DRAGON_EGG || item == Material.COMMAND_BLOCK) && !TownyActionEventExecutor.canDestroy(player, clickedBlock.getLocation(), item)) {
                  event.setCancelled(true);
                  return;
               }

               if (TownyPaperEvents.SIGN_OPEN_GET_CAUSE == null && ItemLists.SIGNS.contains(item) && !this.isSignWaxed(clickedBlock) && !TownyActionEventExecutor.canDestroy(player, clickedBlock.getLocation(), item)) {
                  event.setCancelled(true);
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onDragonEggLeftClick(PlayerInteractEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else {
         Player player = event.getPlayer();
         if (TownyAPI.getInstance().isTownyWorld(player.getWorld())) {
            if (event.hasBlock() && event.getAction() == Action.LEFT_CLICK_BLOCK) {
               Block block = event.getClickedBlock();
               if (block.getType() == Material.DRAGON_EGG) {
                  if (!TownyActionEventExecutor.canDestroy(player, block)) {
                     event.setCancelled(true);
                  }
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onPlayerBlowsUpBedOrRespawnAnchor(PlayerInteractEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         Block block = event.getClickedBlock();
         Player player = event.getPlayer();
         if (event.hasBlock() && event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
            Location blockLoc = block.getLocation();
            if (block.getType() == Material.RESPAWN_ANCHOR && !block.getWorld().isRespawnAnchorWorks()) {
               RespawnAnchor anchor = (RespawnAnchor)block.getBlockData();
               if (anchor.getCharges() > 0) {
                  BukkitTools.fireEvent(new BedExplodeEvent(player, blockLoc, (Location)null, block.getType()));
               }

               return;
            }

            if (Tag.BEDS.isTagged(block.getType()) && player.getWorld().getEnvironment().equals(Environment.NETHER)) {
               Bed bed = (Bed)block.getBlockData();
               BukkitTools.fireEvent(new BedExplodeEvent(player, blockLoc, block.getRelative(bed.getFacing()).getLocation(), block.getType()));
               return;
            }

            if (TownySettings.getBedUse() && !TownyUniverse.getInstance().getPermissionSource().testPermission((Permissible)player, PermissionNodes.TOWNY_BYPASS_BED_RESTRICTION.getNode()) && (Tag.BEDS.isTagged(block.getType()) || this.disallowedAnchorClick(event, block))) {
               boolean isOwner = false;
               boolean isInnPlot = false;
               boolean isEnemy = false;
               Translatable denialMessage = Translatable.of("msg_err_cant_use_bed");
               if (!TownyAPI.getInstance().isWilderness(blockLoc)) {
                  TownBlock townblock = TownyAPI.getInstance().getTownBlock(blockLoc);
                  Resident resident = TownyUniverse.getInstance().getResident(player.getUniqueId());
                  Town town = townblock.getTownOrNull();
                  if (resident == null || town == null) {
                     return;
                  }

                  isOwner = townblock.isOwner(resident);
                  isInnPlot = townblock.getType() == TownBlockType.INN;
                  if (CombatUtil.isEnemyTownBlock(player, townblock.getWorldCoord()) || town.hasOutlaw(resident)) {
                     isEnemy = true;
                     denialMessage = Translatable.of("msg_err_no_sleep_in_enemy_inn");
                  }
               }

               if (isEnemy || !isOwner && !isInnPlot) {
                  PlayerDeniedBedUseEvent pdbue = new PlayerDeniedBedUseEvent(player, blockLoc, isEnemy, denialMessage);
                  if (!BukkitTools.isEventCancelled(pdbue)) {
                     event.setCancelled(true);
                     TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)pdbue.getDenialMessage());
                  }
               }
            }
         }

      }
   }

   private boolean disallowedAnchorClick(PlayerInteractEvent event, Block block) {
      boolean var10000;
      if (block.getWorld().isRespawnAnchorWorks()) {
         BlockData var4 = block.getBlockData();
         if (var4 instanceof RespawnAnchor) {
            RespawnAnchor anchor = (RespawnAnchor)var4;
            if (anchor.getCharges() > 0 && (event.getItem() == null || event.getItem().getType() != Material.GLOWSTONE || anchor.getCharges() >= anchor.getMaximumCharges())) {
               var10000 = true;
               return var10000;
            }
         }
      }

      var10000 = false;
      return var10000;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerInteractWithArmourStand(PlayerArmorStandManipulateEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         event.setCancelled(!TownyActionEventExecutor.canDestroy(event.getPlayer(), event.getRightClicked().getLocation(), Material.ARMOR_STAND));
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         if (event.getRightClicked() != null) {
            Player player = event.getPlayer();
            Material mat = null;
            TownyPermission.ActionType actionType = TownyPermission.ActionType.DESTROY;
            EntityType entityType = event.getRightClicked().getType();
            Material item = player.getInventory().getItem(EquipmentSlot.HAND).getType();
            if (EntityLists.SWITCH_PROTECTED.contains(entityType)) {
               mat = EntityTypeUtil.parseEntityToMaterial(entityType);
               actionType = TownyPermission.ActionType.SWITCH;
            } else if (EntityLists.DYEABLE.contains(entityType) && ItemLists.DYES.contains(item)) {
               mat = item;
            } else if (item != null && item == Material.BUCKET && EntityLists.MILKABLE.contains(entityType)) {
               mat = EntityTypeUtil.parseEntityToMaterial(entityType);
               actionType = TownyPermission.ActionType.ITEM_USE;
            } else if (item != null && item == Material.COOKIE && EntityType.PARROT.equals(entityType)) {
               mat = EntityTypeUtil.parseEntityToMaterial(entityType);
            } else if (EntityLists.RIGHT_CLICK_PROTECTED.contains(entityType)) {
               mat = EntityTypeUtil.parseEntityToMaterial(entityType);
            }

            if (mat != null) {
               if (actionType == TownyPermission.ActionType.DESTROY) {
                  event.setCancelled(!TownyActionEventExecutor.canDestroy(player, event.getRightClicked().getLocation(), mat));
                  return;
               }

               if (TownySettings.isSwitchMaterial(mat, event.getRightClicked().getLocation()) && actionType == TownyPermission.ActionType.SWITCH) {
                  event.setCancelled(!TownyActionEventExecutor.canSwitch(player, event.getRightClicked().getLocation(), mat));
                  return;
               }
            }

            if (item != null) {
               if (event.getRightClicked().getType().equals(EntityType.SHEEP) && item == Material.SHEARS && !TownyAPI.getInstance().isWilderness(event.getRightClicked().getLocation())) {
                  event.setCancelled(!TownyActionEventExecutor.canDestroy(player, event.getRightClicked().getLocation(), item));
                  return;
               }

               if (item == Material.NAME_TAG) {
                  event.setCancelled(!TownyActionEventExecutor.canDestroy(player, event.getRightClicked().getLocation(), item));
                  return;
               }

               if (TownySettings.isItemUseMaterial(item, event.getRightClicked().getLocation())) {
                  event.setCancelled(!TownyActionEventExecutor.canItemuse(player, event.getRightClicked().getLocation(), item));
                  return;
               }
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerMove(PlayerMoveEvent event) {
      if (!PluginIntegrations.getInstance().isNPC(event.getPlayer())) {
         if (this.plugin.isError()) {
            event.setCancelled(true);
         } else {
            Player player = event.getPlayer();
            Location to = event.getTo();
            Location from = event.getFrom();
            if (from.getBlockX() != to.getBlockX() || from.getBlockZ() != to.getBlockZ() || from.getBlockY() != to.getBlockY()) {
               if (this.teleportWarmupTime > 0 && this.isMovementCancellingWarmup) {
                  Resident resident = TownyAPI.getInstance().getResident(player);
                  if (resident != null && resident.hasRequestedTeleport() && !resident.isAdmin() && TeleportWarmupTimerTask.abortTeleportRequest(resident, CancelledTownyTeleportEvent.CancelledTeleportReason.MOVEMENT)) {
                     TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_err_teleport_cancelled"));
                  }
               }

               if (WorldCoord.cellChanged(from, to)) {
                  TownyWorld fromWorld = TownyAPI.getInstance().getTownyWorld(from.getWorld());
                  TownyWorld toWorld = TownyAPI.getInstance().getTownyWorld(to.getWorld());
                  if (fromWorld == null || toWorld == null) {
                     TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("not_registered"));
                     return;
                  }

                  WorldCoord fromCoord = WorldCoord.parseWorldCoord(from);
                  WorldCoord toCoord = WorldCoord.parseWorldCoord(to);
                  this.onPlayerMoveChunk(player, fromCoord, toCoord, event);
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onPlayerTeleport(PlayerTeleportEvent event) {
      if (!PluginIntegrations.getInstance().isNPC(event.getPlayer())) {
         if (this.plugin.isError()) {
            event.setCancelled(true);
         } else {
            Player player = event.getPlayer();
            Resident resident = TownyUniverse.getInstance().getResident(player.getUniqueId());
            boolean isAdmin = !Towny.getPlugin().hasPlayerMode(player, "adminbypass") && resident != null && (resident.isAdmin() || resident.hasPermissionNode(PermissionNodes.TOWNY_ADMIN_OUTLAW_TELEPORT_BYPASS.getNode()));
            if (resident != null && resident.isJailed() && !isAdmin) {
               if (event.getCause() == TeleportCause.COMMAND) {
                  TownyMessaging.sendErrorMsg((CommandSender)event.getPlayer(), (Translatable)Translatable.of("msg_err_jailed_players_no_teleport"));
                  event.setCancelled(true);
                  return;
               }

               if (event.getCause() == TeleportCause.PLUGIN) {
                  return;
               }

               if ((event.getCause() == TeleportCause.ENDER_PEARL || event.getCause() == TeleportCause.CHORUS_FRUIT) && !TownySettings.JailAllowsTeleportItems()) {
                  TownyMessaging.sendErrorMsg((CommandSender)event.getPlayer(), (Translatable)Translatable.of("msg_err_jailed_players_no_teleport"));
                  event.setCancelled(true);
               }
            }

            if (resident != null && !TownySettings.canOutlawsTeleportOutOfTowns() && !isAdmin) {
               TownBlock tb = TownyAPI.getInstance().getTownBlock(event.getFrom());
               if (tb != null && tb.hasTown()) {
                  Town town = tb.getTownOrNull();
                  if (town != null && town.hasOutlaw(resident)) {
                     if (event.getCause() == TeleportCause.COMMAND) {
                        TownyMessaging.sendErrorMsg((CommandSender)event.getPlayer(), (Translatable)Translatable.of("msg_err_outlawed_players_no_teleport"));
                        event.setCancelled(true);
                        return;
                     }

                     if (event.getCause() == TeleportCause.PLUGIN) {
                        return;
                     }

                     if (!TownySettings.canOutlawsUseTeleportItems() && (event.getCause() == TeleportCause.ENDER_PEARL || event.getCause() == TeleportCause.CHORUS_FRUIT)) {
                        TownyMessaging.sendErrorMsg((CommandSender)event.getPlayer(), (Translatable)Translatable.of("msg_err_outlawed_players_no_teleport"));
                        event.setCancelled(true);
                     }
                  }
               }
            }

            if (event.getCause() == TeleportCause.CHORUS_FRUIT && TownySettings.isItemUseMaterial(Material.CHORUS_FRUIT, event.getTo()) && !isAdmin && !TownyActionEventExecutor.canItemuse(event.getPlayer(), event.getTo(), Material.CHORUS_FRUIT)) {
               event.setCancelled(true);
            } else if (event.getCause() == TeleportCause.ENDER_PEARL && TownySettings.isItemUseMaterial(Material.ENDER_PEARL, event.getTo()) && !isAdmin && !TownyActionEventExecutor.canItemuse(event.getPlayer(), event.getTo(), Material.ENDER_PEARL)) {
               event.setCancelled(true);
            } else {
               if (resident != null && resident.hasRespawnProtection()) {
                  resident.removeRespawnProtection();
               }

               this.onPlayerMove(event);
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerChangeWorld(PlayerChangedWorldEvent event) {
      if (event.getPlayer().isOnline()) {
         TownyPerms.assignPermissions((Resident)null, event.getPlayer());
      }

   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerFishEvent(PlayerFishEvent event) {
      if (TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         if (event.getState().equals(State.CAUGHT_ENTITY)) {
            Player player = event.getPlayer();
            Entity caught = event.getCaught();
            boolean test = false;
            if (caught.getType().equals(EntityType.PLAYER)) {
               TownyWorld world = TownyAPI.getInstance().getTownyWorld(event.getCaught().getWorld());
               if (world == null) {
                  return;
               }

               TownBlock tb = TownyAPI.getInstance().getTownBlock(event.getCaught().getLocation());
               test = !CombatUtil.preventPvP(world, tb);
            } else {
               test = TownyActionEventExecutor.canDestroy(player, caught.getLocation(), Material.DIRT);
            }

            if (!test) {
               event.setCancelled(true);
               event.getHook().remove();
            }
         }

      }
   }

   private void onPlayerMoveChunk(Player player, WorldCoord from, WorldCoord to, PlayerMoveEvent moveEvent) {
      PlayerCache cache = this.plugin.getCacheOrNull(player.getUniqueId());
      if (cache != null) {
         cache.resetAndUpdate(to);
      }

      PlayerChangePlotEvent event = new PlayerChangePlotEvent(player, from, to, moveEvent);
      BukkitTools.fireEvent(event);
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerChangePlotEvent(PlayerChangePlotEvent event) {
      if (TownyUniverse.getInstance().hasResident(event.getPlayer().getUniqueId())) {
         WorldCoord from = event.getFrom();
         WorldCoord to = event.getTo();
         if (!to.isWilderness() || !from.isWilderness()) {
            if (to.isWilderness()) {
               BukkitTools.fireEvent(new PlayerExitsFromTownBorderEvent(event.getPlayer(), to, from, from.getTownOrNull(), event.getMoveEvent()));
            } else if (from.isWilderness()) {
               BukkitTools.fireEvent(new PlayerEntersIntoTownBorderEvent(event.getPlayer(), to, from, to.getTownOrNull(), event.getMoveEvent()));
            } else {
               if (to.getTownOrNull().equals(from.getTownOrNull())) {
                  return;
               }

               BukkitTools.fireEvent(new PlayerEntersIntoTownBorderEvent(event.getPlayer(), to, from, to.getTownOrNull(), event.getMoveEvent()));
               BukkitTools.fireEvent(new PlayerExitsFromTownBorderEvent(event.getPlayer(), to, from, from.getTownOrNull(), event.getMoveEvent()));
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerChangeDistricts(PlayerChangePlotEvent event) {
      if (TownyUniverse.getInstance().hasResident(event.getPlayer().getUniqueId())) {
         WorldCoord from = event.getFrom();
         WorldCoord to = event.getTo();
         boolean fromHasDistrict = !from.isWilderness() && from.getTownBlockOrNull().hasDistrict();
         boolean toHasDistrict = !to.isWilderness() && to.getTownBlockOrNull().hasDistrict();
         if ((!to.isWilderness() || !from.isWilderness()) && (fromHasDistrict || toHasDistrict)) {
            District fromDistrict = fromHasDistrict ? from.getTownBlockOrNull().getDistrict() : null;
            District toDistrict = toHasDistrict ? to.getTownBlockOrNull().getDistrict() : null;
            if (to.isWilderness() && fromHasDistrict) {
               BukkitTools.fireEvent(new PlayerExitsFromDistrictEvent(event.getPlayer(), to, from, fromDistrict, event.getMoveEvent()));
            } else if (from.isWilderness() && toHasDistrict) {
               BukkitTools.fireEvent(new PlayerEntersIntoDistrictEvent(event.getPlayer(), to, from, toDistrict, event.getMoveEvent()));
            } else if (!to.isWilderness() && !from.isWilderness() && to.getTownOrNull().equals(from.getTownOrNull()) && fromHasDistrict && toHasDistrict && !fromDistrict.equals(toDistrict)) {
               BukkitTools.fireEvent(new PlayerExitsFromDistrictEvent(event.getPlayer(), to, from, fromDistrict, event.getMoveEvent()));
               BukkitTools.fireEvent(new PlayerEntersIntoDistrictEvent(event.getPlayer(), to, from, toDistrict, event.getMoveEvent()));
            } else {
               if (fromHasDistrict) {
                  BukkitTools.fireEvent(new PlayerExitsFromDistrictEvent(event.getPlayer(), to, from, fromDistrict, event.getMoveEvent()));
               }

               if (toHasDistrict) {
                  BukkitTools.fireEvent(new PlayerEntersIntoDistrictEvent(event.getPlayer(), to, from, toDistrict, event.getMoveEvent()));
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onOutlawEnterTown(PlayerEntersIntoTownBorderEvent event) {
      Resident outlaw = TownyUniverse.getInstance().getResident(event.getPlayer().getUniqueId());
      if (outlaw != null) {
         Town town = event.getEnteredTown();
         if (!outlaw.isJailed() || !outlaw.getJailTown().equals(town)) {
            if (town.hasOutlaw(outlaw)) {
               ResidentUtil.outlawEnteredTown(outlaw, town, event.getPlayer().getLocation());
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerDeathHandleKeepLevelAndInventory(PlayerDeathEvent event) {
      Resident resident = TownyAPI.getInstance().getResident(event.getEntity());
      if (resident != null) {
         TownBlock tb = TownyAPI.getInstance().getTownBlock(event.getEntity().getLocation());
         this.tryKeepInventory(event, resident, tb);
         this.tryKeepExperience(event, tb);
      }
   }

   private boolean tryKeepInventory(PlayerDeathEvent event, Resident resident, TownBlock tb) {
      boolean keepInventory = this.getKeepInventoryValue(event.getKeepInventory(), resident, tb);
      PlayerKeepsInventoryEvent pkie = new PlayerKeepsInventoryEvent(event, keepInventory);
      if (!BukkitTools.isEventCancelled(pkie)) {
         event.setKeepInventory(true);
         event.getDrops().clear();
         return true;
      } else {
         return false;
      }
   }

   private boolean getKeepInventoryValue(boolean keepInventory, Resident resident, TownBlock tb) {
      keepInventory = TownySettings.getKeepInventoryInTowns() && tb != null;
      if (tb == null) {
         return keepInventory;
      } else {
         if (resident.hasTown() && !keepInventory) {
            Town town = resident.getTownOrNull();
            Town tbTown = tb.getTownOrNull();
            if (TownySettings.getKeepInventoryInOwnTown() && tbTown.equals(town)) {
               keepInventory = true;
            }

            if (TownySettings.getKeepInventoryInAlliedTowns() && !keepInventory && tbTown.isAlliedWith(town)) {
               keepInventory = true;
            }
         }

         if (TownySettings.getKeepInventoryInArenas() && !keepInventory && tb.getType() == TownBlockType.ARENA) {
            keepInventory = true;
         }

         return keepInventory;
      }
   }

   private boolean tryKeepExperience(PlayerDeathEvent event, TownBlock tb) {
      boolean keepExperience = this.getKeepExperienceValue(tb != null, tb != null ? tb.getType() : null);
      PlayerKeepsExperienceEvent pkee = new PlayerKeepsExperienceEvent(event, keepExperience);
      if (!BukkitTools.isEventCancelled(pkee)) {
         event.setKeepLevel(true);
         event.setDroppedExp(0);
         return true;
      } else {
         return false;
      }
   }

   private boolean getKeepExperienceValue(boolean inTown, TownBlockType type) {
      if (!inTown) {
         return false;
      } else if (TownySettings.getKeepExperienceInTowns()) {
         return true;
      } else {
         return type != null && type == TownBlockType.ARENA && TownySettings.getKeepExperienceInArenas();
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerEnterTown(PlayerEntersIntoTownBorderEvent event) {
      Resident resident = event.getResident();
      Town town = event.getEnteredTown();
      if (resident != null && town != null) {
         if (TownySettings.isNotificationUsingTitles() && resident.isSeeingBorderTitles()) {
            TitleNotificationEvent tne = new TitleNotificationEvent(new TitleNotification(town, event.getTo()), event.getPlayer());
            BukkitTools.fireEvent(tne);
            String title = tne.getTitleNotification().getTitleNotification();
            String subtitle = tne.getTitleNotification().getSubtitleNotification();
            TownyMessaging.sendTitleMessageToResident(resident, title, subtitle, TownySettings.getNotificationTitlesDurationTicks());
         }

      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerLeaveTown(PlayerExitsFromTownBorderEvent event) {
      Resident resident = event.getResident();
      if (resident != null && event.getTo().isWilderness()) {
         if (TownySettings.isNotificationUsingTitles() && resident.isSeeingBorderTitles()) {
            TitleNotificationEvent tne = new TitleNotificationEvent(new TitleNotification(event.getLeftTown(), event.getTo()), event.getPlayer());
            BukkitTools.fireEvent(tne);
            String title = tne.getTitleNotification().getTitleNotification();
            String subtitle = tne.getTitleNotification().getSubtitleNotification();
            TownyMessaging.sendTitleMessageToResident(resident, title, subtitle, TownySettings.getNotificationTitlesDurationTicks());
         }

         if (resident.isJailed()) {
            JailUtil.unJailResident(resident, UnJailReason.ESCAPE);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerTakeLecternBookEvent(PlayerTakeLecternBookEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getLectern().getWorld())) {
         event.setCancelled(!TownyActionEventExecutor.canDestroy(event.getPlayer(), event.getLectern().getLocation(), Material.LECTERN));
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerUsesCommand(PlayerCommandPreprocessEvent event) {
      if (!this.plugin.isError() && TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         this.checkForOpDeOpCommand(event);
         Resident resident = TownyUniverse.getInstance().getResident(event.getPlayer().getUniqueId());
         if (resident != null && !resident.isAdmin()) {
            String command = event.getMessage();
            if (this.blockJailedPlayerCommand(event.getPlayer(), resident, command)) {
               event.setCancelled(true);
            } else if (this.blockWarPlayerCommand(event.getPlayer(), resident, command)) {
               event.setCancelled(true);
            } else {
               TownBlock townBlock = TownyAPI.getInstance().getTownBlock(event.getPlayer());
               if (this.blockOutlawedPlayerCommand(event.getPlayer(), resident, townBlock, command) || this.blockCommandInsideTown(event.getPlayer(), resident, townBlock, command)) {
                  event.setCancelled(true);
               }

            }
         }
      }
   }

   private void checkForOpDeOpCommand(PlayerCommandPreprocessEvent event) {
      String[] args = CommandList.normalizeCommand(event.getMessage()).split(" ");
      String command = args[0];
      if ((command.equalsIgnoreCase("op") || command.equalsIgnoreCase("deop")) && args.length == 2) {
         Player target = Bukkit.getPlayer(args[1]);
         if (target != null && target.isOnline()) {
            if (event.getPlayer().hasPermission("minecraft.command." + command)) {
               if (target.isOp() != "op".equalsIgnoreCase(command)) {
                  Towny plugin = Towny.getPlugin();
                  plugin.getScheduler().runLater((Entity)target, (Runnable)(() -> {
                     plugin.deleteCache(target);
                  }), 1L);
               }
            }
         }
      }
   }

   public boolean blockWarPlayerCommand(Player player, Resident resident, String command) {
      if (resident.hasTown() && resident.getTownOrNull().hasActiveWar() && this.blockedWarCommands.containsCommand(command)) {
         TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_command_war_blocked"));
         return true;
      } else {
         return false;
      }
   }

   public boolean blockOutlawedPlayerCommand(Player player, Resident resident, TownBlock townBlock, String command) {
      if (townBlock != null && townBlock.hasTown()) {
         Town town = townBlock.getTownOrNull();
         if (town != null && town.hasOutlaw(resident) && this.blockedOutlawCommands.containsCommand(command)) {
            TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_err_you_cannot_use_command_while_in_outlaw_town"));
            return true;
         }
      }

      return false;
   }

   public boolean blockJailedPlayerCommand(Player player, Resident resident, String command) {
      if (!resident.isJailed()) {
         return false;
      } else if (this.blockedJailCommands.containsCommand(command)) {
         TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_you_cannot_use_that_command_while_jailed"));
         return true;
      } else {
         return false;
      }
   }

   public boolean blockCommandInsideTown(Player player, Resident resident, TownBlock townBlock, String command) {
      if (!TownySettings.allowTownCommandBlacklisting()) {
         return false;
      } else if (resident.hasPermissionNode(PermissionNodes.TOWNY_ADMIN_TOWN_COMMAND_BLACKLIST_BYPASS.getNode())) {
         return false;
      } else {
         Town town = townBlock == null ? null : townBlock.getTownOrNull();
         if (town != null && town.hasActiveWar() && this.blockedWarCommands.containsCommand(command)) {
            TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_command_war_blocked"));
            return true;
         } else if (this.blockedTownCommands.containsCommand(command) && this.blockedTouristCommands.containsCommand(command)) {
            if (town == null) {
               return false;
            } else if (!town.hasResident(resident) && !resident.hasPermissionNode(PermissionNodes.TOWNY_ADMIN_TOURIST_COMMAND_LIMITATION_BYPASS.getNode()) && (!TownySettings.doTrustedResidentsBypassTownBlockedCommands() || !town.hasTrustedResident(resident)) && (!resident.hasTown() || !TownySettings.doAlliesBypassTownBlockedCommands() || !CombatUtil.isAlly(town, resident.getTownOrNull()))) {
               TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_command_outsider_blocked", town.getName()));
               return true;
            } else {
               return false;
            }
         } else if (town != null && this.blockedTownCommands.containsCommand(command)) {
            TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_command_blocked_inside_towns"));
            return true;
         } else {
            if (this.ownPlotLimitedCommands.containsCommand(command)) {
               if (town == null) {
                  TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_command_limited"));
                  return true;
               }

               if (town.hasResident(player) && TownyUniverse.getInstance().getPermissionSource().hasOwnTownOverride(player, Material.DIRT, TownyPermission.ActionType.BUILD)) {
                  return false;
               }

               Resident owner = townBlock.getResidentOrNull();
               if (owner == null) {
                  if (town.hasResident(player) && TownyUniverse.getInstance().getPermissionSource().hasTownOwnedOverride(player, Material.DIRT, TownyPermission.ActionType.BUILD)) {
                     return false;
                  }

                  TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_command_limited"));
                  return true;
               }

               if (!owner.getName().equals(player.getName())) {
                  TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_command_limited"));
                  return true;
               }
            }

            return false;
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onAdminToolUseOnBlocks(PlayerInteractEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (event.getHand() != EquipmentSlot.OFF_HAND && TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         if (event.hasItem() && event.getPlayer().getInventory().getItemInMainHand().getType().getKey().getKey().equalsIgnoreCase(TownySettings.getTool()) && this.plugin.hasPlayerMode(event.getPlayer(), "infotool") && TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((Permissible)event.getPlayer()) && event.getClickedBlock() != null) {
            Player player = event.getPlayer();
            Block block = event.getClickedBlock();
            BlockState state = PaperLib.getBlockState(block, false).getState();
            BlockData data = state.getBlockData();
            if (ItemLists.SIGNS.contains(block.getType()) && data instanceof Rotatable) {
               Rotatable rotatable = (Rotatable)data;
               TownyMessaging.sendMessage((Object)player, (List)Arrays.asList(ChatTools.formatTitle("Sign Info"), ChatTools.formatCommand("", "Sign Type", "", block.getType().name()), ChatTools.formatCommand("", "Facing", "", rotatable.getRotation().toString())));
            } else if (Tag.DOORS.isTagged(block.getType())) {
               Door door = (Door)block.getBlockData();
               TownyMessaging.sendMessage((Object)player, (List)Arrays.asList(ChatTools.formatTitle("Door Info"), ChatTools.formatCommand("", "Door Type", "", block.getType().getKey().toString()), ChatTools.formatCommand("", "hinged on ", "", String.valueOf(door.getHinge())), ChatTools.formatCommand("", "isOpen", "", String.valueOf(door.isOpen())), ChatTools.formatCommand("", "getFacing", "", door.getFacing().name())));
            } else {
               TownyMessaging.sendMessage((Object)player, (List)Arrays.asList(ChatTools.formatTitle("Block Info"), ChatTools.formatCommand("", "Material", "", block.getType().getKey().toString()), ChatTools.formatCommand("", "MaterialData", "", block.getBlockData().getAsString())));
            }

            event.setUseInteractedBlock(Result.DENY);
            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onAdminToolUseOnEntities(PlayerInteractEntityEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (event.getHand() != EquipmentSlot.OFF_HAND && TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         if (event.getRightClicked() != null && event.getPlayer().getInventory().getItemInMainHand().getType().getKey().getKey().equalsIgnoreCase(TownySettings.getTool()) && this.plugin.hasPlayerMode(event.getPlayer(), "infotool") && TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((Permissible)event.getPlayer())) {
            Entity entity = event.getRightClicked();
            TownyMessaging.sendMessage((Object)event.getPlayer(), (List)Arrays.asList(ChatTools.formatTitle("Entity Info"), ChatTools.formatCommand("", "Entity Class", "", entity.getType().getEntityClass().getSimpleName()), ChatTools.formatCommand("", "Entity Type", "", entity.getType().getKey().toString())));
            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onEggLand(PlayerEggThrowEvent event) {
      if (TownySettings.isItemUseMaterial(Material.EGG, event.getEgg().getLocation()) && !TownyActionEventExecutor.canItemuse(event.getPlayer(), event.getEgg().getLocation(), Material.EGG)) {
         event.setHatching(false);
      }

   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onPlayerPickupItem(EntityPickupItemEvent event) {
      if (!TownySettings.getRespawnProtectionAllowPickup()) {
         LivingEntity var3 = event.getEntity();
         if (var3 instanceof Player) {
            Player player = (Player)var3;
            Resident resident = TownyAPI.getInstance().getResident(player);
            if (resident == null) {
               return;
            }

            if (resident.hasRespawnProtection()) {
               event.setCancelled(true);
               if (!resident.isRespawnPickupWarningShown()) {
                  resident.setRespawnPickupWarningShown(true);
                  TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_err_cannot_pickup_respawn_protection"));
               }
            }

            return;
         }
      }

   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onPlayerChangeGameMode(PlayerGameModeChangeEvent event) {
      if (TownyAPI.getInstance().isTownyWorld(event.getPlayer().getWorld())) {
         Towny.getPlugin().deleteCache(event.getPlayer());
      }
   }

   private void loadBlockedCommandLists() {
      this.blockedJailCommands = new CommandList(TownySettings.getJailBlacklistedCommands());
      this.blockedTouristCommands = new CommandList(TownySettings.getTouristBlockedCommands());
      this.blockedTownCommands = new CommandList(TownySettings.getTownBlacklistedCommands());
      this.blockedOutlawCommands = new CommandList(TownySettings.getOutlawBlacklistedCommands());
      this.blockedWarCommands = new CommandList(TownySettings.getWarBlacklistedCommands());
      this.ownPlotLimitedCommands = new CommandList(TownySettings.getPlayerOwnedPlotLimitedCommands());
   }

   private boolean isSignWaxed(Block block) {
      if (!MinecraftVersion.CURRENT_VERSION.isOlderThan(MinecraftVersion.MINECRAFT_1_20)) {
         BlockState var3 = PaperLib.getBlockState(block, false).getState();
         if (var3 instanceof Sign) {
            Sign sign = (Sign)var3;

            try {
               return sign.isWaxed();
            } catch (NoSuchMethodError var4) {
               return false;
            }
         }
      }

      return false;
   }
}
