package com.palmergames.bukkit.towny.listeners;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.event.executors.TownyActionEventExecutor;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.regen.TownyRegenAPI;
import com.palmergames.bukkit.towny.regen.block.BlockLocation;
import com.palmergames.bukkit.towny.utils.BorderUtil;
import com.palmergames.bukkit.util.BlockUtil;
import com.palmergames.bukkit.util.ItemLists;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.type.Chest;
import org.bukkit.block.data.type.Chest.Type;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFertilizeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.block.CauldronLevelChangeEvent;
import org.bukkit.event.block.EntityBlockFormEvent;
import org.bukkit.permissions.Permissible;

public class TownyBlockListener implements Listener {
   private final Towny plugin;

   public TownyBlockListener(Towny instance) {
      this.plugin = instance;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onBlockBreak(BlockBreakEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else {
         Block block = event.getBlock();
         if (TownyAPI.getInstance().isTownyWorld(block.getWorld())) {
            event.setCancelled(!TownyActionEventExecutor.canDestroy(event.getPlayer(), block.getLocation(), block.getType()));
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onBlockPlace(BlockPlaceEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else {
         Block block = event.getBlock();
         if (TownyAPI.getInstance().isTownyWorld(block.getWorld())) {
            if (block.getType() != Material.FIRE || block.getRelative(BlockFace.DOWN).getType() != Material.OBSIDIAN) {
               if (!TownyActionEventExecutor.canBuild(event.getPlayer(), block.getLocation(), block.getType())) {
                  event.setBuild(false);
                  event.setCancelled(true);
               }

               if (!event.isCancelled() && block.getType() == Material.CHEST && !TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((Permissible)event.getPlayer())) {
                  this.testDoubleChest(event.getPlayer(), event.getBlock());
               }

            }
         }
      }
   }

   private void testDoubleChest(Player player, Block block) {
      List<Block> blocksToUpdate = new ArrayList();
      List<WorldCoord> safeWorldCoords = new ArrayList();
      Iterator var5 = BlockUtil.CARDINAL_BLOCKFACES.iterator();

      while(true) {
         Block testBlock;
         WorldCoord wc;
         Chest data;
         Chest testData;
         do {
            do {
               do {
                  do {
                     do {
                        do {
                           do {
                              if (!var5.hasNext()) {
                                 if (!blocksToUpdate.isEmpty()) {
                                    var5 = blocksToUpdate.iterator();

                                    while(var5.hasNext()) {
                                       Block b = (Block)var5.next();
                                       player.sendBlockChange(b.getLocation(), b.getBlockData());
                                    }
                                 }

                                 return;
                              }

                              BlockFace face = (BlockFace)var5.next();
                              testBlock = block.getRelative(face);
                           } while(BlockUtil.sameWorldCoord(block, testBlock));
                        } while(testBlock.getType() != Material.CHEST);

                        wc = WorldCoord.parseWorldCoord(testBlock);
                     } while(safeWorldCoords.contains(wc));

                     data = (Chest)block.getBlockData();
                     testData = (Chest)testBlock.getBlockData();
                  } while(data.getType() != Type.SINGLE);
               } while(!data.getFacing().equals(testData.getFacing()));
            } while((data.getFacing().equals(BlockFace.SOUTH) || data.getFacing().equals(BlockFace.NORTH)) && block.getZ() != testBlock.getZ());
         } while((data.getFacing().equals(BlockFace.EAST) || data.getFacing().equals(BlockFace.WEST)) && block.getX() != testBlock.getX());

         if (BlockUtil.sameOwnerOrHasMayorOverride(block, testBlock, player)) {
            safeWorldCoords.add(wc);
         } else {
            blocksToUpdate.add(testBlock);
            data.setType(Type.SINGLE);
            block.setBlockData(data);
            testData.setType(Type.SINGLE);
            testBlock.setBlockData(testData);
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onBlockBurn(BlockBurnEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
         event.setCancelled(!TownyActionEventExecutor.canBurn(event.getBlock()));
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onBlockIgnite(BlockIgniteEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
         event.setCancelled(!TownyActionEventExecutor.canBurn(event.getBlock()));
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onBlockPistonRetract(BlockPistonRetractEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
         if (!this.canBlockMove(event.getBlock(), event.isSticky() ? event.getBlock().getRelative(event.getDirection().getOppositeFace()) : event.getBlock().getRelative(event.getDirection()), false)) {
            event.setCancelled(true);
         }

         List<Block> blocks = event.getBlocks();
         if (!blocks.isEmpty()) {
            Iterator var3 = blocks.iterator();

            while(var3.hasNext()) {
               Block block = (Block)var3.next();
               if (!this.canBlockMove(block, block.getRelative(event.getDirection()), false)) {
                  event.setCancelled(true);
               }
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onBlockPistonExtend(BlockPistonExtendEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else {
         TownyWorld world = TownyAPI.getInstance().getTownyWorld(event.getBlock().getWorld());
         if (world != null && world.isUsingTowny()) {
            boolean allowWild = world.getUnclaimedZoneBuild();
            if (!this.canBlockMove(event.getBlock(), event.getBlock().getRelative(event.getDirection()), allowWild)) {
               event.setCancelled(true);
            }

            List<Block> blocks = event.getBlocks();
            if (!blocks.isEmpty()) {
               Iterator var5 = blocks.iterator();

               while(var5.hasNext()) {
                  Block block = (Block)var5.next();
                  if (!this.canBlockMove(block, block.getRelative(event.getDirection()), allowWild)) {
                     event.setCancelled(true);
                  }
               }
            }

         }
      }
   }

   private boolean canBlockMove(Block block, Block blockTo, boolean allowWild) {
      WorldCoord from = WorldCoord.parseWorldCoord(block);
      WorldCoord to = WorldCoord.parseWorldCoord(blockTo);
      if (from.equals(to) || to.isWilderness() && from.isWilderness() || allowWild && to.isWilderness()) {
         return true;
      } else {
         TownBlock currentTownBlock = from.getTownBlockOrNull();
         TownBlock destinationTownBlock = to.getTownBlockOrNull();
         if (currentTownBlock != null && destinationTownBlock != null) {
            if (currentTownBlock.hasResident() && destinationTownBlock.hasResident() && currentTownBlock.getResidentOrNull() == destinationTownBlock.getResidentOrNull()) {
               return true;
            } else {
               return currentTownBlock.getTownOrNull() == destinationTownBlock.getTownOrNull() && !currentTownBlock.hasResident() && !destinationTownBlock.hasResident();
            }
         } else {
            return false;
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onCreateExplosion(BlockExplodeEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else {
         TownyWorld townyWorld = TownyAPI.getInstance().getTownyWorld(event.getBlock().getWorld());
         if (townyWorld != null && townyWorld.isUsingTowny()) {
            Material material = event.getBlock().getType();
            if (material == Material.AIR && townyWorld.hasBedExplosionAtBlock(event.getBlock().getLocation())) {
               material = townyWorld.getBedExplosionMaterial(event.getBlock().getLocation());
            }

            List<Block> blocks = TownyActionEventExecutor.filterExplodableBlocks(event.blockList(), material, (Entity)null, event);
            event.blockList().clear();
            event.blockList().addAll(blocks);
            if (!event.blockList().isEmpty()) {
               if (townyWorld.isUsingPlotManagementWildBlockRevert() && townyWorld.isProtectingExplosionBlock(material)) {
                  int count = 0;
                  Iterator var6 = event.blockList().iterator();

                  while(var6.hasNext()) {
                     Block block = (Block)var6.next();
                     if (TownyAPI.getInstance().isWilderness(block) && townyWorld.isExplodedBlockAllowedToRevert(block.getType()) && !TownyRegenAPI.hasProtectionRegenTask(new BlockLocation(block.getLocation()))) {
                        ++count;
                        TownyRegenAPI.beginProtectionRegenTask(block, count, townyWorld, event);
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onFrostWalkerFreezeWater(EntityBlockFormEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld()) && TownySettings.doesFrostWalkerRequireBuildPerms()) {
         Entity var3 = event.getEntity();
         if (var3 instanceof Player) {
            Player player = (Player)var3;
            event.setCancelled(!TownyActionEventExecutor.canBuild(player, event.getBlock().getLocation(), event.getBlock().getType()));
         }

      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onBlockFromToEvent(BlockFromToEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
         if (TownyRegenAPI.hasActiveRegeneration(WorldCoord.parseWorldCoord(event.getBlock()))) {
            event.setCancelled(true);
         }

         if (TownySettings.getPreventFluidGriefingEnabled() && event.getBlock().getType() != Material.DRAGON_EGG) {
            if (!this.canBlockMove(event.getBlock(), event.getToBlock(), true)) {
               event.setCancelled(true);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onBlockDispense(BlockDispenseEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
         if (event.getBlock().getType() == Material.DISPENSER) {
            Material mat = event.getItem().getType();
            if (!ItemLists.BUCKETS.contains(mat) || TownySettings.getPreventFluidGriefingEnabled()) {
               if (ItemLists.BUCKETS.contains(mat) || mat == Material.BONE_MEAL || mat == Material.HONEYCOMB) {
                  if (!this.canBlockMove(event.getBlock(), event.getBlock().getRelative(((Directional)event.getBlock().getBlockData()).getFacing()), true)) {
                     event.setCancelled(true);
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onBlockFertilize(BlockFertilizeEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
         List<BlockState> allowed = BorderUtil.allowedBlocks(event.getBlocks(), event.getBlock(), event.getPlayer());
         event.getBlocks().clear();
         event.getBlocks().addAll(allowed);
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onSculkSpread(BlockSpreadEvent event) {
      String sourceName = event.getSource().getType().getKey().getKey();
      if (sourceName.startsWith("sculk")) {
         if (this.plugin.isError()) {
            event.setCancelled(true);
         } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
            if (sourceName.equalsIgnoreCase("sculk_catalyst")) {
               event.setCancelled(!this.canBlockMove(event.getSource(), event.getBlock(), true));
            }

         }
      }
   }

   @EventHandler(
      ignoreCancelled = true,
      priority = EventPriority.LOW
   )
   public void onCauldronLevelChange(CauldronLevelChangeEvent event) {
      Entity var3 = event.getEntity();
      if (var3 instanceof Player) {
         Player player = (Player)var3;
         if (this.plugin.isError()) {
            event.setCancelled(true);
         } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
            switch(event.getReason()) {
            case BOTTLE_EMPTY:
            case BUCKET_EMPTY:
               event.setCancelled(!TownyActionEventExecutor.canBuild(player, event.getBlock()));
               break;
            case BUCKET_FILL:
            case BOTTLE_FILL:
            case ARMOR_WASH:
            case SHULKER_WASH:
            case BANNER_WASH:
               event.setCancelled(!TownyActionEventExecutor.canDestroy(player, event.getBlock()));
               break;
            case EXTINGUISH:
               if (!TownyActionEventExecutor.canDestroy(player, event.getBlock())) {
                  event.setCancelled(true);
                  if (player.getFireTicks() > 0) {
                     player.setFireTicks(0);
                     player.getWorld().playSound(player, Sound.ENTITY_GENERIC_EXTINGUISH_FIRE, 0.7F, 1.6F);
                  }
               }
            }

         }
      }
   }
}
