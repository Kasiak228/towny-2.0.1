package com.palmergames.bukkit.towny.listeners;

import com.palmergames.adventure.key.Key;
import com.palmergames.adventure.sound.Sound;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownBlockTypeHandler;
import com.palmergames.bukkit.towny.object.TownyInventory;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.gui.EditGUI;
import com.palmergames.bukkit.towny.object.gui.PermissionGUI;
import com.palmergames.bukkit.towny.object.gui.SelectionGUI;
import com.palmergames.bukkit.towny.utils.PermissionGUIUtil;
import com.palmergames.bukkit.towny.utils.ResidentUtil;
import com.palmergames.bukkit.util.Colors;
import com.palmergames.paperlib.PaperLib;
import java.util.Collection;
import java.util.Set;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.meta.ItemMeta;

public class TownyInventoryListener implements Listener {
   private final Towny plugin;
   private final Sound clickSound;

   public TownyInventoryListener(Towny plugin) {
      this.clickSound = Sound.sound(Key.key("minecraft", "block.stone_button.click_on"), Sound.Source.PLAYER, 1.0F, 1.0F);
      this.plugin = plugin;
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onClick(InventoryClickEvent event) {
      InventoryHolder var3 = PaperLib.getHolder(event.getInventory(), false).getHolder();
      if (var3 instanceof TownyInventory) {
         TownyInventory townyInventory = (TownyInventory)var3;
         if (event.getCurrentItem() != null || event.getHotbarButton() != -1) {
            event.setCancelled(true);
            if (event.getHotbarButton() > -1) {
               return;
            } else {
               Player player = (Player)event.getWhoClicked();
               Resident resident = TownyUniverse.getInstance().getResident(player.getUniqueId());
               if (resident == null || event.getClickedInventory() != null && !(PaperLib.getHolder(event.getClickedInventory(), false).getHolder() instanceof TownyInventory)) {
                  return;
               } else {
                  InventoryHolder var8 = event.getInventory().getHolder();
                  if (var8 instanceof EditGUI) {
                     EditGUI editGUI = (EditGUI)var8;
                     ItemMeta meta = event.getCurrentItem().getItemMeta();
                     if (meta == null) {
                        return;
                     }

                     Material type = event.getCurrentItem().getType();
                     ChatColor var10001;
                     if (type == Material.LIME_WOOL) {
                        if (meta.getDisplayName().equals("§a" + ChatColor.BOLD + "Save")) {
                           editGUI.saveChanges();
                        } else {
                           var10001 = ChatColor.BOLD;
                           meta.setDisplayName("§4" + var10001 + Colors.strip(meta.getDisplayName()));
                           event.getCurrentItem().setType(Material.RED_WOOL);
                        }
                     } else if (type == Material.RED_WOOL) {
                        if (meta.getDisplayName().equals("§4" + ChatColor.BOLD + "Back")) {
                           editGUI.exitScreen();
                        } else if (meta.getDisplayName().equals("§4" + ChatColor.BOLD + "Delete")) {
                           editGUI.deleteResident();
                        } else {
                           var10001 = ChatColor.BOLD;
                           meta.setDisplayName("§8" + var10001 + Colors.strip(meta.getDisplayName()));
                           event.getCurrentItem().setType(Material.GRAY_WOOL);
                        }
                     } else {
                        if (type != Material.GRAY_WOOL) {
                           return;
                        }

                        var10001 = ChatColor.BOLD;
                        meta.setDisplayName("§a" + var10001 + Colors.strip(meta.getDisplayName()));
                        event.getCurrentItem().setType(Material.LIME_WOOL);
                     }

                     event.getCurrentItem().setItemMeta(meta);
                     editGUI.playClickSound(player);
                  } else {
                     var8 = event.getInventory().getHolder();
                     if (var8 instanceof PermissionGUI) {
                        PermissionGUI permissionGUI = (PermissionGUI)var8;
                        if (event.getCurrentItem().getType() == Material.PLAYER_HEAD && permissionGUI.canEdit()) {
                           PermissionGUIUtil.openPermissionEditorGUI(resident, permissionGUI.getTownBlock(), event.getCurrentItem());
                           Towny.getAdventure().player(player).playSound(this.clickSound);
                        } else if (event.getCurrentItem().getType() == Material.WRITTEN_BOOK) {
                           player.openBook(PermissionGUIUtil.createTutorialBook());
                        } else if (event.getCurrentItem().getType() == Material.NAME_TAG) {
                           if (this.plugin.isFolia()) {
                              TownyMessaging.sendErrorMsg((CommandSender)player, (Translatable)Translatable.of("msg_perm_gui_folia"));
                              return;
                           }

                           PermissionGUIUtil.handleConversation(player);
                           event.getWhoClicked().closeInventory();
                        } else {
                           permissionGUI.tryPaginate(event.getCurrentItem(), player, resident, event.getView());
                        }
                     } else {
                        var8 = event.getInventory().getHolder();
                        if (var8 instanceof SelectionGUI) {
                           SelectionGUI selectionGUI = (SelectionGUI)var8;
                           TownBlockType type = TownBlockTypeHandler.getType(Colors.strip(event.getCurrentItem().getItemMeta().getDisplayName()));
                           if (type == null) {
                              selectionGUI.playClickSound(player);
                              return;
                           }

                           Set var10000;
                           switch(selectionGUI.getType()) {
                           case ITEMUSE:
                              var10000 = type.getData().getItemUseIds();
                              break;
                           case ALLOWEDBLOCKS:
                              var10000 = type.getData().getAllowedBlocks();
                              break;
                           case SWITCHES:
                              var10000 = type.getData().getSwitchIds();
                              break;
                           default:
                              throw new IncompatibleClassChangeError();
                           }

                           Set<Material> materialSet = var10000;
                           String var15;
                           if (materialSet.isEmpty()) {
                              var15 = Translatable.of("gui_title_no_restrictions").forLocale(resident);
                           } else {
                              switch(selectionGUI.getType()) {
                              case ITEMUSE:
                                 var15 = Translatable.of("gui_title_towny_itemuse").forLocale(resident);
                                 break;
                              case ALLOWEDBLOCKS:
                                 var15 = Translatable.of("gui_title_towny_allowedblocks", type.getName()).forLocale(resident);
                                 break;
                              case SWITCHES:
                                 var15 = Translatable.of("gui_title_towny_switch").forLocale(resident);
                                 break;
                              default:
                                 throw new IncompatibleClassChangeError();
                              }
                           }

                           String title = var15;
                           resident.setGUISelectionType(selectionGUI.getType());
                           selectionGUI.playClickSound(player);
                           ResidentUtil.openGUIInventory(resident, (Collection)materialSet, title);
                        } else {
                           townyInventory.tryPaginate(event.getCurrentItem(), player, resident, event.getView());
                        }
                     }
                  }

                  return;
               }
            }
         }
      }

   }
}
