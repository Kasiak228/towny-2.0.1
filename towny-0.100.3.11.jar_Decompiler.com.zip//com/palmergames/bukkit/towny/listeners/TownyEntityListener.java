package com.palmergames.bukkit.towny.listeners;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.executors.TownyActionEventExecutor;
import com.palmergames.bukkit.towny.event.mobs.MobSpawnRemovalEvent;
import com.palmergames.bukkit.towny.hooks.PluginIntegrations;
import com.palmergames.bukkit.towny.object.Coord;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownBlockType;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.regen.TownyRegenAPI;
import com.palmergames.bukkit.towny.regen.block.BlockLocation;
import com.palmergames.bukkit.towny.tasks.MobRemovalTimerTask;
import com.palmergames.bukkit.towny.utils.BorderUtil;
import com.palmergames.bukkit.towny.utils.CombatUtil;
import com.palmergames.bukkit.towny.utils.EntityTypeUtil;
import com.palmergames.bukkit.util.BukkitTools;
import com.palmergames.bukkit.util.EntityLists;
import com.palmergames.bukkit.util.ItemLists;
import com.palmergames.util.JavaUtil;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Creature;
import org.bukkit.entity.DragonFireball;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.LightningStrike;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.LlamaSpit;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ShulkerBullet;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.entity.Trident;
import org.bukkit.entity.Vehicle;
import org.bukkit.entity.Villager;
import org.bukkit.entity.memory.MemoryKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.AreaEffectCloudApplyEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityBreakDoorEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.LingeringPotionSplashEvent;
import org.bukkit.event.entity.PigZapEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.hanging.HangingBreakEvent.RemoveCause;
import org.bukkit.potion.PotionEffect;
import org.bukkit.projectiles.BlockProjectileSource;
import org.bukkit.projectiles.ProjectileSource;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.ApiStatus.Internal;

public class TownyEntityListener implements Listener {
   private final Towny plugin;
   private static final BiMap<String, String> POTION_LEGACY_NAMES = (BiMap)JavaUtil.make(HashBiMap.create(), (map) -> {
      map.put("slow", "slowness");
      map.put("fast_digging", "haste");
      map.put("slow_digging", "mining_fatigue");
      map.put("increase_damage", "strength");
      map.put("heal", "instant_health");
      map.put("harm", "instant_damage");
      map.put("jump", "jump_boost");
      map.put("confusion", "nausea");
      map.put("damage_resistance", "resistance");
   });

   public TownyEntityListener(Towny instance) {
      this.plugin = instance;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
         Entity attacker = event.getDamager();
         Entity defender = event.getEntity();
         if (event.getCause() == DamageCause.ENTITY_EXPLOSION && !(attacker instanceof Projectile)) {
            boolean cancelExplosiveDamage = false;
            if (EntityTypeUtil.isInstanceOfAny(TownySettings.getProtectedEntityTypes(), defender) && TownySettings.areProtectedEntitiesProtectedAgainstMobs() && this.entityProtectedFromExplosiveDamageHere(defender, event.getCause())) {
               cancelExplosiveDamage = true;
            }

            if (defender instanceof Player && EntityTypeUtil.isPVPExplosive(attacker.getType())) {
               cancelExplosiveDamage = CombatUtil.preventPvP(TownyAPI.getInstance().getTownyWorld(defender.getWorld()), TownyAPI.getInstance().getTownBlock(defender.getLocation()));
            }

            if (cancelExplosiveDamage) {
               event.setDamage(0.0D);
               event.setCancelled(true);
               return;
            }
         }

         if (CombatUtil.preventDamageCall(attacker, defender, event.getCause())) {
            if (attacker instanceof Projectile && !attacker.getType().equals(EntityType.TRIDENT)) {
               attacker.remove();
            }

            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onAxolotlTarget(EntityTargetLivingEntityEvent event) {
      Entity var4 = event.getEntity();
      if (var4 instanceof Mob) {
         Mob attacker = (Mob)var4;
         if (attacker.getType().getKey().equals(NamespacedKey.minecraft("axolotl"))) {
            LivingEntity var5 = event.getTarget();
            if (var5 instanceof Mob) {
               Mob defender = (Mob)var5;
               if (CombatUtil.preventDamageCall(attacker, defender, DamageCause.ENTITY_ATTACK)) {
                  attacker.setMemory(MemoryKey.HAS_HUNTING_COOLDOWN, true);
                  event.setCancelled(true);
               }
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onEntityDeath(EntityDeathEvent event) {
      if (!this.plugin.isError()) {
         Entity entity = event.getEntity();
         if (TownyAPI.getInstance().isTownyWorld(entity.getWorld())) {
            TownBlock townBlock = TownyAPI.getInstance().getTownBlock(entity.getLocation());
            if (townBlock != null) {
               if (entity instanceof Monster && townBlock.getType() == TownBlockType.ARENA) {
                  event.getDrops().clear();
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onEntityTakesExplosionDamage(EntityDamageEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
         if (event.getCause() != null && this.causeIsExplosive(event.getCause()) && this.entityProtectedFromExplosiveDamageHere(event.getEntity(), event.getCause())) {
            event.setDamage(0.0D);
            event.setCancelled(true);
         }

      }
   }

   private boolean causeIsExplosive(DamageCause cause) {
      boolean var10000;
      switch(cause) {
      case ENTITY_EXPLOSION:
      case BLOCK_EXPLOSION:
      case LIGHTNING:
         var10000 = true;
         break;
      default:
         var10000 = false;
      }

      return var10000;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onDragonFireBallCloudDamage(AreaEffectCloudApplyEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyPaperEvents.DRAGON_FIREBALL_GET_EFFECT_CLOUD == null && event.getEntity().getSource() instanceof DragonFireball) {
         if (discardAreaEffectCloud(event.getEntity())) {
            event.setCancelled(true);
            event.getEntity().remove();
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onLingeringPotionSplashEvent(LingeringPotionSplashEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
         ThrownPotion potion = event.getEntity();
         if (this.hasDetrimentalEffects(potion.getEffects())) {
            if (discardAreaEffectCloud(event.getAreaEffectCloud())) {
               event.setCancelled(true);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPotionSplashEvent(PotionSplashEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
         if (this.hasDetrimentalEffects(event.getPotion().getEffects())) {
            Iterator var2 = event.getAffectedEntities().iterator();

            while(var2.hasNext()) {
               LivingEntity defender = (LivingEntity)var2.next();
               if (CombatUtil.preventDamageCall(event.getPotion(), defender, DamageCause.MAGIC)) {
                  event.setIntensity(defender, -1.0D);
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onCreatureSpawn(CreatureSpawnEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else {
         TownyWorld townyWorld = TownyAPI.getInstance().getTownyWorld(event.getEntity().getWorld());
         if (townyWorld != null && townyWorld.isUsingTowny()) {
            LivingEntity livingEntity = event.getEntity();
            if (!this.entityIsExempt(livingEntity, event.getSpawnReason())) {
               if (this.disallowedWorldMob(townyWorld.hasWorldMobs(), livingEntity)) {
                  if (this.weAreAllowedToRemoveThis(livingEntity)) {
                     event.setCancelled(true);
                  }
               } else if (this.disallowedWildernessMob(townyWorld.hasWildernessMobs(), livingEntity)) {
                  if (this.weAreAllowedToRemoveThis(livingEntity)) {
                     event.setCancelled(true);
                  }
               } else if (this.disallowedTownMob(livingEntity) && this.weAreAllowedToRemoveThis(livingEntity)) {
                  event.setCancelled(true);
               }

            }
         }
      }
   }

   private boolean entityIsExempt(LivingEntity livingEntity, SpawnReason spawnReason) {
      return PluginIntegrations.getInstance().isNPC(livingEntity) || this.entityIsExemptByName(livingEntity) || MobRemovalTimerTask.isSpawnReasonIgnored(livingEntity, spawnReason);
   }

   private boolean entityIsExemptByName(LivingEntity livingEntity) {
      return TownySettings.isSkippingRemovalOfNamedMobs() && livingEntity.getCustomName() != null && !PluginIntegrations.getInstance().checkHostileEliteMobs(livingEntity);
   }

   private boolean disallowedWorldMob(boolean worldAllowsMobs, LivingEntity livingEntity) {
      return !worldAllowsMobs && MobRemovalTimerTask.isRemovingWorldEntity(livingEntity) || this.disallowedWorldVillagerBaby(livingEntity);
   }

   private boolean disallowedWorldVillagerBaby(LivingEntity livingEntity) {
      boolean var10000;
      if (TownySettings.isRemovingVillagerBabiesWorld() && livingEntity instanceof Villager) {
         Villager villager = (Villager)livingEntity;
         if (!villager.isAdult()) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private boolean disallowedWildernessMob(boolean wildernessAllowsMobs, LivingEntity livingEntity) {
      return TownyAPI.getInstance().isWilderness(livingEntity.getLocation()) && !wildernessAllowsMobs && MobRemovalTimerTask.isRemovingWildernessEntity(livingEntity);
   }

   private boolean disallowedTownMob(LivingEntity livingEntity) {
      return !TownyAPI.getInstance().isWilderness(livingEntity.getLocation()) && (this.disallowedByTown(livingEntity) || this.disallowedTownVillagerBaby(livingEntity));
   }

   private boolean disallowedByTown(LivingEntity livingEntity) {
      return !TownyAPI.getInstance().areMobsEnabled(livingEntity.getLocation()) && MobRemovalTimerTask.isRemovingTownEntity(livingEntity);
   }

   private boolean disallowedTownVillagerBaby(LivingEntity livingEntity) {
      boolean var10000;
      if (TownySettings.isRemovingVillagerBabiesTown() && livingEntity instanceof Villager) {
         Villager villager = (Villager)livingEntity;
         if (!villager.isAdult()) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private boolean weAreAllowedToRemoveThis(LivingEntity livingEntity) {
      return !BukkitTools.isEventCancelled(new MobSpawnRemovalEvent(livingEntity));
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onEntityInteract(EntityInteractEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld())) {
         Block block = event.getBlock();
         Entity entity = event.getEntity();
         List<Entity> passengers = entity.getPassengers();
         Iterator var5 = passengers.iterator();

         while(var5.hasNext()) {
            Entity passenger = (Entity)var5.next();
            if (passenger instanceof Player) {
               Player player = (Player)passenger;
               if (TownySettings.isSwitchMaterial(block.getType(), block.getLocation())) {
                  event.setCancelled(!TownyActionEventExecutor.canSwitch(player, block.getLocation(), block.getType()));
                  return;
               }
            }
         }

         if (entity instanceof Creature) {
            if (!(entity instanceof Villager) || !ItemLists.WOOD_DOORS.contains(block.getType())) {
               if (block.getType() == Material.STONE_PRESSURE_PLATE) {
                  if (TownySettings.isCreatureTriggeringPressurePlateDisabled()) {
                     event.setCancelled(true);
                  }

               } else if (!TownyAPI.getInstance().isWilderness(block)) {
                  if (TownySettings.isSwitchMaterial(block.getType(), block.getLocation())) {
                     event.setCancelled(true);
                  }
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onEntityChangeBlockEvent(EntityChangeBlockEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else {
         Block block = event.getBlock();
         TownyWorld townyWorld = TownyAPI.getInstance().getTownyWorld(block.getWorld());
         if (townyWorld != null && townyWorld.isUsingTowny()) {
            Material blockMat = block.getType();
            Entity entity = event.getEntity();
            EntityType entityType = event.getEntityType();
            if (blockMat.equals(Material.FARMLAND)) {
               if (entity instanceof Player) {
                  Player player = (Player)entity;
                  event.setCancelled(TownySettings.isPlayerCropTramplePrevented() || !TownyActionEventExecutor.canDestroy(player, block));
               } else {
                  event.setCancelled(townyWorld.isDisableCreatureTrample());
               }

            } else if (entity instanceof FallingBlock && TownyRegenAPI.hasActiveRegeneration(WorldCoord.parseWorldCoord(event.getBlock()))) {
               event.setCancelled(true);
            } else {
               if (entityType == EntityType.ENDERMAN) {
                  event.setCancelled(townyWorld.isEndermanProtect());
               } else if (entityType == EntityType.RAVAGER) {
                  event.setCancelled(townyWorld.isDisableCreatureTrample());
               } else {
                  List passengers;
                  if (entityType == EntityType.WITHER) {
                     passengers = TownyActionEventExecutor.filterExplodableBlocks(Collections.singletonList(block), blockMat, entity, event);
                     event.setCancelled(passengers.isEmpty());
                  } else {
                     Player player;
                     if (EntityLists.BOATS.contains(entityType) && blockMat.equals(Material.LILY_PAD)) {
                        passengers = entity.getPassengers();
                        if (!passengers.isEmpty()) {
                           Object var13 = passengers.get(0);
                           if (var13 instanceof Player) {
                              player = (Player)var13;
                              event.setCancelled(!TownyActionEventExecutor.canDestroy(player, block));
                              return;
                           }
                        }

                        event.setCancelled(!TownyAPI.getInstance().isWilderness(block));
                     } else if (entity instanceof ThrownPotion) {
                        ThrownPotion potion = (ThrownPotion)entity;
                        if (potion.getEffects().isEmpty() && ItemLists.CAMPFIRES.contains(blockMat)) {
                           ProjectileSource var10 = potion.getShooter();
                           if (var10 instanceof BlockProjectileSource) {
                              BlockProjectileSource bps = (BlockProjectileSource)var10;
                              event.setCancelled(!BorderUtil.allowedMove(bps.getBlock(), block));
                           } else {
                              var10 = potion.getShooter();
                              if (var10 instanceof Player) {
                                 player = (Player)var10;
                                 event.setCancelled(!TownyActionEventExecutor.canDestroy(player, block));
                              }
                           }
                        }
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onEntityExplode(EntityExplodeEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else {
         TownyWorld townyWorld = TownyAPI.getInstance().getTownyWorld(event.getEntity().getWorld());
         if (townyWorld != null && townyWorld.isUsingTowny()) {
            List<Block> blocks = TownyActionEventExecutor.filterExplodableBlocks(event.blockList(), (Material)null, event.getEntity(), event);
            event.blockList().clear();
            event.blockList().addAll(blocks);
            if (!event.blockList().isEmpty()) {
               Entity entity = event.getEntity();
               if (townyWorld.isUsingPlotManagementWildEntityRevert() && townyWorld.isProtectingExplosionEntity(entity)) {
                  int count = 0;
                  Iterator var6 = event.blockList().iterator();

                  while(var6.hasNext()) {
                     Block block = (Block)var6.next();
                     if (TownyAPI.getInstance().isWilderness(block) && townyWorld.isExplodedBlockAllowedToRevert(block.getType()) && !TownyRegenAPI.hasProtectionRegenTask(new BlockLocation(block.getLocation()))) {
                        ++count;
                        TownyRegenAPI.beginProtectionRegenTask(block, count, townyWorld, event);
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onEntityCombustByEntityEvent(EntityCombustByEntityEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
         Entity combuster = event.getCombuster();
         Entity defender = event.getEntity();
         LivingEntity attacker = null;
         if (combuster instanceof Projectile) {
            Projectile projectile = (Projectile)combuster;
            ProjectileSource source = projectile.getShooter();
            if (source instanceof BlockProjectileSource) {
               BlockProjectileSource blockSource = (BlockProjectileSource)source;
               if (CombatUtil.preventDispenserDamage(blockSource.getBlock(), defender, DamageCause.PROJECTILE)) {
                  combuster.remove();
                  event.setCancelled(true);
                  return;
               }
            } else {
               attacker = (LivingEntity)source;
            }

            if (attacker != null && CombatUtil.preventDamageCall(attacker, defender, DamageCause.PROJECTILE)) {
               combuster.remove();
               event.setCancelled(true);
            }
         } else if (combuster instanceof LightningStrike) {
            LightningStrike lightning = (LightningStrike)combuster;
            Entity var10 = CombatUtil.getLightningCausingEntity(lightning);
            if (var10 instanceof Player) {
               Player player = (Player)var10;
               if (CombatUtil.preventDamageCall(player, defender, DamageCause.LIGHTNING)) {
                  event.setCancelled(true);
               }
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onHangingBreak(HangingBreakEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
         Entity hanging = event.getEntity();
         RemoveCause removeCause = event.getCause();
         if (removeCause.equals(RemoveCause.PHYSICS)) {
            if (this.attachedToRegeneratingBlock(hanging) || this.itemFrameBrokenByBoatExploit(hanging)) {
               event.setCancelled(true);
            }

         } else if (event instanceof HangingBreakByEntityEvent) {
            HangingBreakByEntityEvent evt = (HangingBreakByEntityEvent)event;
            if (this.preventHangingBrokenByEntity(hanging, removeCause, evt.getRemover())) {
               event.setCancelled(true);
            }

         } else if (removeCause.equals(RemoveCause.EXPLOSION)) {
            if (this.entityProtectedFromExplosiveDamageHere(hanging, DamageCause.BLOCK_EXPLOSION) || this.weAreRevertingBlockExplosionsInWild(hanging.getLocation())) {
               event.setCancelled(true);
            }

         }
      }
   }

   private boolean attachedToRegeneratingBlock(Entity hanging) {
      return EntityLists.HANGING.contains(hanging) && TownyRegenAPI.hasProtectionRegenTask(new BlockLocation(hanging.getLocation().add(hanging.getFacing().getOppositeFace().getDirection())));
   }

   private boolean itemFrameBrokenByBoatExploit(Entity hanging) {
      if (EntityLists.ITEM_FRAMES.contains(hanging)) {
         Block block = hanging.getLocation().add(hanging.getFacing().getOppositeFace().getDirection()).getBlock();
         if (block.isLiquid() || block.isEmpty()) {
            return false;
         }

         Iterator var3 = hanging.getNearbyEntities(0.5D, 0.5D, 0.5D).iterator();

         while(var3.hasNext()) {
            Entity entity = (Entity)var3.next();
            if (entity instanceof Vehicle) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean preventHangingBrokenByEntity(Entity hanging, RemoveCause removeCause, Object remover) {
      if (!removeCause.equals(RemoveCause.EXPLOSION) || !this.entityProtectedFromExplosiveDamageHere(hanging, DamageCause.ENTITY_EXPLOSION) && !this.weAreRevertingThisRemoversExplosionsInWild(hanging.getLocation(), remover)) {
         if (remover instanceof Projectile) {
            Projectile projectile = (Projectile)remover;
            remover = projectile.getShooter();
         }

         if (remover instanceof Player) {
            Player player = (Player)remover;
            return !this.allowedToBreak(player, hanging);
         } else if (remover instanceof Entity) {
            return !TownyAPI.getInstance().isWilderness(hanging.getLocation());
         } else {
            return false;
         }
      } else {
         return true;
      }
   }

   private boolean allowedToBreak(Player player, Entity hanging) {
      return TownyActionEventExecutor.canDestroy(player, hanging.getLocation(), EntityTypeUtil.parseEntityToMaterial(hanging.getType(), Material.GRASS_BLOCK));
   }

   private boolean weAreRevertingThisRemoversExplosionsInWild(Location loc, Object remover) {
      TownyWorld townyWorld = TownyAPI.getInstance().getTownyWorld(loc.getWorld());
      return remover != null && TownyAPI.getInstance().isWilderness(loc) && townyWorld.isUsingPlotManagementWildEntityRevert() && townyWorld.isProtectingExplosionEntity((Entity)remover);
   }

   private boolean weAreRevertingBlockExplosionsInWild(Location loc) {
      return TownyAPI.getInstance().isWilderness(loc) && TownyAPI.getInstance().getTownyWorld(loc.getWorld()).isUsingPlotManagementWildBlockRevert();
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onHangingPlace(HangingPlaceEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
         Material mat = EntityTypeUtil.parseEntityToMaterial(event.getEntity().getType(), Material.GRASS_BLOCK);
         event.setCancelled(!TownyActionEventExecutor.canBuild(event.getPlayer(), event.getEntity().getLocation(), mat));
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPigHitByLightning(PigZapEvent event) {
      if (this.plugin.isError()) {
         event.setCancelled(true);
      } else if (TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
         if (this.entityProtectedFromExplosiveDamageHere(event.getEntity(), DamageCause.LIGHTNING)) {
            event.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onProjectileHitEventButtonOrPlate(ProjectileHitEvent event) {
      if (!this.plugin.isError() && TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld()) && event.getHitBlock() != null && event.getEntity().getShooter() instanceof Player) {
         Block block = event.getHitBlock().getRelative(event.getHitBlockFace());
         Material material = block.getType();
         if (ItemLists.PROJECTILE_TRIGGERED_REDSTONE.contains(material) && TownySettings.isSwitchMaterial(material, block.getLocation()) && !TownyActionEventExecutor.canSwitch((Player)event.getEntity().getShooter(), block.getLocation(), material)) {
            BlockData data = block.getBlockData();
            block.setType(Material.AIR);
            this.plugin.getScheduler().run(block.getLocation(), () -> {
               block.setBlockData(data);
            });
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onProjectileHitBlockEvent(ProjectileHitEvent event) {
      Block hitBlock = event.getHitBlock();
      if (!this.plugin.isError() && TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld()) && hitBlock != null && !this.projectileIsIrrelevantToBlock(hitBlock)) {
         ProjectileSource var4 = event.getEntity().getShooter();
         if (!(var4 instanceof Player)) {
            if (!TownyAPI.getInstance().isWilderness(hitBlock)) {
               event.setCancelled(true);
            }

         } else {
            Player player = (Player)var4;
            if (this.disallowedTargetSwitch(hitBlock, player) || this.disallowedProjectileBlockBreak(hitBlock, event.getEntity(), player) || this.disallowedCampfireLighting(hitBlock, event.getEntity(), player)) {
               event.setCancelled(true);
            }

         }
      }
   }

   private boolean projectileIsIrrelevantToBlock(Block hitBlock) {
      return hitBlock.getType() != Material.TARGET && !ItemLists.PROJECTILE_BREAKABLE_BLOCKS.contains(hitBlock.getType()) && !ItemLists.CAMPFIRES.contains(hitBlock.getType());
   }

   private boolean disallowedTargetSwitch(Block hitBlock, Player player) {
      return hitBlock.getType() == Material.TARGET && TownySettings.isSwitchMaterial(Material.TARGET, hitBlock.getLocation()) && !TownyActionEventExecutor.canSwitch(player, hitBlock.getLocation(), hitBlock.getType());
   }

   private boolean disallowedProjectileBlockBreak(Block hitBlock, Projectile projectile, Player player) {
      if (hitBlock.getType() == Material.POINTED_DRIPSTONE && !(projectile instanceof Trident)) {
         return false;
      } else if (hitBlock.getType().getKey().equals(NamespacedKey.minecraft("decorated_pot")) && (projectile instanceof ShulkerBullet || projectile instanceof EnderPearl || projectile instanceof LlamaSpit)) {
         return false;
      } else {
         return ItemLists.PROJECTILE_BREAKABLE_BLOCKS.contains(hitBlock.getType()) && !TownyActionEventExecutor.canDestroy(player, hitBlock.getLocation(), hitBlock.getType());
      }
   }

   private boolean disallowedCampfireLighting(Block hitBlock, Projectile projectile, Player player) {
      return ItemLists.CAMPFIRES.contains(hitBlock.getType()) && this.isFireArrow(projectile) && !TownyActionEventExecutor.canDestroy(player, hitBlock);
   }

   private boolean isFireArrow(Projectile projectile) {
      boolean var10000;
      if (projectile instanceof Arrow) {
         Arrow arrow = (Arrow)projectile;
         if (arrow.getFireTicks() > 0) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onDoorBreak(EntityBreakDoorEvent event) {
      if (TownyAPI.getInstance().isTownyWorld(event.getBlock().getWorld()) && !TownyAPI.getInstance().isWilderness(event.getBlock().getLocation())) {
         event.setCancelled(true);
      }

   }

   private boolean entityProtectedFromExplosiveDamageHere(Entity entity, DamageCause cause) {
      return !TownyActionEventExecutor.canExplosionDamageEntities(entity.getLocation(), entity, cause);
   }

   private boolean hasDetrimentalEffects(Collection<PotionEffect> effects) {
      if (effects.isEmpty()) {
         return false;
      } else {
         List<String> detrimentalPotions = TownySettings.getPotionTypes().stream().map((type) -> {
            return type.toLowerCase(Locale.ROOT);
         }).toList();
         return effects.stream().map((effect) -> {
            return BukkitTools.potionEffectName(effect.getType());
         }).anyMatch((name) -> {
            if (detrimentalPotions.contains(name)) {
               return true;
            } else {
               String legacyName = (String)POTION_LEGACY_NAMES.inverse().get(name);
               return legacyName != null && detrimentalPotions.contains(legacyName);
            }
         });
      }
   }

   @Internal
   public static boolean discardAreaEffectCloud(@NotNull AreaEffectCloud effectCloud) {
      TownyWorld townyWorld = TownyAPI.getInstance().getTownyWorld(effectCloud.getWorld());
      Location loc = effectCloud.getLocation();
      int radius = (int)Math.ceil((double)effectCloud.getRadius());
      WorldCoord lastChecked = null;

      for(int x = loc.getBlockX() - radius; x < loc.getBlockX() + radius; ++x) {
         for(int z = loc.getBlockZ() - radius; z < loc.getBlockZ() + radius; ++z) {
            if (lastChecked == null || lastChecked.getX() != Coord.toCell(x) || lastChecked.getZ() != Coord.toCell(z)) {
               WorldCoord current = WorldCoord.parseWorldCoord(effectCloud.getWorld().getName(), x, z);
               TownBlock townBlock = current.getTownBlockOrNull();
               if (townyWorld != null && CombatUtil.preventPvP(townyWorld, townBlock)) {
                  return true;
               }

               lastChecked = current;
            }
         }
      }

      return false;
   }
}
