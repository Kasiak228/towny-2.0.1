package com.palmergames.bukkit.towny.listeners;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.event.executors.TownyActionEventExecutor;
import com.palmergames.bukkit.towny.hooks.PluginIntegrations;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.tasks.MobRemovalTimerTask;
import com.palmergames.bukkit.towny.utils.BorderUtil;
import com.palmergames.util.JavaUtil;
import com.palmergames.util.TimeTools;
import java.lang.invoke.MethodHandle;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockEvent;
import org.bukkit.event.block.TNTPrimeEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityEvent;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.projectiles.BlockProjectileSource;
import org.bukkit.projectiles.ProjectileSource;
import org.jetbrains.annotations.ApiStatus.Internal;

@Internal
public class TownyPaperEvents implements Listener {
   private final Towny plugin;
   private static final String SPIGOT_PRIME_EVENT = "org.bukkit.event.block.TNTPrimeEvent";
   private static final String PAPER_PRIME_EVENT = "com.destroystokyo.paper.event.block.TNTPrimeEvent";
   private static final String SIGN_OPEN_EVENT = "io.papermc.paper.event.player.PlayerOpenSignEvent";
   private static final String SPIGOT_SIGN_OPEN_EVENT = "org.bukkit.event.player.PlayerSignOpenEvent";
   private static final String USED_SIGN_OPEN_EVENT = JavaUtil.classExists("io.papermc.paper.event.player.PlayerOpenSignEvent") ? "io.papermc.paper.event.player.PlayerOpenSignEvent" : "org.bukkit.event.player.PlayerSignOpenEvent";
   private static final String PLAYER_ELYTRA_BOOST_EVENT = "com.destroystokyo.paper.event.player.PlayerElytraBoostEvent";
   private static final String DRAGON_FIREBALL_HIT_EVENT = "com.destroystokyo.paper.event.entity.EnderDragonFireballHitEvent";
   public static final MethodHandle SIGN_OPEN_GET_CAUSE;
   private static final MethodHandle SIGN_OPEN_GET_SIGN;
   private static final MethodHandle GET_ORIGIN;
   private static final MethodHandle GET_PRIMER_ENTITY;
   public static final MethodHandle DRAGON_FIREBALL_GET_EFFECT_CLOUD;
   public static final String ADD_TO_WORLD_EVENT = "com.destroystokyo.paper.event.entity.EntityAddToWorldEvent";

   public TownyPaperEvents(Towny plugin) {
      this.plugin = plugin;
   }

   public void register() {
      if (JavaUtil.classExists("org.bukkit.event.block.TNTPrimeEvent")) {
         this.registerEvent("org.bukkit.event.block.TNTPrimeEvent", this::tntPrimeEvent, EventPriority.LOW, true);
      } else if (GET_PRIMER_ENTITY != null) {
         this.registerEvent("com.destroystokyo.paper.event.block.TNTPrimeEvent", this::tntPrimeEvent, EventPriority.LOW, true);
         TownyMessaging.sendDebugMsg("TNTPRimeEvent#getPrimerEntity method found, using TNTPrimeEvent listener.");
      }

      if (GET_ORIGIN != null) {
         this.registerEvent(EntityChangeBlockEvent.class, this.fallingBlockListener(), EventPriority.LOW, true);
         TownyMessaging.sendDebugMsg("Entity#getOrigin found, using falling block listener.");
      }

      if (SIGN_OPEN_GET_CAUSE != null) {
         this.registerEvent(JavaUtil.classExists("io.papermc.paper.event.player.PlayerOpenSignEvent") ? "io.papermc.paper.event.player.PlayerOpenSignEvent" : "org.bukkit.event.player.PlayerSignOpenEvent", this::openSignListener, EventPriority.LOW, true);
         TownyMessaging.sendDebugMsg("PlayerOpenSignEvent#getCause found, using PlayerOpenSignEvent listener.");
      }

      if (DRAGON_FIREBALL_GET_EFFECT_CLOUD != null) {
         this.registerEvent("com.destroystokyo.paper.event.entity.EnderDragonFireballHitEvent", this::dragonFireballHitEventListener, EventPriority.LOW, true);
         TownyMessaging.sendDebugMsg("Using " + DRAGON_FIREBALL_GET_EFFECT_CLOUD + " listener.");
      }

      this.registerEvent("com.destroystokyo.paper.event.player.PlayerElytraBoostEvent", this::playerElytraBoostListener, EventPriority.LOW, true);
      if (this.plugin.isFolia()) {
         this.registerEvent("com.destroystokyo.paper.event.entity.EntityAddToWorldEvent", this::entityAddToWorldListener, EventPriority.MONITOR, false);
      }

   }

   private <T extends Event> void registerEvent(String className, Supplier<Consumer<T>> executor, EventPriority eventPriority, boolean ignoreCancelled) {
      try {
         Class<T> eventClass = Class.forName(className).asSubclass(Event.class);
         this.registerEvent(eventClass, (Consumer)executor.get(), eventPriority, ignoreCancelled);
      } catch (ClassNotFoundException var6) {
      }

   }

   private <T extends Event> void registerEvent(Class<T> eventClass, Consumer<T> consumer, EventPriority eventPriority, boolean ignoreCancelled) {
      Bukkit.getPluginManager().registerEvent(eventClass, this, eventPriority, (listener, event) -> {
         consumer.accept(event);
      }, this.plugin, ignoreCancelled);
   }

   private Consumer<PlayerEvent> playerElytraBoostListener() {
      return (event) -> {
         Player player = event.getPlayer();
         if (TownySettings.isItemUseMaterial(Material.FIREWORK_ROCKET, player.getLocation())) {
            ((Cancellable)event).setCancelled(!TownyActionEventExecutor.canItemuse(player, player.getLocation(), Material.FIREWORK_ROCKET));
         }
      };
   }

   private Consumer<Event> tntPrimeEvent() {
      return (event) -> {
         Entity primerEntity = null;
         if (event.getClass().getName().equals("org.bukkit.event.block.TNTPrimeEvent")) {
            primerEntity = ((TNTPrimeEvent)event).getPrimingEntity();
         } else if (GET_PRIMER_ENTITY != null) {
            try {
               primerEntity = GET_PRIMER_ENTITY.invoke(event);
            } catch (Throwable var8) {
               return;
            }
         }

         if (primerEntity instanceof Projectile) {
            Projectile projectile = (Projectile)primerEntity;
            Cancellable cancellable = (Cancellable)event;
            Block block = ((BlockEvent)event).getBlock();
            ProjectileSource patt7010$temp = projectile.getShooter();
            if (patt7010$temp instanceof Player) {
               Player player = (Player)patt7010$temp;
               cancellable.setCancelled(!TownyActionEventExecutor.canDestroy(player, block));
            } else {
               patt7010$temp = projectile.getShooter();
               if (patt7010$temp instanceof BlockProjectileSource) {
                  BlockProjectileSource bps = (BlockProjectileSource)patt7010$temp;
                  if (!BorderUtil.allowedMove(bps.getBlock(), block)) {
                     cancellable.setCancelled(true);
                  }
               }
            }
         }

      };
   }

   private Consumer<EntityChangeBlockEvent> fallingBlockListener() {
      return (event) -> {
         if (GET_ORIGIN != null && event.getEntityType() == EntityType.FALLING_BLOCK && TownyAPI.getInstance().isTownyWorld(event.getEntity().getWorld())) {
            Location origin;
            try {
               origin = GET_ORIGIN.invokeExact(event.getEntity());
            } catch (Throwable var4) {
               this.plugin.getLogger().log(Level.WARNING, "An exception occurred while invoking Entity#getOrigin reflectively", var4);
               return;
            }

            if (origin != null) {
               if (origin.getBlockZ() != event.getBlock().getZ() || origin.getBlockX() != event.getBlock().getX()) {
                  if (!BorderUtil.allowedMove(origin.getBlock(), event.getBlock())) {
                     event.setCancelled(true);
                  }

               }
            }
         }
      };
   }

   private Consumer<Event> openSignListener() {
      return (event) -> {
         if (SIGN_OPEN_GET_CAUSE != null && SIGN_OPEN_GET_SIGN != null) {
            Enum cause;
            Sign sign;
            try {
               cause = SIGN_OPEN_GET_CAUSE.invoke(event);
               sign = SIGN_OPEN_GET_SIGN.invoke(event);
            } catch (Throwable var5) {
               this.plugin.getLogger().log(Level.WARNING, "An exception occurred while invoking " + USED_SIGN_OPEN_EVENT + "#getCause/#getSign reflectively", var5);
               return;
            }

            if (cause.name().equals("INTERACT") && sign.isPlaced()) {
               if (!TownyActionEventExecutor.canDestroy(((PlayerEvent)event).getPlayer(), sign.getBlock())) {
                  ((Cancellable)event).setCancelled(true);
               }

            }
         }
      };
   }

   private Consumer<Event> dragonFireballHitEventListener() {
      return (event) -> {
         if (DRAGON_FIREBALL_GET_EFFECT_CLOUD != null) {
            AreaEffectCloud effectCloud;
            try {
               effectCloud = DRAGON_FIREBALL_GET_EFFECT_CLOUD.invoke(event);
            } catch (Throwable var4) {
               this.plugin.getLogger().log(Level.WARNING, "An exception occurred when invoking com.destroystokyo.paper.event.entity.EnderDragonFireballHitEvent#getAreaEffectCloud reflectively.", var4);
               return;
            }

            if (TownyEntityListener.discardAreaEffectCloud(effectCloud)) {
               ((Cancellable)event).setCancelled(true);
            }

         }
      };
   }

   private Consumer<EntityEvent> entityAddToWorldListener() {
      return (event) -> {
         Entity patt9699$temp = event.getEntity();
         if (patt9699$temp instanceof LivingEntity) {
            LivingEntity entity = (LivingEntity)patt9699$temp;
            if (!(entity instanceof Player) && !PluginIntegrations.getInstance().isNPC(entity)) {
               this.plugin.getScheduler().runRepeating((Entity)entity, (Runnable)(() -> {
                  TownyWorld world = TownyAPI.getInstance().getTownyWorld(entity.getWorld());
                  if (MobRemovalTimerTask.isRemovingEntities(world)) {
                     MobRemovalTimerTask.checkEntity(this.plugin, world, entity);
                  }

               }), 1L, TimeTools.convertToTicks(TownySettings.getMobRemovalSpeed()));
            }
         }
      };
   }

   static {
      SIGN_OPEN_GET_CAUSE = JavaUtil.getMethodHandle(USED_SIGN_OPEN_EVENT, "getCause");
      SIGN_OPEN_GET_SIGN = JavaUtil.getMethodHandle(USED_SIGN_OPEN_EVENT, "getSign");
      GET_ORIGIN = JavaUtil.getMethodHandle(Entity.class, "getOrigin");
      GET_PRIMER_ENTITY = JavaUtil.getMethodHandle("com.destroystokyo.paper.event.block.TNTPrimeEvent", "getPrimerEntity");
      DRAGON_FIREBALL_GET_EFFECT_CLOUD = JavaUtil.getMethodHandle("com.destroystokyo.paper.event.entity.EnderDragonFireballHitEvent", "getAreaEffectCloud");
   }
}
