package com.palmergames.bukkit.towny.listeners;

import com.palmergames.bukkit.config.ConfigNodes;
import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyEconomyHandler;
import com.palmergames.bukkit.towny.TownyMessaging;
import com.palmergames.bukkit.towny.TownySettings;
import com.palmergames.bukkit.towny.TownyUniverse;
import com.palmergames.bukkit.towny.command.TownCommand;
import com.palmergames.bukkit.towny.command.TownyCommand;
import com.palmergames.bukkit.towny.confirmations.Confirmation;
import com.palmergames.bukkit.towny.event.BedExplodeEvent;
import com.palmergames.bukkit.towny.event.ChunkNotificationEvent;
import com.palmergames.bukkit.towny.event.NewTownEvent;
import com.palmergames.bukkit.towny.event.PlayerChangePlotEvent;
import com.palmergames.bukkit.towny.event.SpawnEvent;
import com.palmergames.bukkit.towny.event.TownAddResidentEvent;
import com.palmergames.bukkit.towny.event.TownBlockPermissionChangeEvent;
import com.palmergames.bukkit.towny.event.TownClaimEvent;
import com.palmergames.bukkit.towny.event.TownPreAddResidentEvent;
import com.palmergames.bukkit.towny.event.TownRemoveResidentEvent;
import com.palmergames.bukkit.towny.event.damage.TownyPlayerDamagePlayerEvent;
import com.palmergames.bukkit.towny.event.nation.NationPreTownLeaveEvent;
import com.palmergames.bukkit.towny.event.town.TownPreUnclaimCmdEvent;
import com.palmergames.bukkit.towny.event.town.TownPreUnclaimEvent;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.CellSurface;
import com.palmergames.bukkit.towny.object.PlayerCache;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.SpawnType;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.TownyWorld;
import com.palmergames.bukkit.towny.object.Translatable;
import com.palmergames.bukkit.towny.object.Translation;
import com.palmergames.bukkit.towny.object.WorldCoord;
import com.palmergames.bukkit.towny.utils.BorderUtil;
import com.palmergames.bukkit.towny.utils.ChunkNotificationUtil;
import com.palmergames.bukkit.towny.utils.PlayerCacheUtil;
import com.palmergames.bukkit.towny.utils.ProximityUtil;
import com.palmergames.bukkit.towny.utils.SpawnUtil;
import com.palmergames.bukkit.util.DrawSmokeTaskFactory;
import com.palmergames.util.TimeMgmt;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.permissions.Permissible;

public class TownyCustomListener implements Listener {
   private final Towny plugin;

   public TownyCustomListener(Towny instance) {
      this.plugin = instance;
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerChangePlotEvent(PlayerChangePlotEvent event) {
      Player player = event.getPlayer();
      WorldCoord from = event.getFrom();
      WorldCoord to = event.getTo();
      if (TownyAPI.getInstance().isTownyWorld(to.getBukkitWorld())) {
         Resident resident = TownyUniverse.getInstance().getResident(player.getUniqueId());
         if (resident != null) {
            this.plugin.getScheduler().runLater((Entity)player, (Runnable)(() -> {
               try {
                  if (resident.hasMode("townclaim")) {
                     TownCommand.parseTownClaimCommand(player, new String[0]);
                  }

                  if (resident.hasMode("townunclaim")) {
                     TownCommand.parseTownUnclaimCommand(player, new String[0]);
                  }

                  if (resident.hasMode("plotgroup") && resident.hasPlotGroupName()) {
                     Towny.getPlugin().getScheduler().runLater((Entity)player, (Runnable)(() -> {
                        Bukkit.dispatchCommand(player, "plot group add " + resident.getPlotGroupName());
                     }), 1L);
                  }
               } catch (TownyException var4) {
                  TownyMessaging.sendErrorMsg((Object)player, (String)var4.getMessage(player));
               }

               if (resident.hasMode("map")) {
                  TownyCommand.showMap(player);
               }

               if (resident.hasMode("plotborder") || resident.hasMode("constantplotborder")) {
                  BorderUtil.getPlotBorder(to).runBorderedOnSurface(1, 2, DrawSmokeTaskFactory.showToPlayer(player, to));
               }

            }), 1L);
            if (event.isShowingPlotNotifications()) {
               this.plugin.getScheduler().runLater(() -> {
                  ChunkNotificationUtil.showChunkNotification(player, resident, to, from);
               }, 2L);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerCreateTown(NewTownEvent event) {
      Town town = event.getTown();
      Resident mayor = town.getMayor();
      if (mayor.isOnline() && town.hasHomeBlock() && TownySettings.isShowingClaimParticleEffect()) {
         this.plugin.getScheduler().runAsync(() -> {
            CellSurface.getCellSurface(town.getHomeBlockOrNull().getWorldCoord()).runClaimingParticleOverSurfaceAtPlayer(mayor.getPlayer());
         });
      }

      this.plugin.getScheduler().runLater(() -> {
         double upkeep = TownySettings.getTownUpkeepCost(town);
         if (TownyEconomyHandler.isActive() && TownySettings.isTaxingDaily() && upkeep > 0.0D) {
            String cost = TownyEconomyHandler.getFormattedBalance(upkeep);
            String time = TimeMgmt.formatCountdownTime(TimeMgmt.townyTime(true));
            TownyMessaging.sendTownMessagePrefixed(town, Translatable.of("msg_new_town_advice", cost, time));
         }

      }, 200L);
      int bonus = TownySettings.getNewTownBonusBlocks();
      if (bonus > 0) {
         town.setBonusBlocks(town.getBonusBlocks() + bonus);
      }

   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onBedExplodeEvent(BedExplodeEvent event) {
      TownyWorld world = (TownyWorld)Optional.ofNullable(event.getLocation().getWorld()).map((w) -> {
         return TownyAPI.getInstance().getTownyWorld(w);
      }).orElse((Object)null);
      if (world != null) {
         world.addBedExplosionAtBlock(event.getLocation(), event.getMaterial());
         if (event.getLocation2() != null) {
            world.addBedExplosionAtBlock(event.getLocation2(), event.getMaterial());
         }

         this.plugin.getScheduler().runLater(event.getLocation(), () -> {
            world.removeBedExplosionAtBlock(event.getLocation());
            world.removeBedExplosionAtBlock(event.getLocation2());
         }, 20L);
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onTownLeaveNation(NationPreTownLeaveEvent event) {
      if (event.getTown().isConquered()) {
         event.setCancelMessage(Translation.of("msg_err_your_conquered_town_cannot_leave_the_nation_yet"));
         event.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onPlayerDamagePlayerEvent(TownyPlayerDamagePlayerEvent event) {
      Resident victim = event.getVictimResident();
      Resident attacker = event.getAttackingResident();
      if (victim != null && victim.hasRespawnProtection()) {
         event.setCancelled(true);
         event.setMessage(Translatable.of("msg_err_player_cannot_be_harmed", victim.getName()).forLocale(attacker));
      }

      if (attacker != null && attacker.hasRespawnProtection()) {
         event.setCancelled(true);
         attacker.removeRespawnProtection();
      }

   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onPlayerSpawnsWithTown(SpawnEvent event) {
      if (!TownyUniverse.getInstance().getPermissionSource().isTownyAdmin((Permissible)event.getPlayer())) {
         Town town = TownyAPI.getInstance().getTown(event.getTo());
         if (town != null && town.hasOutlaw(event.getPlayer().getName())) {
            event.setCancelled(true);
            event.setCancelMessage(Translatable.of("msg_error_cannot_town_spawn_youre_an_outlaw_in_town", town.getName()).forLocale((CommandSender)event.getPlayer()));
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onTownUnclaim(TownPreUnclaimCmdEvent event) {
      Player player = event.getResident().getPlayer();
      if (TownySettings.getOutsidersUnclaimingTownBlocks() && player != null) {
         List<WorldCoord> unclaimSelection = event.getUnclaimSelection();
         Town town = event.getTown();
         Iterator var5 = Bukkit.getOnlinePlayers().iterator();

         while(var5.hasNext()) {
            Player target = (Player)var5.next();
            if (!town.hasResident(target) && !TownyAPI.getInstance().isWilderness(target.getLocation()) && unclaimSelection.contains(WorldCoord.parseWorldCoord((Entity)target))) {
               event.setCancelled(true);
               event.setCancelMessage(Translatable.of("msg_cant_unclaim_outsider_in_town").forLocale(event.getResident()));
               break;
            }
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onTownUnclaimDistrict(TownPreUnclaimEvent event) {
      TownBlock townBlock = event.getTownBlock();
      if (townBlock.hasDistrict()) {
         try {
            ProximityUtil.testAdjacentRemoveDistrictRulesOrThrow(townBlock.getWorldCoord(), event.getTown(), townBlock.getDistrict(), 1);
         } catch (TownyException var4) {
            event.setCancelled(true);
            event.setCancelMessage(var4.getMessage());
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onTownClaim(TownClaimEvent event) {
      if (TownySettings.isShowingClaimParticleEffect() && event.getTownBlock().getWorldCoord().isFullyLoaded()) {
         Towny.getPlugin().getScheduler().runAsync(() -> {
            CellSurface.getCellSurface(event.getTownBlock().getWorldCoord()).runClaimingParticleOverSurfaceAtPlayer(event.getResident().getPlayer());
         });
      }

      if (TownySettings.isOverClaimingAllowingStolenLand()) {
         if (event.getTown().availableTownBlocks() <= TownySettings.getTownBlockRatio()) {
            TownyMessaging.sendMsg(event.getResident(), Translatable.literal("§4").append(Translatable.of("msg_warning_you_are_almost_out_of_townblocks")));
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onTownLosesResident(TownRemoveResidentEvent event) {
      if (TownySettings.isOverClaimingAllowingStolenLand()) {
         if (event.getTown().isOverClaimed()) {
            TownyMessaging.sendPrefixedTownMessage(event.getTown(), Translatable.literal("§4").append(Translatable.of("msg_warning_your_town_is_overclaimed")));
         }

      }
   }

   @EventHandler
   public void onChunkNotification(ChunkNotificationEvent event) {
      if (TownySettings.isOverClaimingAllowingStolenLand() && !event.getToCoord().isWilderness() && !event.getFromCoord().isWilderness()) {
         Town town = TownyAPI.getInstance().getTown(event.getPlayer());
         if (town != null) {
            if (town.availableTownBlocks() >= 1 && town.equals(event.getFromCoord().getTownOrNull())) {
               if (event.getToCoord().canBeStolen()) {
                  String message = event.getMessage() + Translatable.of("chunk_notification_takeover_available").forLocale((CommandSender)event.getPlayer());
                  event.setMessage(message);
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onResidentPreJoinTown(TownPreAddResidentEvent event) {
      Resident resident = event.getResident();
      long minTime = TownySettings.getResidentMinTimeToJoinTown();
      if (minTime > 0L) {
         long timePlayed = System.currentTimeMillis() - resident.getRegistered();
         if (timePlayed < minTime) {
            String timeRemaining = TimeMgmt.getFormattedTimeValue((double)(minTime - timePlayed));
            event.setCancelled(true);
            event.setCancelMessage(Translatable.of("msg_err_you_cannot_join_town_you_have_not_played_long_enough", timeRemaining).forLocale(resident));
         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onResidentJoinTown(TownAddResidentEvent event) {
      if (TownySettings.isPromptingNewResidentsToTownSpawn() && TownySettings.getBoolean(ConfigNodes.SPAWNING_ALLOW_TOWN_SPAWN)) {
         Town town = event.getTown();
         Player player = event.getResident().getPlayer();
         Town playerLocationTown = (Town)Optional.ofNullable(player).map((p) -> {
            return TownyAPI.getInstance().getTown(p.getLocation());
         }).orElse((Object)null);
         if (player != null && (playerLocationTown == null || !playerLocationTown.equals(town))) {
            String notAffordMsg = Translatable.of("msg_err_cant_afford_tp").forLocale((CommandSender)player);
            double cost = town.getSpawnCost();
            if (cost > 0.0D) {
               try {
                  SpawnUtil.sendToTownySpawn(player, new String[0], town, notAffordMsg, false, false, SpawnType.TOWN);
               } catch (TownyException var9) {
                  TownyMessaging.sendErrorMsg((Object)player, (String)var9.getMessage(player));
               }
            } else {
               Confirmation.runOnAccept(() -> {
                  try {
                     SpawnUtil.sendToTownySpawn(player, new String[0], town, notAffordMsg, false, false, SpawnType.TOWN);
                  } catch (TownyException var4) {
                     TownyMessaging.sendErrorMsg((Object)player, (String)var4.getMessage(player));
                  }

               }).setTitle(Translatable.of("msg_new_resident_spawn_to_town_prompt")).sendTo(player);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onTownBlockPermissionChange(TownBlockPermissionChangeEvent event) {
      WorldCoord wc = event.getTownBlock().getWorldCoord();
      Iterator var3 = Bukkit.getOnlinePlayers().iterator();

      while(var3.hasNext()) {
         Player player = (Player)var3.next();
         Towny.getPlugin().getScheduler().runAsync(() -> {
            this.attemptPlayerCacheReset(player, wc);
         });
      }

   }

   private void attemptPlayerCacheReset(Player player, WorldCoord worldCoord) {
      if (worldCoord.getWorldName().equalsIgnoreCase(player.getWorld().getName())) {
         PlayerCache cache = Towny.getPlugin().getCache(player);
         if (cache != null && cache.getLastTownBlock().equals(worldCoord) && !PlayerCacheUtil.isOwnerCache(cache)) {
            Towny.getPlugin().resetCache(player);
         }
      }
   }
}
