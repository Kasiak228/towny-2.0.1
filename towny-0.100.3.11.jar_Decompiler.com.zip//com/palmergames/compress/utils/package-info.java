package com.palmergames.compress.utils;

// $FF: synthetic class
interface package-info {
}
