package com.palmergames.compress.changes;

// $FF: synthetic class
interface package-info {
}
