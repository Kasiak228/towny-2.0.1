package com.palmergames.compress;

// $FF: synthetic class
interface package-info {
}
