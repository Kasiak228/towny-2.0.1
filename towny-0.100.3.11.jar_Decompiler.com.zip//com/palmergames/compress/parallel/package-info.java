package com.palmergames.compress.parallel;

// $FF: synthetic class
interface package-info {
}
