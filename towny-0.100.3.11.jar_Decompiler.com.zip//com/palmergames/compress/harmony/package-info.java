package com.palmergames.compress.harmony;

// $FF: synthetic class
interface package-info {
}
