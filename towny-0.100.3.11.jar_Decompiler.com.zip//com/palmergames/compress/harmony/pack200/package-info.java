package com.palmergames.compress.harmony.pack200;

// $FF: synthetic class
interface package-info {
}
