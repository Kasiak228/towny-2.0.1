package com.palmergames.compress.harmony.unpack200.bytecode;

// $FF: synthetic class
interface package-info {
}
