package com.palmergames.compress.harmony.unpack200.bytecode.forms;

// $FF: synthetic class
interface package-info {
}
