package com.palmergames.compress.harmony.unpack200;

// $FF: synthetic class
interface package-info {
}
