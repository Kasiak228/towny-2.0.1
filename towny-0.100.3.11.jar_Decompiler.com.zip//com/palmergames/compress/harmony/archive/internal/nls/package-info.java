package com.palmergames.compress.harmony.archive.internal.nls;

// $FF: synthetic class
interface package-info {
}
