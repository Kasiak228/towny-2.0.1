package com.palmergames.compress.archivers.ar;

// $FF: synthetic class
interface package-info {
}
