package com.palmergames.compress.archivers.sevenz;

// $FF: synthetic class
interface package-info {
}
