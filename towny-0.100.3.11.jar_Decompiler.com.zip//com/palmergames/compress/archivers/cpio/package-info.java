package com.palmergames.compress.archivers.cpio;

// $FF: synthetic class
interface package-info {
}
