package com.palmergames.compress.archivers.zip;

import java.nio.charset.Charset;

public interface CharsetAccessor {
   Charset getCharset();
}
