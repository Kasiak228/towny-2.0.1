package com.palmergames.compress.archivers.zip;

// $FF: synthetic class
interface package-info {
}
