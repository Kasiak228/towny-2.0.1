package com.palmergames.compress.archivers.dump;

// $FF: synthetic class
interface package-info {
}
