package com.palmergames.compress.archivers;

// $FF: synthetic class
interface package-info {
}
