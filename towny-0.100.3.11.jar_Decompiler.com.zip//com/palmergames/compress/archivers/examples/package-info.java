package com.palmergames.compress.archivers.examples;

// $FF: synthetic class
interface package-info {
}
