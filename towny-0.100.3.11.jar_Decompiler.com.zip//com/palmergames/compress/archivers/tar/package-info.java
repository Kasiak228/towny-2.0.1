package com.palmergames.compress.archivers.tar;

// $FF: synthetic class
interface package-info {
}
