package com.palmergames.compress.archivers.jar;

// $FF: synthetic class
interface package-info {
}
