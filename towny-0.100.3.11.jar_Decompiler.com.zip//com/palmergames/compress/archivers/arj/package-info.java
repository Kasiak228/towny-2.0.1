package com.palmergames.compress.archivers.arj;

// $FF: synthetic class
interface package-info {
}
