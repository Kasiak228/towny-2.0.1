package com.palmergames.compress.compressors;

import java.io.OutputStream;

public abstract class CompressorOutputStream extends OutputStream {
}
