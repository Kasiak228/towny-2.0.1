package com.palmergames.compress.compressors.z;

// $FF: synthetic class
interface package-info {
}
