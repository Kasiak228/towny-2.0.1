package com.palmergames.compress.compressors.snappy;

// $FF: synthetic class
interface package-info {
}
