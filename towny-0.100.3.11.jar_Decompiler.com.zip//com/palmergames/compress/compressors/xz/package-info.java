package com.palmergames.compress.compressors.xz;

// $FF: synthetic class
interface package-info {
}
