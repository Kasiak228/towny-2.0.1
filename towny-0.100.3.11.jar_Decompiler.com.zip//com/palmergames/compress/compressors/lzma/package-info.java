package com.palmergames.compress.compressors.lzma;

// $FF: synthetic class
interface package-info {
}
