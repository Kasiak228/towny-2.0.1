package com.palmergames.compress.compressors;

// $FF: synthetic class
interface package-info {
}
