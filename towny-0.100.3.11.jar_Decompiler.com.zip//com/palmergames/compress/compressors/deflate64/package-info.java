package com.palmergames.compress.compressors.deflate64;

// $FF: synthetic class
interface package-info {
}
