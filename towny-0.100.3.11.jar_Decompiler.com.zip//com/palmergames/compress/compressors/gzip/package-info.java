package com.palmergames.compress.compressors.gzip;

// $FF: synthetic class
interface package-info {
}
