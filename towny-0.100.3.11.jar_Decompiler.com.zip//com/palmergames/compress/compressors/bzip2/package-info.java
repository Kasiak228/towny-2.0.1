package com.palmergames.compress.compressors.bzip2;

// $FF: synthetic class
interface package-info {
}
