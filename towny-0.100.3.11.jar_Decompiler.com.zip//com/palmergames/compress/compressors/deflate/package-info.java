package com.palmergames.compress.compressors.deflate;

// $FF: synthetic class
interface package-info {
}
