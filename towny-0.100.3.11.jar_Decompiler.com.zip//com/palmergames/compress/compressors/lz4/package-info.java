package com.palmergames.compress.compressors.lz4;

// $FF: synthetic class
interface package-info {
}
