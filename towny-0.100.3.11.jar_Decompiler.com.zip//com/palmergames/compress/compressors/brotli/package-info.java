package com.palmergames.compress.compressors.brotli;

// $FF: synthetic class
interface package-info {
}
