package com.palmergames.compress.compressors.zstandard;

// $FF: synthetic class
interface package-info {
}
