package com.palmergames.compress.compressors.lzw;

// $FF: synthetic class
interface package-info {
}
