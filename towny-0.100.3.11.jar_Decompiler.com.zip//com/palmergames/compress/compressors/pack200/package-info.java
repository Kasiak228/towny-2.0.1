package com.palmergames.compress.compressors.pack200;

// $FF: synthetic class
interface package-info {
}
