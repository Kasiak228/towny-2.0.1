package com.palmergames.compress.compressors.lz77support;

// $FF: synthetic class
interface package-info {
}
