package com.palmergames.compress.java.util.jar;

// $FF: synthetic class
interface package-info {
}
