package com.palmergames.util;

import com.palmergames.bukkit.towny.Towny;
import com.palmergames.bukkit.towny.db.TownyDatabaseHandler;
import com.palmergames.bukkit.towny.regen.PlotBlockData;
import com.palmergames.compress.archivers.tar.TarArchiveEntry;
import com.palmergames.compress.archivers.tar.TarArchiveOutputStream;
import com.palmergames.compress.compressors.gzip.GzipCompressorOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.apache.commons.io.IOUtils;
import org.jetbrains.annotations.NotNull;

public final class FileMgmt {
   private static final ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
   private static final Lock readLock;
   private static final Lock writeLock;

   public static boolean checkOrCreateFolder(String folderPath) {
      File file = new File(folderPath);
      return !file.exists() && !file.isDirectory() ? newDir(file) : true;
   }

   public static boolean checkOrCreateFolders(String... folders) {
      String[] var1 = folders;
      int var2 = folders.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String folder = var1[var3];
         if (!checkOrCreateFolder(folder)) {
            return false;
         }
      }

      return true;
   }

   public static boolean checkOrCreateFile(String filePath) {
      File file = new File(filePath);
      if (!checkOrCreateFolder(file.getParentFile().getPath())) {
         return false;
      } else {
         return file.exists() ? true : newFile(file);
      }
   }

   private static boolean newDir(File dir) {
      boolean var1;
      try {
         writeLock.lock();
         var1 = dir.mkdirs();
      } finally {
         writeLock.unlock();
      }

      return var1;
   }

   private static boolean newFile(File file) {
      boolean var2;
      try {
         writeLock.lock();
         boolean var1 = file.createNewFile();
         return var1;
      } catch (IOException var6) {
         var2 = false;
      } finally {
         writeLock.unlock();
      }

      return var2;
   }

   public static boolean checkOrCreateFiles(String... files) {
      String[] var1 = files;
      int var2 = files.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String file = var1[var3];
         if (!checkOrCreateFile(file)) {
            return false;
         }
      }

      return true;
   }

   public static void copyDirectory(File sourceLocation, File targetLocation) throws IOException {
      try {
         writeLock.lock();
         if (sourceLocation.isDirectory()) {
            if (!targetLocation.exists()) {
               targetLocation.mkdir();
            }

            String[] children = sourceLocation.list();
            String[] var3 = children;
            int var4 = children.length;

            for(int var5 = 0; var5 < var4; ++var5) {
               String aChildren = var3[var5];
               copyDirectory(new File(sourceLocation, aChildren), new File(targetLocation, aChildren));
            }
         } else {
            Files.copy(sourceLocation.toPath(), targetLocation.toPath());
         }
      } finally {
         writeLock.unlock();
      }

   }

   public static boolean listToFile(Collection<String> source, String targetLocation) {
      boolean var3;
      try {
         writeLock.lock();

         try {
            Files.write(Path.of(targetLocation, new String[0]), source);
            boolean var2 = true;
            return var2;
         } catch (IOException var7) {
            Towny.getPlugin().getLogger().log(Level.WARNING, "An exception occurred while writing to " + targetLocation, var7);
            var3 = false;
         }
      } finally {
         writeLock.unlock();
      }

      return var3;
   }

   public static void moveFile(File sourceFile, String targetLocation) {
      try {
         writeLock.lock();
         if (sourceFile.isFile()) {
            String var10002 = sourceFile.getParent();
            File f = new File(var10002 + File.separator + targetLocation + File.separator + sourceFile.getName());
            if (f.exists() && f.isFile()) {
               f.delete();
            }

            sourceFile.renameTo(new File(sourceFile.getParent() + File.separator + targetLocation, sourceFile.getName()));
         }
      } finally {
         writeLock.unlock();
      }

   }

   public static void moveTownBlockFile(File sourceFile, String targetLocation, String townDir) {
      try {
         writeLock.lock();
         if (sourceFile.isFile()) {
            String var10000;
            if (!townDir.isEmpty()) {
               var10000 = sourceFile.getParent();
               checkOrCreateFolder(var10000 + File.separator + "deleted" + File.separator + townDir);
            } else {
               var10000 = sourceFile.getParent();
               checkOrCreateFolder(var10000 + File.separator + "deleted");
            }

            String var10002 = sourceFile.getParent();
            File f = new File(var10002 + File.separator + targetLocation + File.separator + townDir + File.separator + sourceFile.getName());
            if (f.exists() && f.isFile()) {
               f.delete();
            }

            sourceFile.renameTo(new File(sourceFile.getParent() + File.separator + targetLocation + File.separator + townDir, sourceFile.getName()));
         }
      } finally {
         writeLock.unlock();
      }

   }

   public static String getFileTimeStamp() {
      long t = System.currentTimeMillis();
      return (new SimpleDateFormat("yyyy-MM-dd HH-mm")).format(t);
   }

   public static void tar(File destination, File... sources) throws IOException {
      try {
         readLock.lock();
         TarArchiveOutputStream archive = new TarArchiveOutputStream(new GzipCompressorOutputStream(new FileOutputStream(destination)));

         try {
            archive.setLongFileMode(3);
            File[] var3 = sources;
            int var4 = sources.length;

            for(int var5 = 0; var5 < var4; ++var5) {
               File sourceFile = var3[var5];
               Path source = sourceFile.toPath();
               Stream files = Files.walk(source);

               try {
                  Iterator var9 = files.toList().iterator();

                  while(var9.hasNext()) {
                     Path path = (Path)var9.next();
                     if (!Files.isDirectory(path, new LinkOption[0])) {
                        InputStream fis = Files.newInputStream(path);

                        try {
                           TarArchiveEntry entry_1 = new TarArchiveEntry(path, source.getParent().relativize(path).toString(), new LinkOption[0]);
                           archive.putArchiveEntry(entry_1);
                           IOUtils.copy(fis, archive);
                           archive.closeArchiveEntry();
                        } catch (Throwable var25) {
                           if (fis != null) {
                              try {
                                 fis.close();
                              } catch (Throwable var24) {
                                 var25.addSuppressed(var24);
                              }
                           }

                           throw var25;
                        }

                        if (fis != null) {
                           fis.close();
                        }
                     }
                  }
               } catch (Throwable var26) {
                  if (files != null) {
                     try {
                        files.close();
                     } catch (Throwable var23) {
                        var26.addSuppressed(var23);
                     }
                  }

                  throw var26;
               }

               if (files != null) {
                  files.close();
               }
            }
         } catch (Throwable var27) {
            try {
               archive.close();
            } catch (Throwable var22) {
               var27.addSuppressed(var22);
            }

            throw var27;
         }

         archive.close();
      } finally {
         readLock.unlock();
      }

   }

   public static void zipFile(File file, String path) {
      try {
         ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(path), StandardCharsets.UTF_8);

         try {
            writeLock.lock();
            byte[] buffer = new byte[2056];
            zos.putNextEntry(new ZipEntry(file.getName()));
            FileInputStream in = new FileInputStream(file);

            int len;
            try {
               while((len = in.read(buffer)) > 0) {
                  zos.write(buffer, 0, len);
               }
            } catch (Throwable var16) {
               try {
                  in.close();
               } catch (Throwable var15) {
                  var16.addSuppressed(var15);
               }

               throw var16;
            }

            in.close();
         } catch (Throwable var17) {
            try {
               zos.close();
            } catch (Throwable var14) {
               var17.addSuppressed(var14);
            }

            throw var17;
         }

         zos.close();
      } catch (IOException var18) {
         Towny.getPlugin().getLogger().log(Level.WARNING, "An exception occurred while zipping up file " + file.getName(), var18);
      } finally {
         writeLock.unlock();
      }

   }

   public static void zipDirectories(File destination, File... sourceFolders) throws IOException {
      try {
         readLock.lock();
         ZipOutputStream output = new ZipOutputStream(new FileOutputStream(destination), StandardCharsets.UTF_8);
         File[] var3 = sourceFolders;
         int var4 = sourceFolders.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            File sourceFolder = var3[var5];
            recursiveZipDirectory(sourceFolder, output);
         }

         output.close();
      } finally {
         readLock.unlock();
      }
   }

   public static void recursiveZipDirectory(File sourceFolder, ZipOutputStream zipStream) throws IOException {
      try {
         readLock.lock();
         String[] dirList = sourceFolder.list();
         byte[] readBuffer = new byte[2156];
         String[] var5 = dirList;
         int var6 = dirList.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            String aDirList = var5[var7];
            File f = new File(sourceFolder, aDirList);
            if (f.isDirectory()) {
               recursiveZipDirectory(f, zipStream);
            } else if (f.isFile() && f.canRead()) {
               FileInputStream input = new FileInputStream(f);

               try {
                  ZipEntry anEntry = new ZipEntry(f.getPath());
                  zipStream.putNextEntry(anEntry);

                  int bytesIn;
                  while((bytesIn = input.read(readBuffer)) != -1) {
                     zipStream.write(readBuffer, 0, bytesIn);
                  }
               } catch (Throwable var18) {
                  try {
                     input.close();
                  } catch (Throwable var17) {
                     var18.addSuppressed(var17);
                  }

                  throw var18;
               }

               input.close();
            }
         }
      } finally {
         readLock.unlock();
      }

   }

   public static void deleteFile(File file) {
      try {
         writeLock.lock();
         if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
               File[] var2 = children;
               int var3 = children.length;

               for(int var4 = 0; var4 < var3; ++var4) {
                  File child = var2[var4];
                  deleteFile(child);
               }
            }

            children = file.listFiles();
            if ((children == null || children.length == 0) && !file.delete()) {
               Towny.getPlugin().getLogger().warning("Error: Could not delete folder: " + file.getPath());
            }
         } else if (file.isFile() && !file.delete()) {
            Towny.getPlugin().getLogger().warning("Error: Could not delete file: " + file.getPath());
         }
      } finally {
         writeLock.unlock();
      }

   }

   public static boolean deleteOldBackups(File backupsDir, long deleteAfter) {
      boolean var4;
      try {
         writeLock.lock();
         TreeSet<Long> deleted = new TreeSet();
         if (backupsDir.isDirectory()) {
            File[] children = backupsDir.listFiles();
            boolean var23;
            if (children == null) {
               var23 = true;
               return var23;
            }

            File[] var5 = children;
            int var6 = children.length;

            for(int var7 = 0; var7 < var6; ++var7) {
               File child = var5[var7];
               if (!child.isDirectory()) {
                  String fileName = child.getName();

                  long timeMade;
                  try {
                     timeMade = TownyDatabaseHandler.BACKUP_DATE_FORMAT.parse(fileName).getTime();
                  } catch (ParseException var20) {
                     try {
                        String[] tokens = fileName.split("\\.")[0].split(" ");
                        String lastToken = tokens[tokens.length - 1];
                        timeMade = Long.parseLong(lastToken);
                     } catch (Exception var19) {
                        Towny.getPlugin().getLogger().warning("File '" + fileName + "' in the backup folder does not match any format recognized by Towny, it will not be automatically deleted.");
                        continue;
                     }
                  }

                  if (timeMade >= 0L) {
                     long age = System.currentTimeMillis() - timeMade;
                     if (age >= deleteAfter) {
                        deleteFile(child);
                        deleted.add(age);
                     }
                  }
               }
            }

            if (!deleted.isEmpty()) {
               Towny.getPlugin().getLogger().info(String.format("Deleting %d Old Backups (%s).", deleted.size(), deleted.size() > 1 ? String.format("%d-%d days old", TimeUnit.MILLISECONDS.toDays((Long)deleted.first()), TimeUnit.MILLISECONDS.toDays((Long)deleted.last())) : String.format("%d days old", TimeUnit.MILLISECONDS.toDays((Long)deleted.first()))));
            }

            var23 = true;
            return var23;
         }

         var4 = false;
      } finally {
         writeLock.unlock();
      }

      return var4;
   }

   public static HashMap<String, String> loadFileIntoHashMap(File file) {
      HashMap var21;
      try {
         readLock.lock();
         HashMap keys = new HashMap();

         try {
            FileInputStream fis = new FileInputStream(file);

            try {
               InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);

               try {
                  Properties properties = new Properties();
                  properties.load(isr);
                  Iterator var5 = properties.stringPropertyNames().iterator();

                  while(var5.hasNext()) {
                     String key = (String)var5.next();
                     String value = properties.getProperty(key);
                     keys.put(key, String.valueOf(value));
                  }
               } catch (Throwable var17) {
                  try {
                     isr.close();
                  } catch (Throwable var16) {
                     var17.addSuppressed(var16);
                  }

                  throw var17;
               }

               isr.close();
            } catch (Throwable var18) {
               try {
                  fis.close();
               } catch (Throwable var15) {
                  var18.addSuppressed(var15);
               }

               throw var18;
            }

            fis.close();
         } catch (IOException var19) {
            Towny.getPlugin().getLogger().log(Level.WARNING, "An exception occurred while reading file " + file.getName(), var19);
         }

         var21 = keys;
      } finally {
         readLock.unlock();
      }

      return var21;
   }

   public static void savePlotData(PlotBlockData data, File file, String path) {
      checkOrCreateFolder(file.getPath());

      try {
         ZipOutputStream output = new ZipOutputStream(new FileOutputStream(path), StandardCharsets.UTF_8);

         try {
            writeLock.lock();
            int var10003 = data.getX();
            output.putNextEntry(new ZipEntry(var10003 + "_" + data.getZ() + "_" + data.getSize() + ".data"));
            DataOutputStream fout = new DataOutputStream(output);

            try {
               fout.write("VER".getBytes(StandardCharsets.UTF_8));
               fout.write(data.getVersion());
               fout.writeInt(data.getHeight());
               fout.writeInt(data.getMinHeight());
               Iterator var5 = (new ArrayList(data.getBlockList())).iterator();

               while(var5.hasNext()) {
                  String block = (String)var5.next();
                  fout.writeUTF(block);
               }
            } catch (Throwable var16) {
               try {
                  fout.close();
               } catch (Throwable var15) {
                  var16.addSuppressed(var15);
               }

               throw var16;
            }

            fout.close();
         } catch (Throwable var17) {
            try {
               output.close();
            } catch (Throwable var14) {
               var17.addSuppressed(var14);
            }

            throw var17;
         }

         output.close();
      } catch (IOException var18) {
         Towny.getPlugin().getLogger().log(Level.WARNING, "An exception occurred while saving plot data to " + file.getName(), var18);
      } finally {
         writeLock.unlock();
      }

   }

   @NotNull
   public static String getFileName(@NotNull Path path) {
      String fileName = path.getFileName().toString();
      if (fileName.contains(".")) {
         fileName = fileName.substring(0, fileName.lastIndexOf("."));
      }

      return fileName;
   }

   @NotNull
   public static String getExtension(@NotNull Path path) {
      String fileName = path.getFileName().toString();
      int index = fileName.lastIndexOf(".");
      return index == -1 ? "" : fileName.substring(index + 1);
   }

   static {
      readLock = readWriteLock.readLock();
      writeLock = readWriteLock.writeLock();
   }
}
