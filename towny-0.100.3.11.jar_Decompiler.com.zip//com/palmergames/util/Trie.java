package com.palmergames.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Map.Entry;

public class Trie {
   private static final int MAX_RETURNS = 100;
   private final Trie.TrieNode root = new Trie.TrieNode('\u0000');

   public void addKey(String key) {
      Trie.TrieNode current = this.root;
      char[] var3 = key.toCharArray();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         char c = var3[var5];
         current = (Trie.TrieNode)current.children.computeIfAbsent(c, (k) -> {
            return new Trie.TrieNode(c);
         });
      }

      current.endOfWord = true;
   }

   public void removeKey(String key) {
      if (key != null && !key.isEmpty()) {
         Queue<Trie.TrieNode> found = Collections.asLifoQueue(new LinkedList());
         Trie.TrieNode lastNode = this.root;

         char lastChar;
         for(int i = 0; i < key.length(); ++i) {
            lastChar = key.charAt(i);
            Trie.TrieNode charNode = (Trie.TrieNode)lastNode.children.get(lastChar);
            if (charNode == null) {
               break;
            }

            found.add(charNode);
            lastNode = charNode;
         }

         if (!found.isEmpty() && ((Trie.TrieNode)found.peek()).character == key.charAt(key.length() - 1)) {
            Trie.TrieNode lastCharNode = (Trie.TrieNode)found.poll();
            lastCharNode.endOfWord = false;
            if (lastCharNode.children.isEmpty()) {
               for(lastChar = lastCharNode.character; !found.isEmpty(); lastChar = lastCharNode.character) {
                  lastCharNode = (Trie.TrieNode)found.poll();
                  lastCharNode.children.remove(lastChar);
                  if (lastCharNode.endOfWord || !lastCharNode.children.isEmpty()) {
                     break;
                  }
               }
            }

         }
      }
   }

   public List<String> getStringsFromKey(String key) {
      if (key.length() == 0) {
         return getChildrenStrings(this.root, new ArrayList());
      } else {
         List<String> strings = new ArrayList();
         Map<Trie.TrieNode, String> nodes = new HashMap();
         nodes.put(this.root, "");

         for(int i = 0; i < key.length(); ++i) {
            Map<Trie.TrieNode, String> newNodes = new HashMap();
            char index = Character.toLowerCase(key.charAt(i));
            Iterator var7 = nodes.entrySet().iterator();

            label46:
            while(var7.hasNext()) {
               Entry<Trie.TrieNode, String> entry = (Entry)var7.next();
               Iterator var9 = ((Trie.TrieNode)entry.getKey()).children.values().iterator();

               while(true) {
                  Trie.TrieNode node;
                  String realKey;
                  do {
                     do {
                        if (!var9.hasNext()) {
                           continue label46;
                        }

                        node = (Trie.TrieNode)var9.next();
                     } while(Character.toLowerCase(node.character) != index);

                     String var10000 = (String)entry.getValue();
                     realKey = var10000 + node.character;
                     newNodes.put(node, realKey);
                  } while(i != key.length() - 1);

                  Iterator var12 = getChildrenStrings(node, new ArrayList()).iterator();

                  while(var12.hasNext()) {
                     String string = (String)var12.next();
                     strings.add(realKey + string);
                  }
               }
            }

            nodes = newNodes;
         }

         return strings;
      }
   }

   private static List<String> getChildrenStrings(Trie.TrieNode find, List<String> found) {
      List<String> childrenStrings = new ArrayList();
      Iterator var3 = find.children.values().iterator();

      while(true) {
         Trie.TrieNode trieNode;
         do {
            if (!var3.hasNext()) {
               return found;
            }

            trieNode = (Trie.TrieNode)var3.next();
            if (found.size() + 1 > 100) {
               return found;
            }

            if (trieNode.endOfWord) {
               found.add(String.valueOf(trieNode.character));
            }
         } while(trieNode.children.isEmpty());

         childrenStrings.clear();
         Iterator var5 = getChildrenStrings(trieNode, childrenStrings).iterator();

         while(var5.hasNext()) {
            String string = (String)var5.next();
            if (found.size() + 1 > 100) {
               return found;
            }

            found.add(trieNode.character + string);
         }
      }
   }

   public static class TrieNode {
      final Map<Character, Trie.TrieNode> children = new HashMap();
      final char character;
      boolean endOfWord = false;

      TrieNode(char character) {
         this.character = character;
      }
   }
}
