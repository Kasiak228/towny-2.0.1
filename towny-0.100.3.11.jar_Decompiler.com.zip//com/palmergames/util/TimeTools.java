package com.palmergames.util;

import com.palmergames.bukkit.towny.TownySettings;
import java.util.regex.Pattern;

public class TimeTools {
   private static final long MILLIS_PER_SECOND = 1000L;
   private static final long MILLIS_PER_MINUTE = 60000L;
   private static final long MILLIS_PER_HOUR = 3600000L;
   private static final long MILLIS_PER_DAY = 86400000L;

   public static long secondsFromDhms(String dhms) {
      int seconds = 0;
      int minutes = 0;
      int hours = 0;
      int days = 0;
      if (dhms.contains("d")) {
         days = Integer.parseInt(dhms.split("d")[0].replaceAll(" ", ""));
         if (dhms.contains("h") || dhms.contains("m") || dhms.contains("s")) {
            dhms = dhms.split("d")[1];
         }
      }

      if (dhms.contains("h")) {
         hours = Integer.parseInt(dhms.split("h")[0].replaceAll(" ", ""));
         if (dhms.contains("m") || dhms.contains("s")) {
            dhms = dhms.split("h")[1];
         }
      }

      if (dhms.contains("m")) {
         minutes = Integer.parseInt(dhms.split("m")[0].replaceAll(" ", ""));
         if (dhms.contains("s")) {
            dhms = dhms.split("m")[1];
         }
      }

      if (dhms.contains("s")) {
         seconds = Integer.parseInt(dhms.split("s")[0].replaceAll(" ", ""));
      }

      return (long)days * 86400L + (long)hours * 3600L + (long)minutes * 60L + (long)seconds;
   }

   public static long getMillis(String dhms) {
      return getSeconds(dhms) * 1000L;
   }

   public static long getSeconds(String dhms) {
      return Pattern.matches(".*[a-zA-Z].*", dhms) ? secondsFromDhms(dhms) : Long.parseLong(dhms);
   }

   public static long getTicks(String dhms) {
      return convertToTicks(getSeconds(dhms));
   }

   public static long convertToTicks(long t) {
      return t * 20L;
   }

   public static int convertToShortTicks(double timeSeconds) {
      return (int)(timeSeconds / (double)TownySettings.getShortInterval() + 0.5D);
   }

   public static int getHours(long milliSeconds) {
      return (int)(milliSeconds / 1000L / 60L) / 60;
   }

   public static int getDays(long milliSeconds) {
      return (int)(milliSeconds / 1000L / 60L / 60L) / 24;
   }

   public static long getTimeInMillisXSecondsAgo(int seconds) {
      return System.currentTimeMillis() - 1000L * (long)seconds;
   }

   public static long getTimeInMillisXMinutesAgo(int minutes) {
      return System.currentTimeMillis() - 60000L * (long)minutes;
   }

   public static long getTimeInMillisXHoursAgo(int hours) {
      return System.currentTimeMillis() - 3600000L * (long)hours;
   }

   public static long getTimeInMillisXDaysAgo(int days) {
      return System.currentTimeMillis() - 86400000L * (long)days;
   }
}
