package com.palmergames.util;

import com.google.common.base.Strings;
import com.palmergames.bukkit.towny.object.Translation;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.md_5.bungee.api.ChatColor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.ApiStatus.Internal;

public class StringMgmt {
   public static final Pattern hexPattern = Pattern.compile("(&#|\\{|§x|<#)([a-fA-F0-9]|§[a-fA-F0-9]){6}(}|>|)");
   public static final Pattern hexReplacePattern = Pattern.compile("(§x|[&{}<>§#])");
   private static final Function<String, String> legacyHexFunction = (hex) -> {
      return ChatColor.of("#" + hex).toString();
   };

   public static String translateHexColors(String string) {
      return translateHexColors(string, legacyHexFunction);
   }

   @Internal
   public static String translateHexColors(String string, Function<String, String> hexFunction) {
      String hex;
      for(Matcher hexMatcher = hexPattern.matcher(string); hexMatcher.find(); string = string.replace(hex, (CharSequence)hexFunction.apply(hexReplacePattern.matcher(hex).replaceAll("")))) {
         hex = hexMatcher.group();
      }

      return string;
   }

   public static String join(Collection<?> args) {
      return join(args, " ");
   }

   public static String join(Collection<?> args, String separator) {
      StringJoiner joiner = new StringJoiner(separator);
      Iterator var3 = args.iterator();

      while(var3.hasNext()) {
         Object o = var3.next();
         joiner.add(o.toString());
      }

      return joiner.toString();
   }

   public static String join(Object[] arr) {
      return join(arr, " ");
   }

   public static String join(Object[] arr, String separator) {
      if (arr.length == 0) {
         return "";
      } else {
         String out = arr[0].toString();

         for(int i = 1; i < arr.length; ++i) {
            out = out + separator + arr[i];
         }

         return out;
      }
   }

   public static String join(Map<?, ?> map, String keyValSeparator, String tokenSeparator) {
      if (map.size() == 0) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder();
         Iterator var4 = map.entrySet().iterator();

         while(var4.hasNext()) {
            Entry<?, ?> entry = (Entry)var4.next();
            sb.append(entry.getKey()).append(keyValSeparator).append(entry.getValue().toString()).append(tokenSeparator);
         }

         return sb.toString();
      }
   }

   public static String repeat(String sequence, int repetitions) {
      return Strings.repeat(sequence, repetitions);
   }

   public static String[] remFirstArg(String[] arr) {
      return remArgs(arr, 1);
   }

   public static String[] remLastArg(String[] arr) {
      return subArray(arr, 0, arr.length - 1);
   }

   public static String[] remArgs(String[] arr, int startFromIndex) {
      if (arr.length == 0) {
         return arr;
      } else if (arr.length < startFromIndex) {
         return new String[0];
      } else {
         String[] newSplit = new String[arr.length - startFromIndex];
         System.arraycopy(arr, startFromIndex, newSplit, 0, arr.length - startFromIndex);
         return newSplit;
      }
   }

   public static String[] subArray(String[] arr, int start, int end) {
      if (arr.length == 0) {
         return arr;
      } else if (end < start) {
         return new String[0];
      } else {
         int length = end - start;
         String[] newSplit = new String[length];
         System.arraycopy(arr, start, newSplit, 0, length);
         return newSplit;
      }
   }

   public static String trimMaxLength(String str, int length) {
      if (str.length() < length) {
         return str;
      } else if (length > 3) {
         return str.substring(0, length);
      } else {
         throw new UnsupportedOperationException("Minimum length of 3 characters.");
      }
   }

   public static String maxLength(String str, int length) {
      if (str.length() < length) {
         return str;
      } else if (length > 3) {
         String var10000 = str.substring(0, length - 3);
         return var10000 + "...";
      } else {
         throw new UnsupportedOperationException("Minimum length of 3 characters.");
      }
   }

   public static boolean containsIgnoreCase(List<String> arr, String str) {
      Iterator var2 = arr.iterator();

      String s;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         s = (String)var2.next();
      } while(!s.equalsIgnoreCase(str));

      return true;
   }

   public static String remUnderscore(String str) {
      return str.replaceAll("_", " ");
   }

   public static String capitalize(String str) {
      if (str != null && !str.isEmpty()) {
         String var10000 = str.substring(0, 1).toUpperCase();
         return var10000 + str.substring(1);
      } else {
         return str;
      }
   }

   public static String capitalizeStrings(String string) {
      return (String)Stream.of(string.split("_")).map((str) -> {
         String var10000 = str.substring(0, 1).toUpperCase();
         return var10000 + str.substring(1);
      }).collect(Collectors.joining("_"));
   }

   public static boolean parseOnOff(String s) throws Exception {
      if (s.equalsIgnoreCase("on")) {
         return true;
      } else if (s.equalsIgnoreCase("off")) {
         return false;
      } else {
         throw new Exception(Translation.of("msg_err_invalid_input", "on/off."));
      }
   }

   public static boolean isAllUpperCase(@NotNull String string) {
      if (string.isEmpty()) {
         return false;
      } else {
         for(int i = 0; i < string.length(); ++i) {
            char character = string.charAt(i);
            if (Character.isLowerCase(character)) {
               return false;
            }
         }

         return true;
      }
   }

   public static boolean isAllUpperCase(@NotNull Collection<String> collection) {
      if (collection.isEmpty()) {
         return false;
      } else {
         Iterator var1 = collection.iterator();

         String string;
         do {
            if (!var1.hasNext()) {
               return true;
            }

            string = (String)var1.next();
         } while(isAllUpperCase(string));

         return false;
      }
   }

   public static List<String> addToList(List<String> list, String addition) {
      List<String> out = new ArrayList(list);
      out.add(addition);
      return out;
   }

   public static String wrap(String string, int wrapLength, String newlineString) {
      int index = 0;

      StringBuilder stringBuilder;
      for(stringBuilder = new StringBuilder(string); index + wrapLength < stringBuilder.length() && (index = stringBuilder.lastIndexOf(" ", index + wrapLength)) != -1; index += newlineString.length()) {
         stringBuilder.replace(index, index + 1, newlineString);
      }

      return stringBuilder.toString();
   }
}
