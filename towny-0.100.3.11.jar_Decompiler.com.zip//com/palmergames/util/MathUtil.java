package com.palmergames.util;

import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.Coord;
import com.palmergames.bukkit.towny.object.Translatable;

public class MathUtil {
   public static double sqr(double a) {
      return a * a;
   }

   public static double distanceSquared(double a, double b) {
      return sqr(a) + sqr(b);
   }

   public static double distance(double a, double b) {
      return Math.sqrt(distanceSquared(a, b));
   }

   public static double distance(double x1, double x2, double y1, double y2) {
      return distance(x1 - x2, y1 - y2);
   }

   public static double distance(Coord coord1, Coord coord2) {
      return distance((double)coord1.getX(), (double)coord2.getX(), (double)coord1.getZ(), (double)coord2.getZ());
   }

   public static double getDoubleOrThrow(String input) throws TownyException {
      try {
         double d = Double.parseDouble(input);
         return d;
      } catch (NumberFormatException var4) {
         throw new TownyException(Translatable.of("msg_error_must_be_num"));
      }
   }

   public static int getIntOrThrow(String input) throws TownyException {
      try {
         int i = Integer.parseInt(input);
         return i;
      } catch (NumberFormatException var3) {
         throw new TownyException(Translatable.of("msg_error_must_be_int"));
      }
   }

   public static int getPositiveIntOrThrow(String input) throws TownyException {
      int i = getIntOrThrow(input);
      if (i < 0) {
         throw new TownyException(Translatable.of("msg_err_negative"));
      } else {
         return i;
      }
   }
}
