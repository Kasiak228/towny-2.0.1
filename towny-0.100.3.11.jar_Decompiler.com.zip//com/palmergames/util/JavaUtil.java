package com.palmergames.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class JavaUtil {
   public static boolean isSubInterface(Class<?> sup, Class<?> sub) {
      if (sup.isInterface() && sub.isInterface()) {
         if (sup.equals(sub)) {
            return true;
         }

         Class[] var2 = sub.getInterfaces();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Class<?> c = var2[var4];
            if (isSubInterface(sup, c)) {
               return true;
            }
         }
      }

      return false;
   }

   public static List<String> readTextFromJar(String path) throws IOException {
      InputStream is = readResource(path);

      List var3;
      try {
         BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

         try {
            var3 = (List)reader.lines().collect(Collectors.toList());
         } catch (Throwable var7) {
            try {
               reader.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         reader.close();
      } catch (Throwable var8) {
         if (is != null) {
            try {
               is.close();
            } catch (Throwable var5) {
               var8.addSuppressed(var5);
            }
         }

         throw var8;
      }

      if (is != null) {
         is.close();
      }

      return var3;
   }

   @NotNull
   public static InputStream readResource(String resource) throws IOException {
      InputStream is = JavaUtil.class.getResourceAsStream(resource);
      return is;
   }

   public static void saveResource(String resource, Path destination, CopyOption... options) throws IOException {
      InputStream is = readResource(resource);

      try {
         Files.copy(is, destination, options);
      } catch (Throwable var7) {
         if (is != null) {
            try {
               is.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }
         }

         throw var7;
      }

      if (is != null) {
         is.close();
      }

   }

   public static boolean classExists(@NotNull String className) {
      try {
         Class.forName(className);
         return true;
      } catch (ClassNotFoundException var2) {
         return false;
      }
   }

   public static <T> T make(Supplier<T> supplier) {
      return supplier.get();
   }

   public static <T> T make(T initial, Consumer<T> initializer) {
      initializer.accept(initial);
      return initial;
   }

   @Nullable
   public static MethodHandle getMethodHandle(@NotNull String className, @NotNull String methodName) {
      try {
         return getMethodHandle(Class.forName(className), methodName);
      } catch (ClassNotFoundException var3) {
         return null;
      }
   }

   @Nullable
   public static MethodHandle getMethodHandle(@NotNull Class<?> clazz, @NotNull String methodName) {
      try {
         Method method = clazz.getDeclaredMethod(methodName);
         method.setAccessible(true);
         return MethodHandles.publicLookup().unreflect(method);
      } catch (ReflectiveOperationException var3) {
         return null;
      }
   }

   @Nullable
   public static MethodHandle getMethodHandle(@NotNull Class<?> clazz, @NotNull String methodName, Class<?>... paramTypes) {
      try {
         Method method = clazz.getDeclaredMethod(methodName, paramTypes);
         method.setAccessible(true);
         return MethodHandles.publicLookup().unreflect(method);
      } catch (ReflectiveOperationException var4) {
         return null;
      }
   }

   @Nullable
   public static MethodHandle getFieldHandle(@NotNull Class<?> clazz, @NotNull String fieldName) {
      try {
         Field field = clazz.getDeclaredField(fieldName);
         field.setAccessible(true);
         return MethodHandles.publicLookup().unreflectGetter(field);
      } catch (ReflectiveOperationException var3) {
         return null;
      }
   }
}
